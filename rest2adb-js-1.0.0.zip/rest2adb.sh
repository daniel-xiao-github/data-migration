#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# rest2adb launcher — Linux / macOS
#
# Checks for Node.js (>=18) and npm dependencies before running.
# Prompts the user for approval before installing anything.
# ─────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MIN_NODE_MAJOR=18

# ── colours (if terminal supports them) ─────────────────────
if [ -t 1 ]; then
  BOLD="\033[1m"  GREEN="\033[32m"  YELLOW="\033[33m"
  RED="\033[31m"  RESET="\033[0m"
else
  BOLD=""  GREEN=""  YELLOW=""  RED=""  RESET=""
fi

info()  { printf "${BOLD}%s${RESET}\n" "$*"; }
ok()    { printf "${GREEN}✔ %s${RESET}\n" "$*"; }
warn()  { printf "${YELLOW}! %s${RESET}\n" "$*"; }
fail()  { printf "${RED}✖ %s${RESET}\n" "$*" >&2; }

ask_yes_no() {
  local prompt="$1"
  printf "${BOLD}%s [y/N] ${RESET}" "$prompt"
  read -r answer
  case "$answer" in
    [Yy]|[Yy][Ee][Ss]) return 0 ;;
    *) return 1 ;;
  esac
}

# ── 1. Check Node.js ────────────────────────────────────────
check_node() {
  # On macOS, accept Xcode / Command Line Tools license if needed.
  # Without it, git (and thus nvm, Homebrew, etc.) refuses to run.
  if [ "$(uname -s)" = "Darwin" ]; then
    local xcl_check
    xcl_check="$(/usr/bin/git --version 2>&1 || true)"
    if echo "$xcl_check" | grep -qi "xcode.*license"; then
      warn "Xcode / Command Line Tools license has not been accepted."
      if ask_yes_no "Run 'sudo xcodebuild -license accept' now?"; then
        sudo xcodebuild -license accept
      else
        fail "Xcode license must be accepted before proceeding."
        exit 1
      fi
      echo ""
    fi
  fi

  if ! command -v node >/dev/null 2>&1; then
    fail "Node.js is not installed."
    echo ""
    info "rest2adb requires Node.js >= ${MIN_NODE_MAJOR}."
    echo ""
    echo "Install options:"
    echo "  • https://nodejs.org  (official installers)"
    echo "  • nvm:    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash"
    echo "  • brew:   brew install node           (macOS)"
    echo "  • apt:    sudo apt install nodejs npm  (Debian/Ubuntu)"
    echo "  • dnf:    sudo dnf install nodejs npm  (Fedora)"
    echo ""
    if command -v brew >/dev/null 2>&1; then
      if ask_yes_no "Install Node.js via Homebrew now?"; then
        brew install node
      else
        exit 1
      fi
    elif command -v apt >/dev/null 2>&1; then
      if ask_yes_no "Install Node.js 18 via NodeSource apt repository now?"; then
        curl -fsSL https://deb.nodesource.com/setup_${MIN_NODE_MAJOR}.x | sudo -E bash -
        sudo apt install -y nodejs
      else
        exit 1
      fi
    elif command -v dnf >/dev/null 2>&1; then
      if ask_yes_no "Install Node.js 18 via NodeSource dnf repository now?"; then
        curl -fsSL https://rpm.nodesource.com/setup_${MIN_NODE_MAJOR}.x | sudo -E bash -
        sudo dnf install -y nodejs
      else
        exit 1
      fi
    else
      if ask_yes_no "Install Node.js via nvm (node version manager) now?"; then
        export NVM_DIR="${HOME}/.nvm"
        curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash
        [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
        nvm install "${MIN_NODE_MAJOR}"
      else
        fail "Please install Node.js manually, then re-run this script."
        exit 1
      fi
    fi
    echo ""
  fi

  # Verify version
  local node_version
  node_version="$(node -v 2>/dev/null | sed 's/^v//')"
  local major="${node_version%%.*}"
  if [ -z "$major" ] || [ "$major" -lt "$MIN_NODE_MAJOR" ]; then
    fail "Node.js v${node_version} found, but >= ${MIN_NODE_MAJOR} is required."
    echo "  Please upgrade: https://nodejs.org"
    exit 1
  fi
  ok "Node.js v${node_version}"
}

# ── 2. Check / install npm dependencies ─────────────────────
check_deps() {
  if [ ! -d "${SCRIPT_DIR}/node_modules" ]; then
    warn "npm dependencies are not installed."
    echo ""
    if ask_yes_no "Run 'npm install' to install required dependencies?"; then
      info "Installing dependencies..."
      (cd "$SCRIPT_DIR" && npm install --production)
      ok "Dependencies installed."
    else
      fail "Cannot run without dependencies. Exiting."
      exit 1
    fi
    echo ""
  else
    ok "Dependencies present"
  fi
}

# ── 3. Launch ────────────────────────────────────────────────
check_node
check_deps
exec node "${SCRIPT_DIR}/src/cli.js" "$@"
