# data-migration-rest2adb-js

Automated REST API endpoint discovery and data migration to Oracle Autonomous Database (ADB) with Claude-powered OAuth 2.0 configuration generation.

## How It Works

Given a REST API base URL, this tool:

1. **Discovers endpoints** — probes for OpenAPI/Swagger specs, HATEOAS links, and common REST patterns
2. **Auto-configures OAuth 2.0** — matches known providers, queries OIDC discovery, and uses Claude AI to research auth requirements and generate a configuration UI
3. **Maps to ADB tables** — converts API response schemas to Oracle DDL with proper column types, primary/foreign keys, and migration metadata
4. **Executes migration** — extracts data with automatic pagination handling and loads into Autonomous Database

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐     ┌───────────┐
│  REST API   │────▶│  Discovery   │────▶│   Mapping    │────▶│    ADB    │
│  Base URL   │     │  Engine      │     │   Engine     │     │  Tables   │
└─────────────┘     └──────┬───────┘     └──────────────┘     └───────────┘
                           │
                    ┌──────▼───────┐
                    │ OAuth Config │
                    │ (Claude AI)  │
                    └──────────────┘
```

## Quick Start

```bash
npm install

# Discover endpoints from an API
node src/cli.js discover https://api.example.com

# Auto-configure OAuth 2.0 and generate config UI
node src/cli.js oauth https://api.example.com --html oauth-config.html

# Generate ADB table mappings and DDL
node src/cli.js map https://api.example.com --ddl schema.sql

# Full pipeline: discover + OAuth + mapping
node src/cli.js plan https://api.example.com -o ./output

# Dry-run migration
node src/cli.js migrate https://api.example.com --token YOUR_TOKEN
```

## CLI Commands

### `discover <url>`

Discover REST API endpoints from a base URL.

```bash
node src/cli.js discover https://petstore.swagger.io/v2 --format table
node src/cli.js discover https://api.github.com -o discovery.json
node src/cli.js discover https://api.example.com --token YOUR_TOKEN
```

Discovery strategies (tried in order):
1. **OpenAPI/Swagger** — probes 30+ well-known spec paths (`/openapi.json`, `/swagger.json`, etc.)
2. **HATEOAS** — follows hypermedia links from the root endpoint (HAL, JSON:API, Link headers)
3. **Heuristic probing** — tests 300+ common resource paths across API version prefixes

### `oauth <url>`

Auto-configure OAuth 2.0 Authorization Code flow.

```bash
# Generate interactive HTML configuration UI
node src/cli.js oauth https://graph.microsoft.com --html config.html

# Force Claude AI research even for known providers
node src/cli.js oauth https://api.custom-saas.com --force-claude -o oauth.json
```

The OAuth module uses a layered strategy:

| Layer | Source | Speed | Reliability |
|-------|--------|-------|-------------|
| 1 | Well-known providers (12+ built-in) | Instant | High |
| 2 | OIDC Discovery (`.well-known/openid-configuration`) | Fast | High |
| 3 | OpenAPI security schemes | Fast | Medium |
| 4 | Claude AI web research | ~10s | Medium |

**Built-in providers:** Microsoft/Azure AD, Google, GitHub, Salesforce, Okta, Auth0, Slack, HubSpot, Shopify, Stripe.

### `map <url>`

Generate Oracle ADB table mappings from discovered endpoints.

```bash
node src/cli.js map https://api.example.com --ddl schema.sql
node src/cli.js map https://api.example.com --include "users|products" -o mapping.json
```

Features:
- JSON/API types mapped to Oracle types (VARCHAR2, NUMBER, CLOB, TIMESTAMP, etc.)
- Auto-detection of primary and foreign keys
- Oracle reserved word handling
- JSON constraint generation for CLOB columns
- Migration metadata columns (source path, timestamp, raw JSON)

### `plan <url>`

Run the full pipeline and output all artifacts.

```bash
node src/cli.js plan https://api.example.com -o ./rest2adb-output
```

Generates:
- `discovery.json` — API discovery results
- `oauth-config.json` — OAuth 2.0 configuration
- `oauth-config.html` — Interactive configuration UI
- `mapping-plan.json` — Table mapping plan
- `schema.sql` — Oracle DDL statements
- `migration-config.json` — Migration configuration

### `migrate <url>`

Execute data migration (dry-run by default).

```bash
# Dry-run (read-only, no database writes)
node src/cli.js migrate https://api.example.com --token YOUR_TOKEN

# Execute for real (requires ADB connection)
node src/cli.js migrate https://api.example.com --token YOUR_TOKEN --execute
```

## Claude-Powered OAuth Research

When a REST API is not a well-known provider and OIDC discovery fails, the tool uses the Anthropic API (Claude) to research the API's authentication requirements.

Set `ANTHROPIC_API_KEY` to enable:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
node src/cli.js oauth https://api.custom-service.com --html config.html
```

Claude will identify:
- Authorization and token endpoint URLs
- Required and optional scopes
- Extra parameters (audience, tenant ID, resource, etc.)
- PKCE requirements and client auth method
- Dynamic fields the user must provide
- Implementation notes and gotchas

The generated HTML configuration UI includes all discovered fields with descriptions, validation, and export-to-JSON functionality.

## Programmatic API

```javascript
const { run, discoverApi, autoConfigureOAuth, generateMappingPlan } = require('./src');

// Full pipeline
const result = await run('https://api.example.com', {
  onProgress: (p) => console.log(`[${p.step}] ${p.message}`),
});

// Individual modules
const discovery = await discoverApi('https://api.example.com');
const oauth = await autoConfigureOAuth('https://api.example.com', discovery);
const mapping = generateMappingPlan(discovery);
```

## Testing

```bash
npm test
```

## Project Structure

```
src/
├── index.js                     # Main programmatic API
├── cli.js                       # CLI interface
├── discovery/
│   ├── index.js                 # Discovery orchestrator
│   ├── openapi-detector.js      # OpenAPI/Swagger spec detection
│   └── heuristic-prober.js      # Common endpoint probing
├── oauth/
│   ├── index.js                 # OAuth orchestrator
│   ├── well-known-providers.js  # Built-in provider configs
│   ├── oidc-discovery.js        # OIDC .well-known discovery
│   ├── claude-oauth-researcher.js  # Claude AI research
│   └── config-ui-generator.js   # HTML/JSON UI generation
├── mapping/
│   ├── index.js                 # Mapping orchestrator
│   └── schema-mapper.js         # REST-to-Oracle type mapping
├── migration/
│   └── executor.js              # Data extraction and loading
└── utils/
    ├── http.js                  # HTTP client with retry
    └── url.js                   # URL normalization
```
