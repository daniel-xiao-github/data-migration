/**
 * URL parsing and normalization utilities.
 */

function normalizeBaseUrl(url) {
  let normalized = url.trim();
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = 'https://' + normalized;
  }
  // Remove trailing slash
  normalized = normalized.replace(/\/+$/, '');
  return normalized;
}

function extractDomain(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname;
  } catch {
    return url;
  }
}

function extractBasePath(url) {
  try {
    const parsed = new URL(url);
    return parsed.pathname.replace(/\/+$/, '') || '/';
  } catch {
    return '/';
  }
}

function joinPath(base, ...segments) {
  const basePart = base.replace(/\/+$/, '');
  const rest = segments.map(s => s.replace(/^\/+|\/+$/g, '')).filter(Boolean);
  return [basePart, ...rest].join('/');
}

module.exports = { normalizeBaseUrl, extractDomain, extractBasePath, joinPath };
