/**
 * HTTP utility layer for API probing and discovery.
 * Handles retries, timeouts, and response normalization.
 */
const axios = require('axios');

const DEFAULT_TIMEOUT = 15000;
const MAX_RETRIES = 2;

function createClient(baseURL, { headers = {}, auth = null, timeout = DEFAULT_TIMEOUT } = {}) {
  const config = { baseURL, timeout, headers: { ...headers } };

  if (auth?.type === 'bearer') {
    config.headers['Authorization'] = `Bearer ${auth.token}`;
  } else if (auth?.type === 'basic') {
    config.auth = { username: auth.username, password: auth.password };
  } else if (auth?.type === 'apikey') {
    if (auth.in === 'header') {
      config.headers[auth.name] = auth.value;
    }
  }

  return axios.create(config);
}

async function probe(client, path, method = 'get', { retries = MAX_RETRIES, allowedStatuses = null } = {}) {
  let lastError;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const response = await client.request({ method, url: path });
      return {
        status: response.status,
        headers: response.headers,
        data: response.data,
        ok: true,
      };
    } catch (err) {
      lastError = err;
      if (err.response) {
        const status = err.response.status;
        if (allowedStatuses && allowedStatuses.includes(status)) {
          return {
            status,
            headers: err.response.headers,
            data: err.response.data,
            ok: false,
          };
        }
        // Don't retry client errors (except 429)
        if (status >= 400 && status < 500 && status !== 429) {
          return { status, headers: err.response.headers, data: err.response.data, ok: false };
        }
      }
      if (attempt < retries) {
        await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
      }
    }
  }
  return { status: 0, headers: {}, data: null, ok: false, error: lastError?.message };
}

async function probeMultiple(client, paths, method = 'get') {
  const results = {};
  // Run in batches of 5 to avoid overwhelming the server
  for (let i = 0; i < paths.length; i += 5) {
    const batch = paths.slice(i, i + 5);
    const batchResults = await Promise.allSettled(
      batch.map(path => probe(client, path, method, { retries: 0 }))
    );
    batch.forEach((path, idx) => {
      const result = batchResults[idx];
      results[path] = result.status === 'fulfilled' ? result.value : { status: 0, ok: false };
    });
  }
  return results;
}

module.exports = { createClient, probe, probeMultiple };
