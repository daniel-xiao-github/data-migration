/**
 * Mapping orchestrator.
 * Takes discovery results and produces a complete migration plan with table mappings.
 */
const { mapEndpointToTable, generateDDL } = require('./schema-mapper');

/**
 * Generate a complete mapping from discovered endpoints to ADB tables.
 *
 * @param {object} discoveryResult - Result from API discovery
 * @param {object} options - Mapping options
 * @returns {object} Complete mapping plan
 */
function generateMappingPlan(discoveryResult, options = {}) {
  const endpoints = discoveryResult.endpoints || [];
  const includeFilter = options.include || null; // regex or tag filter
  const excludeFilter = options.exclude || null;

  // Filter to data-bearing GET endpoints (the ones we want to migrate)
  const dataEndpoints = endpoints.filter(ep => {
    // Only GET endpoints for data extraction
    if (ep.method !== 'GET') return false;

    // Skip meta/health endpoints
    const path = ep.path.toLowerCase();
    if (/\/(health|ping|status|version|info|docs|swagger|openapi)$/i.test(path)) return false;

    // Apply include/exclude filters
    if (includeFilter && !matchesFilter(ep, includeFilter)) return false;
    if (excludeFilter && matchesFilter(ep, excludeFilter)) return false;

    return true;
  });

  // Group endpoints by resource (avoid duplicate tables for /users and /users/{id})
  const grouped = groupByResource(dataEndpoints);

  // Map each resource group to a table
  const tables = [];
  for (const [resource, eps] of Object.entries(grouped)) {
    // Prefer collection endpoints (no path params) for table structure
    const collectionEp = eps.find(e => !e.path.includes('{')) || eps[0];
    const table = mapEndpointToTable(collectionEp);

    // Record all related endpoints
    table.sourceEndpoints = eps.map(e => ({
      path: e.path,
      method: e.method,
      summary: e.summary,
      isCollection: !e.path.includes('{'),
    }));

    tables.push(table);
  }

  // Generate DDL
  const ddlStatements = generateDDL(tables);

  // Generate migration config
  const migrationConfig = generateMigrationConfig(discoveryResult, tables);

  return {
    apiInfo: discoveryResult.apiInfo || {},
    baseUrl: discoveryResult.baseUrl,
    discoveryMethod: discoveryResult.discoveryMethod,
    totalEndpoints: endpoints.length,
    dataEndpoints: dataEndpoints.length,
    tables,
    ddl: ddlStatements,
    migrationConfig,
  };
}

function groupByResource(endpoints) {
  const groups = {};

  for (const ep of endpoints) {
    // Normalize path to get resource base
    const resourceBase = ep.path
      .replace(/\/\{[^}]+\}/g, '')  // Remove path parameters
      .replace(/\/+$/, '');          // Remove trailing slash

    if (!groups[resourceBase]) {
      groups[resourceBase] = [];
    }
    groups[resourceBase].push(ep);
  }

  return groups;
}

function matchesFilter(endpoint, filter) {
  if (typeof filter === 'string') {
    const regex = new RegExp(filter, 'i');
    return regex.test(endpoint.path) ||
      (endpoint.tags || []).some(t => regex.test(t)) ||
      regex.test(endpoint.summary || '');
  }
  if (filter instanceof RegExp) {
    return filter.test(endpoint.path);
  }
  return false;
}

function generateMigrationConfig(discoveryResult, tables) {
  return {
    source: {
      type: 'rest_api',
      baseUrl: discoveryResult.baseUrl,
      auth: {
        type: 'oauth2',
        note: 'Configure via the OAuth configuration UI',
      },
      pagination: {
        strategy: 'auto-detect',
        supportedStrategies: ['offset-limit', 'cursor', 'page-number', 'link-header'],
      },
      rateLimit: {
        requestsPerSecond: 5,
        retryAfterHeader: true,
      },
    },
    target: {
      type: 'oracle_autonomous_database',
      connection: {
        walletPath: '${WALLET_PATH}',
        tnsName: '${TNS_NAME}',
        username: '${DB_USERNAME}',
        password: '${DB_PASSWORD}',
      },
      schema: '${DB_SCHEMA}',
      batchSize: 1000,
      commitInterval: 5000,
    },
    tables: tables.map(t => ({
      tableName: t.tableName,
      sourceEndpoint: t.endpoint.path,
      primaryKey: t.primaryKey,
      columnCount: t.columns.length,
      strategy: 'full-refresh', // or 'incremental'
    })),
    schedule: {
      type: 'manual',
      note: 'Configure cron or event triggers as needed',
    },
  };
}

module.exports = { generateMappingPlan };
