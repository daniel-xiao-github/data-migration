/**
 * REST API response schema to ADB (Autonomous Database) table schema mapper.
 *
 * Maps discovered API endpoint response structures to relational table definitions
 * suitable for Oracle Autonomous Database.
 */

// JSON/API type to Oracle SQL type mapping
const TYPE_MAP = {
  string: 'VARCHAR2(4000)',
  text: 'CLOB',
  integer: 'NUMBER(38)',
  int: 'NUMBER(38)',
  number: 'NUMBER',
  float: 'NUMBER',
  double: 'BINARY_DOUBLE',
  boolean: 'NUMBER(1)',
  date: 'DATE',
  'date-time': 'TIMESTAMP WITH TIME ZONE',
  datetime: 'TIMESTAMP WITH TIME ZONE',
  timestamp: 'TIMESTAMP WITH TIME ZONE',
  email: 'VARCHAR2(320)',
  uri: 'VARCHAR2(2000)',
  url: 'VARCHAR2(2000)',
  uuid: 'VARCHAR2(36)',
  binary: 'BLOB',
  object: 'CLOB', // Store nested objects as JSON in CLOB
  array: 'CLOB',  // Store arrays as JSON in CLOB
  unknown: 'VARCHAR2(4000)',
};

// Fields that typically serve as primary keys
const PK_PATTERNS = ['id', 'uuid', 'guid', '_id', 'pk'];

// Fields that are typically foreign keys
const FK_PATTERNS = [
  /^(.+)_id$/,
  /^(.+)Id$/,
  /^(.+)_uuid$/,
  /^fk_(.+)$/,
];

/**
 * Map a discovered endpoint to an ADB table definition.
 */
function mapEndpointToTable(endpoint) {
  const tableName = generateTableName(endpoint);
  const columns = [];
  const primaryKey = null;
  const foreignKeys = [];

  // Extract fields from endpoint response schema
  const fields = extractFieldsFromEndpoint(endpoint);

  for (const field of fields) {
    const column = mapFieldToColumn(field);
    columns.push(column);

    if (column.isPrimaryKey) {
      // primaryKey is the first PK candidate
    }
  }

  // Ensure there's at least a surrogate primary key
  const hasPk = columns.some(c => c.isPrimaryKey);
  if (!hasPk) {
    columns.unshift({
      name: 'MIGRATION_ID',
      type: 'NUMBER',
      nullable: false,
      isPrimaryKey: true,
      isForeignKey: false,
      description: 'Auto-generated surrogate key for migration',
      sourceField: null,
    });
  }

  // Add migration metadata columns
  columns.push(
    {
      name: 'SOURCE_API_PATH',
      type: 'VARCHAR2(2000)',
      nullable: true,
      isPrimaryKey: false,
      isForeignKey: false,
      description: 'The API endpoint this record was fetched from',
      sourceField: null,
    },
    {
      name: 'MIGRATED_AT',
      type: 'TIMESTAMP WITH TIME ZONE',
      nullable: false,
      isPrimaryKey: false,
      isForeignKey: false,
      description: 'Timestamp when this record was migrated',
      sourceField: null,
      defaultValue: 'SYSTIMESTAMP',
    },
    {
      name: 'RAW_JSON',
      type: 'CLOB',
      nullable: true,
      isPrimaryKey: false,
      isForeignKey: false,
      description: 'Original JSON response for reference',
      sourceField: null,
      isJson: true,
    }
  );

  return {
    tableName,
    endpoint: {
      path: endpoint.path,
      method: endpoint.method,
      summary: endpoint.summary,
    },
    columns,
    primaryKey: columns.find(c => c.isPrimaryKey)?.name || 'MIGRATION_ID',
    foreignKeys: columns.filter(c => c.isForeignKey).map(c => ({
      column: c.name,
      referencedTable: c.fkReference?.table || null,
      referencedColumn: c.fkReference?.column || 'ID',
    })),
  };
}

function generateTableName(endpoint) {
  let name = endpoint.summary || endpoint.operationId || endpoint.path;
  name = name
    .replace(/^\/+/, '')
    .replace(/[\/\-\.]/g, '_')
    .replace(/[^a-zA-Z0-9_]/g, '')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '')
    .toUpperCase();

  // Remove version prefixes
  name = name.replace(/^(API_)?(V\d+_)?/, '');

  // Limit to Oracle's identifier length
  if (name.length > 128) {
    name = name.substring(0, 128);
  }

  return name || 'UNNAMED_TABLE';
}

function extractFieldsFromEndpoint(endpoint) {
  const fields = [];

  // From response schema
  if (endpoint.responses) {
    for (const [, response] of Object.entries(endpoint.responses)) {
      if (response.schema) {
        const schema = response.schema;
        if (schema.type === 'array' && schema.items?.fields) {
          for (const [name, info] of Object.entries(schema.items.fields)) {
            fields.push({ name, ...info });
          }
        } else if (schema.type === 'object' && schema.fields) {
          for (const [name, info] of Object.entries(schema.fields)) {
            fields.push({ name, ...info });
          }
        }
      }
    }
  }

  // From _meta sample fields (heuristic discovery)
  if (endpoint._meta?.sampleFields) {
    const existingNames = new Set(fields.map(f => f.name));
    for (const name of endpoint._meta.sampleFields) {
      if (!existingNames.has(name)) {
        fields.push({ name, type: 'unknown', format: null, description: null, required: false });
      }
    }
  }

  return fields;
}

function mapFieldToColumn(field) {
  const columnName = fieldNameToColumnName(field.name);
  const sqlType = resolveOracleType(field);
  const isPk = isPrimaryKeyCandidate(field.name);
  const fkMatch = isForeignKeyCandidate(field.name);

  return {
    name: columnName,
    type: sqlType,
    nullable: !field.required && !isPk,
    isPrimaryKey: isPk,
    isForeignKey: !!fkMatch,
    fkReference: fkMatch ? { table: fkMatch.toUpperCase(), column: 'ID' } : null,
    description: field.description || null,
    sourceField: field.name,
  };
}

function fieldNameToColumnName(name) {
  // Convert camelCase/snake_case to UPPER_SNAKE_CASE
  let col = name
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .replace(/[.\-\s]/g, '_')
    .replace(/[^a-zA-Z0-9_]/g, '')
    .toUpperCase();

  // Oracle reserved words — prefix if necessary
  const reserved = new Set(['ID', 'DATE', 'ORDER', 'GROUP', 'USER', 'TABLE', 'INDEX', 'TYPE', 'STATUS', 'NAME', 'VALUE', 'KEY', 'LEVEL', 'NUMBER', 'SIZE', 'COMMENT']);
  if (reserved.has(col)) {
    col = `${col}_VAL`;
  }

  return col || 'UNKNOWN_FIELD';
}

function resolveOracleType(field) {
  // Check format first (more specific)
  if (field.format && TYPE_MAP[field.format]) {
    return TYPE_MAP[field.format];
  }

  // Infer from field name patterns
  const nameLower = (field.name || '').toLowerCase();
  if (nameLower.includes('email')) return TYPE_MAP.email;
  if (nameLower.includes('url') || nameLower.includes('uri') || nameLower.includes('href')) return TYPE_MAP.uri;
  if (nameLower.includes('uuid') || nameLower.includes('guid')) return TYPE_MAP.uuid;
  if (nameLower.endsWith('_at') || nameLower.endsWith('_date') || nameLower === 'created' || nameLower === 'updated') return TYPE_MAP.datetime;
  if (nameLower === 'description' || nameLower === 'body' || nameLower === 'content') return TYPE_MAP.text;

  // Fall back to type
  return TYPE_MAP[field.type] || TYPE_MAP.unknown;
}

function isPrimaryKeyCandidate(fieldName) {
  const lower = fieldName.toLowerCase();
  return PK_PATTERNS.some(p => lower === p);
}

function isForeignKeyCandidate(fieldName) {
  for (const pattern of FK_PATTERNS) {
    const match = fieldName.match(pattern);
    if (match) {
      return match[1]; // The referenced entity name
    }
  }
  return null;
}

/**
 * Generate DDL (CREATE TABLE) for all mapped tables.
 */
function generateDDL(tables) {
  const statements = [];

  for (const table of tables) {
    const colDefs = table.columns.map(col => {
      let def = `  ${col.name} ${col.type}`;
      if (col.defaultValue) def += ` DEFAULT ${col.defaultValue}`;
      if (!col.nullable) def += ' NOT NULL';
      return def;
    });

    // Add primary key constraint
    colDefs.push(`  CONSTRAINT ${table.tableName}_PK PRIMARY KEY (${table.primaryKey})`);

    const ddl = `CREATE TABLE ${table.tableName} (\n${colDefs.join(',\n')}\n)`;
    statements.push(ddl);

    // Add JSON check constraint for CLOB columns storing JSON
    const jsonCols = table.columns.filter(c => c.isJson);
    for (const col of jsonCols) {
      statements.push(
        `ALTER TABLE ${table.tableName} ADD CONSTRAINT ${table.tableName}_${col.name}_JSON CHECK (${col.name} IS JSON)`
      );
    }
  }

  return statements;
}

module.exports = { mapEndpointToTable, generateDDL, generateTableName, fieldNameToColumnName, resolveOracleType };
