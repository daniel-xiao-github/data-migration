/**
 * OpenAPI / Swagger specification detector.
 * Probes well-known paths for API specification documents.
 */
const { probe, probeMultiple } = require('../utils/http');

// Well-known paths where OpenAPI/Swagger specs are typically served
const SPEC_PATHS = [
  // OpenAPI 3.x
  '/openapi.json',
  '/openapi.yaml',
  '/api/openapi.json',
  '/api/openapi.yaml',
  '/v1/openapi.json',
  '/v2/openapi.json',
  '/v3/openapi.json',
  '/api/v1/openapi.json',
  '/api/v2/openapi.json',
  '/api/v3/openapi.json',
  '/docs/openapi.json',
  '/api-docs/openapi.json',
  // Swagger 2.x
  '/swagger.json',
  '/swagger.yaml',
  '/api/swagger.json',
  '/api/swagger.yaml',
  '/v1/swagger.json',
  '/v2/swagger.json',
  '/api/v1/swagger.json',
  '/api/v2/swagger.json',
  '/api-docs',
  '/api-docs.json',
  // Common documentation endpoints
  '/docs',
  '/api/docs',
  '/swagger-ui',
  '/swagger-ui.html',
  '/redoc',
  '/api/schema',
  '/api/schema/',
  '/.well-known/openapi.json',
  '/.well-known/schema-discovery',
];

function isOpenApiSpec(data) {
  if (!data || typeof data !== 'object') return false;
  return !!(data.openapi || data.swagger || data.paths);
}

function detectSpecVersion(data) {
  if (data.openapi) {
    return { format: 'openapi', version: data.openapi };
  }
  if (data.swagger) {
    return { format: 'swagger', version: data.swagger };
  }
  return null;
}

async function detectOpenApiSpec(client) {
  const results = await probeMultiple(client, SPEC_PATHS);
  const found = [];

  for (const [path, result] of Object.entries(results)) {
    if (result.ok && result.data) {
      let data = result.data;
      // Handle string responses (YAML or JSON string)
      if (typeof data === 'string') {
        try {
          data = JSON.parse(data);
        } catch {
          // Might be YAML — caller can parse
          found.push({ path, format: 'yaml', raw: data });
          continue;
        }
      }
      if (isOpenApiSpec(data)) {
        const version = detectSpecVersion(data);
        found.push({ path, ...version, spec: data });
      }
    }
  }

  return found;
}

function extractEndpointsFromSpec(spec) {
  const endpoints = [];
  const paths = spec.paths || {};

  for (const [path, methods] of Object.entries(paths)) {
    for (const [method, operation] of Object.entries(methods)) {
      if (['get', 'post', 'put', 'patch', 'delete', 'head', 'options'].includes(method)) {
        const endpoint = {
          path,
          method: method.toUpperCase(),
          operationId: operation.operationId || null,
          summary: operation.summary || null,
          description: operation.description || null,
          tags: operation.tags || [],
          parameters: (operation.parameters || []).map(p => ({
            name: p.name,
            in: p.in,
            required: p.required || false,
            type: p.schema?.type || p.type || 'string',
            description: p.description || null,
          })),
          requestBody: extractRequestBody(operation.requestBody),
          responses: extractResponses(operation.responses),
          security: operation.security || null,
        };
        endpoints.push(endpoint);
      }
    }
  }

  return endpoints;
}

function extractRequestBody(requestBody) {
  if (!requestBody) return null;
  const content = requestBody.content || {};
  const result = { required: requestBody.required || false, contentTypes: {} };
  for (const [contentType, media] of Object.entries(content)) {
    result.contentTypes[contentType] = extractSchemaShape(media.schema);
  }
  return result;
}

function extractResponses(responses) {
  if (!responses) return {};
  const result = {};
  for (const [statusCode, response] of Object.entries(responses)) {
    result[statusCode] = {
      description: response.description || null,
      schema: null,
    };
    if (response.content) {
      for (const [, media] of Object.entries(response.content)) {
        result[statusCode].schema = extractSchemaShape(media.schema);
        break; // Take first content type
      }
    } else if (response.schema) {
      // Swagger 2.x
      result[statusCode].schema = extractSchemaShape(response.schema);
    }
  }
  return result;
}

function extractSchemaShape(schema, depth = 0) {
  if (!schema || depth > 5) return null;
  if (schema.$ref) {
    return { $ref: schema.$ref };
  }
  if (schema.type === 'object' || schema.properties) {
    const fields = {};
    for (const [name, prop] of Object.entries(schema.properties || {})) {
      fields[name] = {
        type: prop.type || 'unknown',
        format: prop.format || null,
        description: prop.description || null,
        required: (schema.required || []).includes(name),
      };
    }
    return { type: 'object', fields };
  }
  if (schema.type === 'array' && schema.items) {
    return { type: 'array', items: extractSchemaShape(schema.items, depth + 1) };
  }
  return { type: schema.type || 'unknown', format: schema.format || null };
}

function extractSecuritySchemes(spec) {
  // OpenAPI 3.x
  if (spec.components?.securitySchemes) {
    return spec.components.securitySchemes;
  }
  // Swagger 2.x
  if (spec.securityDefinitions) {
    return spec.securityDefinitions;
  }
  return {};
}

function extractServerInfo(spec) {
  // OpenAPI 3.x
  if (spec.servers) {
    return spec.servers.map(s => ({ url: s.url, description: s.description || null }));
  }
  // Swagger 2.x
  if (spec.host) {
    const scheme = (spec.schemes || ['https'])[0];
    const basePath = spec.basePath || '/';
    return [{ url: `${scheme}://${spec.host}${basePath}`, description: null }];
  }
  return [];
}

module.exports = {
  detectOpenApiSpec,
  extractEndpointsFromSpec,
  extractSecuritySchemes,
  extractServerInfo,
  SPEC_PATHS,
};
