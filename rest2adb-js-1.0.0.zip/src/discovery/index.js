/**
 * Main discovery orchestrator.
 * Combines OpenAPI detection, HATEOAS traversal, and heuristic probing
 * to build a comprehensive endpoint map.
 */
const { createClient } = require('../utils/http');
const { normalizeBaseUrl } = require('../utils/url');
const { detectOpenApiSpec, extractEndpointsFromSpec, extractSecuritySchemes, extractServerInfo } = require('./openapi-detector');
const { probeEndpoints, discoverFromHateoas } = require('./heuristic-prober');

/**
 * Discover all endpoints from a REST API base URL.
 *
 * Strategy:
 * 1. Try to find an OpenAPI/Swagger spec (most reliable)
 * 2. Try HATEOAS discovery from the root endpoint
 * 3. Fall back to heuristic probing of common patterns
 *
 * @param {string} baseUrl - The API base URL
 * @param {object} options - Configuration options
 * @returns {object} Discovery result with endpoints, auth info, and metadata
 */
async function discoverApi(baseUrl, options = {}) {
  const url = normalizeBaseUrl(baseUrl);
  const client = createClient(url, {
    headers: options.headers || {},
    auth: options.auth || null,
    timeout: options.timeout || 15000,
  });

  const result = {
    baseUrl: url,
    discoveryMethod: null,
    specVersion: null,
    apiInfo: {},
    endpoints: [],
    securitySchemes: {},
    servers: [],
    hateoasLinks: [],
    heuristicResults: null,
    warnings: [],
  };

  const onProgress = options.onProgress || (() => {});

  // --- Phase 1: OpenAPI/Swagger spec detection ---
  onProgress({ phase: 'openapi', message: 'Searching for OpenAPI/Swagger specification...' });
  const specs = await detectOpenApiSpec(client);

  if (specs.length > 0) {
    const best = specs.find(s => s.spec) || specs[0];
    if (best.spec) {
      result.discoveryMethod = 'openapi';
      result.specVersion = `${best.format} ${best.version}`;
      result.apiInfo = {
        title: best.spec.info?.title || null,
        description: best.spec.info?.description || null,
        version: best.spec.info?.version || null,
        specPath: best.path,
      };
      result.endpoints = extractEndpointsFromSpec(best.spec);
      result.securitySchemes = extractSecuritySchemes(best.spec);
      result.servers = extractServerInfo(best.spec);

      onProgress({
        phase: 'openapi',
        message: `Found ${best.format} ${best.version} spec at ${best.path}`,
        endpointCount: result.endpoints.length,
      });

      return result;
    }
  }

  // --- Phase 2: HATEOAS discovery ---
  onProgress({ phase: 'hateoas', message: 'Trying HATEOAS discovery from root...' });
  const hateoasLinks = await discoverFromHateoas(client);

  if (hateoasLinks.length > 0) {
    result.hateoasLinks = hateoasLinks;
    result.discoveryMethod = 'hateoas';

    // Convert HATEOAS links to endpoint format
    for (const link of hateoasLinks) {
      result.endpoints.push({
        path: link.href,
        method: link.method,
        operationId: null,
        summary: link.rel,
        description: `Discovered via HATEOAS (rel: ${link.rel})`,
        tags: ['hateoas'],
        parameters: [],
        requestBody: null,
        responses: {},
        security: null,
      });
    }

    if (hateoasLinks.length >= 3) {
      onProgress({
        phase: 'hateoas',
        message: `Discovered ${hateoasLinks.length} links via HATEOAS`,
      });
      return result;
    }
  }

  // --- Phase 3: Heuristic probing ---
  onProgress({ phase: 'heuristic', message: 'Probing common endpoint patterns...' });
  const heuristic = await probeEndpoints(client, {
    onProgress: (p) => {
      onProgress({
        phase: 'heuristic',
        message: `Probed ${p.probed}/${p.total} paths (found: ${p.discovered}, auth-required: ${p.authRequired})`,
        ...p,
      });
    },
  });

  result.heuristicResults = heuristic;
  result.discoveryMethod = result.hateoasLinks.length > 0 ? 'hateoas+heuristic' : 'heuristic';

  // Convert heuristic discoveries to endpoint format
  for (const ep of heuristic.discovered) {
    result.endpoints.push({
      path: ep.path,
      method: 'GET',
      operationId: null,
      summary: ep.resourceName,
      description: `Discovered via heuristic probing`,
      tags: ['discovered'],
      parameters: [],
      requestBody: null,
      responses: {
        [ep.status]: {
          description: 'Successful response',
          schema: ep.isCollection
            ? { type: 'array', items: { type: 'object', fields: fieldsFromSample(ep.sampleFields) } }
            : { type: 'object', fields: fieldsFromSample(ep.sampleFields) },
        },
      },
      security: null,
      _meta: {
        isCollection: ep.isCollection,
        isSingleton: ep.isSingleton,
        sampleFields: ep.sampleFields,
      },
    });
  }

  // Record auth-required endpoints as warnings
  for (const ep of heuristic.authRequired) {
    result.warnings.push(`Endpoint ${ep.path} requires authentication (HTTP ${ep.status})`);
    result.endpoints.push({
      path: ep.path,
      method: 'GET',
      operationId: null,
      summary: ep.resourceName,
      description: `Requires authentication (HTTP ${ep.status})`,
      tags: ['auth-required'],
      parameters: [],
      requestBody: null,
      responses: {},
      security: [{ type: 'unknown' }],
    });
  }

  onProgress({
    phase: 'complete',
    message: `Discovery complete. Found ${result.endpoints.length} endpoints.`,
    endpointCount: result.endpoints.length,
  });

  return result;
}

function fieldsFromSample(fieldNames) {
  const fields = {};
  for (const name of fieldNames) {
    fields[name] = { type: 'unknown', format: null, description: null, required: false };
  }
  return fields;
}

module.exports = { discoverApi };
