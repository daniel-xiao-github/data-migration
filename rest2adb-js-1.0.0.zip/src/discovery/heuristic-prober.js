/**
 * Heuristic endpoint prober.
 * When no OpenAPI spec is found, probes common REST patterns to discover endpoints.
 */
const { probe, probeMultiple } = require('../utils/http');

// Common REST resource names to probe
const COMMON_RESOURCES = [
  'users', 'accounts', 'customers', 'profiles', 'people', 'members',
  'products', 'items', 'goods', 'catalog', 'inventory',
  'orders', 'transactions', 'invoices', 'payments', 'subscriptions',
  'posts', 'articles', 'blogs', 'comments', 'reviews', 'content',
  'categories', 'tags', 'labels', 'groups', 'teams',
  'projects', 'tasks', 'issues', 'tickets', 'events',
  'files', 'documents', 'images', 'media', 'attachments',
  'messages', 'notifications', 'emails', 'chats',
  'settings', 'preferences', 'config', 'configuration',
  'roles', 'permissions', 'organizations', 'workspaces',
  'reports', 'analytics', 'stats', 'metrics', 'dashboards',
  'contacts', 'leads', 'deals', 'pipelines', 'campaigns',
];

// Common API version prefixes
const VERSION_PREFIXES = ['', '/api', '/api/v1', '/api/v2', '/api/v3', '/v1', '/v2', '/v3'];

// Common meta / utility endpoints
const META_ENDPOINTS = [
  '/health', '/healthz', '/status', '/ping', '/version', '/info',
  '/api', '/api/info', '/api/version',
  '/me', '/api/me', '/whoami',
];

function generateProbePaths(resources = COMMON_RESOURCES, prefixes = VERSION_PREFIXES) {
  const paths = new Set();
  for (const prefix of prefixes) {
    for (const resource of resources) {
      paths.add(`${prefix}/${resource}`);
    }
  }
  // Add meta endpoints
  for (const ep of META_ENDPOINTS) {
    paths.add(ep);
  }
  return [...paths];
}

function classifyResponse(path, result) {
  if (!result.ok && result.status === 0) return null;

  const classification = {
    path,
    status: result.status,
    accessible: result.ok,
    requiresAuth: result.status === 401 || result.status === 403,
    contentType: result.headers?.['content-type'] || '',
    isJson: false,
    isCollection: false,
    isSingleton: false,
    resourceName: extractResourceName(path),
    sampleFields: [],
  };

  if (result.data && typeof result.data === 'object') {
    classification.isJson = true;

    if (Array.isArray(result.data)) {
      classification.isCollection = true;
      if (result.data.length > 0) {
        classification.sampleFields = Object.keys(result.data[0]).slice(0, 20);
      }
    } else if (result.data.data && Array.isArray(result.data.data)) {
      // Wrapped collection pattern: { data: [...], meta: {...} }
      classification.isCollection = true;
      if (result.data.data.length > 0) {
        classification.sampleFields = Object.keys(result.data.data[0]).slice(0, 20);
      }
    } else if (result.data.results && Array.isArray(result.data.results)) {
      // DRF-style pagination: { results: [...], count: N }
      classification.isCollection = true;
      if (result.data.results.length > 0) {
        classification.sampleFields = Object.keys(result.data.results[0]).slice(0, 20);
      }
    } else if (result.data.items && Array.isArray(result.data.items)) {
      classification.isCollection = true;
      if (result.data.items.length > 0) {
        classification.sampleFields = Object.keys(result.data.items[0]).slice(0, 20);
      }
    } else {
      classification.isSingleton = true;
      classification.sampleFields = Object.keys(result.data).slice(0, 20);
    }
  }

  return classification;
}

function extractResourceName(path) {
  const segments = path.split('/').filter(Boolean);
  // Skip version/api prefixes
  const meaningful = segments.filter(s => !s.match(/^(api|v\d+)$/i));
  return meaningful[meaningful.length - 1] || null;
}

async function probeEndpoints(client, { resources, prefixes, onProgress } = {}) {
  const paths = generateProbePaths(
    resources || COMMON_RESOURCES,
    prefixes || VERSION_PREFIXES
  );

  const discovered = [];
  const authRequired = [];

  // Probe in batches
  const batchSize = 10;
  for (let i = 0; i < paths.length; i += batchSize) {
    const batch = paths.slice(i, i + batchSize);
    const results = await probeMultiple(client, batch);

    for (const [path, result] of Object.entries(results)) {
      const classified = classifyResponse(path, result);
      if (!classified) continue;

      if (classified.accessible) {
        discovered.push(classified);
      } else if (classified.requiresAuth) {
        authRequired.push(classified);
      }
    }

    if (onProgress) {
      onProgress({
        probed: Math.min(i + batchSize, paths.length),
        total: paths.length,
        discovered: discovered.length,
        authRequired: authRequired.length,
      });
    }
  }

  return { discovered, authRequired };
}

async function discoverFromHateoas(client, entryPoint = '/') {
  const result = await probe(client, entryPoint, 'get', { allowedStatuses: [401, 403] });
  if (!result.ok || !result.data) return [];

  const links = [];

  // Look for _links (HAL format)
  if (result.data._links) {
    for (const [rel, link] of Object.entries(result.data._links)) {
      if (link.href) {
        links.push({ rel, href: link.href, method: link.method || 'GET' });
      }
    }
  }

  // Look for links array (JSON:API / general)
  if (Array.isArray(result.data.links)) {
    for (const link of result.data.links) {
      if (link.href || link.url) {
        links.push({ rel: link.rel || link.name, href: link.href || link.url, method: link.method || 'GET' });
      }
    }
  }

  // Look for Link header
  const linkHeader = result.headers?.['link'];
  if (linkHeader) {
    const parsed = parseLinkHeader(linkHeader);
    links.push(...parsed);
  }

  return links;
}

function parseLinkHeader(header) {
  const links = [];
  const parts = header.split(',');
  for (const part of parts) {
    const match = part.match(/<([^>]+)>;\s*rel="([^"]+)"/);
    if (match) {
      links.push({ href: match[1], rel: match[2], method: 'GET' });
    }
  }
  return links;
}

module.exports = {
  probeEndpoints,
  discoverFromHateoas,
  classifyResponse,
  generateProbePaths,
  COMMON_RESOURCES,
  VERSION_PREFIXES,
  META_ENDPOINTS,
};
