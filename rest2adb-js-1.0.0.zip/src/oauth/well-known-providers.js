/**
 * Well-known OAuth 2.0 provider configurations.
 * Serves as a fast-path before falling back to Claude-powered web research.
 */

const PROVIDERS = {
  // Microsoft / Azure
  'login.microsoftonline.com': {
    name: 'Microsoft Identity Platform (Azure AD)',
    authorizationUrl: 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token',
    revokeUrl: 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/logout',
    discoveryUrl: 'https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration',
    scopes: ['openid', 'profile', 'email', 'offline_access'],
    extraParams: {
      authorize: { prompt: 'consent', response_mode: 'query' },
      token: {},
    },
    placeholders: { tenant: 'Your Azure AD tenant ID or "common"' },
    docs: 'https://learn.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-auth-code-flow',
  },

  'graph.microsoft.com': {
    name: 'Microsoft Graph API',
    authorizationUrl: 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token',
    discoveryUrl: 'https://login.microsoftonline.com/{tenant}/v2.0/.well-known/openid-configuration',
    scopes: ['https://graph.microsoft.com/.default', 'offline_access'],
    extraParams: {
      authorize: { prompt: 'consent' },
      token: {},
    },
    placeholders: { tenant: 'Your Azure AD tenant ID or "common"' },
    docs: 'https://learn.microsoft.com/en-us/graph/auth-v2-user',
  },

  // Google
  'accounts.google.com': {
    name: 'Google OAuth 2.0',
    authorizationUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    revokeUrl: 'https://oauth2.googleapis.com/revoke',
    discoveryUrl: 'https://accounts.google.com/.well-known/openid-configuration',
    scopes: ['openid', 'profile', 'email'],
    extraParams: {
      authorize: { access_type: 'offline', include_granted_scopes: 'true' },
      token: {},
    },
    placeholders: {},
    docs: 'https://developers.google.com/identity/protocols/oauth2/web-server',
  },

  'googleapis.com': {
    name: 'Google APIs',
    authorizationUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    revokeUrl: 'https://oauth2.googleapis.com/revoke',
    discoveryUrl: 'https://accounts.google.com/.well-known/openid-configuration',
    scopes: [],
    extraParams: {
      authorize: { access_type: 'offline', include_granted_scopes: 'true' },
      token: {},
    },
    placeholders: {},
    docs: 'https://developers.google.com/identity/protocols/oauth2',
    note: 'Scopes depend on the specific Google API being accessed. Check https://developers.google.com/identity/protocols/oauth2/scopes',
  },

  // GitHub
  'api.github.com': {
    name: 'GitHub OAuth',
    authorizationUrl: 'https://github.com/login/oauth/authorize',
    tokenUrl: 'https://github.com/login/oauth/access_token',
    scopes: ['repo', 'read:user', 'user:email'],
    extraParams: {
      authorize: { allow_signup: 'true' },
      token: {},
    },
    placeholders: {},
    docs: 'https://docs.github.com/en/developers/apps/building-oauth-apps/authorizing-oauth-apps',
  },

  // Salesforce
  'login.salesforce.com': {
    name: 'Salesforce OAuth 2.0',
    authorizationUrl: 'https://login.salesforce.com/services/oauth2/authorize',
    tokenUrl: 'https://login.salesforce.com/services/oauth2/token',
    revokeUrl: 'https://login.salesforce.com/services/oauth2/revoke',
    discoveryUrl: 'https://login.salesforce.com/.well-known/openid-configuration',
    scopes: ['api', 'refresh_token', 'full'],
    extraParams: {
      authorize: { display: 'page' },
      token: {},
    },
    placeholders: {},
    docs: 'https://help.salesforce.com/s/articleView?id=sf.remoteaccess_oauth_web_server_flow.htm',
  },

  // Okta
  'okta.com': {
    name: 'Okta OAuth 2.0',
    authorizationUrl: 'https://{domain}/oauth2/v1/authorize',
    tokenUrl: 'https://{domain}/oauth2/v1/token',
    revokeUrl: 'https://{domain}/oauth2/v1/revoke',
    discoveryUrl: 'https://{domain}/.well-known/openid-configuration',
    scopes: ['openid', 'profile', 'email', 'offline_access'],
    extraParams: {
      authorize: { response_mode: 'query', state: '{random}' },
      token: {},
    },
    placeholders: { domain: 'Your Okta domain (e.g., dev-123456.okta.com)' },
    docs: 'https://developer.okta.com/docs/guides/implement-grant-type/authcode/main/',
  },

  // Auth0
  'auth0.com': {
    name: 'Auth0 OAuth 2.0',
    authorizationUrl: 'https://{domain}/authorize',
    tokenUrl: 'https://{domain}/oauth/token',
    revokeUrl: 'https://{domain}/oauth/revoke',
    discoveryUrl: 'https://{domain}/.well-known/openid-configuration',
    scopes: ['openid', 'profile', 'email', 'offline_access'],
    extraParams: {
      authorize: { audience: '{api_identifier}' },
      token: {},
    },
    placeholders: { domain: 'Your Auth0 domain (e.g., myapp.auth0.com)', api_identifier: 'Your Auth0 API identifier' },
    docs: 'https://auth0.com/docs/get-started/authentication-and-authorization-flow/authorization-code-flow',
  },

  // Slack
  'slack.com': {
    name: 'Slack OAuth 2.0',
    authorizationUrl: 'https://slack.com/oauth/v2/authorize',
    tokenUrl: 'https://slack.com/api/oauth.v2.access',
    scopes: ['channels:read', 'chat:write', 'users:read'],
    extraParams: {
      authorize: { user_scope: '' },
      token: {},
    },
    placeholders: {},
    docs: 'https://api.slack.com/authentication/oauth-v2',
  },

  // HubSpot
  'api.hubapi.com': {
    name: 'HubSpot OAuth 2.0',
    authorizationUrl: 'https://app.hubspot.com/oauth/authorize',
    tokenUrl: 'https://api.hubapi.com/oauth/v1/token',
    scopes: ['crm.objects.contacts.read', 'crm.objects.deals.read'],
    extraParams: {
      authorize: { optional_scope: '' },
      token: {},
    },
    placeholders: {},
    docs: 'https://developers.hubspot.com/docs/api/oauth-quickstart-guide',
  },

  // Shopify
  'myshopify.com': {
    name: 'Shopify OAuth 2.0',
    authorizationUrl: 'https://{shop}.myshopify.com/admin/oauth/authorize',
    tokenUrl: 'https://{shop}.myshopify.com/admin/oauth/access_token',
    scopes: ['read_products', 'read_orders', 'read_customers'],
    extraParams: {
      authorize: { grant_options: '' },
      token: {},
    },
    placeholders: { shop: 'Your Shopify store name' },
    docs: 'https://shopify.dev/docs/apps/auth/oauth',
  },

  // Stripe
  'api.stripe.com': {
    name: 'Stripe Connect OAuth',
    authorizationUrl: 'https://connect.stripe.com/oauth/authorize',
    tokenUrl: 'https://connect.stripe.com/oauth/token',
    revokeUrl: 'https://connect.stripe.com/oauth/deauthorize',
    scopes: ['read_write'],
    extraParams: {
      authorize: { response_type: 'code', stripe_landing: 'login' },
      token: { grant_type: 'authorization_code' },
    },
    placeholders: {},
    docs: 'https://stripe.com/docs/connect/oauth-reference',
  },
};

/**
 * Try to match a URL to a known OAuth provider.
 */
function matchProvider(url) {
  const hostname = extractHostname(url);
  if (!hostname) return null;

  // Exact match
  if (PROVIDERS[hostname]) {
    return { ...PROVIDERS[hostname], matchedOn: hostname };
  }

  // Suffix match (e.g., "dev-123.okta.com" matches "okta.com")
  for (const [domain, config] of Object.entries(PROVIDERS)) {
    if (hostname.endsWith(`.${domain}`) || hostname.endsWith(domain)) {
      return { ...config, matchedOn: domain };
    }
  }

  // Check if URL contains known provider patterns (only distinctive names)
  const DISTINCTIVE_KEYS = ['googleapis', 'microsoftonline', 'salesforce', 'okta', 'auth0', 'hubapi', 'shopify', 'stripe'];
  for (const [domain, config] of Object.entries(PROVIDERS)) {
    const key = domain.split('.')[0];
    if (DISTINCTIVE_KEYS.includes(key) && hostname.includes(key)) {
      return { ...config, matchedOn: domain };
    }
  }

  return null;
}

function extractHostname(url) {
  try {
    return new URL(url.startsWith('http') ? url : `https://${url}`).hostname;
  } catch {
    return null;
  }
}

module.exports = { PROVIDERS, matchProvider };
