/**
 * OAuth 2.0 auto-configuration orchestrator.
 *
 * Combines multiple strategies to produce a complete OAuth configuration:
 * 1. Well-known provider matching (instant)
 * 2. OIDC Discovery (.well-known/openid-configuration)
 * 3. OpenAPI spec security schemes
 * 4. Claude-powered web research (when other methods are insufficient)
 */
const { matchProvider } = require('./well-known-providers');
const { discoverOidc } = require('./oidc-discovery');
const { researchOAuthConfig } = require('./claude-oauth-researcher');
const { generateConfigUI } = require('./config-ui-generator');

/**
 * Auto-detect and configure OAuth 2.0 for a REST API.
 *
 * @param {string} apiBaseUrl - The REST API base URL
 * @param {object} discoveryResult - Results from API endpoint discovery
 * @param {object} options - Configuration options
 * @returns {object} Complete OAuth configuration with UI definition
 */
async function autoConfigureOAuth(apiBaseUrl, discoveryResult = {}, options = {}) {
  const onProgress = options.onProgress || (() => {});
  const result = {
    strategy: null,
    providerMatch: null,
    oidcConfig: null,
    claudeResearch: null,
    finalConfig: null,
    configUI: null,
    warnings: [],
  };

  // --- Strategy 1: Well-known provider matching ---
  onProgress({ phase: 'provider-match', message: 'Checking well-known OAuth providers...' });
  const providerMatch = matchProvider(apiBaseUrl);
  if (providerMatch) {
    result.providerMatch = providerMatch;
    result.strategy = 'well-known-provider';
    onProgress({
      phase: 'provider-match',
      message: `Matched well-known provider: ${providerMatch.name}`,
    });
  }

  // --- Strategy 2: OIDC Discovery ---
  onProgress({ phase: 'oidc', message: 'Attempting OIDC discovery...' });
  try {
    const oidcConfig = await discoverOidc(apiBaseUrl);
    if (oidcConfig) {
      result.oidcConfig = oidcConfig;
      if (!result.strategy) result.strategy = 'oidc-discovery';
      onProgress({
        phase: 'oidc',
        message: `OIDC configuration found at ${oidcConfig.foundAt}`,
      });
    }
  } catch (err) {
    result.warnings.push(`OIDC discovery failed: ${err.message}`);
  }

  // --- Strategy 3: Extract from OpenAPI security schemes ---
  const securitySchemes = discoveryResult.securitySchemes || {};
  const hasOAuthScheme = Object.values(securitySchemes).some(s => s.type === 'oauth2');
  if (hasOAuthScheme && !result.strategy) {
    result.strategy = 'openapi-security';
  }

  // --- Strategy 4: Claude-powered research ---
  const needsClaudeResearch = !result.strategy ||
    options.forceClaudeResearch ||
    !result.providerMatch?.authorizationUrl ||
    (!result.oidcConfig?.authorizationUrl && !hasOAuthScheme);

  if (needsClaudeResearch) {
    onProgress({ phase: 'claude-research', message: 'Using Claude AI to research OAuth configuration...' });
    const claudeResult = await researchOAuthConfig(apiBaseUrl, {
      apiName: discoveryResult.apiInfo?.title || null,
      securitySchemes,
      endpoints: discoveryResult.endpoints || [],
      oidcConfig: result.oidcConfig,
    });

    result.claudeResearch = claudeResult;
    if (claudeResult.success) {
      result.strategy = (result.strategy ? result.strategy + '+' : '') + 'claude-research';
      onProgress({
        phase: 'claude-research',
        message: `Claude identified: ${claudeResult.config.provider_name}`,
      });
    } else {
      result.warnings.push(claudeResult.error);
      onProgress({
        phase: 'claude-research',
        message: `Claude research unavailable: ${claudeResult.error}`,
      });
    }
  }

  // --- Merge all sources into final config ---
  result.finalConfig = mergeConfigurations(result);

  // --- Generate configuration UI ---
  result.configUI = generateConfigUI(result.finalConfig);

  onProgress({
    phase: 'complete',
    message: `OAuth configuration complete (strategy: ${result.strategy})`,
  });

  return result;
}

/**
 * Merge configurations from multiple sources, preferring more specific/reliable sources.
 */
function mergeConfigurations(result) {
  const base = {
    provider_name: 'Unknown',
    oauth_type: 'oauth2_authorization_code',
    authorization_url: '',
    token_url: '',
    revoke_url: null,
    scopes: { required: [], optional: [], description: {} },
    extra_authorize_params: {},
    extra_token_params: {},
    client_config: {
      auth_method: 'client_secret_post',
      pkce_required: false,
      pkce_method: 'S256',
      state_required: true,
    },
    dynamic_fields: [],
    token_response_format: {
      access_token_path: 'access_token',
      refresh_token_path: 'refresh_token',
      expires_in_path: 'expires_in',
      token_type: 'Bearer',
    },
    documentation_url: null,
    notes: [],
  };

  // Layer 1: Well-known provider (highest confidence for known providers)
  if (result.providerMatch) {
    const p = result.providerMatch;
    base.provider_name = p.name;
    base.authorization_url = p.authorizationUrl;
    base.token_url = p.tokenUrl;
    base.revoke_url = p.revokeUrl || null;
    base.scopes.required = p.scopes || [];
    base.extra_authorize_params = p.extraParams?.authorize || {};
    base.extra_token_params = p.extraParams?.token || {};
    base.documentation_url = p.docs || null;

    if (p.placeholders && Object.keys(p.placeholders).length > 0) {
      for (const [name, description] of Object.entries(p.placeholders)) {
        base.dynamic_fields.push({
          name,
          label: name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          type: 'text',
          placeholder: description,
          required: true,
          description,
        });
      }
    }
  }

  // Layer 2: OIDC Discovery (authoritative for endpoints)
  if (result.oidcConfig) {
    const oidc = result.oidcConfig;
    if (oidc.authorizationUrl) base.authorization_url = oidc.authorizationUrl;
    if (oidc.tokenUrl) base.token_url = oidc.tokenUrl;
    if (oidc.revokeUrl) base.revoke_url = oidc.revokeUrl;
    if (oidc.scopesSupported?.length > 0) {
      base.scopes.optional = oidc.scopesSupported.filter(
        s => !base.scopes.required.includes(s)
      );
    }
    if (oidc.codeChallengeMethodsSupported?.length > 0) {
      base.client_config.pkce_required = true;
      base.client_config.pkce_method = oidc.codeChallengeMethodsSupported.includes('S256')
        ? 'S256' : oidc.codeChallengeMethodsSupported[0];
    }
  }

  // Layer 3: Claude research (fills in gaps and provides extra detail)
  if (result.claudeResearch?.success && result.claudeResearch.config) {
    const claude = result.claudeResearch.config;

    if (!base.authorization_url && claude.authorization_url) {
      base.authorization_url = claude.authorization_url;
    }
    if (!base.token_url && claude.token_url) {
      base.token_url = claude.token_url;
    }
    if (!base.revoke_url && claude.revoke_url) {
      base.revoke_url = claude.revoke_url;
    }
    if (base.provider_name === 'Unknown' && claude.provider_name) {
      base.provider_name = claude.provider_name;
    }
    if (!base.documentation_url && claude.documentation_url) {
      base.documentation_url = claude.documentation_url;
    }

    // Merge scopes
    if (claude.scopes?.required?.length > 0) {
      const existing = new Set(base.scopes.required);
      for (const s of claude.scopes.required) {
        if (!existing.has(s)) base.scopes.required.push(s);
      }
    }
    if (claude.scopes?.description) {
      base.scopes.description = { ...base.scopes.description, ...claude.scopes.description };
    }

    // Merge extra params
    if (claude.extra_authorize_params) {
      base.extra_authorize_params = { ...base.extra_authorize_params, ...claude.extra_authorize_params };
    }
    if (claude.extra_token_params) {
      base.extra_token_params = { ...base.extra_token_params, ...claude.extra_token_params };
    }

    // Merge dynamic fields
    if (claude.dynamic_fields?.length > 0) {
      const existingNames = new Set(base.dynamic_fields.map(f => f.name));
      for (const field of claude.dynamic_fields) {
        if (!existingNames.has(field.name)) {
          base.dynamic_fields.push(field);
        }
      }
    }

    // Merge client config
    if (claude.client_config) {
      base.client_config = { ...base.client_config, ...claude.client_config };
    }

    // Merge notes
    if (claude.notes?.length > 0) {
      base.notes.push(...claude.notes);
    }
  }

  // Always ensure standard dynamic fields are present
  ensureStandardFields(base);

  return base;
}

function ensureStandardFields(config) {
  const existingNames = new Set(config.dynamic_fields.map(f => f.name));

  const standardFields = [
    {
      name: 'client_id',
      label: 'Client ID',
      type: 'text',
      placeholder: 'Your OAuth application client ID',
      required: true,
      description: 'The client ID from your registered OAuth application',
    },
    {
      name: 'client_secret',
      label: 'Client Secret',
      type: 'password',
      placeholder: 'Your OAuth application client secret',
      required: true,
      description: 'The client secret from your registered OAuth application',
    },
    {
      name: 'redirect_uri',
      label: 'Redirect URI',
      type: 'url',
      placeholder: 'http://localhost:3000/oauth/callback',
      required: true,
      description: 'The callback URL registered with your OAuth application',
    },
  ];

  for (const field of standardFields) {
    if (!existingNames.has(field.name)) {
      config.dynamic_fields.push(field);
    }
  }
}

module.exports = { autoConfigureOAuth };
