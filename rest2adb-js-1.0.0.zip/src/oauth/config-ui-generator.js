/**
 * OAuth Configuration UI Generator.
 * Produces structured UI definitions and HTML forms from OAuth configurations.
 */

/**
 * Generate a structured UI definition from an OAuth configuration.
 * This can be consumed by any frontend framework or rendered as HTML.
 */
function generateConfigUI(config) {
  const sections = [];

  // --- Section 1: Provider Info ---
  sections.push({
    id: 'provider-info',
    title: 'OAuth Provider',
    type: 'info',
    fields: [
      { type: 'display', label: 'Provider', value: config.provider_name },
      { type: 'display', label: 'Auth Type', value: config.oauth_type },
      ...(config.documentation_url ? [{
        type: 'link', label: 'Documentation', value: config.documentation_url,
      }] : []),
    ],
  });

  // --- Section 2: OAuth Endpoints ---
  sections.push({
    id: 'endpoints',
    title: 'OAuth Endpoints',
    type: 'form',
    fields: [
      {
        name: 'authorization_url',
        label: 'Authorization URL',
        type: 'url',
        value: config.authorization_url,
        required: true,
        readonly: !!config.authorization_url,
        description: 'The URL where users are redirected to grant authorization',
      },
      {
        name: 'token_url',
        label: 'Token URL',
        type: 'url',
        value: config.token_url,
        required: true,
        readonly: !!config.token_url,
        description: 'The URL used to exchange authorization codes for tokens',
      },
      ...(config.revoke_url ? [{
        name: 'revoke_url',
        label: 'Revoke URL',
        type: 'url',
        value: config.revoke_url,
        required: false,
        readonly: true,
        description: 'The URL used to revoke tokens',
      }] : []),
    ],
  });

  // --- Section 3: Client Configuration ---
  sections.push({
    id: 'client-config',
    title: 'Client Configuration',
    type: 'form',
    fields: config.dynamic_fields.map(field => ({
      name: field.name,
      label: field.label,
      type: field.type || 'text',
      value: '',
      placeholder: field.placeholder || '',
      required: field.required !== false,
      description: field.description || '',
      pattern: field.pattern || null,
      options: field.options || null,
    })),
  });

  // --- Section 4: Scopes ---
  const allScopes = [
    ...config.scopes.required.map(s => ({
      name: s,
      required: true,
      description: config.scopes.description?.[s] || '',
    })),
    ...(config.scopes.optional || []).map(s => ({
      name: s,
      required: false,
      description: config.scopes.description?.[s] || '',
    })),
  ];

  if (allScopes.length > 0) {
    sections.push({
      id: 'scopes',
      title: 'Scopes',
      type: 'checklist',
      fields: allScopes.map(scope => ({
        name: `scope_${scope.name}`,
        label: scope.name,
        type: 'checkbox',
        checked: scope.required,
        disabled: scope.required,
        description: scope.description,
      })),
    });
  }

  // --- Section 5: Extra Parameters ---
  const extraParams = [];
  for (const [name, param] of Object.entries(config.extra_authorize_params || {})) {
    const paramDef = typeof param === 'object' ? param : { value: param };
    extraParams.push({
      name: `authorize_${name}`,
      label: name,
      phase: 'authorize',
      type: paramDef.options?.length > 0 ? 'select' : 'text',
      value: paramDef.value || '',
      required: paramDef.required || false,
      description: paramDef.description || `Extra parameter for authorization request`,
      options: paramDef.options || null,
    });
  }
  for (const [name, param] of Object.entries(config.extra_token_params || {})) {
    const paramDef = typeof param === 'object' ? param : { value: param };
    extraParams.push({
      name: `token_${name}`,
      label: name,
      phase: 'token',
      type: paramDef.options?.length > 0 ? 'select' : 'text',
      value: paramDef.value || '',
      required: paramDef.required || false,
      description: paramDef.description || `Extra parameter for token request`,
      options: paramDef.options || null,
    });
  }

  if (extraParams.length > 0) {
    sections.push({
      id: 'extra-params',
      title: 'Additional Parameters',
      type: 'form',
      fields: extraParams,
    });
  }

  // --- Section 6: Advanced Settings ---
  sections.push({
    id: 'advanced',
    title: 'Advanced Settings',
    type: 'form',
    collapsed: true,
    fields: [
      {
        name: 'auth_method',
        label: 'Client Auth Method',
        type: 'select',
        value: config.client_config?.auth_method || 'client_secret_post',
        options: ['client_secret_post', 'client_secret_basic', 'private_key_jwt', 'none'],
        description: 'How client credentials are sent to the token endpoint',
      },
      {
        name: 'pkce_enabled',
        label: 'PKCE',
        type: 'checkbox',
        checked: config.client_config?.pkce_required || false,
        description: 'Proof Key for Code Exchange (recommended for security)',
      },
      {
        name: 'pkce_method',
        label: 'PKCE Method',
        type: 'select',
        value: config.client_config?.pkce_method || 'S256',
        options: ['S256', 'plain'],
        description: 'Code challenge method for PKCE',
        dependsOn: 'pkce_enabled',
      },
      {
        name: 'state_enabled',
        label: 'State Parameter',
        type: 'checkbox',
        checked: config.client_config?.state_required !== false,
        description: 'Include state parameter for CSRF protection (recommended)',
      },
    ],
  });

  // --- Notes ---
  if (config.notes?.length > 0) {
    sections.push({
      id: 'notes',
      title: 'Important Notes',
      type: 'info',
      fields: config.notes.map((note, i) => ({
        type: 'display',
        label: `Note ${i + 1}`,
        value: note,
      })),
    });
  }

  return { sections };
}

/**
 * Generate a standalone HTML page for the OAuth configuration UI.
 */
function generateConfigHtml(config, uiDef) {
  const sections = uiDef.sections;

  const renderField = (field) => {
    switch (field.type) {
      case 'display':
        return `<div class="field display-field">
          <label>${esc(field.label)}</label>
          <span>${esc(field.value)}</span>
        </div>`;

      case 'link':
        return `<div class="field link-field">
          <label>${esc(field.label)}</label>
          <a href="${esc(field.value)}" target="_blank" rel="noopener">${esc(field.value)}</a>
        </div>`;

      case 'checkbox':
        return `<div class="field checkbox-field">
          <label>
            <input type="checkbox" name="${esc(field.name)}"
              ${field.checked ? 'checked' : ''}
              ${field.disabled ? 'disabled' : ''}
              ${field.dependsOn ? `data-depends-on="${esc(field.dependsOn)}"` : ''}>
            <span class="checkbox-label">${esc(field.label)}</span>
          </label>
          ${field.description ? `<p class="field-desc">${esc(field.description)}</p>` : ''}
        </div>`;

      case 'select':
        return `<div class="field select-field">
          <label for="${esc(field.name)}">${esc(field.label)}</label>
          <select name="${esc(field.name)}" id="${esc(field.name)}"
            ${field.dependsOn ? `data-depends-on="${esc(field.dependsOn)}"` : ''}>
            ${(field.options || []).map(opt =>
              `<option value="${esc(opt)}" ${opt === field.value ? 'selected' : ''}>${esc(opt)}</option>`
            ).join('\n')}
          </select>
          ${field.description ? `<p class="field-desc">${esc(field.description)}</p>` : ''}
        </div>`;

      case 'password':
        return `<div class="field">
          <label for="${esc(field.name)}">${esc(field.label)}${field.required ? ' *' : ''}</label>
          <input type="password" name="${esc(field.name)}" id="${esc(field.name)}"
            placeholder="${esc(field.placeholder || '')}"
            ${field.required ? 'required' : ''}
            ${field.pattern ? `pattern="${esc(field.pattern)}"` : ''}>
          ${field.description ? `<p class="field-desc">${esc(field.description)}</p>` : ''}
        </div>`;

      default: // text, url
        return `<div class="field">
          <label for="${esc(field.name)}">${esc(field.label)}${field.required ? ' *' : ''}</label>
          <input type="${field.type === 'url' ? 'url' : 'text'}" name="${esc(field.name)}" id="${esc(field.name)}"
            value="${esc(field.value || '')}"
            placeholder="${esc(field.placeholder || '')}"
            ${field.required ? 'required' : ''}
            ${field.readonly ? 'readonly' : ''}
            ${field.pattern ? `pattern="${esc(field.pattern)}"` : ''}>
          ${field.description ? `<p class="field-desc">${esc(field.description)}</p>` : ''}
        </div>`;
    }
  };

  const renderSection = (section) => {
    const collapsed = section.collapsed ? 'collapsed' : '';
    return `
    <section class="config-section ${collapsed}" id="${esc(section.id)}">
      <h2 class="section-title" ${section.collapsed ? 'onclick="this.parentElement.classList.toggle(\'collapsed\')"' : ''}>
        ${esc(section.title)}
        ${section.collapsed ? '<span class="toggle-icon">&#9660;</span>' : ''}
      </h2>
      <div class="section-body">
        ${section.fields.map(renderField).join('\n')}
      </div>
    </section>`;
  };

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OAuth 2.0 Configuration - ${esc(config.provider_name)}</title>
  <style>
    :root {
      --primary: #2563eb;
      --primary-dark: #1d4ed8;
      --bg: #f8fafc;
      --card-bg: #ffffff;
      --border: #e2e8f0;
      --text: #1e293b;
      --text-muted: #64748b;
      --success: #16a34a;
      --error: #dc2626;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      background: var(--bg); color: var(--text);
      line-height: 1.6; padding: 2rem;
    }
    .container { max-width: 720px; margin: 0 auto; }
    h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
    .subtitle { color: var(--text-muted); margin-bottom: 2rem; }
    .config-section {
      background: var(--card-bg); border: 1px solid var(--border);
      border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem;
    }
    .config-section.collapsed .section-body { display: none; }
    .config-section.collapsed .toggle-icon { transform: rotate(-90deg); }
    .section-title {
      font-size: 1.1rem; margin-bottom: 1rem;
      display: flex; align-items: center; gap: 0.5rem;
    }
    .collapsed .section-title { cursor: pointer; margin-bottom: 0; }
    .toggle-icon { font-size: 0.7rem; transition: transform 0.2s; display: inline-block; }
    .field { margin-bottom: 1rem; }
    .field:last-child { margin-bottom: 0; }
    .field label { display: block; font-weight: 500; margin-bottom: 0.25rem; font-size: 0.9rem; }
    .field input[type="text"], .field input[type="url"],
    .field input[type="password"], .field select {
      width: 100%; padding: 0.5rem 0.75rem; border: 1px solid var(--border);
      border-radius: 6px; font-size: 0.9rem; transition: border-color 0.15s;
    }
    .field input:focus, .field select:focus {
      outline: none; border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
    }
    .field input[readonly] { background: #f1f5f9; color: var(--text-muted); }
    .field-desc { font-size: 0.8rem; color: var(--text-muted); margin-top: 0.25rem; }
    .display-field { display: flex; gap: 0.5rem; align-items: baseline; }
    .display-field label { min-width: 120px; }
    .display-field span { color: var(--text-muted); }
    .link-field { display: flex; gap: 0.5rem; align-items: baseline; }
    .link-field label { min-width: 120px; }
    .link-field a { color: var(--primary); }
    .checkbox-field label { display: flex; align-items: center; gap: 0.5rem; cursor: pointer; }
    .checkbox-label { font-weight: 400; }
    .btn-group { display: flex; gap: 0.75rem; margin-top: 1.5rem; }
    .btn {
      padding: 0.6rem 1.5rem; border: none; border-radius: 6px;
      font-size: 0.9rem; cursor: pointer; font-weight: 500;
    }
    .btn-primary { background: var(--primary); color: white; }
    .btn-primary:hover { background: var(--primary-dark); }
    .btn-secondary { background: var(--border); color: var(--text); }
    .btn-secondary:hover { background: #cbd5e1; }
    #output {
      margin-top: 1rem; padding: 1rem; background: #1e293b; color: #e2e8f0;
      border-radius: 8px; font-family: monospace; font-size: 0.85rem;
      white-space: pre-wrap; display: none; max-height: 400px; overflow-y: auto;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>OAuth 2.0 Configuration</h1>
    <p class="subtitle">${esc(config.provider_name)} — Authorization Code Flow</p>

    <form id="oauth-config-form">
      ${sections.map(renderSection).join('\n')}

      <div class="btn-group">
        <button type="button" class="btn btn-primary" onclick="exportConfig()">Export Configuration</button>
        <button type="button" class="btn btn-secondary" onclick="copyConfig()">Copy JSON</button>
        <button type="button" class="btn btn-secondary" onclick="testConnection()">Test Connection</button>
      </div>
    </form>

    <pre id="output"></pre>
  </div>

  <script>
    function collectFormData() {
      const form = document.getElementById('oauth-config-form');
      const data = {};
      for (const el of form.elements) {
        if (!el.name) continue;
        if (el.type === 'checkbox') {
          data[el.name] = el.checked;
        } else {
          data[el.name] = el.value;
        }
      }
      return data;
    }

    function buildOAuthConfig(formData) {
      return {
        provider: ${JSON.stringify(config.provider_name)},
        oauth_type: ${JSON.stringify(config.oauth_type)},
        authorization_url: formData.authorization_url || ${JSON.stringify(config.authorization_url)},
        token_url: formData.token_url || ${JSON.stringify(config.token_url)},
        revoke_url: formData.revoke_url || ${JSON.stringify(config.revoke_url || '')},
        client_id: formData.client_id || '',
        client_secret: formData.client_secret ? '***REDACTED***' : '',
        redirect_uri: formData.redirect_uri || '',
        scopes: getSelectedScopes(),
        pkce: {
          enabled: formData.pkce_enabled || false,
          method: formData.pkce_method || 'S256',
        },
        state_enabled: formData.state_enabled !== false,
        auth_method: formData.auth_method || 'client_secret_post',
        extra_params: getExtraParams(formData),
      };
    }

    function getSelectedScopes() {
      const scopes = [];
      for (const el of document.querySelectorAll('input[type="checkbox"]')) {
        if (el.name.startsWith('scope_') && el.checked) {
          scopes.push(el.name.replace('scope_', ''));
        }
      }
      return scopes;
    }

    function getExtraParams(formData) {
      const authorize = {};
      const token = {};
      for (const [key, value] of Object.entries(formData)) {
        if (key.startsWith('authorize_') && value) {
          authorize[key.replace('authorize_', '')] = value;
        } else if (key.startsWith('token_') && value) {
          token[key.replace('token_', '')] = value;
        }
      }
      return { authorize, token };
    }

    function exportConfig() {
      const config = buildOAuthConfig(collectFormData());
      const output = document.getElementById('output');
      output.textContent = JSON.stringify(config, null, 2);
      output.style.display = 'block';
    }

    function copyConfig() {
      const config = buildOAuthConfig(collectFormData());
      navigator.clipboard.writeText(JSON.stringify(config, null, 2))
        .then(() => alert('Configuration copied to clipboard'))
        .catch(() => {
          exportConfig();
          alert('Could not copy. Config displayed below.');
        });
    }

    function testConnection() {
      const formData = collectFormData();
      const authUrl = formData.authorization_url || ${JSON.stringify(config.authorization_url)};
      if (!authUrl) {
        alert('No authorization URL configured');
        return;
      }
      const params = new URLSearchParams({
        response_type: 'code',
        client_id: formData.client_id || 'TEST_CLIENT_ID',
        redirect_uri: formData.redirect_uri || 'http://localhost:3000/callback',
        scope: getSelectedScopes().join(' '),
        state: Math.random().toString(36).substring(7),
      });
      const output = document.getElementById('output');
      output.textContent = 'Authorization URL that would be opened:\\n\\n' + authUrl + '?' + params.toString();
      output.style.display = 'block';
    }

    // Handle dependent field visibility
    document.querySelectorAll('[data-depends-on]').forEach(el => {
      const dep = document.querySelector('[name="' + el.dataset.dependsOn + '"]');
      if (dep) {
        const toggle = () => {
          el.closest('.field').style.display = dep.checked ? '' : 'none';
        };
        dep.addEventListener('change', toggle);
        toggle();
      }
    });
  </script>
</body>
</html>`;
}

function esc(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

module.exports = { generateConfigUI, generateConfigHtml };
