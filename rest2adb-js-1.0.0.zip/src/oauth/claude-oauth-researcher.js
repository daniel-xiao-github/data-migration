/**
 * Claude-powered OAuth 2.0 configuration researcher.
 *
 * Uses the Anthropic API (Claude) to:
 * 1. Research a given REST API's authentication requirements
 * 2. Generate complete OAuth 2.0 authorization code flow configuration
 * 3. Identify required extra parameters, scopes, and provider-specific quirks
 * 4. Produce a ready-to-use configuration UI definition
 *
 * Requires ANTHROPIC_API_KEY environment variable.
 */

const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';
const CLAUDE_MODEL = 'claude-sonnet-4-20250514';

/**
 * Use Claude to research OAuth 2.0 configuration for a given API.
 *
 * @param {string} apiBaseUrl - The REST API base URL
 * @param {object} context - Additional context from discovery
 * @param {string} context.apiName - Name of the API (if known)
 * @param {object} context.securitySchemes - Security schemes from OpenAPI spec
 * @param {string[]} context.endpoints - Discovered endpoints
 * @param {object} context.oidcConfig - OIDC discovery results (if any)
 * @returns {object} Complete OAuth configuration with UI definition
 */
async function researchOAuthConfig(apiBaseUrl, context = {}) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      success: false,
      error: 'ANTHROPIC_API_KEY environment variable is required for Claude-powered OAuth research',
      fallback: buildFallbackConfig(apiBaseUrl, context),
    };
  }

  const prompt = buildResearchPrompt(apiBaseUrl, context);

  try {
    const response = await callClaude(apiKey, prompt);
    const config = parseClaudeResponse(response);
    return { success: true, config };
  } catch (err) {
    return {
      success: false,
      error: `Claude research failed: ${err.message}`,
      fallback: buildFallbackConfig(apiBaseUrl, context),
    };
  }
}

function buildResearchPrompt(apiBaseUrl, context) {
  const contextParts = [];

  if (context.apiName) {
    contextParts.push(`API Name: ${context.apiName}`);
  }

  if (context.securitySchemes && Object.keys(context.securitySchemes).length > 0) {
    contextParts.push(`Security schemes found in OpenAPI spec:\n${JSON.stringify(context.securitySchemes, null, 2)}`);
  }

  if (context.endpoints && context.endpoints.length > 0) {
    const sampleEndpoints = context.endpoints.slice(0, 20).map(e =>
      typeof e === 'string' ? e : `${e.method} ${e.path}`
    );
    contextParts.push(`Sample endpoints discovered:\n${sampleEndpoints.join('\n')}`);
  }

  if (context.oidcConfig) {
    contextParts.push(`OIDC Discovery results:\n${JSON.stringify(context.oidcConfig, null, 2)}`);
  }

  const contextBlock = contextParts.length > 0
    ? `\n\nHere is what we already know about this API:\n${contextParts.join('\n\n')}`
    : '';

  return `You are an API integration expert. I need you to research and provide the complete OAuth 2.0 Authorization Code flow configuration for this REST API:

**API Base URL:** ${apiBaseUrl}
${contextBlock}

Please provide your response as a JSON object with EXACTLY this structure (no markdown, no code fences, just the raw JSON):

{
  "provider_name": "Human-readable name of the API/OAuth provider",
  "oauth_type": "oauth2_authorization_code",
  "authorization_url": "Full URL for the authorization endpoint",
  "token_url": "Full URL for the token endpoint",
  "revoke_url": "Full URL for token revocation (or null)",
  "scopes": {
    "required": ["list of required scopes"],
    "optional": ["list of optional/recommended scopes"],
    "description": {"scope_name": "what this scope grants access to"}
  },
  "extra_authorize_params": {
    "param_name": {
      "value": "default value or empty string",
      "required": true,
      "description": "What this parameter does",
      "options": ["list of valid values if enumerable, or empty array"]
    }
  },
  "extra_token_params": {
    "param_name": {
      "value": "default value",
      "required": true,
      "description": "What this parameter does"
    }
  },
  "client_config": {
    "auth_method": "client_secret_post or client_secret_basic or private_key_jwt",
    "pkce_required": true,
    "pkce_method": "S256 or plain",
    "state_required": true
  },
  "dynamic_fields": [
    {
      "name": "field_name",
      "label": "Human-readable label",
      "type": "text or select or url",
      "placeholder": "Example value",
      "required": true,
      "description": "Why this field is needed",
      "pattern": "regex pattern for validation (optional)",
      "options": ["for select type only"]
    }
  ],
  "token_response_format": {
    "access_token_path": "path.to.access_token in response JSON",
    "refresh_token_path": "path.to.refresh_token",
    "expires_in_path": "path.to.expires_in",
    "token_type": "Bearer"
  },
  "rate_limits": {
    "requests_per_second": null,
    "requests_per_day": null,
    "note": "Any rate limiting info"
  },
  "documentation_url": "Link to official OAuth docs",
  "notes": ["Any important implementation notes or gotchas"]
}

Important considerations:
1. Include ALL extra parameters needed beyond the standard OAuth 2.0 flow
2. Identify any dynamic fields the user must provide (like tenant IDs, domains, API identifiers)
3. Note if PKCE is required or recommended
4. Specify the correct client authentication method
5. Include any provider-specific quirks or requirements
6. If the API doesn't use OAuth 2.0, describe what authentication it uses instead

Be thorough and precise. This configuration will be used to generate a configuration UI.`;
}

async function callClaude(apiKey, prompt) {
  const axios = require('axios');

  const response = await axios.post(ANTHROPIC_API_URL, {
    model: CLAUDE_MODEL,
    max_tokens: 4096,
    messages: [{ role: 'user', content: prompt }],
  }, {
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    timeout: 60000,
  });

  const content = response.data?.content?.[0]?.text;
  if (!content) {
    throw new Error('Empty response from Claude');
  }
  return content;
}

function parseClaudeResponse(text) {
  // Try to extract JSON from the response
  let jsonStr = text.trim();

  // Remove markdown code fences if present
  const fenceMatch = jsonStr.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  }

  try {
    return JSON.parse(jsonStr);
  } catch {
    // Try to find a JSON object in the text
    const objMatch = text.match(/\{[\s\S]*\}/);
    if (objMatch) {
      return JSON.parse(objMatch[0]);
    }
    throw new Error('Could not parse Claude response as JSON');
  }
}

/**
 * Build a fallback configuration when Claude is unavailable.
 * Uses whatever context we have from OIDC discovery and OpenAPI specs.
 */
function buildFallbackConfig(apiBaseUrl, context) {
  const config = {
    provider_name: context.apiName || 'Unknown API',
    oauth_type: 'oauth2_authorization_code',
    authorization_url: '',
    token_url: '',
    revoke_url: null,
    scopes: { required: [], optional: [], description: {} },
    extra_authorize_params: {},
    extra_token_params: {},
    client_config: {
      auth_method: 'client_secret_post',
      pkce_required: false,
      pkce_method: 'S256',
      state_required: true,
    },
    dynamic_fields: [
      {
        name: 'client_id',
        label: 'Client ID',
        type: 'text',
        placeholder: 'Your OAuth client ID',
        required: true,
        description: 'The client ID from your OAuth application registration',
      },
      {
        name: 'client_secret',
        label: 'Client Secret',
        type: 'password',
        placeholder: 'Your OAuth client secret',
        required: true,
        description: 'The client secret from your OAuth application registration',
      },
      {
        name: 'redirect_uri',
        label: 'Redirect URI',
        type: 'url',
        placeholder: 'http://localhost:3000/callback',
        required: true,
        description: 'The callback URL registered with your OAuth application',
      },
    ],
    documentation_url: null,
    notes: ['Configuration was generated without Claude AI assistance. Please verify all URLs and parameters.'],
  };

  // Merge OIDC discovery data if available
  if (context.oidcConfig) {
    const oidc = context.oidcConfig;
    config.authorization_url = oidc.authorizationUrl || '';
    config.token_url = oidc.tokenUrl || '';
    config.revoke_url = oidc.revokeUrl || null;
    config.scopes.optional = oidc.scopesSupported || [];
    if (oidc.codeChallengeMethodsSupported?.length > 0) {
      config.client_config.pkce_required = true;
      config.client_config.pkce_method = oidc.codeChallengeMethodsSupported.includes('S256') ? 'S256' : oidc.codeChallengeMethodsSupported[0];
    }
  }

  // Merge OpenAPI security scheme data if available
  if (context.securitySchemes) {
    for (const [, scheme] of Object.entries(context.securitySchemes)) {
      if (scheme.type === 'oauth2' && scheme.flows) {
        const flow = scheme.flows.authorizationCode || scheme.flows.implicit || Object.values(scheme.flows)[0];
        if (flow) {
          config.authorization_url = config.authorization_url || flow.authorizationUrl || '';
          config.token_url = config.token_url || flow.tokenUrl || '';
          if (flow.scopes) {
            config.scopes.required = Object.keys(flow.scopes);
            config.scopes.description = flow.scopes;
          }
        }
      }
    }
  }

  return config;
}

module.exports = { researchOAuthConfig, buildFallbackConfig };
