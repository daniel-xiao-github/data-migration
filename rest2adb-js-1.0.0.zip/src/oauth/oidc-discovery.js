/**
 * OpenID Connect Discovery.
 * Fetches .well-known/openid-configuration to auto-detect OAuth 2.0 endpoints.
 */
const { createClient, probe } = require('../utils/http');
const { normalizeBaseUrl, extractDomain } = require('../utils/url');

const OIDC_PATHS = [
  '/.well-known/openid-configuration',
  '/.well-known/oauth-authorization-server',
  '/oauth/.well-known/openid-configuration',
  '/v1/.well-known/openid-configuration',
  '/v2.0/.well-known/openid-configuration',
];

/**
 * Attempt to discover OAuth endpoints via OIDC well-known configuration.
 */
async function discoverOidc(baseUrl) {
  const url = normalizeBaseUrl(baseUrl);
  const client = createClient(url, { timeout: 10000 });
  const domain = extractDomain(url);

  // Also try the domain root for OIDC discovery
  const rootClient = createClient(`https://${domain}`, { timeout: 10000 });

  for (const path of OIDC_PATHS) {
    for (const c of [client, rootClient]) {
      const result = await probe(c, path, 'get', { retries: 1 });
      if (result.ok && result.data && typeof result.data === 'object') {
        return parseOidcConfig(result.data, path);
      }
    }
  }

  return null;
}

function parseOidcConfig(config, foundAt) {
  return {
    foundAt,
    issuer: config.issuer || null,
    authorizationUrl: config.authorization_endpoint || null,
    tokenUrl: config.token_endpoint || null,
    userinfoUrl: config.userinfo_endpoint || null,
    jwksUrl: config.jwks_uri || null,
    revokeUrl: config.revocation_endpoint || null,
    introspectUrl: config.introspection_endpoint || null,
    registrationUrl: config.registration_endpoint || null,
    endSessionUrl: config.end_session_endpoint || null,
    scopesSupported: config.scopes_supported || [],
    responseTypesSupported: config.response_types_supported || [],
    grantTypesSupported: config.grant_types_supported || [],
    tokenEndpointAuthMethods: config.token_endpoint_auth_methods_supported || [],
    codeChallengeMethodsSupported: config.code_challenge_methods_supported || [],
  };
}

module.exports = { discoverOidc, OIDC_PATHS };
