/**
 * data-migration-rest2adb-js
 *
 * Automated REST API endpoint discovery and data migration to
 * Oracle Autonomous Database (ADB) with Claude-powered OAuth 2.0
 * configuration generation.
 *
 * Main programmatic API.
 */

const { discoverApi } = require('./discovery');
const { autoConfigureOAuth } = require('./oauth');
const { generateMappingPlan } = require('./mapping');
const { executeMigration } = require('./migration/executor');
const { generateConfigHtml } = require('./oauth/config-ui-generator');

/**
 * Run the full pipeline: discover -> configure OAuth -> map -> (optionally) migrate.
 *
 * @param {string} baseUrl - REST API base URL
 * @param {object} options
 * @param {object} options.auth - Pre-existing auth credentials
 * @param {boolean} options.skipOAuth - Skip OAuth configuration
 * @param {boolean} options.dryRun - Generate plan without executing migration
 * @param {function} options.onProgress - Progress callback
 * @returns {object} Complete pipeline result
 */
async function run(baseUrl, options = {}) {
  const onProgress = options.onProgress || (() => {});
  const result = {
    discovery: null,
    oauth: null,
    mapping: null,
    migration: null,
  };

  // --- Step 1: Discover API endpoints ---
  onProgress({ step: 'discovery', message: 'Starting API discovery...' });
  result.discovery = await discoverApi(baseUrl, {
    headers: options.headers || {},
    auth: options.auth || null,
    onProgress: (p) => onProgress({ step: 'discovery', ...p }),
  });

  // --- Step 2: Configure OAuth ---
  if (!options.skipOAuth) {
    onProgress({ step: 'oauth', message: 'Configuring OAuth 2.0...' });
    result.oauth = await autoConfigureOAuth(baseUrl, result.discovery, {
      onProgress: (p) => onProgress({ step: 'oauth', ...p }),
    });
  }

  // --- Step 3: Generate mapping plan ---
  onProgress({ step: 'mapping', message: 'Generating migration mapping...' });
  result.mapping = generateMappingPlan(result.discovery, {
    include: options.include,
    exclude: options.exclude,
  });

  // --- Step 4: Execute migration (if not dry run) ---
  if (options.execute && !options.dryRun) {
    onProgress({ step: 'migration', message: 'Executing migration...' });
    result.migration = await executeMigration(result.mapping, {
      dryRun: false,
      authToken: options.authToken,
      dbConnection: options.dbConnection,
      onProgress: (p) => onProgress({ step: 'migration', ...p }),
    });
  } else if (options.execute) {
    result.migration = await executeMigration(result.mapping, {
      dryRun: true,
      authToken: options.authToken,
      onProgress: (p) => onProgress({ step: 'migration', ...p }),
    });
  }

  return result;
}

module.exports = {
  run,
  // Individual modules for custom pipelines
  discoverApi,
  autoConfigureOAuth,
  generateMappingPlan,
  executeMigration,
  generateConfigHtml,
};
