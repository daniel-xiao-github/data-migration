/**
 * Migration executor.
 * Handles the actual data extraction from REST APIs and loading into ADB.
 *
 * This module provides the execution framework. Actual database operations
 * require the Oracle Instant Client and node-oracledb driver to be configured.
 */

const { createClient, probe } = require('../utils/http');

/**
 * Execute a migration plan.
 *
 * @param {object} plan - The mapping plan from generateMappingPlan
 * @param {object} options - Execution options
 * @returns {object} Execution results
 */
async function executeMigration(plan, options = {}) {
  const {
    dryRun = true,
    onProgress = () => {},
    authToken = null,
    dbConnection = null,
  } = options;

  const results = {
    startTime: new Date().toISOString(),
    endTime: null,
    dryRun,
    tables: [],
    totalRecords: 0,
    errors: [],
  };

  const client = createClient(plan.baseUrl, {
    auth: authToken ? { type: 'bearer', token: authToken } : null,
  });

  for (const tableMapping of plan.tables) {
    const tableResult = {
      tableName: tableMapping.tableName,
      sourceEndpoint: tableMapping.sourceEndpoints?.[0]?.path || tableMapping.endpoint?.path,
      recordsExtracted: 0,
      recordsLoaded: 0,
      errors: [],
      status: 'pending',
    };

    try {
      onProgress({
        phase: 'extract',
        table: tableMapping.tableName,
        message: `Extracting data from ${tableResult.sourceEndpoint}...`,
      });

      // Extract data from API
      const data = await extractData(client, tableResult.sourceEndpoint, {
        onProgress: (p) => onProgress({ ...p, table: tableMapping.tableName }),
      });

      tableResult.recordsExtracted = data.length;

      if (dryRun) {
        tableResult.status = 'dry-run';
        tableResult.sampleData = data.slice(0, 3);
        onProgress({
          phase: 'dry-run',
          table: tableMapping.tableName,
          message: `[DRY RUN] Would load ${data.length} records into ${tableMapping.tableName}`,
        });
      } else {
        // Load into ADB
        if (!dbConnection) {
          tableResult.status = 'skipped';
          tableResult.errors.push('No database connection configured');
        } else {
          onProgress({
            phase: 'load',
            table: tableMapping.tableName,
            message: `Loading ${data.length} records into ${tableMapping.tableName}...`,
          });

          const loaded = await loadData(dbConnection, tableMapping, data, { onProgress });
          tableResult.recordsLoaded = loaded;
          tableResult.status = 'completed';
        }
      }

      results.totalRecords += tableResult.recordsExtracted;
    } catch (err) {
      tableResult.status = 'error';
      tableResult.errors.push(err.message);
      results.errors.push({ table: tableMapping.tableName, error: err.message });
    }

    results.tables.push(tableResult);
  }

  results.endTime = new Date().toISOString();
  return results;
}

/**
 * Extract data from a REST API endpoint, handling pagination.
 */
async function extractData(client, endpoint, { onProgress = () => {} } = {}) {
  const allRecords = [];
  let url = endpoint;
  let page = 1;
  const maxPages = 100; // Safety limit

  while (url && page <= maxPages) {
    const result = await probe(client, url);
    if (!result.ok) {
      if (page === 1) {
        throw new Error(`Failed to fetch ${endpoint}: HTTP ${result.status}`);
      }
      break;
    }

    const { records, nextUrl } = extractRecords(result.data, result.headers);
    allRecords.push(...records);

    onProgress({
      phase: 'extract',
      message: `Extracted ${allRecords.length} records (page ${page})`,
      page,
      recordCount: allRecords.length,
    });

    url = nextUrl;
    page++;
  }

  return allRecords;
}

/**
 * Extract records from a response, handling common response wrapper patterns.
 */
function extractRecords(data, headers) {
  let records = [];
  let nextUrl = null;

  if (Array.isArray(data)) {
    records = data;
  } else if (data && typeof data === 'object') {
    // Common wrapper patterns
    if (Array.isArray(data.data)) {
      records = data.data;
    } else if (Array.isArray(data.results)) {
      records = data.results;
      nextUrl = data.next || null;
    } else if (Array.isArray(data.items)) {
      records = data.items;
    } else if (Array.isArray(data.records)) {
      records = data.records;
    } else if (Array.isArray(data.entries)) {
      records = data.entries;
    } else if (Array.isArray(data.value)) {
      // OData format
      records = data.value;
      nextUrl = data['@odata.nextLink'] || null;
    } else {
      // Single object — treat as one record
      records = [data];
    }

    // Check for pagination links
    if (!nextUrl) {
      nextUrl = data.next_page_url || data.nextPageUrl || data.next || null;
      if (data.links?.next) {
        nextUrl = typeof data.links.next === 'string' ? data.links.next : data.links.next.href;
      }
    }
  }

  // Check Link header for pagination
  if (!nextUrl && headers?.link) {
    const match = headers.link.match(/<([^>]+)>;\s*rel="next"/);
    if (match) nextUrl = match[1];
  }

  return { records, nextUrl };
}

/**
 * Load data into ADB table.
 * Requires an active Oracle database connection.
 */
async function loadData(dbConnection, tableMapping, data, { onProgress = () => {} } = {}) {
  // This is the integration point for node-oracledb
  // In a full implementation, this would:
  // 1. Create the table if it doesn't exist (using DDL from mapping)
  // 2. Map JSON fields to table columns
  // 3. Batch insert records
  // 4. Handle conflicts (upsert based on primary key)

  const batchSize = 1000;
  let loaded = 0;

  for (let i = 0; i < data.length; i += batchSize) {
    const batch = data.slice(i, i + batchSize);

    // Build INSERT statements
    const columns = tableMapping.columns
      .filter(c => c.sourceField)
      .map(c => c.name);

    const values = batch.map(record => {
      return tableMapping.columns
        .filter(c => c.sourceField)
        .map(c => record[c.sourceField] ?? null);
    });

    // Execute batch insert via dbConnection
    // await dbConnection.executeMany(insertSql, values, { autoCommit: false });

    loaded += batch.length;
    onProgress({
      phase: 'load',
      message: `Loaded ${loaded}/${data.length} records`,
      loaded,
      total: data.length,
    });
  }

  // await dbConnection.commit();
  return loaded;
}

module.exports = { executeMigration, extractData, extractRecords };
