/**
 * Web server for REST-to-ADB migration UI.
 *
 * Provides a step-by-step wizard:
 *   1. Configure — enter API URL, auth, headers
 *   2. Discover & Plan — discover endpoints, configure OAuth, generate mappings
 *   3. Execute — run migration (dry-run or live)
 *
 * Uses Server-Sent Events (SSE) for real-time progress.
 */

const express = require('express');
const path = require('path');
const crypto = require('crypto');

const { discoverApi } = require('../discovery');
const { autoConfigureOAuth } = require('../oauth');
const { generateMappingPlan } = require('../mapping');
const { executeMigration } = require('../migration/executor');
const { generateConfigHtml } = require('../oauth/config-ui-generator');

/**
 * Create and return an Express app.
 * @param {object} opts - Server options
 * @returns {import('express').Express}
 */
function createApp(opts = {}) {
  const app = express();
  app.use(express.json());
  app.use(express.static(path.join(__dirname, 'public')));

  // In-memory session store (keyed by session id)
  const sessions = new Map();

  // ── helpers ───────────────────────────────────────────────
  function getSession(id) {
    if (!sessions.has(id)) {
      sessions.set(id, {
        id,
        config: null,
        discovery: null,
        oauth: null,
        mapping: null,
        migration: null,
      });
    }
    return sessions.get(id);
  }

  // ── POST /api/sessions — create a new session ────────────
  app.post('/api/sessions', (_req, res) => {
    const id = crypto.randomUUID();
    const session = getSession(id);
    res.json({ id: session.id });
  });

  // ── POST /api/sessions/:id/configure — save auth config ──
  app.post('/api/sessions/:id/configure', (req, res) => {
    const session = getSession(req.params.id);
    const { url, authType, token, apiKeyName, apiKeyValue, apiKeyIn, headers } = req.body;

    if (!url) return res.status(400).json({ error: 'url is required' });

    let auth = null;
    if (authType === 'bearer' && token) {
      auth = { type: 'bearer', token };
    } else if (authType === 'apikey' && apiKeyName && apiKeyValue) {
      auth = { type: 'apikey', name: apiKeyName, value: apiKeyValue, in: apiKeyIn || 'header' };
    }

    const parsedHeaders = {};
    if (headers) {
      for (const h of (Array.isArray(headers) ? headers : headers.split('\n'))) {
        const idx = h.indexOf(':');
        if (idx > 0) {
          parsedHeaders[h.substring(0, idx).trim()] = h.substring(idx + 1).trim();
        }
      }
    }

    session.config = { url, auth, headers: parsedHeaders };
    // Reset downstream state when config changes
    session.discovery = null;
    session.oauth = null;
    session.mapping = null;
    session.migration = null;

    res.json({ ok: true, config: { url, authType: authType || 'none' } });
  });

  // ── GET /api/sessions/:id — get full session state ───────
  app.get('/api/sessions/:id', (req, res) => {
    const session = getSession(req.params.id);
    res.json({
      id: session.id,
      hasConfig: !!session.config,
      url: session.config?.url || null,
      hasDiscovery: !!session.discovery,
      endpointCount: session.discovery?.endpoints?.length || 0,
      discoveryMethod: session.discovery?.discoveryMethod || null,
      hasOAuth: !!session.oauth,
      oauthProvider: session.oauth?.finalConfig?.provider_name || null,
      hasMapping: !!session.mapping,
      tableCount: session.mapping?.tables?.length || 0,
      hasMigration: !!session.migration,
    });
  });

  // ── GET /api/sessions/:id/discovery — get discovery result
  app.get('/api/sessions/:id/discovery', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.discovery) return res.status(404).json({ error: 'No discovery result yet' });
    res.json(session.discovery);
  });

  // ── GET /api/sessions/:id/oauth — get oauth result ───────
  app.get('/api/sessions/:id/oauth', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.oauth) return res.status(404).json({ error: 'No OAuth result yet' });
    res.json(session.oauth);
  });

  // ── GET /api/sessions/:id/oauth-html — get oauth HTML UI ─
  app.get('/api/sessions/:id/oauth-html', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.oauth) return res.status(404).json({ error: 'No OAuth result yet' });
    const html = generateConfigHtml(session.oauth.finalConfig, session.oauth.configUI);
    res.type('html').send(html);
  });

  // ── GET /api/sessions/:id/mapping — get mapping result ───
  app.get('/api/sessions/:id/mapping', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.mapping) return res.status(404).json({ error: 'No mapping result yet' });
    res.json(session.mapping);
  });

  // ── GET /api/sessions/:id/ddl — get DDL as .sql ──────────
  app.get('/api/sessions/:id/ddl', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.mapping) return res.status(404).json({ error: 'No mapping result yet' });
    const ddl = session.mapping.ddl.join(';\n\n') + ';';
    res.type('text/plain').send(ddl);
  });

  // ── GET /api/sessions/:id/migration — get migration result
  app.get('/api/sessions/:id/migration', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.migration) return res.status(404).json({ error: 'No migration result yet' });
    res.json(session.migration);
  });

  // ── SSE: POST /api/sessions/:id/discover — run discovery ─
  app.post('/api/sessions/:id/discover', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.config) return res.status(400).json({ error: 'Configure the API first' });

    sseHeaders(res);

    const { url, auth, headers } = session.config;
    const { include, exclude, skipOAuth } = req.body || {};

    (async () => {
      try {
        // Phase 1 — Discover
        sendSSE(res, 'progress', { step: 'discovery', message: 'Starting API discovery...' });
        session.discovery = await discoverApi(url, {
          headers,
          auth,
          onProgress: (p) => sendSSE(res, 'progress', { step: 'discovery', ...p }),
        });
        sendSSE(res, 'discovery', {
          method: session.discovery.discoveryMethod,
          endpointCount: session.discovery.endpoints.length,
          endpoints: session.discovery.endpoints.slice(0, 50).map(ep => ({
            method: ep.method, path: ep.path, summary: ep.summary || '',
          })),
        });

        // Phase 2 — OAuth
        if (!skipOAuth) {
          sendSSE(res, 'progress', { step: 'oauth', message: 'Auto-configuring OAuth 2.0...' });
          session.oauth = await autoConfigureOAuth(url, session.discovery, {
            onProgress: (p) => sendSSE(res, 'progress', { step: 'oauth', ...p }),
          });
          sendSSE(res, 'oauth', {
            strategy: session.oauth.strategy,
            provider: session.oauth.finalConfig?.provider_name,
            authorizationUrl: session.oauth.finalConfig?.authorization_url,
            tokenUrl: session.oauth.finalConfig?.token_url,
            scopes: session.oauth.finalConfig?.scopes?.required || [],
          });
        }

        // Phase 3 — Mapping
        sendSSE(res, 'progress', { step: 'mapping', message: 'Generating table mappings...' });
        session.mapping = generateMappingPlan(session.discovery, { include, exclude });
        sendSSE(res, 'mapping', {
          tableCount: session.mapping.tables.length,
          tables: session.mapping.tables.map(t => ({
            name: t.tableName,
            columns: t.columns.length,
            primaryKey: t.primaryKey,
            source: t.endpoint?.path || t.sourceEndpoints?.[0]?.path,
          })),
          ddlCount: session.mapping.ddl.length,
        });

        sendSSE(res, 'complete', { ok: true });
      } catch (err) {
        sendSSE(res, 'error', { message: err.message });
      } finally {
        res.end();
      }
    })();
  });

  // ── SSE: POST /api/sessions/:id/migrate — execute ────────
  app.post('/api/sessions/:id/migrate', (req, res) => {
    const session = getSession(req.params.id);
    if (!session.mapping) return res.status(400).json({ error: 'Run discovery & planning first' });

    sseHeaders(res);

    const { dryRun = true } = req.body || {};
    const authToken = session.config?.auth?.type === 'bearer' ? session.config.auth.token : null;

    (async () => {
      try {
        sendSSE(res, 'progress', { step: 'migration', message: dryRun ? 'Starting dry-run...' : 'Starting migration...' });

        session.migration = await executeMigration(session.mapping, {
          dryRun,
          authToken,
          onProgress: (p) => sendSSE(res, 'progress', { step: 'migration', ...p }),
        });

        sendSSE(res, 'migration', {
          dryRun: session.migration.dryRun,
          totalRecords: session.migration.totalRecords,
          tables: session.migration.tables.map(t => ({
            name: t.tableName,
            source: t.sourceEndpoint,
            extracted: t.recordsExtracted,
            loaded: t.recordsLoaded,
            status: t.status,
            errors: t.errors,
            sampleData: t.sampleData?.slice(0, 2),
          })),
          errors: session.migration.errors,
        });

        sendSSE(res, 'complete', { ok: true });
      } catch (err) {
        sendSSE(res, 'error', { message: err.message });
      } finally {
        res.end();
      }
    })();
  });

  return app;
}

// ── SSE helpers ───────────────────────────────────────────────
function sseHeaders(res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  });
}

function sendSSE(res, event, data) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

/**
 * Start the web server.
 */
function startServer({ port = 3000 } = {}) {
  const app = createApp();
  return new Promise((resolve) => {
    const server = app.listen(port, () => resolve(server));
  });
}

module.exports = { createApp, startServer };
