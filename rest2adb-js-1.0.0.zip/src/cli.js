#!/usr/bin/env node

/**
 * CLI interface for data-migration-rest2adb-js.
 *
 * Usage:
 *   rest2adb discover <url>     Discover API endpoints
 *   rest2adb oauth <url>        Auto-configure OAuth 2.0
 *   rest2adb map <url>          Generate ADB table mappings
 *   rest2adb plan <url>         Full pipeline: discover + oauth + map
 *   rest2adb migrate <url>      Execute migration (dry-run by default)
 */

const { program } = require('commander');
const chalk = require('chalk');
const ora = require('ora');
const fs = require('fs');
const path = require('path');

const { discoverApi } = require('./discovery');
const { autoConfigureOAuth } = require('./oauth');
const { generateMappingPlan } = require('./mapping');
const { executeMigration } = require('./migration/executor');
const { generateConfigHtml } = require('./oauth/config-ui-generator');
const { run } = require('./index');
const { startServer } = require('./web/server');

program
  .name('rest2adb')
  .description('Automated REST API endpoint discovery and data migration to Oracle Autonomous Database')
  .version('1.0.0');

// ========== DISCOVER ==========
program
  .command('discover <url>')
  .description('Discover REST API endpoints from a base URL')
  .option('-H, --header <headers...>', 'HTTP headers (format: "Key: Value")')
  .option('--token <token>', 'Bearer token for authentication')
  .option('-o, --output <file>', 'Write results to JSON file')
  .option('--format <format>', 'Output format: json, table, summary', 'summary')
  .action(async (url, opts) => {
    const spinner = ora('Discovering API endpoints...').start();

    try {
      const headers = parseHeaders(opts.header);
      const auth = opts.token ? { type: 'bearer', token: opts.token } : null;

      const result = await discoverApi(url, {
        headers,
        auth,
        onProgress: (p) => {
          spinner.text = p.message || 'Discovering...';
        },
      });

      spinner.succeed(`Discovery complete via ${chalk.cyan(result.discoveryMethod)}`);

      if (opts.format === 'json') {
        const json = JSON.stringify(result, null, 2);
        if (opts.output) {
          fs.writeFileSync(opts.output, json);
          console.log(chalk.green(`Results written to ${opts.output}`));
        } else {
          console.log(json);
        }
      } else if (opts.format === 'table') {
        printEndpointTable(result.endpoints);
      } else {
        printDiscoverySummary(result);
      }

      if (opts.output && opts.format !== 'json') {
        fs.writeFileSync(opts.output, JSON.stringify(result, null, 2));
        console.log(chalk.green(`Full results written to ${opts.output}`));
      }
    } catch (err) {
      spinner.fail(`Discovery failed: ${err.message}`);
      process.exit(1);
    }
  });

// ========== OAUTH ==========
program
  .command('oauth <url>')
  .description('Auto-configure OAuth 2.0 for a REST API')
  .option('-o, --output <file>', 'Write config to JSON file')
  .option('--html <file>', 'Generate HTML configuration UI')
  .option('--force-claude', 'Force Claude AI research even for known providers')
  .action(async (url, opts) => {
    const spinner = ora('Configuring OAuth 2.0...').start();

    try {
      // Quick discovery first for context
      const discovery = await discoverApi(url, {
        onProgress: (p) => { spinner.text = `Discovery: ${p.message || '...'}`; },
      });

      const result = await autoConfigureOAuth(url, discovery, {
        forceClaudeResearch: opts.forceClaude,
        onProgress: (p) => { spinner.text = `OAuth: ${p.message || '...'}`; },
      });

      spinner.succeed(`OAuth configured via ${chalk.cyan(result.strategy)}`);

      // Print summary
      const config = result.finalConfig;
      console.log();
      console.log(chalk.bold('Provider:'), config.provider_name);
      console.log(chalk.bold('Auth URL:'), config.authorization_url || chalk.yellow('(not found)'));
      console.log(chalk.bold('Token URL:'), config.token_url || chalk.yellow('(not found)'));
      console.log(chalk.bold('Scopes:'), config.scopes.required.join(', ') || chalk.yellow('(none)'));
      console.log(chalk.bold('PKCE:'), config.client_config.pkce_required ? chalk.green('Required') : 'Optional');

      if (config.dynamic_fields.length > 0) {
        console.log();
        console.log(chalk.bold('Required configuration fields:'));
        for (const field of config.dynamic_fields) {
          console.log(`  ${chalk.cyan(field.name)}: ${field.description}`);
        }
      }

      if (config.notes?.length > 0) {
        console.log();
        console.log(chalk.bold('Notes:'));
        for (const note of config.notes) {
          console.log(`  - ${note}`);
        }
      }

      // Write output
      if (opts.output) {
        fs.writeFileSync(opts.output, JSON.stringify(result, null, 2));
        console.log(chalk.green(`\nFull config written to ${opts.output}`));
      }

      // Generate HTML UI
      if (opts.html) {
        const html = generateConfigHtml(config, result.configUI);
        fs.writeFileSync(opts.html, html);
        console.log(chalk.green(`OAuth configuration UI written to ${opts.html}`));
      }
    } catch (err) {
      spinner.fail(`OAuth configuration failed: ${err.message}`);
      process.exit(1);
    }
  });

// ========== MAP ==========
program
  .command('map <url>')
  .description('Generate ADB table mappings from discovered endpoints')
  .option('-H, --header <headers...>', 'HTTP headers')
  .option('--token <token>', 'Bearer token')
  .option('-o, --output <file>', 'Write mapping to JSON file')
  .option('--ddl <file>', 'Write DDL statements to SQL file')
  .option('--include <pattern>', 'Include only endpoints matching pattern')
  .option('--exclude <pattern>', 'Exclude endpoints matching pattern')
  .action(async (url, opts) => {
    const spinner = ora('Generating migration mapping...').start();

    try {
      const headers = parseHeaders(opts.header);
      const auth = opts.token ? { type: 'bearer', token: opts.token } : null;

      const discovery = await discoverApi(url, {
        headers,
        auth,
        onProgress: (p) => { spinner.text = `Discovery: ${p.message || '...'}`; },
      });

      spinner.text = 'Generating table mappings...';
      const plan = generateMappingPlan(discovery, {
        include: opts.include,
        exclude: opts.exclude,
      });

      spinner.succeed(`Mapping complete: ${plan.tables.length} tables`);

      // Print summary
      console.log();
      console.log(chalk.bold(`${plan.totalEndpoints} endpoints discovered, ${plan.dataEndpoints} data endpoints mapped to ${plan.tables.length} tables:\n`));

      for (const table of plan.tables) {
        console.log(`  ${chalk.cyan(table.tableName)}`);
        console.log(`    Source: ${table.endpoint.path}`);
        console.log(`    Columns: ${table.columns.length} (PK: ${table.primaryKey})`);
        console.log();
      }

      // Write outputs
      if (opts.output) {
        fs.writeFileSync(opts.output, JSON.stringify(plan, null, 2));
        console.log(chalk.green(`Mapping plan written to ${opts.output}`));
      }

      if (opts.ddl) {
        const ddl = plan.ddl.join(';\n\n') + ';';
        fs.writeFileSync(opts.ddl, ddl);
        console.log(chalk.green(`DDL statements written to ${opts.ddl}`));
      }
    } catch (err) {
      spinner.fail(`Mapping failed: ${err.message}`);
      process.exit(1);
    }
  });

// ========== PLAN (full pipeline) ==========
program
  .command('plan <url>')
  .description('Full pipeline: discover endpoints, configure OAuth, generate mappings')
  .option('-H, --header <headers...>', 'HTTP headers')
  .option('--token <token>', 'Bearer token')
  .option('-o, --output-dir <dir>', 'Output directory for all artifacts', './rest2adb-output')
  .option('--skip-oauth', 'Skip OAuth configuration')
  .option('--include <pattern>', 'Include only endpoints matching pattern')
  .option('--exclude <pattern>', 'Exclude endpoints matching pattern')
  .action(async (url, opts) => {
    const spinner = ora('Running full pipeline...').start();

    try {
      const outputDir = opts.outputDir;
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }

      const result = await run(url, {
        headers: parseHeaders(opts.header),
        auth: opts.token ? { type: 'bearer', token: opts.token } : null,
        skipOAuth: opts.skipOauth,
        include: opts.include,
        exclude: opts.exclude,
        onProgress: (p) => {
          spinner.text = `[${p.step}] ${p.message || '...'}`;
        },
      });

      spinner.succeed('Pipeline complete!');

      // Write all artifacts
      fs.writeFileSync(
        path.join(outputDir, 'discovery.json'),
        JSON.stringify(result.discovery, null, 2)
      );

      if (result.oauth) {
        fs.writeFileSync(
          path.join(outputDir, 'oauth-config.json'),
          JSON.stringify(result.oauth, null, 2)
        );

        const html = generateConfigHtml(result.oauth.finalConfig, result.oauth.configUI);
        fs.writeFileSync(path.join(outputDir, 'oauth-config.html'), html);
      }

      if (result.mapping) {
        fs.writeFileSync(
          path.join(outputDir, 'mapping-plan.json'),
          JSON.stringify(result.mapping, null, 2)
        );

        const ddl = result.mapping.ddl.join(';\n\n') + ';';
        fs.writeFileSync(path.join(outputDir, 'schema.sql'), ddl);

        fs.writeFileSync(
          path.join(outputDir, 'migration-config.json'),
          JSON.stringify(result.mapping.migrationConfig, null, 2)
        );
      }

      // Print summary
      console.log();
      console.log(chalk.bold('Pipeline Results:'));
      console.log(`  Discovery: ${chalk.cyan(result.discovery?.discoveryMethod || 'N/A')} — ${result.discovery?.endpoints?.length || 0} endpoints`);
      if (result.oauth) {
        console.log(`  OAuth:     ${chalk.cyan(result.oauth.strategy || 'N/A')} — ${result.oauth.finalConfig?.provider_name || 'Unknown'}`);
      }
      if (result.mapping) {
        console.log(`  Mapping:   ${chalk.cyan(result.mapping.tables?.length || 0)} tables — ${result.mapping.ddl?.length || 0} DDL statements`);
      }
      console.log();
      console.log(chalk.green(`All artifacts written to ${outputDir}/`));
      console.log(`  discovery.json     — API discovery results`);
      if (result.oauth) {
        console.log(`  oauth-config.json  — OAuth 2.0 configuration`);
        console.log(`  oauth-config.html  — OAuth configuration UI`);
      }
      if (result.mapping) {
        console.log(`  mapping-plan.json  — Table mapping plan`);
        console.log(`  schema.sql         — ADB DDL statements`);
        console.log(`  migration-config.json — Migration configuration`);
      }
    } catch (err) {
      spinner.fail(`Pipeline failed: ${err.message}`);
      process.exit(1);
    }
  });

// ========== MIGRATE ==========
program
  .command('migrate <url>')
  .description('Execute migration (dry-run by default)')
  .option('-H, --header <headers...>', 'HTTP headers')
  .option('--token <token>', 'Bearer token for API access')
  .option('--execute', 'Actually execute the migration (default is dry-run)')
  .option('-o, --output <file>', 'Write results to JSON file')
  .action(async (url, opts) => {
    const spinner = ora('Running migration...').start();
    const isDryRun = !opts.execute;

    if (isDryRun) {
      console.log(chalk.yellow('Running in DRY-RUN mode. Use --execute to perform actual migration.\n'));
    }

    try {
      const result = await run(url, {
        headers: parseHeaders(opts.header),
        auth: opts.token ? { type: 'bearer', token: opts.token } : null,
        execute: true,
        dryRun: isDryRun,
        authToken: opts.token,
        onProgress: (p) => {
          spinner.text = `[${p.step}] ${p.message || '...'}`;
        },
      });

      spinner.succeed(isDryRun ? 'Dry-run complete!' : 'Migration complete!');

      if (result.migration) {
        console.log();
        console.log(chalk.bold('Migration Results:'));
        console.log(`  Total records: ${result.migration.totalRecords}`);
        for (const table of result.migration.tables) {
          const status = table.status === 'completed' ? chalk.green(table.status) :
            table.status === 'dry-run' ? chalk.yellow(table.status) :
            chalk.red(table.status);
          console.log(`  ${table.tableName}: ${table.recordsExtracted} records [${status}]`);
        }
      }

      if (opts.output) {
        fs.writeFileSync(opts.output, JSON.stringify(result, null, 2));
        console.log(chalk.green(`\nResults written to ${opts.output}`));
      }
    } catch (err) {
      spinner.fail(`Migration failed: ${err.message}`);
      process.exit(1);
    }
  });

// ========== WEB UI ==========
program
  .command('web')
  .description('Launch the web-based migration console')
  .option('-p, --port <port>', 'Port to listen on', '3000')
  .action(async (opts) => {
    const port = parseInt(opts.port, 10);
    const server = await startServer({ port });
    const addr = server.address();
    console.log();
    console.log(chalk.bold('REST → ADB Migration Console'));
    console.log(chalk.green(`  http://localhost:${addr.port}`));
    console.log();
    console.log(chalk.dim('Press Ctrl+C to stop.'));
  });

// ========== Helpers ==========

function parseHeaders(headerArgs) {
  const headers = {};
  if (!headerArgs) return headers;
  for (const h of headerArgs) {
    const idx = h.indexOf(':');
    if (idx > 0) {
      headers[h.substring(0, idx).trim()] = h.substring(idx + 1).trim();
    }
  }
  return headers;
}

function printEndpointTable(endpoints) {
  console.log();
  console.log(chalk.bold(`${'Method'.padEnd(8)} ${'Path'.padEnd(50)} ${'Summary'}`));
  console.log('-'.repeat(100));
  for (const ep of endpoints) {
    const method = colorMethod(ep.method);
    console.log(`${method.padEnd(8)} ${ep.path.padEnd(50)} ${ep.summary || ''}`);
  }
  console.log();
}

function printDiscoverySummary(result) {
  console.log();
  console.log(chalk.bold('API Discovery Summary'));
  console.log(`  Base URL:  ${chalk.cyan(result.baseUrl)}`);
  console.log(`  Method:    ${chalk.cyan(result.discoveryMethod)}`);
  if (result.specVersion) {
    console.log(`  Spec:      ${result.specVersion}`);
  }
  if (result.apiInfo?.title) {
    console.log(`  API Name:  ${result.apiInfo.title}`);
  }
  console.log(`  Endpoints: ${chalk.green(result.endpoints.length)}`);

  if (result.endpoints.length > 0) {
    console.log();
    console.log(chalk.bold('  Endpoints:'));
    for (const ep of result.endpoints.slice(0, 30)) {
      const method = colorMethod(ep.method);
      console.log(`    ${method} ${ep.path}`);
    }
    if (result.endpoints.length > 30) {
      console.log(`    ... and ${result.endpoints.length - 30} more`);
    }
  }

  if (result.warnings.length > 0) {
    console.log();
    console.log(chalk.yellow('  Warnings:'));
    for (const w of result.warnings.slice(0, 10)) {
      console.log(`    - ${w}`);
    }
  }
  console.log();
}

function colorMethod(method) {
  const m = (method || 'GET').toUpperCase();
  switch (m) {
    case 'GET': return chalk.green(m);
    case 'POST': return chalk.blue(m);
    case 'PUT': return chalk.yellow(m);
    case 'PATCH': return chalk.yellow(m);
    case 'DELETE': return chalk.red(m);
    default: return m;
  }
}

program.parse();
