#!/usr/bin/env bash
# ================================================================
#  REST → ADB Migration Workbench — Server Status
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/.server.pid"

write_ok()   { printf '  [\033[1;32mOK\033[0m]   %s\n' "$*"; }
write_fail() { printf '  [\033[1;31mFAIL\033[0m] %s\n' "$*"; }
write_info() { printf '  [\033[1;36m....\033[0m] %s\n' "$*"; }

# Read version
APP_VERSION="dev"
if [ -f "$SCRIPT_DIR/VERSION" ]; then
    APP_VERSION=$(cat "$SCRIPT_DIR/VERSION" | tr -d '[:space:]')
fi

echo ''
printf '  \033[1;36m REST -> ADB Migration Workbench  v%s\033[0m\n' "$APP_VERSION"
echo ''

# Read host/port from config
HOST_='127.0.0.1'
PORT_=8500
CONFIG_FILE="$SCRIPT_DIR/config/default.yaml"
if [ -f "$CONFIG_FILE" ]; then
    _h=$(grep -E '^\s+host:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *"\{0,1\}\([^"]*\)"\{0,1\}/\1/' || true)
    _p=$(grep -E '^\s+port:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *\([0-9]*\).*/\1/' || true)
    [ -n "$_h" ] && HOST_="$_h"
    [ -n "$_p" ] && PORT_="$_p"
fi
SERVER_URL="http://${HOST_}:${PORT_}"

# Check PID file
if [ ! -f "$PID_FILE" ]; then
    write_fail "Server is not running (no PID file)."
    exit 1
fi

SERVER_PID=$(cat "$PID_FILE")

# Check if process is alive
if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    write_fail "Server is not running (PID $SERVER_PID is stale)."
    rm -f "$PID_FILE"
    exit 1
fi

write_ok "Server process is running (PID $SERVER_PID)"

# Check if HTTP is responding
if command -v curl >/dev/null 2>&1; then
    if curl -s -o /dev/null -w '' --max-time 3 "$SERVER_URL/api/health" 2>/dev/null; then
        write_ok "HTTP responding at $SERVER_URL"
    else
        write_fail "Process is running but HTTP is not responding at $SERVER_URL"
        exit 1
    fi
else
    PYTHON_EXE=""
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            PYTHON_EXE="$cmd"
            break
        fi
    done
    if [ -n "$PYTHON_EXE" ]; then
        if "$PYTHON_EXE" -c "
import urllib.request, sys
try:
    urllib.request.urlopen('$SERVER_URL/api/health', timeout=3)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
            write_ok "HTTP responding at $SERVER_URL"
        else
            write_fail "Process is running but HTTP is not responding at $SERVER_URL"
            exit 1
        fi
    else
        write_info "Cannot verify HTTP (no curl or python found). Process appears alive."
    fi
fi
echo ''
