#!/usr/bin/env python3
"""REST→ADB Migration Workbench — single-file entry point with auto-bootstrap."""
import sys
import os

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Auto-install missing deps
from app.core.bootstrap import auto_install
auto_install()

import yaml
from app.server import create_app

def load_config() -> dict:
    config_path = os.path.join(PROJECT_ROOT, "config", "default.yaml")
    if os.path.exists(config_path):
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    return {}


def main():
    config = load_config()
    app = create_app(config)

    server_cfg = config.get("server", {})
    host = server_cfg.get("host", "127.0.0.1")
    port = server_cfg.get("port", 8500)
    debug = server_cfg.get("debug", False)

    version_file = os.path.join(PROJECT_ROOT, "VERSION")
    version = "dev"
    if os.path.exists(version_file):
        with open(version_file) as vf:
            version = vf.read().strip()

    print(f"\n{'='*60}")
    print(f"  REST → ADB Migration Workbench v{version}")
    print(f"  Running on http://{host}:{port}")
    print(f"{'='*60}\n")

    app.run(host=host, port=port, debug=debug, threaded=True)


if __name__ == "__main__":
    main()
