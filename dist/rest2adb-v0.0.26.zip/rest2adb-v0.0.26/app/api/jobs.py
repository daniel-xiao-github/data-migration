"""Migration job and batch run API routes."""
from __future__ import annotations
import threading
from flask import Blueprint, request, jsonify, current_app

bp = Blueprint("jobs", __name__, url_prefix="/api")

_running_jobs: dict[str, "MigrationOrchestrator"] = {}
_job_lock = threading.Lock()


def _store():
    return current_app.config["STORE"]


def _get_adapter(conn_config: dict):
    target_type = conn_config.get("target_type", "oracle_adb")
    if target_type == "oracle_adb":
        from app.adapters.oracle_adb import OracleAdbAdapter
        return OracleAdbAdapter()
    elif target_type == "postgresql":
        from app.adapters.postgresql import PostgresAdapter
        return PostgresAdapter()
    elif target_type == "mysql":
        from app.adapters.mysql import MySQLAdapter
        return MySQLAdapter()
    raise ValueError(f"Unknown target type: {target_type}")


def _find_conn(store, collection, conn_id):
    for c in store.get(collection, []):
        if c["id"] == conn_id:
            return c
    return None


# ── Migration jobs ───────────────────────────────────────────────────────

@bp.route("/jobs", methods=["POST"])
def create_job():
    """Create a new migration job."""
    data = request.get_json(force=True)
    required = ["name", "rest_connection_id", "target_connection_id", "endpoints"]
    for field in required:
        if field not in data:
            return jsonify({"error": f"{field} required"}), 400

    store = _store()
    rest_conn = _find_conn(store, "rest_connections", data["rest_connection_id"])
    target_conn = _find_conn(store, "target_connections", data["target_connection_id"])
    if not rest_conn:
        return jsonify({"error": "REST connection not found"}), 404
    if not target_conn:
        return jsonify({"error": "Target connection not found"}), 404

    from uuid import uuid4
    job = {
        "id": str(uuid4()),
        "name": data["name"],
        "rest_connection_id": data["rest_connection_id"],
        "target_connection_id": data["target_connection_id"],
        "endpoints": data["endpoints"],
        "sync_mode": data.get("sync_mode", "full"),
        "write_mode": data.get("write_mode", "insert"),
        "batch_size": data.get("batch_size", 500),
        "max_workers": data.get("max_workers", 3),
        "pk_columns": data.get("pk_columns", []),
        "delta_field": data.get("delta_field"),
        "delta_param": data.get("delta_param"),
        "status": "CREATED",
        "total_endpoints": len(data["endpoints"]),
        "completed_endpoints": 0,
        "total_rows_migrated": 0,
    }
    store.setdefault("jobs", []).append(job)
    return jsonify({"id": job["id"], "status": "created"}), 201


@bp.route("/jobs", methods=["GET"])
def list_jobs():
    return jsonify(_store().get("jobs", []))


@bp.route("/jobs/<job_id>", methods=["GET"])
def get_job(job_id):
    for j in _store().get("jobs", []):
        if j["id"] == job_id:
            return jsonify(j)
    return jsonify({"error": "not found"}), 404


@bp.route("/jobs/<job_id>", methods=["DELETE"])
def delete_job(job_id):
    store = _store()
    store["jobs"] = [j for j in store.get("jobs", []) if j["id"] != job_id]
    return jsonify({"status": "deleted"})


@bp.route("/jobs/<job_id>/start", methods=["POST"])
def start_job(job_id):
    """Start running a migration job in a background thread."""
    store = _store()
    job = None
    for j in store.get("jobs", []):
        if j["id"] == job_id:
            job = j
            break
    if not job:
        return jsonify({"error": "not found"}), 404

    with _job_lock:
        if job_id in _running_jobs:
            return jsonify({"error": "job already running"}), 409

    rest_conn_raw = _find_conn(store, "rest_connections", job["rest_connection_id"])
    target_conn_raw = _find_conn(store, "target_connections", job["target_connection_id"])
    if not rest_conn_raw:
        return jsonify({"error": "REST connection not found"}), 404
    if not target_conn_raw:
        return jsonify({"error": "Target connection not found"}), 404

    # Decrypt credentials before handing to the background thread
    rest_conn = dict(rest_conn_raw)
    ac = dict(rest_conn.get("auth_config", {}))
    for k in ("password", "token", "client_secret", "value"):
        if k in ac and ac[k]:
            try:
                from app.core.crypto import decrypt
                ac[k] = decrypt(ac[k])
            except Exception:
                pass
    rest_conn["auth_config"] = ac

    target_conn = dict(target_conn_raw)
    if target_conn.get("password"):
        try:
            from app.core.crypto import decrypt
            target_conn["password"] = decrypt(target_conn["password"])
        except Exception:
            pass

    # Snapshot data needed by the background thread (avoids app-context issues)
    oauth_cfg = current_app.config.get("OAUTH_MANAGER")
    mappings_by_ep = {}
    for ep in job.get("endpoints", []):
        path = ep.get("path", "")
        key = f"mappings_{job['rest_connection_id']}_{path}"
        mappings_by_ep[path] = store.get(key, [])

    all_rules = []
    for ep in job.get("endpoints", []):
        path = ep.get("path", "")
        key = f"rules_{job['rest_connection_id']}_{path}"
        all_rules.extend(store.get(key, []))

    sync_config = {
        "sync_mode": job.get("sync_mode", "full"),
        "write_mode": job.get("write_mode", "insert"),
        "pk_columns": job.get("pk_columns", []),
        "delta_field": job.get("delta_field"),
        "delta_param": job.get("delta_param"),
    }

    config = {
        "batch_size": job.get("batch_size", 500),
        "max_workers": job.get("max_workers", 3),
        "max_retries": 3,
    }

    def _run():
        adapter = None
        try:
            job["status"] = "RUNNING"

            # Heavy setup runs here in the background thread
            from app.core.rest_client import RestClient
            from app.core.mapping_engine import MappingEngine
            from app.core.validation_engine import ValidationEngine
            from app.core.delta_tracker import DeltaTracker
            from app.core.control_table import ControlTableManager
            from app.core.orchestrator import MigrationOrchestrator

            adapter = _get_adapter(target_conn)
            adapter.connect(target_conn)
            ctl = ControlTableManager(adapter)
            ctl.init_tables()

            client = RestClient(rest_conn, oauth_manager=oauth_cfg)

            orch = MigrationOrchestrator(
                rest_client=client, adapter=adapter, control=ctl,
                mapping_engine=MappingEngine(),
                validation_engine=ValidationEngine(rules=all_rules),
                delta_tracker=DeltaTracker(adapter=adapter),
                config=config,
            )

            with _job_lock:
                _running_jobs[job_id] = orch

            result = orch.run_job(job_id, job.get("endpoints", []),
                                  mappings_by_ep, sync_config)
            job["status"] = result.get("status", "COMPLETED")
            job["completed_endpoints"] = result.get("completed_endpoints", 0)
            job["total_rows_migrated"] = result.get("total_rows", 0)
            if result.get("error"):
                job["error_message"] = result["error"]
        except Exception as e:
            job["status"] = "FAILED"
            job["error_message"] = str(e)
        finally:
            with _job_lock:
                _running_jobs.pop(job_id, None)
            if adapter:
                try:
                    adapter.disconnect()
                except Exception:
                    pass

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    job["status"] = "RUNNING"
    return jsonify({"status": "started", "job_id": job_id})


@bp.route("/jobs/<job_id>/cancel", methods=["POST"])
def cancel_job(job_id):
    with _job_lock:
        orch = _running_jobs.get(job_id)
    if orch:
        orch.cancel()
        return jsonify({"status": "cancelling"})
    return jsonify({"error": "job not running"}), 404


@bp.route("/jobs/<job_id>/pause", methods=["POST"])
def pause_job(job_id):
    with _job_lock:
        orch = _running_jobs.get(job_id)
    if orch:
        orch.cancel()
        for j in _store().get("jobs", []):
            if j["id"] == job_id:
                j["status"] = "PAUSED"
        return jsonify({"status": "paused"})
    return jsonify({"error": "job not running"}), 404


@bp.route("/jobs/<job_id>/restart", methods=["POST"])
def restart_job(job_id):
    """Reset a job's state and start it fresh."""
    store = _store()
    job = None
    for j in store.get("jobs", []):
        if j["id"] == job_id:
            job = j
            break
    if not job:
        return jsonify({"error": "not found"}), 404

    with _job_lock:
        if job_id in _running_jobs:
            return jsonify({"error": "job is currently running — cancel it first"}), 409

    # Reset progress
    job["status"] = "CREATED"
    job["completed_endpoints"] = 0
    job["total_rows_migrated"] = 0
    job.pop("error_message", None)

    # Delegate to start
    return start_job(job_id)


@bp.route("/jobs/<job_id>/logs", methods=["GET"])
def get_job_logs(job_id):
    """Return log lines relevant to a specific job."""
    import os
    store = _store()
    job = None
    for j in store.get("jobs", []):
        if j["id"] == job_id:
            job = j
            break
    if not job:
        return jsonify({"error": "not found"}), 404

    # Collect search terms: job endpoint paths and table names
    terms = set()
    for ep in job.get("endpoints", []):
        path = ep.get("path", "")
        if path:
            terms.add(path)
        table = ep.get("target_table", "")
        if table:
            terms.add(table)
    terms.add(job_id)

    log_path = current_app.config.get("LOG_FILE", "logs/migration.log")
    project_root = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    full_path = os.path.join(project_root, log_path)

    if not os.path.exists(full_path):
        return jsonify({"lines": []})

    limit = request.args.get("lines", 500, type=int)
    matched = []
    with open(full_path, "r") as f:
        for line in f:
            stripped = line.rstrip()
            if any(t in stripped for t in terms):
                matched.append(stripped)

    return jsonify({"lines": matched[-limit:]})


# ── Batch runs ───────────────────────────────────────────────────────────

@bp.route("/batch-runs", methods=["POST"])
def create_batch_run():
    data = request.get_json(force=True)
    name = data.get("name", "batch")
    job_ids = data.get("job_ids", [])
    concurrency = data.get("concurrency", 5)
    if not job_ids:
        return jsonify({"error": "job_ids required"}), 400

    from uuid import uuid4
    batch_run = {
        "batch_run_id": str(uuid4()),
        "name": name,
        "job_ids": job_ids,
        "concurrency": concurrency,
        "status": "CREATED",
        "total_jobs": len(job_ids),
        "completed_jobs": 0,
        "failed_jobs": 0,
    }
    store = _store()
    store.setdefault("batch_runs", []).append(batch_run)
    return jsonify({"batch_run_id": batch_run["batch_run_id"],
                     "status": "created"}), 201


@bp.route("/batch-runs", methods=["GET"])
def list_batch_runs():
    return jsonify(_store().get("batch_runs", []))


@bp.route("/batch-runs/<run_id>", methods=["GET"])
def get_batch_run(run_id):
    for br in _store().get("batch_runs", []):
        if br["batch_run_id"] == run_id:
            return jsonify(br)
    return jsonify({"error": "not found"}), 404


@bp.route("/batch-runs/<run_id>/start", methods=["POST"])
def start_batch_run(run_id):
    """Start a batch run — runs its jobs concurrently."""
    store = _store()
    batch_run = None
    for br in store.get("batch_runs", []):
        if br["batch_run_id"] == run_id:
            batch_run = br
            break
    if not batch_run:
        return jsonify({"error": "not found"}), 404

    concurrency = batch_run.get("concurrency", 5)
    job_ids = batch_run.get("job_ids", [])

    def _run_all():
        batch_run["status"] = "RUNNING"
        completed = 0
        failed = 0
        from concurrent.futures import ThreadPoolExecutor, as_completed as ac
        import requests as _req

        def _run_single(jid):
            try:
                _req.post(f"http://127.0.0.1:{current_app.config.get('PORT', 8500)}"
                          f"/api/jobs/{jid}/start", timeout=5)
            except Exception:
                pass

        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futs = {pool.submit(_run_single, jid): jid for jid in job_ids}
            for f in ac(futs):
                try:
                    f.result()
                    completed += 1
                except Exception:
                    failed += 1
        batch_run["completed_jobs"] = completed
        batch_run["failed_jobs"] = failed
        if failed == 0:
            batch_run["status"] = "COMPLETED"
        elif completed > 0:
            batch_run["status"] = "PARTIAL_FAILURE"
        else:
            batch_run["status"] = "FAILED"

    t = threading.Thread(target=_run_all, daemon=True)
    t.start()
    batch_run["status"] = "RUNNING"
    return jsonify({"status": "started"})


@bp.route("/batch-runs/<run_id>/cancel", methods=["POST"])
def cancel_batch_run(run_id):
    for br in _store().get("batch_runs", []):
        if br["batch_run_id"] == run_id:
            br["status"] = "CANCELLED"
            for jid in br.get("job_ids", []):
                with _job_lock:
                    orch = _running_jobs.get(jid)
                if orch:
                    orch.cancel()
            return jsonify({"status": "cancelling"})
    return jsonify({"error": "not found"}), 404


# ── Quarantine ───────────────────────────────────────────────────────────

@bp.route("/jobs/<job_id>/quarantine", methods=["GET"])
def get_quarantine(job_id):
    store = _store()
    key = f"quarantine_{job_id}"
    return jsonify(store.get(key, []))
