"""MySQL adapter for rest2adb."""
from __future__ import annotations

import logging
import re
import time
from typing import Any

from .base import (
    ColumnDef,
    ColumnInfo,
    ConnectionTestResult,
    TargetAdapter,
)

logger = logging.getLogger(__name__)

try:
    import mysql.connector
except ImportError:
    mysql = None  # type: ignore[assignment]
    _mysql_available = False
else:
    _mysql_available = True


class MySQLAdapter(TargetAdapter):
    """Adapter for MySQL databases using mysql-connector-python."""

    def __init__(self) -> None:
        self._conn: Any | None = None
        self._config: dict | None = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self, config: dict) -> None:
        if not _mysql_available:
            raise RuntimeError(
                "The 'mysql-connector-python' package is required for MySQL connections. "
                "Install it with:  pip install mysql-connector-python"
            )

        self._config = config

        host: str = config["host"]
        port: int = config.get("port", 3306)
        database: str = config["database"]
        user: str = config["username"]
        password: str = config["password"]
        charset: str = config.get("charset", "utf8mb4")
        collation: str = config.get("collation", "utf8mb4_unicode_ci")

        self._conn = mysql.connector.connect(
            host=host,
            port=port,
            database=database,
            user=user,
            password=password,
            charset=charset,
            collation=collation,
            autocommit=False,
        )
        logger.info("MySQL connection established (host=%s, db=%s)", host, database)

    def disconnect(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                logger.warning("Error closing MySQL connection", exc_info=True)
            finally:
                self._conn = None
        logger.info("MySQL connection closed")

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def test_connection(self) -> ConnectionTestResult:
        start = time.perf_counter()
        try:
            cur = self._conn.cursor()
            try:
                cur.execute("SELECT 1")
                cur.fetchone()
            finally:
                cur.close()
            latency = (time.perf_counter() - start) * 1000.0

            version: str | None = None
            try:
                cur = self._conn.cursor()
                try:
                    cur.execute("SELECT VERSION()")
                    row = cur.fetchone()
                    if row:
                        version = row[0]
                finally:
                    cur.close()
            except Exception:
                pass

            return ConnectionTestResult(
                success=True,
                latency_ms=round(latency, 2),
                message="Connection successful",
                version=version,
            )
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000.0
            return ConnectionTestResult(
                success=False,
                latency_ms=round(latency, 2),
                message=str(exc),
            )

    # ------------------------------------------------------------------
    # Schema introspection
    # ------------------------------------------------------------------

    def table_exists(self, table_name: str) -> bool:
        sql = (
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_schema = DATABASE() AND table_name = %s"
        )
        cur = self._conn.cursor()
        try:
            cur.execute(sql, (table_name,))
            row = cur.fetchone()
            return row is not None and row[0] > 0
        finally:
            cur.close()

    def get_columns(self, table_name: str) -> list[ColumnInfo]:
        sql = (
            "SELECT column_name, data_type, is_nullable, "
            "character_maximum_length, numeric_precision, numeric_scale "
            "FROM information_schema.columns "
            "WHERE table_schema = DATABASE() AND table_name = %s "
            "ORDER BY ordinal_position"
        )
        columns: list[ColumnInfo] = []
        cur = self._conn.cursor()
        try:
            cur.execute(sql, (table_name,))
            for row in cur.fetchall():
                columns.append(
                    ColumnInfo(
                        name=row[0],
                        data_type=row[1],
                        nullable=(row[2] == "YES"),
                        max_length=row[3],
                        precision=row[4],
                        scale=row[5],
                    )
                )
        finally:
            cur.close()
        return columns

    # ------------------------------------------------------------------
    # DDL helpers
    # ------------------------------------------------------------------

    def create_table(self, table_name: str, columns: list[ColumnDef]) -> str:
        col_defs: list[str] = []
        pk_cols: list[str] = []

        for col in columns:
            parts = [f"`{col.name}` {col.data_type}"]
            if not col.nullable:
                parts.append("NOT NULL")
            col_defs.append(" ".join(parts))
            if col.primary_key:
                pk_cols.append(f"`{col.name}`")

        if pk_cols:
            col_defs.append(f"PRIMARY KEY ({', '.join(pk_cols)})")

        ddl = (
            f"CREATE TABLE `{table_name}` (\n  "
            + ",\n  ".join(col_defs)
            + "\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        )
        self.execute_ddl(ddl)
        return ddl

    # ------------------------------------------------------------------
    # DML
    # ------------------------------------------------------------------

    def insert_batch(self, table_name: str, columns: list[str], rows: list[tuple]) -> int:
        if not rows:
            return 0

        col_list = ", ".join(f"`{c}`" for c in columns)
        placeholders = ", ".join(["%s"] * len(columns))
        sql = f"INSERT INTO `{table_name}` ({col_list}) VALUES ({placeholders})"

        cur = self._conn.cursor()
        try:
            cur.executemany(sql, rows)
        finally:
            cur.close()
        self._conn.commit()

        return len(rows)

    def upsert_batch(
        self, table_name: str, columns: list[str], pk_columns: list[str], rows: list[tuple]
    ) -> int:
        if not rows:
            return 0

        non_pk = [c for c in columns if c not in pk_columns]

        col_list = ", ".join(f"`{c}`" for c in columns)
        placeholders = ", ".join(["%s"] * len(columns))

        if non_pk:
            update_parts = [f"`{c}` = VALUES(`{c}`)" for c in non_pk]
            update_clause = ", ".join(update_parts)
            sql = (
                f"INSERT INTO `{table_name}` ({col_list}) VALUES ({placeholders}) "
                f"ON DUPLICATE KEY UPDATE {update_clause}"
            )
        else:
            # All columns are PKs -- use INSERT IGNORE to skip duplicates
            sql = f"INSERT IGNORE INTO `{table_name}` ({col_list}) VALUES ({placeholders})"

        cur = self._conn.cursor()
        try:
            cur.executemany(sql, rows)
        finally:
            cur.close()
        self._conn.commit()

        return len(rows)

    def truncate_table(self, table_name: str) -> None:
        self.execute_ddl(f"TRUNCATE TABLE `{table_name}`")

    def execute_ddl(self, sql: str) -> None:
        cur = self._conn.cursor()
        try:
            cur.execute(sql)
        finally:
            cur.close()
        self._conn.commit()

    # ------------------------------------------------------------------
    # Generic query / update
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_sql(sql: str) -> str:
        """Convert Oracle-style :N bind params to MySQL %s style."""
        return re.sub(r":\d+", "%s", sql)

    def execute_query(self, sql: str, params: dict | tuple | None = None) -> list[dict]:
        sql = self._convert_sql(sql)
        cur = self._conn.cursor()
        try:
            if params is not None:
                cur.execute(sql, params)
            else:
                cur.execute(sql)
            col_names = [desc[0].upper() for desc in cur.description]
            results = [dict(zip(col_names, row)) for row in cur.fetchall()]
        finally:
            cur.close()
        return results

    def execute_update(self, sql: str, params: dict | tuple | None = None) -> int:
        sql = self._convert_sql(sql)
        cur = self._conn.cursor()
        try:
            if params is not None:
                cur.execute(sql, params)
            else:
                cur.execute(sql)
            rowcount = cur.rowcount
        finally:
            cur.close()
        self._conn.commit()
        return rowcount

    # ------------------------------------------------------------------
    # Control tables
    # ------------------------------------------------------------------

    def init_control_tables(self, prefix: str) -> None:
        """Create the rest2adb control tables if they do not already exist.

        Column names match those used by ControlTableManager.
        Uses CREATE TABLE IF NOT EXISTS for idempotency.
        """
        p = prefix.upper()

        statements: list[str] = [
            f"""CREATE TABLE IF NOT EXISTS `{p}MIGRATION_JOB` (
                `JOB_ID`                VARCHAR(64) NOT NULL PRIMARY KEY,
                `JOB_NAME`              VARCHAR(256),
                `STATUS`                VARCHAR(32) DEFAULT 'CREATED',
                `REST_CONNECTION_ID`    VARCHAR(64),
                `ADB_CONNECTION_ID`     VARCHAR(64),
                `CONFIG_JSON`           LONGTEXT,
                `CREATED_AT`            TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                `STARTED_AT`            TIMESTAMP NULL DEFAULT NULL,
                `COMPLETED_AT`          TIMESTAMP NULL DEFAULT NULL,
                `ERROR_MESSAGE`         LONGTEXT,
                `TOTAL_ENDPOINTS`       INT DEFAULT 0,
                `COMPLETED_ENDPOINTS`   INT DEFAULT 0,
                `TOTAL_ROWS_MIGRATED`   BIGINT DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}ENDPOINT_STATE` (
                `ENDPOINT_STATE_ID`     VARCHAR(64) NOT NULL PRIMARY KEY,
                `JOB_ID`               VARCHAR(64),
                `ENDPOINT_PATH`        VARCHAR(1024),
                `TARGET_TABLE`         VARCHAR(256),
                `STATUS`               VARCHAR(32) DEFAULT 'PENDING',
                `LAST_PAGE_CURSOR`     VARCHAR(4000),
                `LAST_SUCCESSFUL_BATCH` INT DEFAULT 0,
                `ROWS_FETCHED`         BIGINT DEFAULT 0,
                `ROWS_INSERTED`        BIGINT DEFAULT 0,
                `STARTED_AT`           TIMESTAMP NULL DEFAULT NULL,
                `COMPLETED_AT`         TIMESTAMP NULL DEFAULT NULL,
                `ERROR_MESSAGE`        LONGTEXT,
                `RETRY_COUNT`          INT DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}BATCH_LOG` (
                `BATCH_ID`             VARCHAR(64) NOT NULL PRIMARY KEY,
                `ENDPOINT_STATE_ID`    VARCHAR(64),
                `BATCH_SEQ`            INT,
                `PAGE_PARAM`           VARCHAR(4000),
                `ROWS_IN_BATCH`        INT DEFAULT 0,
                `STATUS`               VARCHAR(32),
                `STARTED_AT`           TIMESTAMP NULL DEFAULT NULL,
                `COMPLETED_AT`         TIMESTAMP NULL DEFAULT NULL,
                `ERROR_MESSAGE`        LONGTEXT
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}SYNC_STATE` (
                `SYNC_STATE_ID`        VARCHAR(64) NOT NULL PRIMARY KEY,
                `JOB_ID`               VARCHAR(64),
                `ENDPOINT_PATH`        VARCHAR(1024),
                `SYNC_MODE`            VARCHAR(32),
                `DELTA_FIELD`          VARCHAR(256),
                `DELTA_PARAM`          VARCHAR(256),
                `LAST_DELTA_VALUE`     VARCHAR(4000),
                `LAST_ETAG`            VARCHAR(4000),
                `LAST_SYNC_AT`         TIMESTAMP NULL DEFAULT NULL,
                `ROWS_SYNCED`          BIGINT DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}QUARANTINE` (
                `QUARANTINE_ID`        VARCHAR(64) NOT NULL PRIMARY KEY,
                `JOB_ID`               VARCHAR(64),
                `ENDPOINT_PATH`        VARCHAR(1024),
                `BATCH_SEQ`            INT,
                `ROW_DATA`             LONGTEXT,
                `VIOLATIONS`           LONGTEXT,
                `SEVERITY`             VARCHAR(32),
                `CREATED_AT`           TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                `RESOLVED`             VARCHAR(1) DEFAULT 'N'
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}BATCH_RUN` (
                `BATCH_RUN_ID`         VARCHAR(64) NOT NULL PRIMARY KEY,
                `BATCH_NAME`           VARCHAR(256),
                `STATUS`               VARCHAR(32) DEFAULT 'CREATED',
                `CONCURRENCY`          INT DEFAULT 5,
                `CREATED_AT`           TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
                `STARTED_AT`           TIMESTAMP NULL DEFAULT NULL,
                `COMPLETED_AT`         TIMESTAMP NULL DEFAULT NULL,
                `TOTAL_JOBS`           INT DEFAULT 0,
                `COMPLETED_JOBS`       INT DEFAULT 0,
                `FAILED_JOBS`          INT DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
            f"""CREATE TABLE IF NOT EXISTS `{p}BATCH_RUN_JOBS` (
                `BATCH_RUN_ID`         VARCHAR(64) NOT NULL,
                `JOB_ID`               VARCHAR(64) NOT NULL,
                `EXECUTION_ORDER`      INT,
                `STATUS`               VARCHAR(32) DEFAULT 'PENDING',
                `STARTED_AT`           TIMESTAMP NULL DEFAULT NULL,
                `COMPLETED_AT`         TIMESTAMP NULL DEFAULT NULL,
                PRIMARY KEY (`BATCH_RUN_ID`, `JOB_ID`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
        ]

        cur = self._conn.cursor()
        try:
            for ddl in statements:
                cur.execute(ddl)
        finally:
            cur.close()
        self._conn.commit()

        logger.info("MySQL control tables initialised (prefix=%s)", prefix)
