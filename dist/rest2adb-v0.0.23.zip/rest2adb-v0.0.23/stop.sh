#!/usr/bin/env bash
# ================================================================
#  REST → ADB Migration Workbench — Stop Server
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/.server.pid"

write_ok()   { printf '  [\033[1;32mOK\033[0m]   %s\n' "$*"; }
write_fail() { printf '  [\033[1;31mFAIL\033[0m] %s\n' "$*"; }
write_info() { printf '  [\033[1;36m....\033[0m] %s\n' "$*"; }

if [ ! -f "$PID_FILE" ]; then
    write_fail "No server PID file found. Is the server running?"
    exit 1
fi

SERVER_PID=$(cat "$PID_FILE")

if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    write_info "Server (PID $SERVER_PID) is not running. Cleaning up PID file."
    rm -f "$PID_FILE"
    exit 0
fi

write_info "Stopping server (PID $SERVER_PID)..."
kill "$SERVER_PID" 2>/dev/null || true

# Wait up to 5 seconds for graceful shutdown
for i in $(seq 1 10); do
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
        break
    fi
    sleep 0.5
done

# Force kill if still running
if kill -0 "$SERVER_PID" 2>/dev/null; then
    write_info "Force stopping server..."
    kill -9 "$SERVER_PID" 2>/dev/null || true
fi

rm -f "$PID_FILE"
write_ok "Server stopped."
