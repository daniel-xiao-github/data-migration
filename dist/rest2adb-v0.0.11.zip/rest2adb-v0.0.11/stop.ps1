# ================================================================
#  REST -> ADB Migration Workbench - Stop Server
# ================================================================
$ErrorActionPreference = 'Continue'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

function Write-Status {
    param([string]$Symbol, [string]$Message, [string]$Colour = 'White')
    Write-Host "  [$Symbol] " -NoNewline -ForegroundColor $Colour
    Write-Host $Message
}
function Write-OK   { param([string]$Msg) Write-Status 'OK'   $Msg 'Green' }
function Write-Fail { param([string]$Msg) Write-Status 'FAIL' $Msg 'Red'   }
function Write-Info { param([string]$Msg) Write-Status '....' $Msg 'Cyan'  }

$pidFile = Join-Path $ScriptDir '.server.pid'

if (-not (Test-Path $pidFile)) {
    Write-Fail 'No server PID file found. Is the server running?'
    exit 1
}

$serverPid = (Get-Content $pidFile -Raw).Trim()

try {
    $proc = Get-Process -Id $serverPid -ErrorAction Stop
    Write-Info "Stopping server (PID $serverPid)..."
    $proc.Kill()
    $proc.WaitForExit(5000) | Out-Null
    Write-OK 'Server stopped.'
} catch {
    Write-Info "Server process (PID $serverPid) not found. It may have already stopped."
}

Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
