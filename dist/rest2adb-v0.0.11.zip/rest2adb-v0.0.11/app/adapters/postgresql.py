"""PostgreSQL adapter for rest2adb."""
from __future__ import annotations

import logging
import re
import time
from typing import Any

from .base import (
    ColumnDef,
    ColumnInfo,
    ConnectionTestResult,
    TargetAdapter,
)

logger = logging.getLogger(__name__)

try:
    import psycopg
except ImportError:
    psycopg = None  # type: ignore[assignment]


class PostgresAdapter(TargetAdapter):
    """Adapter for PostgreSQL databases using psycopg (v3)."""

    def __init__(self) -> None:
        self._conn: Any | None = None
        self._config: dict | None = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self, config: dict) -> None:
        if psycopg is None:
            raise RuntimeError(
                "The 'psycopg' package is required for PostgreSQL connections. "
                "Install it with:  pip install psycopg[binary]"
            )

        self._config = config

        host: str = config["host"]
        port: int = config.get("port", 5432)
        database: str = config["database"]
        user: str = config["username"]
        password: str = config["password"]
        sslmode: str | None = config.get("sslmode")

        conninfo_parts = [
            f"host={host}",
            f"port={port}",
            f"dbname={database}",
            f"user={user}",
            f"password={password}",
        ]
        if sslmode:
            conninfo_parts.append(f"sslmode={sslmode}")

        conninfo = " ".join(conninfo_parts)
        self._conn = psycopg.connect(conninfo, autocommit=False)
        logger.info("PostgreSQL connection established (host=%s, db=%s)", host, database)

    def disconnect(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            except Exception:
                logger.warning("Error closing PostgreSQL connection", exc_info=True)
            finally:
                self._conn = None
        logger.info("PostgreSQL connection closed")

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def test_connection(self) -> ConnectionTestResult:
        start = time.perf_counter()
        try:
            with self._conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
            latency = (time.perf_counter() - start) * 1000.0

            version: str | None = None
            try:
                with self._conn.cursor() as cur:
                    cur.execute("SELECT version()")
                    row = cur.fetchone()
                    if row:
                        version = row[0]
            except Exception:
                pass

            self._conn.rollback()  # clean up any implicit transaction

            return ConnectionTestResult(
                success=True,
                latency_ms=round(latency, 2),
                message="Connection successful",
                version=version,
            )
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000.0
            return ConnectionTestResult(
                success=False,
                latency_ms=round(latency, 2),
                message=str(exc),
            )

    # ------------------------------------------------------------------
    # Schema introspection
    # ------------------------------------------------------------------

    def table_exists(self, table_name: str) -> bool:
        sql = (
            "SELECT COUNT(*) FROM information_schema.tables "
            "WHERE table_schema = 'public' AND table_name = %s"
        )
        with self._conn.cursor() as cur:
            cur.execute(sql, (table_name,))
            row = cur.fetchone()
            self._conn.rollback()
            return row is not None and row[0] > 0

    def get_columns(self, table_name: str) -> list[ColumnInfo]:
        sql = (
            "SELECT column_name, data_type, is_nullable, "
            "character_maximum_length, numeric_precision, numeric_scale "
            "FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = %s "
            "ORDER BY ordinal_position"
        )
        columns: list[ColumnInfo] = []
        with self._conn.cursor() as cur:
            cur.execute(sql, (table_name,))
            for row in cur.fetchall():
                columns.append(
                    ColumnInfo(
                        name=row[0],
                        data_type=row[1],
                        nullable=(row[2] == "YES"),
                        max_length=row[3],
                        precision=row[4],
                        scale=row[5],
                    )
                )
        self._conn.rollback()
        return columns

    # ------------------------------------------------------------------
    # DDL helpers
    # ------------------------------------------------------------------

    def create_table(self, table_name: str, columns: list[ColumnDef]) -> str:
        col_defs: list[str] = []
        pk_cols: list[str] = []

        for col in columns:
            parts = [f'"{col.name}" {col.data_type}']
            if not col.nullable:
                parts.append("NOT NULL")
            col_defs.append(" ".join(parts))
            if col.primary_key:
                pk_cols.append(f'"{col.name}"')

        if pk_cols:
            col_defs.append(f"PRIMARY KEY ({', '.join(pk_cols)})")

        ddl = f'CREATE TABLE "{table_name}" (\n  ' + ",\n  ".join(col_defs) + "\n)"
        self.execute_ddl(ddl)
        return ddl

    # ------------------------------------------------------------------
    # DML
    # ------------------------------------------------------------------

    def insert_batch(self, table_name: str, columns: list[str], rows: list[tuple]) -> int:
        if not rows:
            return 0

        col_list = ", ".join(f'"{c}"' for c in columns)
        placeholders = ", ".join(["%s"] * len(columns))
        sql = f'INSERT INTO "{table_name}" ({col_list}) VALUES ({placeholders})'

        with self._conn.cursor() as cur:
            cur.executemany(sql, rows)
        self._conn.commit()

        return len(rows)

    def upsert_batch(
        self, table_name: str, columns: list[str], pk_columns: list[str], rows: list[tuple]
    ) -> int:
        if not rows:
            return 0

        non_pk = [c for c in columns if c not in pk_columns]

        col_list = ", ".join(f'"{c}"' for c in columns)
        placeholders = ", ".join(["%s"] * len(columns))
        conflict_cols = ", ".join(f'"{c}"' for c in pk_columns)

        if non_pk:
            update_parts = [f'"{c}" = EXCLUDED."{c}"' for c in non_pk]
            update_clause = ", ".join(update_parts)
            sql = (
                f'INSERT INTO "{table_name}" ({col_list}) VALUES ({placeholders}) '
                f"ON CONFLICT ({conflict_cols}) DO UPDATE SET {update_clause}"
            )
        else:
            # All columns are PKs -- nothing to update, just ignore conflicts
            sql = (
                f'INSERT INTO "{table_name}" ({col_list}) VALUES ({placeholders}) '
                f"ON CONFLICT ({conflict_cols}) DO NOTHING"
            )

        with self._conn.cursor() as cur:
            cur.executemany(sql, rows)
        self._conn.commit()

        return len(rows)

    def truncate_table(self, table_name: str) -> None:
        self.execute_ddl(f'TRUNCATE TABLE "{table_name}"')

    def execute_ddl(self, sql: str) -> None:
        with self._conn.cursor() as cur:
            cur.execute(sql)
        self._conn.commit()

    # ------------------------------------------------------------------
    # Generic query / update
    # ------------------------------------------------------------------

    @staticmethod
    def _convert_sql(sql: str) -> str:
        """Convert Oracle-style :N bind params to PostgreSQL %s style."""
        return re.sub(r":\d+", "%s", sql)

    def execute_query(self, sql: str, params: dict | tuple | None = None) -> list[dict]:
        sql = self._convert_sql(sql)
        with self._conn.cursor() as cur:
            if params is not None:
                cur.execute(sql, params)
            else:
                cur.execute(sql)
            col_names = [desc[0].upper() for desc in cur.description]
            results = [dict(zip(col_names, row)) for row in cur.fetchall()]
        self._conn.rollback()  # read-only -- release any implicit transaction
        return results

    def execute_update(self, sql: str, params: dict | tuple | None = None) -> int:
        sql = self._convert_sql(sql)
        with self._conn.cursor() as cur:
            if params is not None:
                cur.execute(sql, params)
            else:
                cur.execute(sql)
            rowcount = cur.rowcount
        self._conn.commit()
        return rowcount

    # ------------------------------------------------------------------
    # Control tables
    # ------------------------------------------------------------------

    def init_control_tables(self, prefix: str) -> None:
        """Create the rest2adb control tables if they do not already exist.

        Column names match those used by ControlTableManager.
        Uses CREATE TABLE IF NOT EXISTS for idempotency.
        """
        p = prefix.upper()

        statements: list[str] = [
            f"""CREATE TABLE IF NOT EXISTS "{p}MIGRATION_JOB" (
                "JOB_ID"                VARCHAR(64) PRIMARY KEY,
                "JOB_NAME"              VARCHAR(256),
                "STATUS"                VARCHAR(32) DEFAULT 'CREATED',
                "REST_CONNECTION_ID"    VARCHAR(64),
                "ADB_CONNECTION_ID"     VARCHAR(64),
                "CONFIG_JSON"           TEXT,
                "CREATED_AT"            TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                "STARTED_AT"            TIMESTAMP WITH TIME ZONE,
                "COMPLETED_AT"          TIMESTAMP WITH TIME ZONE,
                "ERROR_MESSAGE"         TEXT,
                "TOTAL_ENDPOINTS"       INTEGER DEFAULT 0,
                "COMPLETED_ENDPOINTS"   INTEGER DEFAULT 0,
                "TOTAL_ROWS_MIGRATED"   BIGINT DEFAULT 0
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}ENDPOINT_STATE" (
                "ENDPOINT_STATE_ID"     VARCHAR(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR(64),
                "ENDPOINT_PATH"        VARCHAR(1024),
                "TARGET_TABLE"         VARCHAR(256),
                "STATUS"               VARCHAR(32) DEFAULT 'PENDING',
                "LAST_PAGE_CURSOR"     VARCHAR(4000),
                "LAST_SUCCESSFUL_BATCH" INTEGER DEFAULT 0,
                "ROWS_FETCHED"         BIGINT DEFAULT 0,
                "ROWS_INSERTED"        BIGINT DEFAULT 0,
                "STARTED_AT"           TIMESTAMP WITH TIME ZONE,
                "COMPLETED_AT"         TIMESTAMP WITH TIME ZONE,
                "ERROR_MESSAGE"        TEXT,
                "RETRY_COUNT"          INTEGER DEFAULT 0
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}BATCH_LOG" (
                "BATCH_ID"             VARCHAR(64) PRIMARY KEY,
                "ENDPOINT_STATE_ID"    VARCHAR(64),
                "BATCH_SEQ"            INTEGER,
                "PAGE_PARAM"           VARCHAR(4000),
                "ROWS_IN_BATCH"        INTEGER DEFAULT 0,
                "STATUS"               VARCHAR(32),
                "STARTED_AT"           TIMESTAMP WITH TIME ZONE,
                "COMPLETED_AT"         TIMESTAMP WITH TIME ZONE,
                "ERROR_MESSAGE"        TEXT
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}SYNC_STATE" (
                "SYNC_STATE_ID"        VARCHAR(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR(64),
                "ENDPOINT_PATH"        VARCHAR(1024),
                "SYNC_MODE"            VARCHAR(32),
                "DELTA_FIELD"          VARCHAR(256),
                "DELTA_PARAM"          VARCHAR(256),
                "LAST_DELTA_VALUE"     VARCHAR(4000),
                "LAST_ETAG"            VARCHAR(4000),
                "LAST_SYNC_AT"         TIMESTAMP WITH TIME ZONE,
                "ROWS_SYNCED"          BIGINT DEFAULT 0
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}QUARANTINE" (
                "QUARANTINE_ID"        VARCHAR(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR(64),
                "ENDPOINT_PATH"        VARCHAR(1024),
                "BATCH_SEQ"            INTEGER,
                "ROW_DATA"             TEXT,
                "VIOLATIONS"           TEXT,
                "SEVERITY"             VARCHAR(32),
                "CREATED_AT"           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                "RESOLVED"             VARCHAR(1) DEFAULT 'N'
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}BATCH_RUN" (
                "BATCH_RUN_ID"         VARCHAR(64) PRIMARY KEY,
                "BATCH_NAME"           VARCHAR(256),
                "STATUS"               VARCHAR(32) DEFAULT 'CREATED',
                "CONCURRENCY"          INTEGER DEFAULT 5,
                "CREATED_AT"           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                "STARTED_AT"           TIMESTAMP WITH TIME ZONE,
                "COMPLETED_AT"         TIMESTAMP WITH TIME ZONE,
                "TOTAL_JOBS"           INTEGER DEFAULT 0,
                "COMPLETED_JOBS"       INTEGER DEFAULT 0,
                "FAILED_JOBS"          INTEGER DEFAULT 0
            )""",
            f"""CREATE TABLE IF NOT EXISTS "{p}BATCH_RUN_JOBS" (
                "BATCH_RUN_ID"         VARCHAR(64),
                "JOB_ID"               VARCHAR(64),
                "EXECUTION_ORDER"      INTEGER,
                "STATUS"               VARCHAR(32) DEFAULT 'PENDING',
                "STARTED_AT"           TIMESTAMP WITH TIME ZONE,
                "COMPLETED_AT"         TIMESTAMP WITH TIME ZONE,
                PRIMARY KEY ("BATCH_RUN_ID", "JOB_ID")
            )""",
        ]

        with self._conn.cursor() as cur:
            for ddl in statements:
                cur.execute(ddl)
        self._conn.commit()

        logger.info("PostgreSQL control tables initialised (prefix=%s)", prefix)
