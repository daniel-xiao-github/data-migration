#!/usr/bin/env python3
"""Restart helper — spawned as a detached process by /api/restart.

Usage:  python _restart_helper.py <old_pid> <python_exe> <main_py> <pid_file> <log_file>

Steps:
  1. Wait for the old server (old_pid) to exit (kill it if necessary).
  2. Launch main.py as a background process.
  3. Write the new PID to .server.pid.
  4. Poll /api/health to confirm the new server is responding.
  5. Exit.

This script is a permanent part of the distribution (not generated at
runtime), so it survives parent-process death reliably on every platform.
"""
import os
import sys
import time
import signal
import subprocess


def _pid_alive(pid: int) -> bool:
    """Return True if *pid* is still running."""
    if sys.platform == "win32":
        import ctypes
        kernel32 = ctypes.windll.kernel32
        SYNCHRONIZE = 0x00100000
        handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if handle:
            kernel32.CloseHandle(handle)
            return True
        return False
    else:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False


def _kill(pid: int) -> None:
    """Send a graceful kill, then force-kill after a short wait."""
    if sys.platform == "win32":
        subprocess.call(
            ["taskkill", "/PID", str(pid), "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        try:
            os.kill(pid, signal.SIGTERM)
        except (OSError, ProcessLookupError):
            return
        # Wait up to 5 seconds for graceful exit
        for _ in range(20):
            if not _pid_alive(pid):
                return
            time.sleep(0.25)
        # Force kill
        try:
            os.kill(pid, signal.SIGKILL)
        except (OSError, ProcessLookupError):
            pass


def _wait_for_exit(pid: int, timeout: float = 10.0) -> None:
    """Block until *pid* is no longer running (up to *timeout* seconds)."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _pid_alive(pid):
            return
        time.sleep(0.25)
    # Still alive — force kill
    _kill(pid)
    time.sleep(0.5)


def _start_server(python_exe: str, main_py: str, log_file: str) -> int:
    """Launch main.py in the background and return the new PID."""
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)

    with open(log_file, "a") as lf:
        kwargs = dict(
            stdin=subprocess.DEVNULL,
            stdout=lf,
            stderr=lf,
            close_fds=True,
        )
        if sys.platform != "win32":
            kwargs["start_new_session"] = True
        else:
            kwargs["creationflags"] = (
                subprocess.CREATE_NEW_PROCESS_GROUP
                | subprocess.DETACHED_PROCESS
            )

        proc = subprocess.Popen([python_exe, main_py], **kwargs)
    return proc.pid


def _health_check(pid: int, timeout: float = 15.0) -> bool:
    """Poll the new server until /api/health responds or *timeout* elapses."""
    import urllib.request
    import urllib.error
    import yaml

    # Read host/port from config
    app_dir = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(app_dir, "config", "default.yaml")
    host, port = "127.0.0.1", 8500
    if os.path.exists(config_file):
        try:
            with open(config_file) as f:
                cfg = yaml.safe_load(f) or {}
            srv = cfg.get("server", {})
            host = srv.get("host", host)
            port = srv.get("port", port)
        except Exception:
            pass

    url = f"http://{host}:{port}/api/health"
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        # Make sure the process hasn't crashed
        if not _pid_alive(pid):
            return False
        try:
            resp = urllib.request.urlopen(url, timeout=2)
            if resp.status == 200:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def main() -> None:
    if len(sys.argv) != 6:
        print(
            "Usage: _restart_helper.py <old_pid> <python_exe> "
            "<main_py> <pid_file> <log_file>",
            file=sys.stderr,
        )
        sys.exit(1)

    old_pid = int(sys.argv[1])
    python_exe = sys.argv[2]
    main_py = sys.argv[3]
    pid_file = sys.argv[4]
    log_file = sys.argv[5]

    # 1. Wait a moment so the HTTP response can flush
    time.sleep(0.5)

    # 2. Kill old server and wait for it to exit
    _kill(old_pid)
    _wait_for_exit(old_pid)

    # 3. Start new server
    new_pid = _start_server(python_exe, main_py, log_file)

    # 4. Update PID file
    with open(pid_file, "w") as f:
        f.write(str(new_pid))

    # 5. Verify new server is healthy
    if _health_check(new_pid):
        _log(log_file, f"Restart complete — new server PID {new_pid}")
    else:
        _log(log_file, f"WARNING: new server (PID {new_pid}) did not pass health check")


def _log(log_file: str, msg: str) -> None:
    """Append a timestamped message to the log file."""
    try:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(log_file, "a") as f:
            f.write(f"[{ts}] [restart_helper] {msg}\n")
    except Exception:
        pass


if __name__ == "__main__":
    main()
