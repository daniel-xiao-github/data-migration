"""REST API endpoint discovery via OpenAPI spec or sample-based probing."""
from __future__ import annotations
import logging
import json
import re
from typing import Any
from urllib.parse import quote as url_quote

import requests

log = logging.getLogger("rest2adb.discovery")


class DiscoveryEngine:
    """Discovers REST API endpoints and their schemas."""

    def __init__(self, rest_client=None):
        self.rest_client = rest_client

    def discover_from_openapi(self, spec_url: str) -> list[dict]:
        """Parse an OpenAPI spec and extract endpoint metadata.

        Supports both JSON and YAML specs (OpenAPI 3.x and Swagger 2.0).
        Uses prance to fetch, parse, and resolve all ``$ref`` references.
        """
        resp = requests.get(spec_url, timeout=30)
        resp.raise_for_status()
        spec = self._parse_and_resolve_spec(resp)
        return self._parse_openapi_spec(spec)

    @staticmethod
    def _parse_and_resolve_spec(resp) -> dict:
        """Parse a spec response and resolve all $ref references.

        Uses prance's resolver directly without running openapi-spec-validator,
        which rejects many real-world specs (e.g. non-semver version strings).
        """
        from prance.util.formats import parse_spec
        from prance.util.resolver import RefResolver

        spec = parse_spec(resp.text, "file:///openapi-spec")
        resolver = RefResolver(spec, "file:///openapi-spec")
        resolver.resolve_references()
        return resolver.specs

    def discover_from_sample(self, endpoints: list[dict],
                             deep: bool = False) -> list[dict]:
        """Probe endpoints by fetching sample data and inferring schema.

        When *deep=True*, also probes a detail endpoint (``{path}/{id}``)
        to discover additional fields and follows HATEOAS links to discover
        sub-resource endpoints.
        """
        results = []
        for ep in endpoints:
            path = ep.get("path") or ep.get("url", "")
            method = ep.get("http_method", "GET").upper()
            try:
                if method == "GET":
                    resp = self.rest_client.get(path, params=ep.get("query_params", {}))
                else:
                    resp = self.rest_client.post(path, json_body=ep.get("body_template"))
                resp.raise_for_status()
                body = resp.json()
                data = self._find_data_array(body)
                child_tables: list[dict] = []
                fields = self._infer_fields(data, child_tables=child_tables) if data else []
                pagination = self._detect_pagination(body, resp.headers)

                detail_field_names: list[str] = []
                sub_endpoints: list[dict] = []
                if deep and data and method == "GET":
                    extra, subs = self._deep_discover(path, data, fields)
                    if extra:
                        detail_field_names = [f["name"] for f in extra]
                        fields = fields + extra
                    sub_endpoints = subs

                results.append({
                    "path": path,
                    "http_method": method,
                    "summary": ep.get("summary", ""),
                    "parameters": ep.get("parameters", []),
                    "fields": fields,
                    "child_tables": child_tables,
                    "pagination": pagination,
                    "sample_data": data[:5] if data else [],
                    "metadata_source": "sample",
                    "detail_fields": detail_field_names,
                })
                results.extend(sub_endpoints)
            except Exception as e:
                log.warning("Failed to probe endpoint %s: %s", path, e)
                results.append({
                    "path": path,
                    "http_method": method,
                    "summary": f"Error: {e}",
                    "parameters": [],
                    "fields": [],
                    "pagination": None,
                    "sample_data": [],
                    "metadata_source": "error",
                })
        return results

    def discover_manual(self, endpoint: dict, deep: bool = False) -> dict:
        """Probe a single manually-configured endpoint."""
        results = self.discover_from_sample([endpoint], deep=deep)
        return results[0] if results else {}

    # ── Deep discovery helpers ────────────────────────────────────────

    def _deep_discover(self, collection_path: str, collection_data: list[dict],
                       collection_fields: list[dict]) -> tuple[list[dict], list[dict]]:
        """Probe detail endpoint for extra fields and discover sub-resources.

        Returns ``(extra_fields, sub_resource_endpoints)``.
        """
        extra_fields: list[dict] = []
        sub_endpoints: list[dict] = []

        first_item = collection_data[0]
        id_field = self._find_id_field_name(first_item)
        id_value = first_item.get(id_field) if id_field else None
        if id_value is None:
            return extra_fields, sub_endpoints

        detail_path = f"{collection_path.rstrip('/')}/{url_quote(str(id_value), safe='')}"
        try:
            resp = self.rest_client.get(detail_path)
            if resp.status_code >= 400:
                log.debug("Detail probe %s returned %s", detail_path, resp.status_code)
                return extra_fields, sub_endpoints
            detail_body = resp.json()
        except Exception as exc:
            log.debug("Detail probe %s failed: %s", detail_path, exc)
            return extra_fields, sub_endpoints

        detail_item = self._unwrap_single(detail_body)
        if not isinstance(detail_item, dict):
            return extra_fields, sub_endpoints

        # Infer fields from the detail item
        child_tables_det: list[dict] = []
        detail_fields = self._infer_fields([detail_item], child_tables=child_tables_det)

        # Extra fields = those present in detail but missing from collection
        existing_names = {f["name"] for f in collection_fields}
        extra_fields = [f for f in detail_fields if f["name"] not in existing_names]

        # Discover sub-resource endpoints from HATEOAS links
        links = self._extract_links(detail_item, collection_path,
                                    str(id_value), id_field)
        for link in links:
            try:
                sub_resp = self.rest_client.get(link["probe_path"])
                if sub_resp.status_code >= 400:
                    continue
                sub_body = sub_resp.json()
                sub_data = self._find_data_array(sub_body)
                ct: list[dict] = []
                sub_fields = (self._infer_fields(sub_data, child_tables=ct)
                              if sub_data else [])
                sub_pagination = self._detect_pagination(sub_body, sub_resp.headers)
                sub_endpoints.append({
                    "path": link["template_path"],
                    "http_method": "GET",
                    "summary": f"Sub-resource: {link.get('rel', '')}",
                    "parameters": [{
                        "name": id_field,
                        "location": "path",
                        "required": True,
                        "param_type": "string",
                    }],
                    "fields": sub_fields,
                    "child_tables": ct,
                    "pagination": sub_pagination,
                    "sample_data": sub_data[:5] if sub_data else [],
                    "metadata_source": "sample_deep",
                    "parent_endpoint": collection_path,
                })
            except Exception as exc:
                log.debug("Sub-resource probe %s failed: %s",
                          link.get("probe_path"), exc)

        return extra_fields, sub_endpoints

    @staticmethod
    def _unwrap_single(body: Any) -> Any:
        """If a JSON response wraps a single object, unwrap it."""
        if isinstance(body, dict):
            for key in ("data", "result", "item", "record", "payload"):
                if key in body and isinstance(body[key], dict):
                    return body[key]
        return body

    @staticmethod
    def _find_id_field_name(item: dict) -> str | None:
        """Return the name of the most likely ID field in *item*."""
        for key in ("id", "Id", "ID", "_id", "uuid", "key", "pk"):
            if key in item and item[key] is not None:
                return key
        for key in item:
            lower = key.lower()
            if lower.endswith("id") and isinstance(item[key], (str, int)):
                return key
        return None

    def _extract_links(self, item: dict, collection_path: str,
                       id_str: str, id_field: str) -> list[dict]:
        """Extract HATEOAS links from *item* for sub-resource discovery.

        Returns list of ``{"rel", "probe_path", "template_path"}``.
        """
        links: list[dict] = []
        skip_rels = {"self", "edit", "delete", "update", "patch", "remove"}

        for links_key in ("links", "_links", "Links"):
            raw = item.get(links_key)
            if not raw:
                continue
            if isinstance(raw, dict):
                # HAL-style: {"orders": {"href": "/users/123/orders"}}
                for rel, link_obj in raw.items():
                    if rel.lower() in skip_rels:
                        continue
                    href = (link_obj.get("href") if isinstance(link_obj, dict)
                            else link_obj if isinstance(link_obj, str) else None)
                    if href:
                        template = href.replace(id_str, f"{{{id_field}}}")
                        links.append({"rel": rel, "probe_path": href,
                                      "template_path": template})
            elif isinstance(raw, list):
                # JSON-API-style: [{"rel": "orders", "href": "..."}]
                for link_obj in raw:
                    if not isinstance(link_obj, dict):
                        continue
                    rel = link_obj.get("rel", link_obj.get("name", ""))
                    href = link_obj.get("href", link_obj.get("url", ""))
                    if rel.lower() in skip_rels or not href:
                        continue
                    template = href.replace(id_str, f"{{{id_field}}}")
                    links.append({"rel": rel, "probe_path": href,
                                  "template_path": template})

        # Also look for URL-valued fields that look like sub-resources
        base = collection_path.rstrip("/")
        for key, val in item.items():
            if key in ("links", "_links", "Links"):
                continue
            if isinstance(val, str) and val.startswith(base + "/"):
                # Looks like a sub-resource link embedded as a plain field
                rel = key
                if rel.lower() in skip_rels:
                    continue
                template = val.replace(id_str, f"{{{id_field}}}")
                if not any(l["template_path"] == template for l in links):
                    links.append({"rel": rel, "probe_path": val,
                                  "template_path": template})

        return links

    _HTTP_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}

    def _parse_openapi_spec(self, spec: dict) -> list[dict]:
        """Extract GET collection endpoints from a fully-resolved spec."""
        endpoints = []
        paths = spec.get("paths", {})
        for path, path_item in paths.items():
            # Only import GET collection endpoints — skip paths with
            # {param} placeholders (detail / sub-resource / action endpoints)
            if re.search(r'\{[^}]+\}', path):
                log.debug("Skipping parameterised path %s", path)
                continue
            if "get" not in path_item:
                continue
            op = path_item["get"]
            if not isinstance(op, dict):
                continue
            # Collect path-level and operation-level parameters (already resolved)
            path_params = self._normalize_params(path_item.get("parameters", []))
            op_params = self._normalize_params(op.get("parameters", []))
            params = list(path_params)
            seen = {p["name"] for p in params}
            for p in op_params:
                if p["name"] not in seen:
                    params.append(p)
            resp_schema = self._extract_response_schema(op)
            # Unwrap common response wrappers before extracting fields.
            # APIs often wrap collections: {"data": [...], "total": 100}
            if resp_schema:
                resp_schema = self._unwrap_collection_schema(resp_schema)
            child_tables: list[dict] = []
            fields = (self._schema_to_fields(resp_schema, child_tables=child_tables)
                      if resp_schema else [])
            endpoints.append({
                "path": path,
                "http_method": "GET",
                "summary": op.get("summary", op.get("description", "")),
                "parameters": params,
                "fields": fields,
                "child_tables": child_tables,
                "pagination": None,
                "sample_data": [],
                "metadata_source": "openapi",
            })
        return endpoints

    @staticmethod
    def _normalize_params(raw_params: list) -> list[dict]:
        """Normalize already-resolved parameter dicts to our param format."""
        params = []
        for p in raw_params:
            # Swagger 2.0 uses "type" directly; OpenAPI 3.x nests it in "schema"
            param_type = (p.get("schema", {}).get("type")
                          or p.get("type", "string"))
            params.append({
                "name": p.get("name", ""),
                "location": p.get("in", "query"),
                "required": p.get("required", False),
                "param_type": param_type,
            })
        return params

    @staticmethod
    def _extract_response_schema(operation: dict) -> dict | None:
        """Extract the response schema from a fully-resolved operation dict."""
        responses = operation.get("responses", {})
        # prance normalises status codes to strings, but handle int keys too
        resp_ok = (
            responses.get("200", responses.get(200))
            or responses.get("201", responses.get(201))
            or {}
        )

        # OpenAPI 3.x: schema lives under content -> media-type -> schema
        content = resp_ok.get("content", {})
        if content:
            json_content = content.get("application/json")
            if json_content is None:
                for ct, ct_obj in content.items():
                    if "json" in ct.lower() or ct.strip() == "*/*":
                        json_content = ct_obj
                        break
            if json_content:
                schema = json_content.get("schema", {})
                return schema or None

        # OpenAPI 2.0 (Swagger): schema lives directly on the response object
        schema = resp_ok.get("schema", {})
        return schema or None

    def _unwrap_collection_schema(self, schema: dict) -> dict:
        """Unwrap common response wrapper schemas to reach the record schema.

        APIs often wrap collections like ``{"data": [...], "total": 100}``.
        This mirrors what ``_find_data_array`` does for sample data, but
        operates on JSON Schema rather than actual JSON.
        """
        schema = self._resolve_composition(schema)

        # Already an array — just return it (handled by _schema_to_fields)
        if schema.get("type") == "array":
            return schema

        props = schema.get("properties", {})
        if not props:
            return schema

        # Look for a well-known wrapper property that is an array.
        # Be lenient: many specs leave items empty ({}) or omit it entirely,
        # but if the property is named "data"/"results"/etc. and has type
        # "array", it's almost certainly the collection payload.
        wrapper_keys = ("data", "results", "items", "records", "rows",
                        "content", "entries", "list", "payload")
        for key in wrapper_keys:
            if key in props:
                prop = self._resolve_composition(props[key])
                if prop.get("type") == "array":
                    log.debug("Unwrapping response wrapper property '%s'", key)
                    return prop  # return the array schema

        # Fallback: if there's exactly one array property, use it
        array_props = []
        for key, prop in props.items():
            prop = self._resolve_composition(prop)
            if prop.get("type") == "array":
                array_props.append((key, prop))
        if len(array_props) == 1:
            key, prop = array_props[0]
            log.debug("Unwrapping sole array property '%s'", key)
            return prop

        return schema

    @staticmethod
    def _resolve_composition(schema: dict) -> dict:
        """Merge allOf/oneOf/anyOf sub-schemas into a single schema dict.

        This handles the common pattern where $ref resolution produces
        composition keywords instead of inlined properties.
        """
        if not isinstance(schema, dict):
            return schema

        # Handle allOf — merge all sub-schemas
        if "allOf" in schema:
            merged: dict = {}
            merged_props: dict = {}
            merged_required: list = []
            for sub in schema["allOf"]:
                if not isinstance(sub, dict):
                    continue
                merged_props.update(sub.get("properties", {}))
                merged_required.extend(sub.get("required", []))
                for k, v in sub.items():
                    if k not in ("properties", "required"):
                        merged[k] = v
            merged["properties"] = merged_props
            if merged_required:
                merged["required"] = merged_required
            if "type" not in merged:
                merged["type"] = "object"
            return merged

        # Handle oneOf/anyOf — use the first sub-schema that has properties
        for key in ("oneOf", "anyOf"):
            if key in schema:
                for sub in schema[key]:
                    if isinstance(sub, dict) and sub.get("properties"):
                        return sub
                # Fallback: use the first one
                if schema[key] and isinstance(schema[key][0], dict):
                    return schema[key][0]

        return schema

    def _schema_to_fields(self, schema: dict, prefix: str = "",
                          child_tables: list | None = None) -> list[dict]:
        """Convert a fully-resolved JSON Schema to a flat list of field dicts."""
        schema = self._resolve_composition(schema)
        fields = []
        if schema.get("type") == "array" and "items" in schema:
            return self._schema_to_fields(schema["items"], prefix,
                                          child_tables=child_tables)
        props = schema.get("properties", {})
        required = set(schema.get("required", []))
        for name, prop in props.items():
            prop = self._resolve_composition(prop)
            full_name = f"{prefix}{name}" if not prefix else f"{prefix}.{name}"
            ptype = prop.get("type", "string")
            if ptype == "object" and "properties" in prop:
                fields.extend(self._schema_to_fields(prop, full_name,
                                                     child_tables=child_tables))
            elif ptype == "array" and "items" in prop:
                item_schema = self._resolve_composition(prop["items"])
                if item_schema.get("properties"):
                    # Array of objects → child table
                    child_fields = self._schema_to_fields(item_schema, "")
                    if child_tables is not None and child_fields:
                        child_tables.append({
                            "source_array": full_name,
                            "fields": child_fields,
                        })
                    else:
                        fields.extend(self._schema_to_fields(
                            item_schema, full_name,
                            child_tables=child_tables))
                else:
                    fields.append({
                        "name": full_name,
                        "path": full_name,
                        "field_type": ptype,
                        "nullable": name not in required,
                        "description": prop.get("description"),
                        "sample_value": prop.get("example"),
                    })
            else:
                fields.append({
                    "name": full_name,
                    "path": full_name,
                    "field_type": ptype,
                    "nullable": name not in required,
                    "description": prop.get("description"),
                    "sample_value": prop.get("example"),
                })
        return fields

    def _find_data_array(self, body: Any) -> list[dict] | None:
        if isinstance(body, list):
            return body
        if isinstance(body, dict):
            for key in ("data", "results", "items", "records", "rows",
                        "content", "entries", "list", "payload"):
                if key in body and isinstance(body[key], list):
                    return body[key]
            for key, val in body.items():
                if isinstance(val, list) and val and isinstance(val[0], dict):
                    return val
        return None

    def _infer_fields(self, data: list[dict],
                      child_tables: list | None = None) -> list[dict]:
        if not data:
            return []
        field_map: dict[str, dict] = {}
        array_of_obj_fields: dict[str, dict[str, dict]] = {}
        for row in data[:20]:
            flat = self._flatten(row, _array_obj_fields=array_of_obj_fields)
            for key, val in flat.items():
                if key not in field_map:
                    field_map[key] = {
                        "name": key,
                        "path": key,
                        "field_type": self._infer_type(val),
                        "nullable": False,
                        "sample_value": val,
                    }
                if val is None:
                    field_map[key]["nullable"] = True
        # Promote detected arrays of objects to child_tables
        if child_tables is not None:
            for array_path, child_field_map in array_of_obj_fields.items():
                child_tables.append({
                    "source_array": array_path,
                    "fields": list(child_field_map.values()),
                })
        return list(field_map.values())

    def _flatten(self, obj: dict, prefix: str = "",
                 _array_obj_fields: dict | None = None) -> dict:
        items = {}
        for k, v in obj.items():
            full_key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                items.update(self._flatten(v, full_key,
                                           _array_obj_fields=_array_obj_fields))
            elif isinstance(v, list):
                # Detect arrays of objects → child table candidates
                if (v and isinstance(v[0], dict) and _array_obj_fields is not None):
                    if full_key not in _array_obj_fields:
                        _array_obj_fields[full_key] = {}
                    for elem in v[:10]:
                        flat_elem = self._flatten(elem)
                        for ek, ev in flat_elem.items():
                            if ek not in _array_obj_fields[full_key]:
                                _array_obj_fields[full_key][ek] = {
                                    "name": ek,
                                    "path": ek,
                                    "field_type": self._infer_type(ev),
                                    "nullable": False,
                                    "sample_value": ev,
                                }
                else:
                    items[full_key] = json.dumps(v) if v else "[]"
            else:
                items[full_key] = v
        return items

    @staticmethod
    def _infer_type(value: Any) -> str:
        if value is None:
            return "string"
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, int):
            return "integer"
        if isinstance(value, float):
            return "float"
        s = str(value)
        iso_re = r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}"
        if re.match(iso_re, s):
            return "datetime"
        return "string"

    @staticmethod
    def _detect_pagination(body: Any, headers: dict) -> dict | None:
        if "Link" in headers:
            link = headers["Link"]
            if 'rel="next"' in link:
                return {"type": "link_header", "page_size": 100, "param_names": {}}
        if isinstance(body, dict):
            if "next" in body or "next_url" in body or "nextPage" in body:
                return {"type": "next_url", "page_size": 100,
                        "param_names": {"next_url": "next"}}
            if "next_cursor" in body or "cursor" in body:
                return {"type": "cursor", "page_size": 100,
                        "param_names": {"cursor": "cursor",
                                        "cursor_response": "next_cursor"}}
            for key in ("total", "total_count", "totalCount", "count"):
                if key in body:
                    return {"type": "offset_limit", "page_size": 100,
                            "param_names": {"offset": "offset", "limit": "limit"},
                            "total_field": key}
        return None

    @staticmethod
    def suggest_table_name(endpoint_path: str) -> str:
        """Suggest a table name from an endpoint path."""
        name = endpoint_path.strip("/").split("?")[0]
        name = re.sub(r'[{}]', '', name)
        name = re.sub(r'[^a-zA-Z0-9]', '_', name)
        name = re.sub(r'_+', '_', name).strip("_").upper()
        return name or "UNNAMED_TABLE"

    @staticmethod
    def suggest_child_table_name(parent_table: str, source_array: str) -> str:
        """Suggest a child table name from parent table and array field."""
        suffix = re.sub(r'[^a-zA-Z0-9]', '_', source_array)
        suffix = re.sub(r'_+', '_', suffix).strip("_").upper()
        return f"{parent_table}_{suffix}"
