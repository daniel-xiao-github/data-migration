"""Mapping and validation API routes."""
from __future__ import annotations
import re
from flask import Blueprint, request, jsonify, current_app

bp = Blueprint("mappings", __name__, url_prefix="/api")


def _store():
    return current_app.config["STORE"]


def _to_column_name(source_name: str) -> str:
    """Convert a source field name to a clean DB column name.

    Strips the leading ``data.`` wrapper prefix, replaces dots with
    underscores, and upper-cases the result.

    Examples::

        data.host         -> HOST
        data.parent.name  -> PARENT_NAME
        host              -> HOST
    """
    name = re.sub(r'^data\.', '', source_name)
    return name.replace('.', '_').upper()


@bp.route("/mappings/auto-map", methods=["POST"])
def auto_map():
    """Auto-generate field mappings between source fields and target columns."""
    data = request.get_json(force=True)
    source_fields = data.get("source_fields", [])
    target_columns = data.get("target_columns", [])
    if not source_fields:
        return jsonify({"error": "source_fields required"}), 400

    # When no target columns provided, derive them from source fields so
    # that the engine can produce 1-to-1 identity mappings.
    # Strip leading "data." prefix and convert to clean UPPER_CASE names.
    if not target_columns:
        target_columns = [
            {"name": _to_column_name(f["name"]),
             "type": f.get("type") or f.get("field_type", "string")}
            for f in source_fields
        ]

    from app.core.mapping_engine import MappingEngine
    engine = MappingEngine()
    mappings = engine.auto_map(source_fields, target_columns)
    return jsonify({"mappings": mappings, "count": len(mappings)})


@bp.route("/mappings/save", methods=["POST"])
def save_mappings():
    """Save field mappings for a connection+endpoint pair."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoint_path = data.get("endpoint_path")
    mappings = data.get("mappings", [])
    if not conn_id or not endpoint_path:
        return jsonify({"error": "rest_connection_id and endpoint_path required"}), 400

    store = _store()
    key = f"mappings_{conn_id}_{endpoint_path}"
    store[key] = mappings
    return jsonify({"status": "saved", "count": len(mappings)})


@bp.route("/mappings/load", methods=["POST"])
def load_mappings():
    """Load saved mappings for a connection+endpoint pair."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoint_path = data.get("endpoint_path")
    key = f"mappings_{conn_id}_{endpoint_path}"
    mappings = _store().get(key, [])
    return jsonify({"mappings": mappings})


@bp.route("/mappings/endpoints", methods=["GET"])
def mapped_endpoints():
    """List endpoints that have saved mappings for a given REST connection."""
    conn_id = request.args.get("rest_connection_id")
    if not conn_id:
        return jsonify({"error": "rest_connection_id required"}), 400

    store = _store()
    prefix = f"mappings_{conn_id}_"
    results = []
    for key, mappings in store.items():
        if not key.startswith(prefix) or not isinstance(mappings, list):
            continue
        if not mappings:
            continue
        ep_path = key[len(prefix):]
        # Derive target table and child table info from saved mappings
        parent_mappings = [m for m in mappings if not m.get("_is_child")]
        child_mappings = [m for m in mappings if m.get("_is_child")]
        target_table = parent_mappings[0].get("_target_table", "") if parent_mappings else ""
        child_tables = {}
        for m in child_mappings:
            ct = m.get("_target_table", "")
            if ct and ct not in child_tables:
                child_tables[ct] = {
                    "target_table": ct,
                    "source_array": m.get("_source_array", ""),
                    "parent_key": m.get("_parent_key", ""),
                    "fk_column": m.get("_fk_column", ""),
                    "field_count": 0,
                }
            if ct:
                child_tables[ct]["field_count"] += 1
        # Extract path parameters (e.g. {workspace_gid}) from the path
        path_params = re.findall(r'\{([^}]+)\}', ep_path)
        results.append({
            "path": ep_path,
            "target_table": target_table,
            "mapping_count": len(parent_mappings),
            "child_tables": list(child_tables.values()),
            "path_params": path_params,
        })
    return jsonify({"endpoints": results})


@bp.route("/mappings/preview", methods=["POST"])
def preview_mapping():
    """Apply mappings to sample data and return preview."""
    data = request.get_json(force=True)
    mappings = data.get("mappings", [])
    sample_data = data.get("sample_data", [])
    if not mappings or not sample_data:
        return jsonify({"error": "mappings and sample_data required"}), 400

    from app.core.mapping_engine import MappingEngine
    engine = MappingEngine()
    previews = []
    for row in sample_data[:10]:
        mapped = engine.apply_mappings(row, mappings)
        previews.append({"source": row, "target": mapped})
    return jsonify({"preview": previews})


@bp.route("/mappings/type-suggestion", methods=["POST"])
def type_suggestion():
    """Suggest target column types for a given JSON type."""
    data = request.get_json(force=True)
    json_type = data.get("json_type", "string")
    from app.core.mapping_engine import MappingEngine
    suggestion = MappingEngine().suggest_type_mapping(json_type, "")
    return jsonify(suggestion)


# ── Validation rules ─────────────────────────────────────────────────────

@bp.route("/validation/rules", methods=["POST"])
def save_validation_rules():
    """Save validation rules for a connection+endpoint."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoint_path = data.get("endpoint_path")
    rules = data.get("rules", [])
    key = f"rules_{conn_id}_{endpoint_path}"
    _store()[key] = rules
    return jsonify({"status": "saved", "count": len(rules)})


@bp.route("/validation/rules", methods=["GET"])
def get_validation_rules():
    conn_id = request.args.get("rest_connection_id")
    endpoint_path = request.args.get("endpoint_path")
    key = f"rules_{conn_id}_{endpoint_path}"
    return jsonify(_store().get(key, []))


@bp.route("/validation/auto-suggest", methods=["POST"])
def auto_suggest_rules():
    """Auto-suggest validation rules from target column metadata."""
    data = request.get_json(force=True)
    target_columns = data.get("target_columns", [])
    from app.core.validation_engine import ValidationEngine
    rules = ValidationEngine.auto_suggest_rules(target_columns)
    return jsonify({"rules": rules, "count": len(rules)})


@bp.route("/validation/test", methods=["POST"])
def test_validation():
    """Test validation rules against sample data."""
    data = request.get_json(force=True)
    rules = data.get("rules", [])
    sample_data = data.get("sample_data", [])
    mappings = data.get("mappings", [])

    from app.core.validation_engine import ValidationEngine
    engine = ValidationEngine(rules=rules)
    valid, _, quarantined = engine.validate_batch(sample_data, mappings)
    return jsonify({
        "total": len(sample_data),
        "valid": len(valid),
        "quarantined": len(quarantined),
        "quarantine_details": quarantined,
    })
