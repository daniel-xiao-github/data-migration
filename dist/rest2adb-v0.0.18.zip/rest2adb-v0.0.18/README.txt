==============================================================
  REST → ADB Migration Workbench
==============================================================

QUICK START
-----------
  Linux / macOS:       ./start.sh
  Windows (cmd):       start.bat
  Windows (PowerShell): .\start.ps1

The launcher will:
  1. Search for Python 3.9+ (scans well-known directories)
  2. Offer to auto-install Python if not found
  3. Check and install missing package dependencies
  4. Start the migration workbench server in the background
  5. Open the Web UI in your default browser

STOPPING THE SERVER
-------------------
  Linux / macOS:       ./stop.sh
  Windows (cmd):       stop.bat
  Windows (PowerShell): .\stop.ps1

SERVER STATUS
-------------
  Linux / macOS:       ./status.sh
  Windows (cmd):       status.bat
  Windows (PowerShell): .\status.ps1

PREREQUISITES
-------------
  • Python 3.9 or newer  (https://www.python.org/downloads/)
    (auto-installed if missing)
  • Internet connection   (for first-time package install)

MANUAL SETUP (alternative)
--------------------------
  1. pip install -r requirements.txt   # install deps
  2. python main.py                    # start the server
  3. Open http://127.0.0.1:8500 in your browser

UPDATING
--------
  From the Web UI:
    The app checks for updates on startup. If available,
    click the update button in the header to install.

  From the command line:
    Linux / macOS:   ./update.sh
    Windows:         update.bat

  Check only (no install):
    ./update.sh --check

  Updates are fetched from GitHub. Your config, data, and
  logs are preserved automatically.

CONFIGURATION
-------------
  Edit  config/default.yaml  to change the server port,
  batch sizes, logging, and other settings.

  Command-line overrides:
    ./start.sh --host 0.0.0.0 --port 9000
    .\start.ps1 --host 0.0.0.0 --port 9000

==============================================================
