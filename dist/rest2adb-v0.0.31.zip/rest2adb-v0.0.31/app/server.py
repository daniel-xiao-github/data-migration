"""Flask application factory and OAuth callback route."""
from __future__ import annotations
import os
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from flask import Flask, request, jsonify

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = PROJECT_ROOT / "data" / "store.json"


def create_app(config: dict | None = None) -> Flask:
    app = Flask(__name__,
                static_folder=str(PROJECT_ROOT / "app" / "ui"),
                static_url_path="/ui")

    config = config or {}
    app.config["APP_CONFIG"] = config
    app.config["PORT"] = config.get("server", {}).get("port", 8500)
    app.config["LOG_FILE"] = config.get("logging", {}).get("file", "logs/migration.log")

    # In-memory store (persisted to JSON on shutdown)
    app.config["STORE"] = _load_store()

    # Logging
    _setup_logging(app, config)

    # OAuth2 manager
    from app.core.oauth2 import OAuth2Manager
    oauth = OAuth2Manager(config.get("oauth2", {}))
    app.config["OAUTH_MANAGER"] = oauth

    # Register blueprints
    from app.api.connections import bp as conn_bp
    from app.api.discovery import bp as disc_bp
    from app.api.mappings import bp as map_bp
    from app.api.jobs import bp as jobs_bp
    from app.api.logs import bp as logs_bp

    app.register_blueprint(conn_bp)
    app.register_blueprint(disc_bp)
    app.register_blueprint(map_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(logs_bp)

    # OAuth callback
    @app.route("/oauth/callback")
    def oauth_callback():
        code = request.args.get("code")
        state = request.args.get("state")
        error = request.args.get("error")
        if error:
            return f"<h3>OAuth Error: {error}</h3><script>window.close()</script>", 400
        if not code or not state:
            return "<h3>Missing code or state</h3>", 400
        try:
            token = oauth.handle_callback(code, state)
            return ("<h3>Authorization successful!</h3>"
                    "<p>You can close this window.</p>"
                    "<script>window.opener && window.opener.postMessage("
                    "'oauth_complete','*'); window.close();</script>")
        except Exception as e:
            return f"<h3>Token exchange failed: {e}</h3>", 500

    # SPA catch-all
    @app.route("/")
    def index():
        return app.send_static_file("index.html")

    # Persist store on shutdown
    @app.teardown_appcontext
    def _save(exc):
        _persist_store(app.config.get("STORE", {}))

    return app


def _load_store() -> dict:
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text())
        except Exception:
            pass
    return {}


def _persist_store(store: dict) -> None:
    try:
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        DATA_FILE.write_text(json.dumps(store, default=str, indent=2))
    except Exception:
        pass


def _setup_logging(app: Flask, config: dict) -> None:
    log_cfg = config.get("logging", {})
    level = getattr(logging, log_cfg.get("level", "INFO").upper(), logging.INFO)
    log_file = PROJECT_ROOT / log_cfg.get("file", "logs/migration.log")
    log_file.parent.mkdir(parents=True, exist_ok=True)
    max_bytes = log_cfg.get("max_size_mb", 50) * 1024 * 1024
    backup = log_cfg.get("backup_count", 5)

    handler = RotatingFileHandler(str(log_file), maxBytes=max_bytes,
                                  backupCount=backup)
    handler.setLevel(level)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(level)
    root.addHandler(handler)

    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(fmt)
    root.addHandler(console)
