#!/usr/bin/env python3
"""Optional helper to create a virtual environment and install dependencies."""
import os
import sys
import subprocess
import venv

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
VENV_DIR = os.path.join(PROJECT_ROOT, "venv")
REQ_FILE = os.path.join(PROJECT_ROOT, "requirements.txt")


def main():
    if os.path.exists(VENV_DIR):
        print(f"[setup] Virtual environment already exists at {VENV_DIR}")
    else:
        print(f"[setup] Creating virtual environment at {VENV_DIR}...")
        venv.create(VENV_DIR, with_pip=True)
        print("[setup] Virtual environment created.")

    if sys.platform == "win32":
        pip = os.path.join(VENV_DIR, "Scripts", "pip")
        python = os.path.join(VENV_DIR, "Scripts", "python")
    else:
        pip = os.path.join(VENV_DIR, "bin", "pip")
        python = os.path.join(VENV_DIR, "bin", "python")

    print("[setup] Upgrading pip...")
    subprocess.run([pip, "install", "--upgrade", "pip"], check=True)

    print(f"[setup] Installing dependencies from {REQ_FILE}...")
    subprocess.run([pip, "install", "-r", REQ_FILE], check=True)

    print()
    print("=" * 60)
    print("  Setup complete!")
    print()
    if sys.platform == "win32":
        print(f"  Activate:  .\\venv\\Scripts\\activate")
    else:
        print(f"  Activate:  source venv/bin/activate")
    print(f"  Run:       python main.py")
    print("=" * 60)


if __name__ == "__main__":
    main()
