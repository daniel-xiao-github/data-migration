"""Abstract base class for target database adapters."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class ColumnInfo:
    name: str
    data_type: str
    nullable: bool = True
    max_length: int | None = None
    precision: int | None = None
    scale: int | None = None


@dataclass
class ColumnDef:
    name: str
    data_type: str
    nullable: bool = True
    primary_key: bool = False


@dataclass
class ConnectionTestResult:
    success: bool
    latency_ms: float
    message: str
    version: str | None = None
    details: dict | None = None


class TargetAdapter(ABC):
    """Abstract interface that every target-database adapter must implement."""

    @abstractmethod
    def connect(self, config: dict) -> None: ...

    @abstractmethod
    def disconnect(self) -> None: ...

    @abstractmethod
    def test_connection(self) -> ConnectionTestResult: ...

    @abstractmethod
    def table_exists(self, table_name: str) -> bool: ...

    @abstractmethod
    def get_columns(self, table_name: str) -> list[ColumnInfo]: ...

    @abstractmethod
    def create_table(self, table_name: str, columns: list[ColumnDef]) -> str: ...

    @abstractmethod
    def insert_batch(self, table_name: str, columns: list[str], rows: list[tuple]) -> int: ...

    @abstractmethod
    def upsert_batch(
        self, table_name: str, columns: list[str], pk_columns: list[str], rows: list[tuple]
    ) -> int: ...

    @abstractmethod
    def truncate_table(self, table_name: str) -> None: ...

    @abstractmethod
    def execute_ddl(self, sql: str) -> None: ...

    @abstractmethod
    def init_control_tables(self, prefix: str) -> None: ...

    @abstractmethod
    def execute_query(self, sql: str, params: dict | tuple | None = None) -> list[dict]: ...

    @abstractmethod
    def execute_update(self, sql: str, params: dict | tuple | None = None) -> int: ...
