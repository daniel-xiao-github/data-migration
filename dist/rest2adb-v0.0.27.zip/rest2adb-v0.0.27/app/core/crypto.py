"""Fernet encryption for credential storage at rest."""
import os
import base64
from pathlib import Path
from cryptography.fernet import Fernet

_KEY_FILE = Path(__file__).resolve().parent.parent.parent / "config" / ".encryption_key"

def _get_or_create_key() -> bytes:
    if _KEY_FILE.exists():
        return _KEY_FILE.read_bytes().strip()
    key = Fernet.generate_key()
    _KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
    _KEY_FILE.write_bytes(key)
    os.chmod(str(_KEY_FILE), 0o600)
    return key

def get_fernet() -> Fernet:
    return Fernet(_get_or_create_key())

def encrypt(plaintext: str) -> str:
    return get_fernet().encrypt(plaintext.encode()).decode()

def decrypt(ciphertext: str) -> str:
    return get_fernet().decrypt(ciphertext.encode()).decode()
