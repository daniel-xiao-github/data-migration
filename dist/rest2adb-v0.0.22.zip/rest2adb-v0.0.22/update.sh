#!/usr/bin/env bash
# ============================================================
#  REST → ADB Migration Workbench — Update (Linux / macOS)
#
#  Checks GitHub for a newer version and applies the update.
#  Usage:
#    ./update.sh              # check & install
#    ./update.sh --check      # check only
# ============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Find Python (same logic as start.sh)
find_python() {
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            if "$cmd" -c "import sys; assert sys.version_info >= (3,8)" 2>/dev/null; then
                echo "$cmd"
                return
            fi
        fi
    done
    return 1
}

PYTHON=$(find_python) || {
    echo "[FAIL]  Python 3.8+ is required. Install from https://www.python.org/downloads/"
    exit 1
}

exec "$PYTHON" "$SCRIPT_DIR/update.py" "$@"
