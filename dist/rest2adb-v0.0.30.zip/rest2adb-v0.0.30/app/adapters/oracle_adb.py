"""Oracle Autonomous Database adapter for rest2adb."""
from __future__ import annotations

import logging
import time
from typing import Any

from .base import (
    ColumnDef,
    ColumnInfo,
    ConnectionTestResult,
    TargetAdapter,
)

logger = logging.getLogger(__name__)

try:
    import oracledb
except ImportError:
    oracledb = None  # type: ignore[assignment]


class OracleAdbAdapter(TargetAdapter):
    """Adapter for Oracle Autonomous Database (ADB) using python-oracledb."""

    def __init__(self) -> None:
        self._pool: Any | None = None
        self._config: dict | None = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def connect(self, config: dict) -> None:
        if oracledb is None:
            raise RuntimeError(
                "The 'oracledb' package is required for Oracle connections. "
                "Install it with:  pip install oracledb"
            )

        self._config = config

        dsn: str = config["dsn"]
        username: str = config["username"]
        password: str = config["password"]
        wallet_path: str | None = config.get("wallet_path")
        connect_method: str = config.get("connect_method", "thin")
        min_connections: int = config.get("min_connections", 2)
        max_connections: int = config.get("max_connections", 10)

        # If a wallet is provided and thick mode is requested, initialise the
        # Oracle Client libraries (only needs to happen once per process).
        if wallet_path and connect_method == "thick":
            try:
                oracledb.init_oracle_client(config_dir=wallet_path)
            except oracledb.ProgrammingError:
                # Already initialised -- safe to ignore.
                pass

        pool_kwargs: dict[str, Any] = {
            "user": username,
            "password": password,
            "dsn": dsn,
            "min": min_connections,
            "max": max_connections,
        }

        if wallet_path and connect_method == "thin":
            pool_kwargs["config_dir"] = wallet_path
            pool_kwargs["wallet_location"] = wallet_path
            pool_kwargs["wallet_password"] = config.get("wallet_password", password)

        self._pool = oracledb.create_pool(**pool_kwargs)
        logger.info("Oracle connection pool created (min=%s, max=%s)", min_connections, max_connections)

    def disconnect(self) -> None:
        if self._pool is not None:
            try:
                self._pool.close(force=True)
            except Exception:
                logger.warning("Error closing Oracle connection pool", exc_info=True)
            finally:
                self._pool = None
        logger.info("Oracle connection pool closed")

    # ------------------------------------------------------------------
    # Health
    # ------------------------------------------------------------------

    def test_connection(self) -> ConnectionTestResult:
        start = time.perf_counter()
        try:
            with self._pool.acquire() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1 FROM DUAL")
                    cur.fetchone()
            latency = (time.perf_counter() - start) * 1000.0

            version: str | None = None
            try:
                with self._pool.acquire() as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT banner FROM v$version WHERE ROWNUM = 1")
                        row = cur.fetchone()
                        if row:
                            version = row[0]
            except Exception:
                pass

            return ConnectionTestResult(
                success=True,
                latency_ms=round(latency, 2),
                message="Connection successful",
                version=version,
            )
        except Exception as exc:
            latency = (time.perf_counter() - start) * 1000.0
            return ConnectionTestResult(
                success=False,
                latency_ms=round(latency, 2),
                message=str(exc),
            )

    # ------------------------------------------------------------------
    # Schema introspection
    # ------------------------------------------------------------------

    def table_exists(self, table_name: str) -> bool:
        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT COUNT(*) FROM user_tables WHERE table_name = :1",
                    [table_name.upper()],
                )
                row = cur.fetchone()
                return row is not None and row[0] > 0

    def get_columns(self, table_name: str) -> list[ColumnInfo]:
        sql = (
            "SELECT column_name, data_type, nullable, data_length, "
            "data_precision, data_scale "
            "FROM user_tab_columns "
            "WHERE table_name = :1 "
            "ORDER BY column_id"
        )
        columns: list[ColumnInfo] = []
        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, [table_name.upper()])
                for row in cur.fetchall():
                    columns.append(
                        ColumnInfo(
                            name=row[0],
                            data_type=row[1],
                            nullable=(row[2] == "Y"),
                            max_length=row[3],
                            precision=row[4],
                            scale=row[5],
                        )
                    )
        return columns

    # ------------------------------------------------------------------
    # DDL helpers
    # ------------------------------------------------------------------

    def create_table(self, table_name: str, columns: list[ColumnDef]) -> str:
        col_defs: list[str] = []
        pk_cols: list[str] = []

        for col in columns:
            parts = [f'"{col.name}" {col.data_type}']
            if not col.nullable:
                parts.append("NOT NULL")
            col_defs.append(" ".join(parts))
            if col.primary_key:
                pk_cols.append(f'"{col.name}"')

        if pk_cols:
            col_defs.append(f"PRIMARY KEY ({', '.join(pk_cols)})")

        ddl = f'CREATE TABLE "{table_name}" (\n  ' + ",\n  ".join(col_defs) + "\n)"
        self.execute_ddl(ddl)
        return ddl

    # ------------------------------------------------------------------
    # DML
    # ------------------------------------------------------------------

    def insert_batch(self, table_name: str, columns: list[str], rows: list[tuple]) -> int:
        if not rows:
            return 0

        col_list = ", ".join(f'"{c}"' for c in columns)
        bind_list = ", ".join(f":{i + 1}" for i in range(len(columns)))
        sql = f'INSERT INTO "{table_name}" ({col_list}) VALUES ({bind_list})'

        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.executemany(sql, rows)
            conn.commit()

        return len(rows)

    def upsert_batch(
        self, table_name: str, columns: list[str], pk_columns: list[str], rows: list[tuple]
    ) -> int:
        if not rows:
            return 0

        non_pk = [c for c in columns if c not in pk_columns]

        # Build the USING SELECT ... FROM DUAL
        select_parts = [f":{i + 1} AS \"{c}\"" for i, c in enumerate(columns)]
        using_clause = f"SELECT {', '.join(select_parts)} FROM DUAL"

        # ON condition
        on_parts = [f'd."{pk}" = s."{pk}"' for pk in pk_columns]
        on_clause = " AND ".join(on_parts)

        # UPDATE SET
        update_parts = [f'd."{c}" = s."{c}"' for c in non_pk]
        update_clause = ", ".join(update_parts) if update_parts else 'd."{}" = s."{}"'.format(
            pk_columns[0], pk_columns[0]
        )

        # INSERT
        insert_cols = ", ".join(f'"{c}"' for c in columns)
        insert_vals = ", ".join(f's."{c}"' for c in columns)

        sql = (
            f'MERGE INTO "{table_name}" d '
            f"USING ({using_clause}) s "
            f"ON ({on_clause}) "
            f"WHEN MATCHED THEN UPDATE SET {update_clause} "
            f"WHEN NOT MATCHED THEN INSERT ({insert_cols}) VALUES ({insert_vals})"
        )

        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.executemany(sql, rows)
            conn.commit()

        return len(rows)

    def truncate_table(self, table_name: str) -> None:
        self.execute_ddl(f'TRUNCATE TABLE "{table_name}"')

    def execute_ddl(self, sql: str) -> None:
        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
            conn.commit()

    # ------------------------------------------------------------------
    # Generic query / update
    # ------------------------------------------------------------------

    def execute_query(self, sql: str, params: dict | tuple | None = None) -> list[dict]:
        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                if params is not None:
                    cur.execute(sql, params)
                else:
                    cur.execute(sql)
                col_names = [desc[0] for desc in cur.description]
                return [dict(zip(col_names, row)) for row in cur.fetchall()]

    def execute_update(self, sql: str, params: dict | tuple | None = None) -> int:
        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                if params is not None:
                    cur.execute(sql, params)
                else:
                    cur.execute(sql)
            conn.commit()
            return cur.rowcount

    # ------------------------------------------------------------------
    # Control tables
    # ------------------------------------------------------------------

    def init_control_tables(self, prefix: str) -> None:
        """Create the rest2adb control tables if they do not already exist.

        Column names match those used by ControlTableManager.
        Uses PL/SQL BEGIN..EXCEPTION to skip ORA-00955 (table already exists).
        """
        p = prefix.upper()

        statements: list[str] = [
            f"""CREATE TABLE "{p}MIGRATION_JOB" (
                "JOB_ID"                VARCHAR2(64) PRIMARY KEY,
                "JOB_NAME"              VARCHAR2(256),
                "STATUS"                VARCHAR2(32) DEFAULT 'CREATED',
                "REST_CONNECTION_ID"    VARCHAR2(64),
                "ADB_CONNECTION_ID"     VARCHAR2(64),
                "CONFIG_JSON"           CLOB,
                "CREATED_AT"            TIMESTAMP DEFAULT SYSTIMESTAMP,
                "STARTED_AT"            TIMESTAMP,
                "COMPLETED_AT"          TIMESTAMP,
                "ERROR_MESSAGE"         CLOB,
                "TOTAL_ENDPOINTS"       NUMBER DEFAULT 0,
                "COMPLETED_ENDPOINTS"   NUMBER DEFAULT 0,
                "TOTAL_ROWS_MIGRATED"   NUMBER DEFAULT 0
            )""",
            f"""CREATE TABLE "{p}ENDPOINT_STATE" (
                "ENDPOINT_STATE_ID"     VARCHAR2(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR2(64),
                "ENDPOINT_PATH"        VARCHAR2(1024),
                "TARGET_TABLE"         VARCHAR2(256),
                "STATUS"               VARCHAR2(32) DEFAULT 'PENDING',
                "LAST_PAGE_CURSOR"     VARCHAR2(4000),
                "LAST_SUCCESSFUL_BATCH" NUMBER DEFAULT 0,
                "ROWS_FETCHED"         NUMBER DEFAULT 0,
                "ROWS_INSERTED"        NUMBER DEFAULT 0,
                "STARTED_AT"           TIMESTAMP,
                "COMPLETED_AT"         TIMESTAMP,
                "ERROR_MESSAGE"        CLOB,
                "RETRY_COUNT"          NUMBER DEFAULT 0
            )""",
            f"""CREATE TABLE "{p}BATCH_LOG" (
                "BATCH_ID"             VARCHAR2(64) PRIMARY KEY,
                "ENDPOINT_STATE_ID"    VARCHAR2(64),
                "BATCH_SEQ"            NUMBER,
                "PAGE_PARAM"           VARCHAR2(4000),
                "ROWS_IN_BATCH"        NUMBER DEFAULT 0,
                "STATUS"               VARCHAR2(32),
                "STARTED_AT"           TIMESTAMP,
                "COMPLETED_AT"         TIMESTAMP,
                "ERROR_MESSAGE"        CLOB
            )""",
            f"""CREATE TABLE "{p}SYNC_STATE" (
                "SYNC_STATE_ID"        VARCHAR2(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR2(64),
                "ENDPOINT_PATH"        VARCHAR2(1024),
                "SYNC_MODE"            VARCHAR2(32),
                "DELTA_FIELD"          VARCHAR2(256),
                "DELTA_PARAM"          VARCHAR2(256),
                "LAST_DELTA_VALUE"     VARCHAR2(4000),
                "LAST_ETAG"            VARCHAR2(4000),
                "LAST_SYNC_AT"         TIMESTAMP,
                "ROWS_SYNCED"          NUMBER DEFAULT 0
            )""",
            f"""CREATE TABLE "{p}QUARANTINE" (
                "QUARANTINE_ID"        VARCHAR2(64) PRIMARY KEY,
                "JOB_ID"               VARCHAR2(64),
                "ENDPOINT_PATH"        VARCHAR2(1024),
                "BATCH_SEQ"            NUMBER,
                "ROW_DATA"             CLOB,
                "VIOLATIONS"           CLOB,
                "SEVERITY"             VARCHAR2(32),
                "CREATED_AT"           TIMESTAMP DEFAULT SYSTIMESTAMP,
                "RESOLVED"             VARCHAR2(1) DEFAULT 'N'
            )""",
            f"""CREATE TABLE "{p}BATCH_RUN" (
                "BATCH_RUN_ID"         VARCHAR2(64) PRIMARY KEY,
                "BATCH_NAME"           VARCHAR2(256),
                "STATUS"               VARCHAR2(32) DEFAULT 'CREATED',
                "CONCURRENCY"          NUMBER DEFAULT 5,
                "CREATED_AT"           TIMESTAMP DEFAULT SYSTIMESTAMP,
                "STARTED_AT"           TIMESTAMP,
                "COMPLETED_AT"         TIMESTAMP,
                "TOTAL_JOBS"           NUMBER DEFAULT 0,
                "COMPLETED_JOBS"       NUMBER DEFAULT 0,
                "FAILED_JOBS"          NUMBER DEFAULT 0
            )""",
            f"""CREATE TABLE "{p}BATCH_RUN_JOBS" (
                "BATCH_RUN_ID"         VARCHAR2(64),
                "JOB_ID"               VARCHAR2(64),
                "EXECUTION_ORDER"      NUMBER,
                "STATUS"               VARCHAR2(32) DEFAULT 'PENDING',
                "STARTED_AT"           TIMESTAMP,
                "COMPLETED_AT"         TIMESTAMP,
                PRIMARY KEY ("BATCH_RUN_ID", "JOB_ID")
            )""",
        ]

        with self._pool.acquire() as conn:
            with conn.cursor() as cur:
                for ddl in statements:
                    clean_ddl = " ".join(ddl.split())
                    plsql = (
                        f"BEGIN EXECUTE IMMEDIATE '{clean_ddl.replace(chr(39), chr(39)+chr(39))}'; "
                        f"EXCEPTION WHEN OTHERS THEN "
                        f"IF SQLCODE = -955 THEN NULL; ELSE RAISE; END IF; END;"
                    )
                    cur.execute(plsql)
            conn.commit()

        logger.info("Oracle control tables initialised (prefix=%s)", prefix)
