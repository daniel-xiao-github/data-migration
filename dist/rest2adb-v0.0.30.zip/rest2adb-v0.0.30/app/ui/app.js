/* REST→ADB Migration Workbench — SPA Controller */
"use strict";

const App = (() => {
  // ── State ───────────────────────────────────────────────────────────
  let currentStep = 0;
  let discoveredEndpoints = [];
  let currentMappings = [];
  let currentRules = [];
  let jobMappedEndpoints = [];  // endpoints with saved mappings for job creation
  let editingRestId = null;   // non-null when editing a saved REST connection
  let editingTargetId = null; // non-null when editing a saved Target connection

  // ── API helpers ─────────────────────────────────────────────────────
  const api = (path, opts = {}) => {
    const o = { headers: { "Content-Type": "application/json" }, ...opts };
    if (o.body && typeof o.body === "object") o.body = JSON.stringify(o.body);
    return fetch(`/api${path}`, o).then(r => r.json()).catch(e => {
      toast("API error: " + e.message, "error"); return null;
    });
  };
  const GET = p => api(p);
  const POST = (p, b) => api(p, { method: "POST", body: b });
  const PUT = (p, b) => api(p, { method: "PUT", body: b });
  const DEL = p => api(p, { method: "DELETE" });

  // ── Toast ───────────────────────────────────────────────────────────
  function toast(msg, type = "info") {
    const c = document.getElementById("toasts");
    const d = document.createElement("div");
    d.className = `toast toast-${type}`;
    d.textContent = msg;
    c.appendChild(d);
    setTimeout(() => d.remove(), 4000);
  }

  // ── Stepper ─────────────────────────────────────────────────────────
  function goStep(n) {
    currentStep = n;
    document.querySelectorAll(".step").forEach((s, i) => {
      s.classList.toggle("active", i === n);
      s.classList.toggle("done", i < n);
    });
    document.querySelectorAll(".panel").forEach((p, i) => {
      p.classList.toggle("visible", i === n);
    });
    // Refresh data for the new step
    if (n === 0) { loadAllConns(); }
    if (n === 1) {
      populateRestConnSelect("disc-rest-conn").then(() => {
        syncOpenApiUrl();
        loadDiscovered();
      });
    }
    if (n === 2) { populateMapEndpoints(); }
    if (n === 3) { populateEndpointSelect("val-endpoint"); }
    if (n === 4) {
      populateRestConnSelect("job-rest-conn").then(() => populateJobEndpoints());
      populateTargetConnSelect("job-target-conn");
      loadJobs(); loadBatchRuns(); _loadJobTabLog();
    }
  }

  function switchSubTab(group, idx) {
    const tabs = document.querySelectorAll(`#${group}-tabs .sub-tab`);
    const panels = document.querySelectorAll(`.sub-panel[data-tab-group="${group}"]`);
    tabs.forEach((t, i) => t.classList.toggle('active', i === idx));
    panels.forEach((p, i) => p.classList.toggle('visible', i === idx));
  }

  // ── STEP 0: Connections ─────────────────────────────────────────────

  // --- Toggle target DB form fields based on type ---
  function toggleTargetFields() {
    const type = document.getElementById("tc-type").value;
    const oracleFields = document.getElementById("tc-oracle-fields");
    const genericFields = document.getElementById("tc-generic-fields");
    if (type === "oracle_adb") {
      oracleFields.style.display = "";
      genericFields.style.display = "none";
    } else {
      oracleFields.style.display = "none";
      genericFields.style.display = "";
      // Update placeholder based on type
      const portEl = document.getElementById("tc-port");
      const dbEl = document.getElementById("tc-database");
      if (type === "postgresql") {
        portEl.placeholder = "5432";
        dbEl.placeholder = "mydb";
      } else if (type === "mysql") {
        portEl.placeholder = "3306";
        dbEl.placeholder = "mydb";
      }
    }
  }

  // --- REST connection auth fields ---
  function toggleAuthFields() {
    const type = document.getElementById("rc-auth-type").value;
    const div = document.getElementById("auth-details");
    const form = document.getElementById("auth-form");
    if (type === "none") { div.classList.add("hidden"); return; }
    div.classList.remove("hidden");
    let html = "";
    if (type === "api_key") {
      html = `<div class="form-group"><label>Header Name</label>
              <input id="auth-key" placeholder="X-API-Key"></div>
              <div class="form-group"><label>API Key Value</label>
              <input id="auth-value" type="password"></div>`;
    } else if (type === "basic") {
      html = `<div class="form-group"><label>Username</label>
              <input id="auth-username"></div>
              <div class="form-group"><label>Password</label>
              <input id="auth-password" type="password"></div>`;
    } else if (type === "bearer") {
      html = `<div class="form-group full"><label>Bearer Token</label>
              <input id="auth-token" type="password"></div>`;
    } else if (type.startsWith("oauth2")) {
      html = `<div class="form-group"><label>Authorization URL</label>
              <input id="auth-auth-url" placeholder="https://..."></div>
              <div class="form-group"><label>Token URL</label>
              <input id="auth-token-url" placeholder="https://..."></div>
              <div class="form-group"><label>Client ID</label>
              <input id="auth-client-id"></div>
              <div class="form-group"><label>Client Secret</label>
              <input id="auth-client-secret" type="password"></div>
              <div class="form-group"><label>Scopes</label>
              <input id="auth-scopes" placeholder="read write"></div>`;
    }
    form.innerHTML = html;
  }

  function buildAuthConfig() {
    const type = document.getElementById("rc-auth-type").value;
    if (type === "none") return {};
    if (type === "api_key") return {
      key: el("auth-key"), value: el("auth-value"), location: "header"
    };
    if (type === "basic") return {
      username: el("auth-username"), password: el("auth-password")
    };
    if (type === "bearer") return { token: el("auth-token") };
    return {};
  }

  function buildOAuth2Config() {
    const type = document.getElementById("rc-auth-type").value;
    if (!type.startsWith("oauth2")) return null;
    return {
      authorization_url: el("auth-auth-url") || "",
      token_url: el("auth-token-url") || "",
      client_id: el("auth-client-id") || "",
      client_secret: el("auth-client-secret") || "",
      scopes: (el("auth-scopes") || "").split(/\s+/).filter(Boolean),
      use_pkce: true,
    };
  }

  // --- Build REST connection payload from form ---
  function buildRestConnPayload() {
    return {
      name: el("rc-name"),
      base_url: el("rc-base-url"),
      source_type: el("rc-source-type"),
      auth_type: el("rc-auth-type"),
      auth_config: buildAuthConfig(),
      oauth2_config: buildOAuth2Config(),
      openapi_url: el("rc-openapi-url"),
      timeout_seconds: parseInt(el("rc-timeout")) || 30,
    };
  }

  // --- Build Target connection payload from form ---
  function buildTargetConnPayload() {
    const type = el("tc-type");
    const payload = {
      name: el("tc-name"),
      target_type: type,
      username: el("tc-username"),
      password: el("tc-password"),
    };
    if (type === "oracle_adb") {
      payload.dsn = el("tc-dsn");
      payload.wallet_path = el("tc-wallet");
    } else {
      const host = el("tc-host");
      const port = parseInt(el("tc-port")) || null;
      const database = el("tc-database");
      payload.host = host;
      payload.port = port;
      payload.database = database;
      // Build DSN for adapter compatibility
      if (type === "postgresql") {
        payload.dsn = host && database
          ? `${host}${port ? ":" + port : ""}/${database}` : host;
      } else if (type === "mysql") {
        payload.dsn = host || "";
      }
    }
    return payload;
  }

  // --- Test REST connection from form (before saving) ---
  async function testRestConnForm() {
    const conn = buildRestConnPayload();
    if (!conn.base_url) { toast("Enter a Base URL first", "error"); return; }
    toast("Testing connection...", "info");
    const res = await POST("/rest-connections/test", conn);
    if (res) {
      toast(res.success ? `Connected (${res.latency_ms}ms)` : `Failed: ${res.message}`,
            res.success ? "success" : "error");
    }
  }

  // --- Test Target connection from form (before saving) ---
  async function testTargetConnForm() {
    const conn = buildTargetConnPayload();
    if (!conn.username) { toast("Enter credentials first", "error"); return; }
    toast("Testing connection...", "info");
    const res = await POST("/target-connections/test", conn);
    if (res) {
      toast(res.success ? `Connected (${res.latency_ms}ms) ${res.version || ""}` : `Failed: ${res.message}`,
            res.success ? "success" : "error");
    }
  }

  // --- Toggle and send REST connection preview ---
  function togglePreview() {
    const panel = document.getElementById("rc-preview-panel");
    panel.style.display = panel.style.display === "none" ? "" : "none";
  }

  async function sendPreview() {
    const conn = buildRestConnPayload();
    if (!conn.base_url) { toast("Enter a Base URL first", "error"); return; }
    conn.preview_path = el("rc-preview-path") || "/";
    conn.preview_method = el("rc-preview-method") || "GET";
    toast("Sending request...", "info");
    const res = await POST("/rest-connections/preview", conn);
    if (!res) return;

    const resultDiv = document.getElementById("rc-preview-result");
    resultDiv.style.display = "";

    const statusEl = document.getElementById("rc-preview-status");
    const cls = res.success ? "badge-success" : "badge-danger";
    statusEl.innerHTML = `<span class="badge ${cls}">HTTP ${res.status_code}</span> <span class="text-sm text-muted">${res.latency_ms}ms</span>`;

    document.getElementById("rc-preview-headers").textContent =
      Object.entries(res.headers || {}).map(([k, v]) => `${k}: ${v}`).join("\n");
    document.getElementById("rc-preview-body").textContent = res.body || "(empty)";
  }

  // --- Save REST connection (create or update) ---
  async function saveRestConn() {
    const conn = buildRestConnPayload();
    if (editingRestId) {
      const res = await PUT(`/rest-connections/${editingRestId}`, conn);
      if (res && res.status === "updated") {
        toast("REST connection updated", "success");
        cancelEditRest();
      }
    } else {
      const res = await POST("/rest-connections", conn);
      if (res && res.id) {
        toast("REST connection saved", "success");
        clearRestForm();
        hideConnForm("rest");
      }
    }
    loadAllConns();
  }

  // --- Save Target connection (create or update) ---
  async function saveTargetConn() {
    const conn = buildTargetConnPayload();
    if (editingTargetId) {
      const res = await PUT(`/target-connections/${editingTargetId}`, conn);
      if (res && res.status === "updated") {
        toast("Target connection updated", "success");
        cancelEditTarget();
      }
    } else {
      const res = await POST("/target-connections", conn);
      if (res && res.id) {
        toast("Target connection saved", "success");
        clearTargetForm();
        hideConnForm("target");
      }
    }
    loadAllConns();
  }

  // --- Edit REST connection (load into form) ---
  async function editRestConn(id) {
    const conn = await GET(`/rest-connections/${id}`);
    if (!conn) return;

    editingRestId = id;
    document.getElementById("rc-save-btn").textContent = "Update Connection";
    document.getElementById("rc-cancel-btn").style.display = "";

    document.getElementById("rc-name").value = conn.name || "";
    document.getElementById("rc-base-url").value = conn.base_url || "";
    document.getElementById("rc-source-type").value = conn.source_type || "rest_get";
    document.getElementById("rc-auth-type").value = conn.auth_type || "none";
    document.getElementById("rc-openapi-url").value = conn.openapi_url || "";
    document.getElementById("rc-timeout").value = conn.timeout_seconds || 30;

    // Trigger auth fields and populate them
    toggleAuthFields();
    const ac = conn.auth_config || {};
    if (conn.auth_type === "api_key") {
      setEl("auth-key", ac.key);
      setEl("auth-value", ac.value);
    } else if (conn.auth_type === "basic") {
      setEl("auth-username", ac.username);
      setEl("auth-password", ac.password);
    } else if (conn.auth_type === "bearer") {
      setEl("auth-token", ac.token);
    } else if (conn.auth_type && conn.auth_type.startsWith("oauth2")) {
      const oc = conn.oauth2_config || {};
      setEl("auth-auth-url", oc.authorization_url);
      setEl("auth-token-url", oc.token_url);
      setEl("auth-client-id", oc.client_id);
      setEl("auth-client-secret", oc.client_secret);
      setEl("auth-scopes", (oc.scopes || []).join(" "));
    }

    toast("Editing: " + conn.name, "info");
    showConnForm("rest");
    document.getElementById("rc-name").focus();
  }

  // --- Edit Target connection (load into form) ---
  async function editTargetConn(id) {
    const conn = await GET(`/target-connections/${id}`);
    if (!conn) return;

    editingTargetId = id;
    document.getElementById("tc-save-btn").textContent = "Update Connection";
    document.getElementById("tc-cancel-btn").style.display = "";

    document.getElementById("tc-name").value = conn.name || "";
    document.getElementById("tc-type").value = conn.target_type || "oracle_adb";
    toggleTargetFields();

    if (conn.target_type === "oracle_adb") {
      document.getElementById("tc-dsn").value = conn.dsn || "";
      document.getElementById("tc-wallet").value = conn.wallet_path || "";
    } else {
      document.getElementById("tc-host").value = conn.host || "";
      document.getElementById("tc-port").value = conn.port || "";
      document.getElementById("tc-database").value = conn.database || "";
    }
    document.getElementById("tc-username").value = conn.username || "";
    document.getElementById("tc-password").value = conn.password || "";

    toast("Editing: " + conn.name, "info");
    showConnForm("target");
    document.getElementById("tc-name").focus();
  }

  // --- Cancel edit modes ---
  function cancelEditRest() {
    editingRestId = null;
    document.getElementById("rc-save-btn").textContent = "Save Connection";
    document.getElementById("rc-cancel-btn").style.display = "none";
    clearRestForm();
    hideConnForm("rest");
  }

  function cancelEditTarget() {
    editingTargetId = null;
    document.getElementById("tc-save-btn").textContent = "Save Connection";
    document.getElementById("tc-cancel-btn").style.display = "none";
    clearTargetForm();
    hideConnForm("target");
  }

  function clearRestForm() {
    document.getElementById("rc-name").value = "";
    document.getElementById("rc-base-url").value = "";
    document.getElementById("rc-source-type").value = "rest_get";
    document.getElementById("rc-auth-type").value = "none";
    document.getElementById("rc-openapi-url").value = "";
    document.getElementById("rc-timeout").value = "30";
    document.getElementById("auth-details").classList.add("hidden");
    document.getElementById("auth-form").innerHTML = "";
  }

  function clearTargetForm() {
    document.getElementById("tc-name").value = "";
    document.getElementById("tc-type").value = "oracle_adb";
    toggleTargetFields();
    document.getElementById("tc-dsn").value = "";
    document.getElementById("tc-wallet").value = "";
    document.getElementById("tc-host").value = "";
    document.getElementById("tc-port").value = "";
    document.getElementById("tc-database").value = "";
    document.getElementById("tc-username").value = "";
    document.getElementById("tc-password").value = "";
  }

  // --- Show / hide connection forms ---
  function showConnForm(type) {
    // Hide both forms first, then show the requested one
    document.getElementById("conn-form-rest").style.display = "none";
    document.getElementById("conn-form-target").style.display = "none";
    document.getElementById(`conn-form-${type}`).style.display = "";
  }

  function hideConnForm(type) {
    document.getElementById(`conn-form-${type}`).style.display = "none";
  }

  // --- Load / render all saved connections (unified table) ---
  async function loadAllConns() {
    const [restConns, targetConns] = await Promise.all([
      GET("/rest-connections"),
      GET("/target-connections"),
    ]);
    const tbody = document.getElementById("all-conn-list");
    let rows = "";

    if (restConns) {
      rows += restConns.map(c => `<tr>
        <td><span class="tag">REST</span></td>
        <td>${esc(c.name)}</td>
        <td>${esc(c.base_url)}</td>
        <td><span class="tag">${c.auth_type}</span></td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="App.editRestConn('${c.id}')">Edit</button>
          <button class="btn btn-outline btn-sm" onclick="App.testRestConn('${c.id}')">Test</button>
          <button class="btn btn-outline btn-sm" onclick="App.previewSavedRestConn('${c.id}','${esc(c.name)}')">Preview</button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteRestConn('${c.id}')">Del</button>
        </td></tr>`).join("");
    }

    if (targetConns) {
      rows += targetConns.map(c => {
        let displayHost = c.host || c.dsn || "";
        if (displayHost.length > 50) displayHost = displayHost.substring(0, 47) + "...";
        return `<tr>
        <td><span class="tag">${c.target_type === 'oracle_adb' ? 'ADB' : c.target_type.toUpperCase()}</span></td>
        <td>${esc(c.name)}</td>
        <td title="${esc(c.host || c.dsn || "")}">${esc(displayHost)}</td>
        <td><span class="tag">${c.target_type}</span></td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="App.editTargetConn('${c.id}')">Edit</button>
          <button class="btn btn-outline btn-sm" onclick="App.testTargetConn('${c.id}')">Test</button>
          <button class="btn btn-danger btn-sm" onclick="App.deleteTargetConn('${c.id}')">Del</button>
        </td></tr>`;
      }).join("");
    }

    if (!rows) {
      rows = `<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:1.5rem">No connections yet. Click <strong>+ REST</strong> or <strong>+ ADB</strong> to add one.</td></tr>`;
    }

    tbody.innerHTML = rows;
  }

  async function testRestConn(id) {
    const res = await POST(`/rest-connections/${id}/test`);
    if (res) {
      toast(res.success ? `Connected (${res.latency_ms}ms)` : `Failed: ${res.message}`,
            res.success ? "success" : "error");
    }
  }

  async function testTargetConn(id) {
    const res = await POST(`/target-connections/${id}/test`);
    if (res) {
      toast(res.success ? `Connected (${res.latency_ms}ms) ${res.version || ""}` : `Failed: ${res.message}`,
            res.success ? "success" : "error");
    }
  }

  async function previewSavedRestConn(connId, connName) {
    let html = `<div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem" onclick="if(event.target===this)this.remove()" id="rest-preview-overlay">
    <div class="card" style="max-width:750px;width:95vw;max-height:90vh;overflow-y:auto;margin:0">
      <div class="flex-between">
        <h3>Preview: ${esc(connName)}</h3>
        <button class="btn btn-outline btn-sm" onclick="document.getElementById('rest-preview-overlay').remove()">&times;</button>
      </div>
      <div class="form-grid mt-1">
        <div class="form-group"><label>Request Path</label>
          <input id="saved-preview-path" placeholder="/" value="/"></div>
        <div class="form-group"><label>Method</label>
          <select id="saved-preview-method">
            <option value="GET">GET</option><option value="POST">POST</option>
          </select></div>
      </div>
      <button class="btn btn-primary btn-sm mt-1" onclick="App._sendSavedPreview('${connId}')">Send Request</button>
      <div id="saved-preview-result" class="mt-1" style="display:none">
        <div id="saved-preview-status" class="mb-1"></div>
        <details open>
          <summary style="cursor:pointer;font-weight:600;font-size:.85rem">Response Headers</summary>
          <pre id="saved-preview-headers" class="log-viewer" style="max-height:150px;font-size:.75rem;margin-top:.25rem"></pre>
        </details>
        <details open>
          <summary style="cursor:pointer;font-weight:600;font-size:.85rem;margin-top:.5rem">Response Body</summary>
          <pre id="saved-preview-body" class="log-viewer" style="max-height:300px;font-size:.75rem;margin-top:.25rem"></pre>
        </details>
      </div>
    </div></div>`;
    const overlay = document.createElement("div");
    overlay.innerHTML = html;
    document.body.appendChild(overlay.firstElementChild);
  }

  async function _sendSavedPreview(connId) {
    const path = el("saved-preview-path") || "/";
    const method = el("saved-preview-method") || "GET";
    toast("Sending request...", "info");
    const res = await POST(`/rest-connections/${connId}/preview`, {
      preview_path: path, preview_method: method
    });
    if (!res) return;
    const resultDiv = document.getElementById("saved-preview-result");
    resultDiv.style.display = "";
    const statusEl = document.getElementById("saved-preview-status");
    const cls = res.success ? "badge-success" : "badge-danger";
    statusEl.innerHTML = `<span class="badge ${cls}">HTTP ${res.status_code}</span> <span class="text-sm text-muted">${res.latency_ms}ms</span>`;
    document.getElementById("saved-preview-headers").textContent =
      Object.entries(res.headers || {}).map(([k, v]) => `${k}: ${v}`).join("\n");
    document.getElementById("saved-preview-body").textContent = res.body || "(empty)";
  }

  async function deleteRestConn(id) {
    await DEL(`/rest-connections/${id}`);
    toast("Deleted", "info"); loadAllConns();
    if (editingRestId === id) cancelEditRest();
  }

  async function deleteTargetConn(id) {
    await DEL(`/target-connections/${id}`);
    toast("Deleted", "info"); loadAllConns();
    if (editingTargetId === id) cancelEditTarget();
  }

  // ── Export / Import ────────────────────────────────────────────────

  function _downloadJson(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function _readJsonFile(input) {
    return new Promise((resolve, reject) => {
      const file = input.files[0];
      if (!file) return reject(new Error("No file selected"));
      const reader = new FileReader();
      reader.onload = () => {
        try { resolve(JSON.parse(reader.result)); }
        catch (e) { reject(new Error("Invalid JSON file")); }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsText(file);
    });
  }

  async function exportConnections() {
    const data = await GET("/connections/export");
    if (data) {
      _downloadJson(data, "connections-export.json");
      toast("Connections exported", "success");
    }
  }

  async function importConnections(input) {
    try {
      const data = await _readJsonFile(input);
      input.value = "";
      const res = await POST("/connections/import", data);
      if (res) {
        toast(`Imported ${res.rest} REST + ${res.target} target connections` +
              (res.skipped ? ` (${res.skipped} skipped)` : ""), "success");
        loadAllConns();
      }
    } catch (e) { toast(e.message, "error"); }
  }

  async function exportEndpoints() {
    const connId = el("disc-rest-conn");
    if (!connId) { toast("Select a REST connection first", "error"); return; }
    const data = await GET(`/discovery/${connId}/endpoints/export`);
    if (data) {
      const name = (data.rest_connection_name || "endpoints").replace(/\s+/g, "-");
      _downloadJson(data, `${name}-endpoints.json`);
      toast("Endpoints exported", "success");
    }
  }

  async function importEndpoints(input) {
    try {
      const connId = el("disc-rest-conn");
      if (!connId) { toast("Select a REST connection first", "error"); input.value = ""; return; }
      const data = await _readJsonFile(input);
      input.value = "";
      const res = await POST("/discovery/endpoints/import", {
        rest_connection_id: connId,
        endpoints: data.endpoints || data,
      });
      if (res) {
        toast(`Imported ${res.added} endpoints (${res.total} total)`, "success");
        loadDiscovered();
      }
    } catch (e) { toast(e.message, "error"); }
  }

  // ── STEP 1: Discovery ──────────────────────────────────────────────
  async function populateRestConnSelect(selectId) {
    const conns = await GET("/rest-connections") || [];
    const sel = document.getElementById(selectId);
    if (!sel) return;
    sel.innerHTML = conns.map(c =>
      `<option value="${c.id}">${esc(c.name)}</option>`
    ).join("");
  }

  async function populateTargetConnSelect(selectId) {
    const conns = await GET("/target-connections") || [];
    const sel = document.getElementById(selectId);
    if (!sel) return;
    sel.innerHTML = conns.map(c =>
      `<option value="${c.id}">${esc(c.name)}</option>`
    ).join("");
  }

  // Toggle discovery method sections
  document.getElementById("disc-method")?.addEventListener("change", function () {
    document.getElementById("disc-openapi-section").classList.toggle("hidden", this.value !== "openapi");
    document.getElementById("disc-manual-section").classList.toggle("hidden", this.value !== "manual");
    document.getElementById("disc-sample-section").classList.toggle("hidden", this.value !== "sample");
  });

  // Sync OpenAPI URL and load saved endpoints when REST connection changes
  document.getElementById("disc-rest-conn")?.addEventListener("change", () => {
    syncOpenApiUrl();
    loadDiscovered();
  });

  // Refresh job endpoints when REST connection changes
  document.getElementById("job-rest-conn")?.addEventListener("change", () => populateJobEndpoints());

  async function syncOpenApiUrl() {
    const connId = el("disc-rest-conn");
    if (!connId) return;
    const conn = await GET(`/rest-connections/${connId}`);
    if (conn && conn.openapi_url) {
      document.getElementById("disc-openapi-url").value = conn.openapi_url;
    }
  }

  async function discoverOpenAPI() {
    const connId = el("disc-rest-conn");
    const url = el("disc-openapi-url");
    if (!connId || !url) { toast("Select connection and enter URL", "error"); return; }
    toast("Importing from OpenAPI...", "info");
    const res = await POST("/discovery/openapi", { rest_connection_id: connId, openapi_url: url });
    if (res && res.error) { toast("Discovery error: " + res.error, "error"); return; }
    if (res && res.endpoints) {
      discoveredEndpoints = res.endpoints;
      toast(`Discovered ${res.count} endpoints`, "success");
      renderDiscovered();
    }
  }

  async function discoverManual() {
    const connId = el("disc-rest-conn");
    const url = el("disc-manual-url");
    if (!connId || !url) { toast("Select connection and enter URL", "error"); return; }
    const deep = document.getElementById("disc-manual-deep")?.checked || false;
    const endpoint = {
      url: url,
      http_method: el("disc-manual-method"),
      data_root_path: el("disc-manual-root"),
      source_type: "rest_get",
    };
    toast(deep ? "Probing endpoint & sub-resources..." : "Probing endpoint...", "info");
    const res = await POST("/discovery/manual", { rest_connection_id: connId, endpoint, deep });
    if (res && res.error) { toast("Probe error: " + res.error, "error"); return; }
    if (deep && res && res.endpoints) {
      discoveredEndpoints = discoveredEndpoints.concat(res.endpoints);
      const subs = res.endpoints.filter(e => e.metadata_source === "sample_deep").length;
      toast(`Discovered ${res.count} endpoint(s)` + (subs ? ` (${subs} sub-resource${subs > 1 ? "s" : ""})` : ""), "success");
      renderDiscovered();
    } else if (res && res.endpoint) {
      discoveredEndpoints.push(res.endpoint);
      toast("Endpoint discovered", "success");
      renderDiscovered();
    }
  }

  async function discoverSample() {
    const connId = el("disc-rest-conn");
    const urlText = el("disc-sample-urls");
    if (!connId || !urlText.trim()) {
      toast("Select connection and enter at least one endpoint path", "error");
      return;
    }
    const deep = document.getElementById("disc-sample-deep")?.checked || false;
    const paths = urlText.split("\n").map(s => s.trim()).filter(Boolean);
    const endpoints = paths.map(p => ({ path: p, http_method: "GET" }));
    toast(deep ? `Probing ${endpoints.length} endpoints & sub-resources...`
               : `Probing ${endpoints.length} endpoints...`, "info");
    const res = await POST("/discovery/sample", {
      rest_connection_id: connId, endpoints, deep
    });
    if (res && res.error) { toast("Probe error: " + res.error, "error"); return; }
    if (res && res.endpoints) {
      discoveredEndpoints = discoveredEndpoints.concat(res.endpoints);
      const subs = res.endpoints.filter(e => e.metadata_source === "sample_deep").length;
      toast(`Discovered ${res.count} endpoint(s)` + (subs ? ` (${subs} sub-resource${subs > 1 ? "s" : ""})` : ""), "success");
      renderDiscovered();
    }
  }

  async function loadDiscovered() {
    const connId = el("disc-rest-conn");
    if (!connId) return;
    const eps = await GET(`/discovery/${connId}/endpoints`);
    if (eps) { discoveredEndpoints = eps; renderDiscovered(); }
  }

  function renderDiscovered() {
    const tbody = document.getElementById("disc-endpoint-list");
    document.getElementById("disc-count").textContent = `${discoveredEndpoints.length} endpoints`;
    if (!discoveredEndpoints.length) {
      tbody.innerHTML = `<tr><td colspan="7" class="empty-state">No endpoints discovered yet</td></tr>`;
      return;
    }
    const WRAPPER_KEYS = new Set(["data", "results", "items", "records", "rows", "content", "entries", "list", "payload"]);
    tbody.innerHTML = discoveredEndpoints.map((ep, i) => {
      let fields = ep.fields || [];
      let childTbls = ep.child_tables || [];
      // If fields only contain wrapper entries (e.g. "data" type "array"),
      // show the inner child-table field count instead.
      if (fields.length <= 1 && fields.every(f => WRAPPER_KEYS.has(f.name) || f.field_type === "array")) {
        const wrapperChild = childTbls.find(ct => WRAPPER_KEYS.has(ct.source_array) && ct.fields && ct.fields.length);
        if (wrapperChild) {
          fields = wrapperChild.fields;
          childTbls = childTbls.filter(ct => ct !== wrapperChild);
        }
      }
      const nFields = fields.length;
      const nChild = childTbls.length;
      const detailExtra = (ep.detail_fields || []).length;
      let fieldLabel = `${nFields} fields`;
      const parts = [];
      if (detailExtra) parts.push(`+${detailExtra} detail`);
      if (nChild) parts.push(`${nChild} child`);
      if (parts.length) fieldLabel += ` <span class="text-muted text-sm">(${parts.join(", ")})</span>`;
      const isSub = ep.metadata_source === "sample_deep";
      const srcBadge = isSub
        ? `<span class="badge badge-accent" title="Discovered via detail endpoint links">sub-resource</span>`
        : `<span class="badge badge-muted">${ep.metadata_source || ""}</span>`;
      const parentNote = isSub && ep.parent_endpoint
        ? `<br><span class="text-muted text-sm">parent: ${esc(ep.parent_endpoint)}</span>` : "";
      return `<tr>
      <td><input type="checkbox" class="disc-ep-check" value="${i}" checked></td>
      <td><code>${esc(ep.path)}</code>${parentNote}</td>
      <td><span class="badge badge-info">${ep.http_method || "GET"}</span></td>
      <td>${fieldLabel}</td>
      <td>${ep.pagination ? `<span class="tag">${ep.pagination.type}</span>` : "-"}</td>
      <td>${srcBadge}</td>
      <td><button class="btn btn-outline btn-sm" onclick="App.viewEndpoint(${i})">View</button></td>
    </tr>`;
    }).join("");
  }

  function selectAllDiscEndpoints(checked) {
    document.querySelectorAll(".disc-ep-check").forEach(cb => { cb.checked = checked; });
  }

  async function updateSelectedEndpoints() {
    const connId = el("disc-rest-conn");
    if (!connId) { toast("Select a REST connection first", "error"); return; }
    const checked = document.querySelectorAll(".disc-ep-check:checked");
    if (!checked.length) { toast("Select at least one endpoint", "error"); return; }
    const paths = [];
    checked.forEach(cb => {
      const ep = discoveredEndpoints[parseInt(cb.value)];
      if (ep) paths.push(ep.path);
    });
    toast(`Re-probing ${paths.length} endpoint(s)...`, "info");
    const res = await POST("/discovery/update", {
      rest_connection_id: connId, paths, deep: false
    });
    if (res && res.endpoints) {
      discoveredEndpoints = res.endpoints;
      renderDiscovered();
      toast(`Updated ${res.updated} endpoint(s)`, "success");
    } else if (res && res.error) {
      toast("Update failed: " + res.error, "error");
    }
  }

  function viewEndpoint(idx) {
    const ep = discoveredEndpoints[idx];
    if (!ep) return;

    // Build a modal-style overlay instead of alert
    const detailSet = new Set(ep.detail_fields || []);
    const WRAPPER_SET = new Set(["data", "results", "items", "records", "rows", "content", "entries", "list", "payload"]);
    let viewFields = ep.fields || [];
    let viewChildTables = (ep.child_tables || []).slice();
    // Promote wrapper child table to main fields when unwrap failed
    if (viewFields.length <= 1 && viewFields.every(f => WRAPPER_SET.has(f.name) || f.field_type === "array")) {
      const wci = viewChildTables.findIndex(ct => WRAPPER_SET.has(ct.source_array) && ct.fields && ct.fields.length);
      if (wci >= 0) {
        viewFields = viewChildTables[wci].fields;
        viewChildTables.splice(wci, 1);
      }
    }
    if (!viewFields.length && viewChildTables.length) {
      const wci = viewChildTables.findIndex(ct => WRAPPER_SET.has(ct.source_array) && ct.fields && ct.fields.length);
      if (wci >= 0) {
        viewFields = viewChildTables[wci].fields;
        viewChildTables.splice(wci, 1);
      }
    }
    const childTables = viewChildTables;

    let html = `<div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;display:flex;align-items:center;justify-content:center" onclick="if(event.target===this)this.remove()">
    <div class="card" style="max-width:700px;width:95vw;max-height:85vh;overflow-y:auto;margin:0">
      <div class="flex-between">
        <h3>Endpoint: <code>${esc(ep.path)}</code></h3>
        <button class="btn btn-outline btn-sm" onclick="this.closest('[style*=fixed]').remove()">&times;</button>
      </div>
      <div class="mt-1">
        <span class="badge badge-info">${ep.http_method || "GET"}</span>
        <span class="badge badge-muted">${ep.metadata_source || ""}</span>`;
    if (ep.parent_endpoint) html += `<span class="text-sm text-muted" style="margin-left:.5rem">parent: ${esc(ep.parent_endpoint)}</span>`;
    if (ep.pagination) html += `<span class="tag" style="margin-left:.5rem">${ep.pagination.type}</span>`;
    html += `</div>`;

    // Inline fields
    const fields = viewFields;
    html += `<h4 style="margin-top:1rem;font-size:.85rem">Fields (${fields.length})</h4>`;
    if (fields.length) {
      html += `<table><thead><tr><th>Name</th><th>Type</th><th>Nullable</th><th>Source</th></tr></thead><tbody>`;
      html += fields.map(f => {
        const tag = detailSet.has(f.name) ? '<span class="badge badge-accent">detail</span>' : '';
        return `<tr><td><code>${esc(f.name)}</code></td><td>${esc(f.field_type)}</td><td>${f.nullable ? "yes" : "no"}</td><td>${tag}</td></tr>`;
      }).join("");
      html += `</tbody></table>`;
    } else {
      html += `<p class="text-muted text-sm">No inline fields detected.</p>`;
    }

    // Child tables (arrays of objects)
    if (childTables.length) {
      html += `<h4 style="margin-top:1rem;font-size:.85rem">Child Tables (${childTables.length})</h4>`;
      for (const ct of childTables) {
        const ctFields = ct.fields || [];
        html += `<details style="margin-top:.5rem"><summary style="cursor:pointer;font-weight:600;font-size:.8rem"><code>${esc(ct.source_array)}</code> &mdash; ${ctFields.length} fields</summary>`;
        if (ctFields.length) {
          html += `<table style="margin-top:.25rem"><thead><tr><th>Name</th><th>Type</th><th>Nullable</th></tr></thead><tbody>`;
          html += ctFields.map(f =>
            `<tr><td><code>${esc(f.name)}</code></td><td>${esc(f.field_type)}</td><td>${f.nullable ? "yes" : "no"}</td></tr>`
          ).join("");
          html += `</tbody></table>`;
        }
        html += `</details>`;
      }
    }

    // Sample data
    const sample = ep.sample_data || [];
    if (sample.length) {
      html += `<details style="margin-top:1rem"><summary style="cursor:pointer;font-weight:600;font-size:.85rem">Sample Data (${sample.length} rows)</summary>`;
      html += `<pre class="log-viewer" style="max-height:250px;font-size:.75rem;margin-top:.25rem">${esc(JSON.stringify(sample, null, 2))}</pre>`;
      html += `</details>`;
    }

    html += `</div></div>`;

    const overlay = document.createElement("div");
    overlay.innerHTML = html;
    document.body.appendChild(overlay.firstElementChild);
  }

  // ── STEP 2: Mapping ────────────────────────────────────────────────

  function populateEndpointSelect(selectId) {
    const sel = document.getElementById(selectId);
    if (!sel) return;
    sel.innerHTML = discoveredEndpoints.map((ep, i) =>
      `<option value="${i}">${esc(ep.path)}</option>`
    ).join("");
  }

  async function populateMapEndpoints() {
    const div = document.getElementById("map-endpoint-checks");
    if (!discoveredEndpoints.length) {
      div.innerHTML = `<p class="text-muted text-sm">No endpoints discovered. Go to Discovery first.</p>`;
      return;
    }
    // Check which endpoints have saved mappings
    const connId = el("disc-rest-conn") || el("job-rest-conn");
    let savedInfo = {};
    if (connId) {
      const mres = await GET(`/mappings/endpoints?rest_connection_id=${encodeURIComponent(connId)}`);
      if (mres && mres.endpoints) {
        mres.endpoints.forEach(ep => { savedInfo[ep.path] = ep.mapping_count || 0; });
      }
    }
    div.innerHTML = discoveredEndpoints.map((ep, i) => {
      const table = ep.path.replace(/[^a-zA-Z0-9]/g, "_").replace(/_+/g, "_")
                           .replace(/^_|_$/g, "").toUpperCase();
      const childCount = (ep.child_tables || []).length;
      const childLabel = childCount ? ` + ${childCount} linked` : "";
      const savedCount = savedInfo[ep.path] || 0;
      const savedBadge = savedCount
        ? `<span class="badge badge-success">${savedCount} saved</span>` : "";
      return `<div class="map-ep-block" style="border:1px solid var(--border);border-radius:6px;margin-bottom:.5rem;padding:.5rem .75rem">
        <label style="display:flex;align-items:center;gap:.5rem;padding:.3rem 0">
          <input type="checkbox" class="map-ep-check" value="${i}" checked>
          <code>${esc(ep.path)}</code>
          <span class="text-muted text-sm">(${(ep.fields||[]).length} fields${childLabel})</span>
          <span class="text-muted text-sm">&rarr; ${table}</span>
          ${savedBadge}
        </label>
        <div class="ep-mapping-container" id="ep-mappings-${i}" style="margin-top:.25rem"></div>
      </div>`;
    }).join("");
  }

  function selectAllMapEndpoints(checked) {
    document.querySelectorAll(".map-ep-check").forEach(cb => cb.checked = checked);
  }

  async function loadSavedMappings() {
    const connId = el("disc-rest-conn") || el("job-rest-conn");
    if (!connId) { toast("No connection selected", "error"); return; }
    const checked = document.querySelectorAll(".map-ep-check:checked");
    if (!checked.length) { toast("Select at least one endpoint", "error"); return; }

    // Keep mappings for unchecked endpoints
    const checkedIdxSet = new Set();
    checked.forEach(cb => checkedIdxSet.add(parseInt(cb.value)));
    const kept = currentMappings.filter(m => !checkedIdxSet.has(m._ep_idx));
    let loaded = 0;

    for (const cb of checked) {
      const idx = parseInt(cb.value);
      const ep = discoveredEndpoints[idx];
      if (!ep) continue;
      const res = await POST("/mappings/load", {
        rest_connection_id: connId, endpoint_path: ep.path
      });
      if (res && res.mappings && res.mappings.length) {
        // Tag each mapping with _ep_idx for rendering
        const enriched = res.mappings.map(m => ({ ...m, _ep_idx: idx }));
        kept.push(...enriched);
        loaded += res.mappings.length;
      }
    }
    currentMappings = kept;
    renderMappings();
    toast(loaded ? `Loaded ${loaded} saved mappings` : "No saved mappings found for selected endpoints", loaded ? "success" : "info");
  }

  async function autoMapAll() {
    const checked = document.querySelectorAll(".map-ep-check:checked");
    if (!checked.length) { toast("Select at least one endpoint", "error"); return; }

    // Keep mappings for unchecked endpoints, override only selected
    const checkedIdxSet = new Set();
    checked.forEach(cb => checkedIdxSet.add(parseInt(cb.value)));
    const kept = currentMappings.filter(m => !checkedIdxSet.has(m._ep_idx));
    let totalMapped = 0;

    for (const cb of checked) {
      const idx = parseInt(cb.value);
      const ep = discoveredEndpoints[idx];
      if (!ep || !ep.fields || !ep.fields.length) continue;
      const source_fields = ep.fields.map(f => ({ name: f.name, type: f.field_type || "string" }));
      const res = await POST("/mappings/auto-map", { source_fields, target_columns: [] });
      if (res && res.mappings) {
        const table = ep.path.replace(/[^a-zA-Z0-9]/g, "_").replace(/_+/g, "_")
                   .replace(/^_|_$/g, "").toUpperCase();
        const enriched = res.mappings.map(m => ({
          ...m, _endpoint_path: ep.path, _target_table: table, _ep_idx: idx
        }));
        kept.push(...enriched);
        totalMapped += enriched.length;
      }
      // Auto-map child tables (arrays of objects)
      const childTables = ep.child_tables || [];
      for (const ct of childTables) {
        if (!ct.fields || !ct.fields.length) continue;
        const childFields = ct.fields.map(f => ({ name: f.name, type: f.field_type || "string" }));
        const childRes = await POST("/mappings/auto-map", { source_fields: childFields, target_columns: [] });
        if (childRes && childRes.mappings) {
          const parentTable = ep.path.replace(/[^a-zA-Z0-9]/g, "_").replace(/_+/g, "_")
                     .replace(/^_|_$/g, "").toUpperCase();
          const childSuffix = ct.source_array.replace(/[^a-zA-Z0-9]/g, "_").replace(/_+/g, "_")
                                             .replace(/^_|_$/g, "").toUpperCase();
          const childTable = parentTable + "_" + childSuffix;
          const enriched = childRes.mappings.map(m => ({
            ...m, _endpoint_path: ep.path, _target_table: childTable,
            _source_array: ct.source_array, _is_child: true,
            _parent_table: parentTable, _ep_idx: idx
          }));
          kept.push(...enriched);
          totalMapped += enriched.length;
        }
      }
    }
    currentMappings = kept;
    renderMappings();
    toast(`${totalMapped} fields mapped across ${checked.length} endpoints`, "success");
  }

  function renderMappings() {
    // Clear all per-endpoint containers
    document.querySelectorAll(".ep-mapping-container").forEach(c => { c.innerHTML = ""; });

    if (!currentMappings.length) return;

    // Group by endpoint index, then by target table within each endpoint
    const byEp = {};
    currentMappings.forEach((m, i) => {
      const epIdx = m._ep_idx != null ? m._ep_idx : 0;
      if (!byEp[epIdx]) byEp[epIdx] = {};
      const key = m._target_table || m._endpoint_path || "(unknown)";
      if (!byEp[epIdx][key]) byEp[epIdx][key] = { mappings: [], meta: m };
      byEp[epIdx][key].mappings.push({ ...m, _idx: i });
    });

    for (const [epIdx, groups] of Object.entries(byEp)) {
      const container = document.getElementById(`ep-mappings-${epIdx}`);
      if (!container) continue;
      container.innerHTML = Object.entries(groups).map(([table, group]) => {
        const mappings = group.mappings;
        const meta = group.meta;
        const isChild = meta._is_child;
        const label = isChild
          ? `<span class="badge badge-warning" style="font-size:.7rem">linked</span> ${esc(meta._source_array)}`
          : `Field Mappings`;
        const fkRow = isChild
          ? `<div style="padding:.4rem .85rem;background:#fffbe6;border-top:1px solid var(--border);font-size:.78rem;display:flex;align-items:center;gap:.5rem">
               <span class="text-muted">FK column:</span>
               <input value="${esc(meta._fk_column || 'PARENT_ID')}" onclick="event.stopPropagation()"
                      onchange="App.updateChildFk('${table.replace(/'/g, "\\'")}',this.value)"
                      style="padding:.2rem .4rem;border:1px solid var(--border);border-radius:4px;font-size:.78rem;font-family:var(--mono);width:10rem">
               <span class="text-muted">Parent key:</span>
               <input value="${esc(meta._parent_key || 'gid')}" onclick="event.stopPropagation()"
                      onchange="App.updateChildParentKey('${table.replace(/'/g, "\\'")}',this.value)"
                      style="padding:.2rem .4rem;border:1px solid var(--border);border-radius:4px;font-size:.78rem;font-family:var(--mono);width:10rem">
             </div>`
          : "";
        return `<div class="accordion-group" style="margin-top:.35rem">
          <div class="accordion-header" onclick="this.parentElement.classList.toggle('open')">
            <span class="accordion-chevron">&#9654;</span>
            ${label}
            <span class="badge badge-info">${mappings.length} fields</span>
            <span class="text-muted text-sm">&rarr;</span>
            <input value="${esc(table)}" onclick="event.stopPropagation()"
                   onchange="App.updateGroupTable2('${table.replace(/'/g, "\\'")}',this.value)"
                   style="padding:.25rem .5rem;border:1px solid var(--border);border-radius:4px;font-size:.8rem;font-family:var(--mono);width:12rem">
          </div>${fkRow}
          <div class="accordion-body">
            <table>
              <thead><tr><th>Source Field</th><th></th><th>Target Column</th><th>Confidence</th><th></th></tr></thead>
              <tbody>${mappings.map(m => {
                const conf = (m.confidence * 100).toFixed(0);
                const cls = conf >= 90 ? "badge-success" : conf >= 70 ? "badge-warning" : "badge-danger";
                return `<tr>
                  <td><code>${esc(m.source_path)}</code></td>
                  <td style="color:var(--primary);font-weight:bold">&rarr;</td>
                  <td><input value="${esc(m.target_column)}" onchange="App.updateMapping(${m._idx},'target_column',this.value)"
                      style="width:100%;padding:.3rem;border:1px solid var(--border);border-radius:4px"></td>
                  <td><span class="badge ${cls}">${conf}%</span></td>
                  <td><button class="btn btn-danger btn-sm" onclick="App.removeMapping(${m._idx})">x</button></td>
                </tr>`;
              }).join("")}</tbody>
            </table>
          </div>
        </div>`;
      }).join("");
    }
  }

  function updateMapping(idx, field, value) {
    if (currentMappings[idx]) currentMappings[idx][field] = value;
  }

  function updateGroupTable2(oldTable, newTable) {
    currentMappings.forEach(m => {
      if (m._target_table === oldTable) m._target_table = newTable;
    });
    renderMappings();
  }

  function updateChildFk(table, value) {
    currentMappings.forEach(m => {
      if (m._target_table === table && m._is_child) m._fk_column = value;
    });
  }

  function updateChildParentKey(table, value) {
    currentMappings.forEach(m => {
      if (m._target_table === table && m._is_child) m._parent_key = value;
    });
  }

  function removeMapping(idx) {
    currentMappings.splice(idx, 1);
    renderMappings();
  }

  async function saveMappings() {
    const connId = el("disc-rest-conn") || el("job-rest-conn");
    if (!connId) { toast("No connection selected", "error"); return; }
    // Group mappings by endpoint and save each group
    const byEp = {};
    currentMappings.forEach(m => {
      const ep = m._endpoint_path || "(unknown)";
      if (!byEp[ep]) byEp[ep] = [];
      byEp[ep].push(m);
    });
    let saved = 0;
    for (const [epPath, mappings] of Object.entries(byEp)) {
      await POST("/mappings/save", {
        rest_connection_id: connId, endpoint_path: epPath, mappings
      });
      saved++;
    }
    toast(`Mappings saved for ${saved} endpoint(s)`, "success");
  }

  async function previewMapping(ep) {
    if (!ep.sample_data || !ep.sample_data.length || !currentMappings.length) return;
    const res = await POST("/mappings/preview", {
      mappings: currentMappings, sample_data: ep.sample_data.slice(0, 3)
    });
    if (res && res.preview) {
      document.getElementById("map-preview-card").style.display = "";
      document.getElementById("map-preview").textContent =
        JSON.stringify(res.preview, null, 2);
    }
  }

  // ── STEP 3: Validation ─────────────────────────────────────────────
  async function autoSuggestRules() {
    const columns = currentMappings.map(m => ({
      name: m.target_column, data_type: "VARCHAR2", nullable: true, max_length: 4000
    }));
    const res = await POST("/validation/auto-suggest", { target_columns: columns });
    if (res && res.rules) {
      currentRules = res.rules;
      renderRules();
      toast(`${res.count} rules suggested`, "success");
    }
  }

  function renderRules() {
    const tbody = document.getElementById("rules-list");
    tbody.innerHTML = currentRules.map((r, i) => `<tr>
      <td><input value="${esc(r.field_path)}" onchange="App.updateRule(${i},'field_path',this.value)"
          style="width:100%;padding:.3rem;border:1px solid var(--border);border-radius:4px"></td>
      <td><select onchange="App.updateRule(${i},'rule_type',this.value)" style="padding:.3rem;border:1px solid var(--border);border-radius:4px">
        ${["required","regex","range","length","enum","type_check","date_format","expression"]
          .map(t => `<option value="${t}" ${t===r.rule_type?"selected":""}>${t}</option>`).join("")}
      </select></td>
      <td><input value='${esc(JSON.stringify(r.config||{}))}' onchange="App.updateRuleConfig(${i},this.value)"
          style="width:100%;padding:.3rem;border:1px solid var(--border);border-radius:4px;font-family:var(--mono);font-size:.75rem"></td>
      <td><select onchange="App.updateRule(${i},'severity',this.value)" style="padding:.3rem">
        <option value="error" ${r.severity==="error"?"selected":""}>Error</option>
        <option value="warning" ${r.severity==="warning"?"selected":""}>Warning</option>
      </select></td>
      <td><button class="btn btn-danger btn-sm" onclick="App.removeRule(${i})">x</button></td>
    </tr>`).join("");
  }

  function addRuleRow() {
    currentRules.push({ field_path: "", rule_type: "required", config: {}, severity: "error", message: "" });
    renderRules();
  }

  function updateRule(idx, field, value) {
    if (currentRules[idx]) currentRules[idx][field] = value;
  }

  function updateRuleConfig(idx, value) {
    try { currentRules[idx].config = JSON.parse(value); } catch (e) { /* ignore */ }
  }

  function removeRule(idx) {
    currentRules.splice(idx, 1);
    renderRules();
  }

  async function saveRules() {
    const epIdx = parseInt(el("val-endpoint"));
    const ep = discoveredEndpoints[epIdx];
    if (!ep) return;
    const connId = el("disc-rest-conn") || el("job-rest-conn");
    await POST("/validation/rules", {
      rest_connection_id: connId, endpoint_path: ep.path, rules: currentRules
    });
    toast("Rules saved", "success");
  }

  async function testRules() {
    const epIdx = parseInt(el("val-endpoint"));
    const ep = discoveredEndpoints[epIdx];
    if (!ep || !ep.sample_data) { toast("No sample data available", "error"); return; }
    const res = await POST("/validation/test", {
      rules: currentRules, sample_data: ep.sample_data, mappings: currentMappings
    });
    if (res) {
      const card = document.getElementById("val-result-card");
      card.style.display = "";
      document.getElementById("val-results").innerHTML = `
        <p>Total rows: <strong>${res.total}</strong> |
           Valid: <span class="badge badge-success">${res.valid}</span> |
           Quarantined: <span class="badge badge-danger">${res.quarantined}</span></p>
        ${res.quarantined > 0 ? `<pre style="font-size:.75rem;max-height:200px;overflow:auto;background:#f8f9fa;padding:.5rem;border-radius:4px">${esc(JSON.stringify(res.quarantine_details, null, 2))}</pre>` : ""}`;
    }
  }

  // ── STEP 4: Migration ──────────────────────────────────────────────

  // Session-sticky endpoint selection state
  function _jobSelKey(connId) { return `rest2adb_job_sel_${connId}`; }
  function _loadJobSel(connId) {
    try { return JSON.parse(sessionStorage.getItem(_jobSelKey(connId))) || null; }
    catch { return null; }
  }
  function _saveJobSel(connId) {
    const sel = {};
    document.querySelectorAll(".job-ep-check").forEach(cb => { sel[cb.value] = cb.checked; });
    sessionStorage.setItem(_jobSelKey(connId), JSON.stringify(sel));
  }

  function selectAllJobEndpoints(checked) {
    document.querySelectorAll(".job-ep-check").forEach(cb => { cb.checked = checked; });
    const connId = el("job-rest-conn");
    if (connId) _saveJobSel(connId);
  }

  async function populateJobEndpoints() {
    const div = document.getElementById("job-endpoint-checks");
    const connId = el("job-rest-conn");
    if (!connId) {
      div.innerHTML = `<p class="text-muted text-sm">Select a REST connection first.</p>`;
      jobMappedEndpoints = [];
      return;
    }
    const res = await GET(`/mappings/endpoints?rest_connection_id=${encodeURIComponent(connId)}`);
    const mapped = (res && res.endpoints) || [];
    jobMappedEndpoints = mapped;
    if (!mapped.length) {
      div.innerHTML = `<p class="text-muted text-sm">No saved mappings found. Go to Mapping (Step 3) and save mappings first.</p>`;
      return;
    }
    const savedSel = _loadJobSel(connId);
    div.innerHTML = mapped.map((ep, i) => {
      const childInfo = (ep.child_tables || []).length
        ? ` + ${ep.child_tables.length} child table(s)` : "";
      const params = ep.path_params || [];
      const paramInputs = params.length ? `
        <div class="job-ep-params" data-ep="${i}" style="margin-left:1.6rem;margin-bottom:.3rem">
          ${params.map(p => `
            <div style="display:flex;align-items:center;gap:.4rem;margin-top:.2rem">
              <code style="font-size:.75rem;min-width:8rem">{${esc(p)}}</code>
              <input class="job-param-input" data-ep="${i}" data-param="${esc(p)}"
                     placeholder="value for ${esc(p)}" style="font-size:.8rem;padding:.15rem .4rem;flex:1;max-width:20rem">
            </div>`).join("")}
        </div>` : "";
      const isChecked = savedSel ? (savedSel[String(i)] !== false) : true;
      return `
      <label style="display:flex;align-items:center;gap:.5rem;padding:.3rem 0">
        <input type="checkbox" class="job-ep-check" value="${i}" ${isChecked ? "checked" : ""} onchange="App._saveJobSel('${esc(connId)}')">
        <code>${esc(ep.path)}</code>
        <span class="text-muted text-sm">&rarr; ${esc(ep.target_table)} (${ep.mapping_count} mappings${childInfo})</span>
      </label>${paramInputs}`;
    }).join("");
  }

  async function createJob() {
    const name = el("job-name");
    const restConn = el("job-rest-conn");
    const targetConn = el("job-target-conn");
    if (!name || !restConn || !targetConn) { toast("Fill all required fields", "error"); return; }

    const checked = document.querySelectorAll(".job-ep-check:checked");
    if (!checked.length) { toast("Select at least one endpoint", "error"); return; }

    // Collect path parameter values and validate
    const paramValues = {};
    document.querySelectorAll(".job-param-input").forEach(inp => {
      const epIdx = inp.dataset.ep;
      const param = inp.dataset.param;
      if (!paramValues[epIdx]) paramValues[epIdx] = {};
      paramValues[epIdx][param] = inp.value.trim();
    });
    // Validate that checked endpoints with path params have values filled in
    for (const cb of checked) {
      const idx = cb.value;
      const mep = jobMappedEndpoints[parseInt(idx)];
      if (!mep) continue;
      const params = mep.path_params || [];
      for (const p of params) {
        if (!paramValues[idx] || !paramValues[idx][p]) {
          toast(`Provide a value for {${p}} in ${mep.path}`, "error");
          return;
        }
      }
    }

    // Build endpoints from saved mapping metadata
    const endpoints = [];
    for (const cb of checked) {
      const idx = parseInt(cb.value);
      const mep = jobMappedEndpoints[idx];
      if (!mep) continue;
      // Resolve path parameters — substitute {param} with user-provided values
      let resolvedPath = mep.path;
      const epParams = paramValues[String(idx)] || {};
      for (const [param, value] of Object.entries(epParams)) {
        resolvedPath = resolvedPath.replace(`{${param}}`, encodeURIComponent(value));
      }
      // Load full mappings from server to get field details and child tables
      const loadRes = await POST("/mappings/load", {
        rest_connection_id: restConn, endpoint_path: mep.path
      });
      const mappings = (loadRes && loadRes.mappings) || [];
      const parentMappings = mappings.filter(m => !m._is_child);
      const childMappings = mappings.filter(m => m._is_child);
      // Derive fields from parent mappings
      const fields = parentMappings.map(m => ({
        name: m.source_path, field_type: m.source_type || "string"
      }));
      // Build child_tables from child mappings
      const childGroups = {};
      childMappings.forEach(m => {
        const ct = m._target_table;
        if (!ct) return;
        if (!childGroups[ct]) {
          childGroups[ct] = {
            source_array: m._source_array || "",
            target_table: ct,
            parent_key: m._parent_key || "gid",
            foreign_key_column: m._fk_column || "PARENT_ID",
            fields: [],
          };
        }
        childGroups[ct].fields.push({
          name: m.source_path, field_type: m.source_type || "string"
        });
      });
      // Also look up discovered endpoint for pagination / http_method if available
      const disc = discoveredEndpoints.find(d => d.path === mep.path);
      endpoints.push({
        path: resolvedPath,
        http_method: disc?.http_method || "GET",
        fields,
        child_tables: Object.values(childGroups),
        pagination: disc?.pagination || null,
        target_table: mep.target_table,
        path_params: epParams,
      });
    }

    const res = await POST("/jobs", {
      name, rest_connection_id: restConn, target_connection_id: targetConn,
      endpoints,
      sync_mode: el("job-sync-mode"),
      write_mode: el("job-write-mode"),
      batch_size: parseInt(el("job-batch-size")) || 500,
      max_workers: parseInt(el("job-max-workers")) || 3,
      delta_field: el("job-delta-field") || null,
    });
    if (res && res.id) { toast("Job created", "success"); switchSubTab('mig', 1); loadJobs(); }
  }

  let _jobPollTimer = null;

  async function loadJobs() {
    const jobs = await GET("/jobs") || [];
    const tbody = document.getElementById("job-list");
    const hasRunning = jobs.some(j => j.status === "RUNNING");
    tbody.innerHTML = jobs.map(j => {
      const statusCls = {
        CREATED: "badge-muted", RUNNING: "badge-info", PAUSED: "badge-warning",
        COMPLETED: "badge-success", FAILED: "badge-danger", CANCELLED: "badge-muted"
      }[j.status] || "badge-muted";
      const pct = j.total_endpoints > 0
        ? Math.round((j.completed_endpoints / j.total_endpoints) * 100) : 0;
      return `<tr>
        <td>${esc(j.name)}</td>
        <td><span class="badge ${statusCls}">${j.status}</span></td>
        <td>
          <div style="display:flex;align-items:center;gap:.5rem">
            <div class="progress-bar" style="flex:1;min-width:60px"><div class="progress-fill" style="width:${pct}%"></div></div>
            <span class="text-sm text-muted">${j.completed_endpoints || 0}/${j.total_endpoints || 0}</span>
          </div>
        </td>
        <td>${(j.total_rows_migrated || 0).toLocaleString()}</td>
        <td>
          <button class="btn btn-outline btn-sm" onclick="App.viewJobDetails('${j.id}')">Details</button>
          ${j.status === "CREATED" ? `<button class="btn btn-success btn-sm" onclick="App.startJob('${j.id}')">Start</button>` : ""}
          ${j.status === "RUNNING" ? `<button class="btn btn-warning btn-sm" onclick="App.cancelJob('${j.id}')">Cancel</button>` : ""}
          ${j.status === "PAUSED" ? `<button class="btn btn-success btn-sm" onclick="App.startJob('${j.id}')">Resume</button>` : ""}
          <button class="btn btn-danger btn-sm" onclick="App.deleteJob('${j.id}')">Del</button>
        </td></tr>
        ${j.error_message ? `<tr><td colspan="5" style="color:var(--danger);font-size:.8rem;padding:.25rem .65rem;border-bottom:2px solid var(--border)">Error: ${esc(j.error_message)}</td></tr>` : ""}`;
    }).join("");

    // Also refresh event log in jobs tab
    _loadJobTabLog();

    // Auto-poll every 2s while any job is RUNNING
    if (_jobPollTimer) { clearTimeout(_jobPollTimer); _jobPollTimer = null; }
    if (hasRunning) { _jobPollTimer = setTimeout(loadJobs, 2000); }
  }

  function refreshJobs() { loadJobs(); }

  let _jobSSE = null;
  function toggleJobSSE() {
    if (_jobSSE) {
      _jobSSE.close(); _jobSSE = null;
      toast("Live updates stopped", "info"); return;
    }
    _jobSSE = new EventSource("/api/logs/stream");
    _jobSSE.onmessage = (e) => {
      const div = document.getElementById("job-tab-log");
      if (div) { div.innerHTML += "<br>" + formatLogLine(e.data); div.scrollTop = div.scrollHeight; }
    };
    _jobSSE.addEventListener("job_update", () => loadJobs());
    toast("Live updates enabled", "success");
  }

  async function _loadJobTabLog() {
    const res = await GET("/logs/file?lines=100");
    if (res && res.lines) {
      const div = document.getElementById("job-tab-log");
      if (div) { div.innerHTML = res.lines.map(l => formatLogLine(l)).join("<br>"); div.scrollTop = div.scrollHeight; }
    }
  }

  async function viewJobDetails(jobId) {
    const j = await GET(`/jobs/${jobId}`);
    if (!j || j.error) { toast("Job not found", "error"); return; }

    const statusCls = {
      CREATED: "badge-muted", RUNNING: "badge-info", PAUSED: "badge-warning",
      COMPLETED: "badge-success", FAILED: "badge-danger", CANCELLED: "badge-muted"
    }[j.status] || "badge-muted";
    const pct = j.total_endpoints > 0
      ? Math.round((j.completed_endpoints / j.total_endpoints) * 100) : 0;
    const canStart = j.status === "CREATED";
    const canResume = j.status === "PAUSED" || j.status === "FAILED";
    const canRestart = j.status === "COMPLETED" || j.status === "FAILED" || j.status === "CANCELLED";
    const canCancel = j.status === "RUNNING";

    // Fetch job-specific logs
    const logRes = await GET(`/jobs/${jobId}/logs?lines=500`);
    const logLines = (logRes && logRes.lines) || [];

    // Build endpoints table
    const eps = j.endpoints || [];
    const epRows = eps.map((ep, i) => {
      const nFields = (ep.fields || []).length;
      const nChild = (ep.child_tables || []).length;
      return `<tr>
        <td><code>${esc(ep.path)}</code></td>
        <td>${esc(ep.target_table || "")}</td>
        <td>${nFields} fields${nChild ? ` + ${nChild} child` : ""}</td>
      </tr>`;
    }).join("");

    let html = `<div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;display:flex;align-items:center;justify-content:center;padding:1rem" onclick="if(event.target===this)this.remove()">
    <div class="card" style="max-width:800px;width:95vw;max-height:90vh;overflow-y:auto;margin:0">
      <div class="flex-between">
        <h3>${esc(j.name)}</h3>
        <button class="btn btn-outline btn-sm" onclick="this.closest('[style*=fixed]').remove()">&times;</button>
      </div>

      <div style="display:flex;align-items:center;gap:1rem;margin-top:.75rem">
        <span class="badge ${statusCls}" style="font-size:.85rem;padding:.25rem .75rem">${j.status}</span>
        <div class="progress-bar" style="flex:1"><div class="progress-fill" style="width:${pct}%"></div></div>
        <span class="text-sm">${pct}%</span>
      </div>

      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:.75rem;margin-top:.75rem">
        <div style="text-align:center;padding:.5rem;background:var(--bg);border-radius:6px">
          <div style="font-size:1.25rem;font-weight:600">${j.completed_endpoints || 0}/${j.total_endpoints || 0}</div>
          <div class="text-sm text-muted">Endpoints</div>
        </div>
        <div style="text-align:center;padding:.5rem;background:var(--bg);border-radius:6px">
          <div style="font-size:1.25rem;font-weight:600">${(j.total_rows_migrated || 0).toLocaleString()}</div>
          <div class="text-sm text-muted">Rows Migrated</div>
        </div>
        <div style="text-align:center;padding:.5rem;background:var(--bg);border-radius:6px">
          <div style="font-size:1.25rem;font-weight:600">${esc(j.sync_mode || "full")}</div>
          <div class="text-sm text-muted">Sync Mode</div>
        </div>
      </div>

      ${j.error_message ? `<div style="margin-top:.75rem;padding:.5rem .75rem;background:#fce8e6;border-radius:6px;color:var(--danger);font-size:.85rem"><strong>Error:</strong> ${esc(j.error_message)}</div>` : ""}

      <div class="btn-group" style="margin-top:.75rem">
        ${canStart ? `<button class="btn btn-success btn-sm" onclick="App.startJob('${j.id}');this.closest('[style*=fixed]').remove()">Start</button>` : ""}
        ${canResume ? `<button class="btn btn-success btn-sm" onclick="App.resumeJob('${j.id}');this.closest('[style*=fixed]').remove()">Resume</button>` : ""}
        ${canRestart ? `<button class="btn btn-primary btn-sm" onclick="App.restartJob('${j.id}');this.closest('[style*=fixed]').remove()">Restart</button>` : ""}
        ${canCancel ? `<button class="btn btn-warning btn-sm" onclick="App.cancelJob('${j.id}');this.closest('[style*=fixed]').remove()">Cancel</button>` : ""}
        <button class="btn btn-danger btn-sm" onclick="if(confirm('Delete this job?')){App.deleteJob('${j.id}');this.closest('[style*=fixed]').remove()}">Delete</button>
      </div>

      <details style="margin-top:1rem" ${eps.length <= 6 ? "open" : ""}>
        <summary style="cursor:pointer;font-weight:600;font-size:.85rem">Endpoints (${eps.length})</summary>
        <table style="margin-top:.25rem"><thead><tr><th>Path</th><th>Target Table</th><th>Fields</th></tr></thead>
        <tbody>${epRows || '<tr><td colspan="3" class="text-muted">No endpoints</td></tr>'}</tbody></table>
      </details>

      <details style="margin-top:.75rem">
        <summary style="cursor:pointer;font-weight:600;font-size:.85rem">Job Log (${logLines.length} lines)</summary>
        <div class="log-viewer mt-1" style="max-height:300px">${logLines.length ? logLines.map(l => formatLogLine(l)).join("<br>") : '<span class="text-muted">No log entries for this job.</span>'}</div>
      </details>

      <details style="margin-top:.75rem">
        <summary style="cursor:pointer;font-weight:600;font-size:.85rem">Configuration</summary>
        <div style="margin-top:.5rem;display:grid;grid-template-columns:1fr 1fr;gap:.35rem .75rem;font-size:.82rem">
          <span class="text-muted">Write Mode:</span><span>${esc(j.write_mode || "insert")}</span>
          <span class="text-muted">Batch Size:</span><span>${j.batch_size || 500}</span>
          <span class="text-muted">Max Workers:</span><span>${j.max_workers || 3}</span>
          <span class="text-muted">Delta Field:</span><span>${esc(j.delta_field || "—")}</span>
        </div>
      </details>

    </div></div>`;

    const overlay = document.createElement("div");
    overlay.innerHTML = html;
    document.body.appendChild(overlay.firstElementChild);
  }

  async function startJob(id) {
    const res = await POST(`/jobs/${id}/start`);
    if (res && res.status === "started") {
      toast("Job started", "success");
    } else {
      toast(res?.error || "Failed to start job", "error");
    }
    loadJobs();
  }

  async function cancelJob(id) {
    await POST(`/jobs/${id}/cancel`);
    toast("Job cancelling...", "info");
    setTimeout(loadJobs, 1000);
  }

  async function deleteJob(id) {
    await DEL(`/jobs/${id}`);
    toast("Job deleted", "info");
    loadJobs();
  }

  // ── Batch Runs ─────────────────────────────────────────────────────
  async function createBatchRun() {
    const jobs = await GET("/jobs") || [];
    const jobIds = jobs.filter(j => j.status === "CREATED").map(j => j.id);
    if (!jobIds.length) { toast("No CREATED jobs available", "error"); return; }
    const conc = prompt("Concurrency (1-20):", "5");
    if (!conc) return;
    const name = prompt("Batch run name:", "batch-" + Date.now());
    if (!name) return;
    const res = await POST("/batch-runs", {
      name, job_ids: jobIds, concurrency: parseInt(conc) || 5
    });
    if (res) { toast("Batch run created", "success"); switchSubTab('mig', 2); loadBatchRuns(); }
  }

  async function loadBatchRuns() {
    const runs = await GET("/batch-runs") || [];
    const tbody = document.getElementById("batch-run-list");
    tbody.innerHTML = runs.map(br => {
      const statusCls = {
        CREATED: "badge-muted", RUNNING: "badge-info", COMPLETED: "badge-success",
        PARTIAL_FAILURE: "badge-warning", FAILED: "badge-danger", CANCELLED: "badge-muted"
      }[br.status] || "badge-muted";
      return `<tr>
        <td>${esc(br.name)}</td>
        <td>${br.total_jobs}</td>
        <td>${br.concurrency}</td>
        <td><span class="badge ${statusCls}">${br.status}</span></td>
        <td>${br.completed_jobs || 0}/${br.total_jobs} done, ${br.failed_jobs || 0} failed</td>
        <td>
          ${br.status === "CREATED" ? `<button class="btn btn-success btn-sm" onclick="App.startBatchRun('${br.batch_run_id}')">Start</button>` : ""}
          ${br.status === "RUNNING" ? `<button class="btn btn-danger btn-sm" onclick="App.cancelBatchRun('${br.batch_run_id}')">Cancel</button>` : ""}
        </td></tr>`;
    }).join("");
  }

  async function startBatchRun(id) {
    await POST(`/batch-runs/${id}/start`);
    toast("Batch run started", "success");
    setTimeout(loadBatchRuns, 1000);
  }

  async function cancelBatchRun(id) {
    await POST(`/batch-runs/${id}/cancel`);
    toast("Batch run cancelling...", "info");
    setTimeout(loadBatchRuns, 1000);
  }

  // ── Job actions (used by Details popup) ────────────────────────────
  async function resumeJob(id) {
    const res = await POST(`/jobs/${id}/start`);
    if (res && res.status === "started") {
      toast("Job resumed", "success");
    } else {
      toast(res?.error || "Failed to resume job", "error");
    }
    loadJobs();
  }

  async function restartJob(id) {
    const res = await POST(`/jobs/${id}/restart`);
    if (res && res.status === "started") {
      toast("Job restarted", "success");
    } else {
      toast(res?.error || "Failed to restart job", "error");
    }
    loadJobs();
  }

  function formatLogLine(line) {
    const safe = line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    // Colorize log level tags
    return safe
      .replace(/\[ERROR\]/g,   '<span style="color:#f44747;font-weight:600">[ERROR]</span>')
      .replace(/\[WARNING\]/g, '<span style="color:#cca700;font-weight:600">[WARNING]</span>')
      .replace(/\[INFO\]/g,    '<span style="color:#6a9955;font-weight:600">[INFO]</span>')
      .replace(/\[DEBUG\]/g,   '<span style="color:#808080">[DEBUG]</span>');
  }

  function showLogs() { goStep(4); switchSubTab('mig', 1); }

  async function clearLogs() {
    await POST("/logs/clear");
    const el = document.getElementById("job-tab-log");
    if (el) el.innerHTML = "";
    toast("Logs cleared", "info");
  }

  // ── Health check ───────────────────────────────────────────────────
  async function checkHealth() {
    try {
      const res = await GET("/health");
      const dot = document.getElementById("health-dot");
      if (res && res.status === "ok") {
        dot.textContent = "v" + (res.version || "0.0.0");
        dot.className = "badge badge-success";
      }
    } catch (e) { /* ignore */ }
  }

  // ── Update check ──────────────────────────────────────────────────
  let updateInfo = null;

  async function checkForUpdate() {
    try {
      const res = await GET("/update/check");
      if (res && res.update_available) {
        updateInfo = res;
        const btn = document.getElementById("update-btn");
        btn.style.display = "";
        btn.textContent = "Update v" + res.latest_version;
        btn.classList.add("update-btn-pulse");
      }
    } catch (e) { /* silently ignore — not critical */ }
  }

  function showUpdateInfo() {
    if (!updateInfo) return;
    document.getElementById("update-cur-ver").textContent = "v" + updateInfo.current_version;
    document.getElementById("update-new-ver").textContent = "v" + updateInfo.latest_version;
    document.getElementById("update-title").textContent =
      updateInfo.release_name || ("v" + updateInfo.latest_version);

    const notesDiv = document.getElementById("update-notes");
    if (updateInfo.release_notes) {
      notesDiv.style.display = "";
      document.getElementById("update-notes-body").textContent = updateInfo.release_notes;
    } else {
      notesDiv.style.display = "none";
    }

    document.getElementById("update-banner").style.display = "";
  }

  function hideUpdateInfo() {
    document.getElementById("update-banner").style.display = "none";
  }

  async function installUpdate() {
    const btn = document.getElementById("update-install-btn");
    btn.disabled = true;
    btn.textContent = "Installing...";

    const progressDiv = document.getElementById("update-progress");
    const progressBar = document.getElementById("update-progress-bar");
    const progressMsg = document.getElementById("update-progress-msg");
    progressDiv.style.display = "";

    const stages = { checking: 10, downloading: 30, extracting: 60, applying: 80, done: 100, up_to_date: 100 };

    try {
      const resp = await fetch("/api/update/apply", { method: "POST" });
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        // Process complete lines (ndjson)
        const lines = buffer.split("\n");
        buffer = lines.pop(); // keep incomplete line in buffer
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const evt = JSON.parse(line);
            progressMsg.textContent = evt.message || "";
            const pct = stages[evt.stage] || 0;
            progressBar.style.width = pct + "%";

            if (evt.stage === "error") {
              progressBar.style.background = "var(--danger)";
              progressBar.style.width = "100%";
              btn.textContent = "Failed";
              toast(evt.message, "error");
              return;
            }

            if (evt.stage === "done" || evt.stage === "up_to_date") {
              progressBar.style.width = "100%";
              progressBar.style.background = "var(--success)";
              btn.style.display = "none";
              document.getElementById("update-restart").style.display = "";
              // Update the header version badge
              const dot = document.getElementById("health-dot");
              if (evt.version) dot.textContent = "v" + evt.version;
              // Hide the update button in header
              document.getElementById("update-btn").style.display = "none";
              toast(evt.stage === "up_to_date"
                ? "Already up to date. Restart to apply."
                : "Update installed! Restart the server.", "success");
            }
          } catch (e) { /* skip malformed line */ }
        }
      }
    } catch (e) {
      progressBar.style.background = "var(--danger)";
      progressBar.style.width = "100%";
      progressMsg.textContent = "Network error: " + e.message;
      btn.textContent = "Failed";
      toast("Update failed: " + e.message, "error");
    }
  }

  async function restartServer() {
    const restartDiv = document.getElementById("update-restart");
    restartDiv.innerHTML = '<span class="text-sm">Restarting server...</span>';
    // Use raw fetch — the POST() helper shows error toasts on network failures
    // which are expected here since the server is about to die.
    try {
      await fetch("/api/restart", { method: "POST",
        headers: { "Content-Type": "application/json" }, body: "{}" });
    } catch (e) { /* expected — server is shutting down */ }
    // Wait for the server to come back, then reload
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts++;
      try {
        const r = await fetch("/api/health");
        if (r.ok) {
          clearInterval(poll);
          window.location.reload();
        }
      } catch (e) { /* server still restarting */ }
      if (attempts > 30) {
        clearInterval(poll);
        restartDiv.innerHTML = '<span class="text-sm text-muted">Server is taking long to restart. Please refresh manually.</span>';
      }
    }, 1000);
  }

  // ── Helpers ────────────────────────────────────────────────────────
  function el(id) { const e = document.getElementById(id); return e ? e.value : ""; }
  function setEl(id, val) { const e = document.getElementById(id); if (e) e.value = val || ""; }
  function esc(s) {
    if (s == null) return "";
    const d = document.createElement("div");
    d.textContent = String(s);
    return d.innerHTML;
  }

  // ── Init ───────────────────────────────────────────────────────────
  checkHealth();
  checkForUpdate();
  loadAllConns();
  toggleTargetFields(); // set initial field state

  // ── Public API ─────────────────────────────────────────────────────
  return {
    goStep, switchSubTab, toggleAuthFields, toggleTargetFields,
    showConnForm, hideConnForm,
    saveRestConn, testRestConn, deleteRestConn, editRestConn, cancelEditRest,
    testRestConnForm, testTargetConnForm, togglePreview, sendPreview,
    saveTargetConn, testTargetConn, deleteTargetConn, editTargetConn, cancelEditTarget,
    exportConnections, importConnections, exportEndpoints, importEndpoints,
    discoverOpenAPI, discoverManual, discoverSample, viewEndpoint,
    selectAllDiscEndpoints, updateSelectedEndpoints,
    autoMapAll, selectAllMapEndpoints, loadSavedMappings,
    updateMapping, updateGroupTable2,
    updateChildFk, updateChildParentKey, removeMapping, saveMappings,
    autoSuggestRules, addRuleRow, updateRule, updateRuleConfig, removeRule,
    saveRules, testRules,
    createJob, startJob, cancelJob, deleteJob, viewJobDetails,
    refreshJobs, toggleJobSSE,
    selectAllJobEndpoints, _saveJobSel: _saveJobSel,
    createBatchRun, startBatchRun, cancelBatchRun,
    showLogs, clearLogs, resumeJob, restartJob,
    previewSavedRestConn, _sendSavedPreview,
    showUpdateInfo, hideUpdateInfo, installUpdate, restartServer,
  };
})();
