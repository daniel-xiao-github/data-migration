"""Discovery API routes — OpenAPI import, sample probing, manual endpoint."""
from __future__ import annotations
from flask import Blueprint, request, jsonify, current_app

bp = Blueprint("discovery", __name__, url_prefix="/api")


def _store():
    return current_app.config["STORE"]


def _get_rest_client(conn_id):
    from app.core.rest_client import RestClient
    for c in _store().get("rest_connections", []):
        if c["id"] == conn_id:
            # Decrypt auth_config secrets before creating the client
            conn = dict(c)
            ac = dict(conn.get("auth_config", {}))
            for k in ("password", "token", "client_secret", "value"):
                if k in ac and ac[k]:
                    try:
                        from app.core.crypto import decrypt
                        ac[k] = decrypt(ac[k])
                    except Exception:
                        pass
            conn["auth_config"] = ac
            oauth = current_app.config.get("OAUTH_MANAGER")
            return RestClient(conn, oauth_manager=oauth)
    return None


@bp.route("/discovery/openapi", methods=["POST"])
def discover_openapi():
    """Import endpoints from an OpenAPI/Swagger spec."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    spec_url = data.get("openapi_url")
    if not conn_id or not spec_url:
        return jsonify({"error": "rest_connection_id and openapi_url required"}), 400

    client = _get_rest_client(conn_id)
    if not client:
        return jsonify({"error": "REST connection not found"}), 404

    from app.core.discovery_engine import DiscoveryEngine
    engine = DiscoveryEngine(rest_client=client)
    try:
        endpoints = engine.discover_from_openapi(spec_url)
        # Store discovered endpoints
        store = _store()
        key = f"discovered_{conn_id}"
        store[key] = endpoints
        return jsonify({"endpoints": endpoints, "count": len(endpoints)})
    except Exception as e:
        import logging
        logging.getLogger("rest2adb.discovery").exception(
            "OpenAPI discovery failed for %s", spec_url
        )
        msg = str(e)
        code = 502 if "HTTPError" in type(e).__name__ else 500
        return jsonify({"error": msg, "spec_url": spec_url}), code


@bp.route("/discovery/graphql", methods=["POST"])
def discover_graphql():
    """Discover endpoints from a GraphQL schema via introspection."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    graphql_url = data.get("graphql_url")
    probe = data.get("probe", True)
    if not conn_id or not graphql_url:
        return jsonify({"error": "rest_connection_id and graphql_url required"}), 400

    client = _get_rest_client(conn_id)
    if not client:
        return jsonify({"error": "REST connection not found"}), 404

    from app.core.discovery_engine import DiscoveryEngine
    engine = DiscoveryEngine(rest_client=client)
    try:
        endpoints = engine.discover_from_graphql(graphql_url, probe=probe)
        store = _store()
        key = f"discovered_{conn_id}"
        existing = store.get(key, [])
        existing_paths = {ep.get("path") for ep in existing}
        added = 0
        for ep in endpoints:
            if ep.get("path") not in existing_paths:
                existing.append(ep)
                existing_paths.add(ep.get("path"))
                added += 1
        store[key] = existing
        return jsonify({"endpoints": existing, "count": len(existing),
                         "discovered": len(endpoints), "added": added})
    except Exception as e:
        import logging
        logging.getLogger("rest2adb.discovery").exception(
            "GraphQL discovery failed for %s", graphql_url
        )
        msg = str(e)
        code = 502 if "HTTPError" in type(e).__name__ else 500
        return jsonify({"error": msg, "graphql_url": graphql_url}), code


@bp.route("/discovery/sample", methods=["POST"])
def discover_sample():
    """Probe endpoints by fetching sample data."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoints = data.get("endpoints", [])
    deep = data.get("deep", False)
    if not conn_id or not endpoints:
        return jsonify({"error": "rest_connection_id and endpoints required"}), 400

    client = _get_rest_client(conn_id)
    if not client:
        return jsonify({"error": "REST connection not found"}), 404

    from app.core.discovery_engine import DiscoveryEngine
    engine = DiscoveryEngine(rest_client=client)
    results = engine.discover_from_sample(endpoints, deep=deep)
    store = _store()
    key = f"discovered_{conn_id}"
    store[key] = results
    return jsonify({"endpoints": results, "count": len(results)})


@bp.route("/discovery/manual", methods=["POST"])
def discover_manual():
    """Probe a single manually-configured endpoint."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoint = data.get("endpoint", {})
    deep = data.get("deep", False)
    if not conn_id or not endpoint:
        return jsonify({"error": "rest_connection_id and endpoint required"}), 400

    client = _get_rest_client(conn_id)
    if not client:
        return jsonify({"error": "REST connection not found"}), 404

    from app.core.discovery_engine import DiscoveryEngine
    engine = DiscoveryEngine(rest_client=client)

    store = _store()
    key = f"discovered_{conn_id}"

    if deep:
        # Deep discovery may return multiple endpoints (main + sub-resources)
        results = engine.discover_from_sample([endpoint], deep=True)
        store.setdefault(key, []).extend(results)
        return jsonify({"endpoints": results, "count": len(results)})

    result = engine.discover_manual(endpoint)
    store.setdefault(key, []).append(result)
    return jsonify({"endpoint": result})


@bp.route("/discovery/<conn_id>/endpoints", methods=["GET"])
def list_discovered(conn_id):
    """List previously discovered endpoints for a connection."""
    store = _store()
    key = f"discovered_{conn_id}"
    endpoints = store.get(key, [])
    return jsonify(endpoints)


@bp.route("/discovery/<conn_id>/endpoints", methods=["DELETE"])
def clear_discovered(conn_id):
    """Clear discovered endpoints."""
    store = _store()
    store.pop(f"discovered_{conn_id}", None)
    return jsonify({"status": "cleared"})


@bp.route("/discovery/<conn_id>/endpoints/export", methods=["GET"])
def export_endpoints(conn_id):
    """Export discovered endpoints for a connection."""
    store = _store()
    key = f"discovered_{conn_id}"
    endpoints = store.get(key, [])
    # Find connection name for context
    conn_name = conn_id
    for c in store.get("rest_connections", []):
        if c["id"] == conn_id:
            conn_name = c.get("name", conn_id)
            break
    return jsonify({
        "version": "1",
        "rest_connection_name": conn_name,
        "endpoints": endpoints,
    })


@bp.route("/discovery/endpoints/import", methods=["POST"])
def import_endpoints():
    """Import discovered endpoints and associate with a REST connection."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    endpoints = data.get("endpoints", [])
    if not conn_id:
        return jsonify({"error": "rest_connection_id required"}), 400
    if not endpoints:
        return jsonify({"error": "endpoints list required"}), 400
    store = _store()
    key = f"discovered_{conn_id}"
    existing = store.get(key, [])
    existing_paths = {ep.get("path") for ep in existing}
    added = 0
    for ep in endpoints:
        if ep.get("path") not in existing_paths:
            existing.append(ep)
            existing_paths.add(ep.get("path"))
            added += 1
    store[key] = existing
    return jsonify({"status": "imported", "added": added,
                     "total": len(existing)})


@bp.route("/discovery/suggest-table-name", methods=["POST"])
def suggest_table_name():
    data = request.get_json(force=True)
    path = data.get("path", "")
    from app.core.discovery_engine import DiscoveryEngine
    name = DiscoveryEngine.suggest_table_name(path)
    return jsonify({"table_name": name})


@bp.route("/discovery/update", methods=["POST"])
def update_endpoints():
    """Re-probe selected endpoints to refresh their schema/fields."""
    data = request.get_json(force=True)
    conn_id = data.get("rest_connection_id")
    paths = data.get("paths", [])
    deep = data.get("deep", False)
    if not conn_id or not paths:
        return jsonify({"error": "rest_connection_id and paths required"}), 400

    client = _get_rest_client(conn_id)
    if not client:
        return jsonify({"error": "REST connection not found"}), 404

    store = _store()
    key = f"discovered_{conn_id}"
    existing = store.get(key, [])

    # Build lookup of endpoints to re-probe
    path_set = set(paths)
    to_probe = [ep for ep in existing if ep.get("path") in path_set]
    if not to_probe:
        return jsonify({"error": "No matching endpoints found"}), 404

    from app.core.discovery_engine import DiscoveryEngine
    engine = DiscoveryEngine(rest_client=client)

    # Re-probe each selected endpoint
    probe_input = [{"path": ep.get("path"), "http_method": ep.get("http_method", "GET")}
                   for ep in to_probe]
    results = engine.discover_from_sample(probe_input, deep=deep)

    # Merge: replace matched endpoints with fresh results, keep the rest
    updated_paths = {ep.get("path") for ep in results}
    kept = [ep for ep in existing if ep.get("path") not in path_set]
    kept.extend(results)
    store[key] = kept

    return jsonify({
        "updated": len(results),
        "total": len(kept),
        "endpoints": kept,
    })
