"""Auto-install missing Python dependencies on first launch."""
import sys
import os
import subprocess
import importlib
import logging

log = logging.getLogger("rest2adb.bootstrap")

REQUIRED_PACKAGES = {
    "flask": "flask>=3.0",
    "oracledb": "python-oracledb>=2.0",
    "psycopg": "psycopg[binary]>=3.1",
    "mysql.connector": "mysql-connector-python>=8.3",
    "requests": "requests>=2.31",
    "yaml": "pyyaml>=6.0",
    "openapi_spec_validator": "openapi-spec-validator>=0.7",
    "jsonpath_ng": "jsonpath-ng>=1.6",
    "thefuzz": "thefuzz[speedup]>=0.22",
    "cryptography": "cryptography>=42.0",
    "pydantic": "pydantic>=2.5",
    "authlib": "authlib>=1.3",
}

def auto_install():
    missing = []
    for import_name, pip_name in REQUIRED_PACKAGES.items():
        try:
            importlib.import_module(import_name)
        except ImportError:
            missing.append(pip_name)
    if not missing:
        return
    print(f"[REST2ADB] First-run setup: installing {len(missing)} missing package(s)...")
    project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    venv_dir = os.path.join(project_root, "venv")
    if sys.platform == "win32":
        venv_pip = os.path.join(venv_dir, "Scripts", "pip")
    else:
        venv_pip = os.path.join(venv_dir, "bin", "pip")
    if os.path.exists(venv_pip):
        pip_cmd = [venv_pip]
    else:
        pip_cmd = [sys.executable, "-m", "pip"]
    cmd = pip_cmd + ["install", "--quiet"] + missing
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[REST2ADB] Auto-install failed. Run manually:\n  pip install -r requirements.txt")
        print(result.stderr)
        sys.exit(1)
    print("[REST2ADB] Dependencies installed successfully.")
