"""REST + Target connection CRUD API routes."""
from __future__ import annotations
import json
from flask import Blueprint, request, jsonify, current_app

bp = Blueprint("connections", __name__, url_prefix="/api")


# ── helpers ──────────────────────────────────────────────────────────────

def _store():
    return current_app.config["STORE"]


def _encrypt(val: str) -> str:
    try:
        from app.core.crypto import encrypt
        return encrypt(val)
    except Exception:
        return val


def _decrypt(val: str) -> str:
    try:
        from app.core.crypto import decrypt
        return decrypt(val)
    except Exception:
        return val


# ── REST connections ─────────────────────────────────────────────────────

@bp.route("/rest-connections", methods=["GET"])
def list_rest_connections():
    conns = _store().get("rest_connections", [])
    safe = []
    for c in conns:
        c2 = dict(c)
        ac = dict(c2.get("auth_config", {}))
        for k in ("password", "token", "client_secret", "value"):
            if k in ac:
                ac[k] = "••••••"
        c2["auth_config"] = ac
        safe.append(c2)
    return jsonify(safe)


@bp.route("/rest-connections", methods=["POST"])
def create_rest_connection():
    data = request.get_json(force=True)
    from uuid import uuid4
    data.setdefault("id", str(uuid4()))
    ac = data.get("auth_config", {})
    for k in ("password", "token", "client_secret", "value"):
        if k in ac and ac[k]:
            ac[k] = _encrypt(ac[k])
    data["auth_config"] = ac
    store = _store()
    store.setdefault("rest_connections", []).append(data)
    return jsonify({"id": data["id"], "status": "created"}), 201


@bp.route("/rest-connections/<conn_id>", methods=["GET"])
def get_rest_connection(conn_id):
    for c in _store().get("rest_connections", []):
        if c["id"] == conn_id:
            conn = dict(c)
            ac = dict(conn.get("auth_config", {}))
            for k in ("password", "token", "client_secret", "value"):
                if k in ac and ac[k]:
                    ac[k] = _decrypt(ac[k])
            conn["auth_config"] = ac
            return jsonify(conn)
    return jsonify({"error": "not found"}), 404


@bp.route("/rest-connections/<conn_id>", methods=["PUT"])
def update_rest_connection(conn_id):
    conns = _store().get("rest_connections", [])
    for i, c in enumerate(conns):
        if c["id"] == conn_id:
            data = request.get_json(force=True)
            data["id"] = conn_id
            old_ac = c.get("auth_config", {})
            ac = data.get("auth_config", {})
            for k in ("password", "token", "client_secret", "value"):
                if k in ac and ac[k] and not ac[k].startswith("gAAAAA"):
                    ac[k] = _encrypt(ac[k])
                elif k in ac and not ac[k] and k in old_ac:
                    # Preserve old encrypted value if field left blank
                    ac[k] = old_ac[k]
            data["auth_config"] = ac
            conns[i] = data
            return jsonify({"status": "updated"})
    return jsonify({"error": "not found"}), 404


@bp.route("/rest-connections/<conn_id>", methods=["DELETE"])
def delete_rest_connection(conn_id):
    conns = _store().get("rest_connections", [])
    _store()["rest_connections"] = [c for c in conns if c["id"] != conn_id]
    return jsonify({"status": "deleted"})


@bp.route("/rest-connections/test", methods=["POST"])
def test_rest_connection_unsaved():
    """Test a REST connection without saving it first."""
    data = request.get_json(force=True)
    from app.core.rest_client import RestClient
    oauth = current_app.config.get("OAUTH_MANAGER")
    client = RestClient(data, oauth_manager=oauth)
    result = client.test_connection()
    return jsonify(result)


@bp.route("/rest-connections/preview", methods=["POST"])
def preview_rest_connection():
    """Send a request using connection config and return full response for preview."""
    data = request.get_json(force=True)
    preview_path = data.pop("preview_path", "/")
    preview_method = data.pop("preview_method", "GET").upper()
    from app.core.rest_client import RestClient
    oauth = current_app.config.get("OAUTH_MANAGER")
    client = RestClient(data, oauth_manager=oauth)
    import time
    start = time.time()
    try:
        if preview_method == "POST":
            resp = client.post(preview_path)
        else:
            resp = client.get(preview_path)
        latency = (time.time() - start) * 1000
        # Collect response headers
        headers = dict(resp.headers)
        # Truncate body for preview
        body_text = resp.text[:5000] if resp.text else ""
        # Try to pretty-print JSON
        try:
            body_json = resp.json()
            body_text = json.dumps(body_json, indent=2)[:5000]
        except Exception:
            pass
        return jsonify({
            "success": resp.status_code < 400,
            "status_code": resp.status_code,
            "latency_ms": round(latency, 2),
            "headers": headers,
            "body": body_text,
        })
    except Exception as e:
        latency = (time.time() - start) * 1000
        return jsonify({
            "success": False,
            "status_code": 0,
            "latency_ms": round(latency, 2),
            "headers": {},
            "body": str(e),
        })


@bp.route("/rest-connections/<conn_id>/test", methods=["POST"])
def test_rest_connection(conn_id):
    for c in _store().get("rest_connections", []):
        if c["id"] == conn_id:
            # Decrypt auth secrets before testing
            conn = dict(c)
            ac = dict(conn.get("auth_config", {}))
            for k in ("password", "token", "client_secret", "value"):
                if k in ac and ac[k]:
                    ac[k] = _decrypt(ac[k])
            conn["auth_config"] = ac
            from app.core.rest_client import RestClient
            oauth = current_app.config.get("OAUTH_MANAGER")
            client = RestClient(conn, oauth_manager=oauth)
            result = client.test_connection()
            return jsonify(result)
    return jsonify({"error": "not found"}), 404


@bp.route("/rest-connections/<conn_id>/preview", methods=["POST"])
def preview_saved_rest_connection(conn_id):
    """Send a preview request using a saved REST connection."""
    for c in _store().get("rest_connections", []):
        if c["id"] == conn_id:
            conn = dict(c)
            ac = dict(conn.get("auth_config", {}))
            for k in ("password", "token", "client_secret", "value"):
                if k in ac and ac[k]:
                    ac[k] = _decrypt(ac[k])
            conn["auth_config"] = ac
            data = request.get_json(force=True) if request.is_json else {}
            preview_path = data.get("preview_path", "/")
            preview_method = data.get("preview_method", "GET").upper()
            from app.core.rest_client import RestClient
            import time
            oauth = current_app.config.get("OAUTH_MANAGER")
            client = RestClient(conn, oauth_manager=oauth)
            start = time.time()
            try:
                if preview_method == "POST":
                    resp = client.post(preview_path)
                else:
                    resp = client.get(preview_path)
                latency = (time.time() - start) * 1000
                headers = dict(resp.headers)
                body_text = resp.text[:5000] if resp.text else ""
                try:
                    body_json = resp.json()
                    body_text = json.dumps(body_json, indent=2)[:5000]
                except Exception:
                    pass
                return jsonify({
                    "success": resp.status_code < 400,
                    "status_code": resp.status_code,
                    "latency_ms": round(latency, 2),
                    "headers": headers,
                    "body": body_text,
                })
            except Exception as e:
                latency = (time.time() - start) * 1000
                return jsonify({
                    "success": False, "status_code": 0,
                    "latency_ms": round(latency, 2),
                    "headers": {}, "body": str(e),
                })
    return jsonify({"error": "not found"}), 404


# ── Target connections ───────────────────────────────────────────────────

@bp.route("/target-connections", methods=["GET"])
def list_target_connections():
    conns = _store().get("target_connections", [])
    safe = []
    for c in conns:
        c2 = dict(c)
        c2["password"] = "••••••"
        safe.append(c2)
    return jsonify(safe)


@bp.route("/target-connections", methods=["POST"])
def create_target_connection():
    data = request.get_json(force=True)
    from uuid import uuid4
    data.setdefault("id", str(uuid4()))
    if data.get("password"):
        data["password"] = _encrypt(data["password"])
    store = _store()
    store.setdefault("target_connections", []).append(data)
    return jsonify({"id": data["id"], "status": "created"}), 201


@bp.route("/target-connections/<conn_id>", methods=["GET"])
def get_target_connection(conn_id):
    for c in _store().get("target_connections", []):
        if c["id"] == conn_id:
            conn = dict(c)
            if conn.get("password"):
                conn["password"] = _decrypt(conn["password"])
            return jsonify(conn)
    return jsonify({"error": "not found"}), 404


@bp.route("/target-connections/<conn_id>", methods=["PUT"])
def update_target_connection(conn_id):
    conns = _store().get("target_connections", [])
    for i, c in enumerate(conns):
        if c["id"] == conn_id:
            data = request.get_json(force=True)
            data["id"] = conn_id
            if data.get("password") and not data["password"].startswith("gAAAAA"):
                data["password"] = _encrypt(data["password"])
            elif not data.get("password") and c.get("password"):
                # Preserve old encrypted password if field left blank
                data["password"] = c["password"]
            conns[i] = data
            return jsonify({"status": "updated"})
    return jsonify({"error": "not found"}), 404


@bp.route("/target-connections/<conn_id>", methods=["DELETE"])
def delete_target_connection(conn_id):
    conns = _store().get("target_connections", [])
    _store()["target_connections"] = [c for c in conns if c["id"] != conn_id]
    return jsonify({"status": "deleted"})


@bp.route("/target-connections/test", methods=["POST"])
def test_target_connection_unsaved():
    """Test a target connection without saving it first."""
    data = request.get_json(force=True)
    adapter = _get_adapter(data)
    try:
        adapter.connect(data)
        result = adapter.test_connection()
        adapter.disconnect()
        return jsonify({
            "success": result.success,
            "latency_ms": result.latency_ms,
            "message": result.message,
            "version": result.version,
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})


@bp.route("/target-connections/<conn_id>/test", methods=["POST"])
def test_target_connection(conn_id):
    for c in _store().get("target_connections", []):
        if c["id"] == conn_id:
            # Decrypt password before testing
            conn = dict(c)
            if conn.get("password"):
                conn["password"] = _decrypt(conn["password"])
            adapter = _get_adapter(conn)
            try:
                adapter.connect(conn)
                result = adapter.test_connection()
                adapter.disconnect()
                return jsonify({
                    "success": result.success,
                    "latency_ms": result.latency_ms,
                    "message": result.message,
                    "version": result.version,
                })
            except Exception as e:
                return jsonify({"success": False, "message": str(e)})
    return jsonify({"error": "not found"}), 404


# ── OAuth2 ───────────────────────────────────────────────────────────────

@bp.route("/rest-connections/<conn_id>/oauth/authorize", methods=["POST"])
def oauth_authorize(conn_id):
    for c in _store().get("rest_connections", []):
        if c["id"] == conn_id:
            oauth = current_app.config.get("OAUTH_MANAGER")
            if not oauth:
                return jsonify({"error": "OAuth2 not configured"}), 400
            oauth_config = c.get("oauth2_config", {})
            if not oauth_config:
                return jsonify({"error": "No OAuth2 config on connection"}), 400
            url = oauth.generate_auth_url(conn_id, oauth_config)
            return jsonify({"authorization_url": url})
    return jsonify({"error": "not found"}), 404


@bp.route("/rest-connections/<conn_id>/oauth/status", methods=["GET"])
def oauth_status(conn_id):
    oauth = current_app.config.get("OAUTH_MANAGER")
    if not oauth:
        return jsonify({"authorized": False})
    return jsonify(oauth.get_token_status(conn_id))


@bp.route("/rest-connections/<conn_id>/oauth/revoke", methods=["POST"])
def oauth_revoke(conn_id):
    oauth = current_app.config.get("OAUTH_MANAGER")
    if oauth:
        oauth.revoke_token(conn_id)
    return jsonify({"status": "revoked"})


# ── Export / Import ──────────────────────────────────────────────────────

@bp.route("/connections/export", methods=["GET"])
def export_connections():
    """Export all REST and Target connections (secrets redacted)."""
    store = _store()
    rest = []
    for c in store.get("rest_connections", []):
        c2 = dict(c)
        ac = dict(c2.get("auth_config", {}))
        for k in ("password", "token", "client_secret", "value"):
            if k in ac:
                ac[k] = ""
        c2["auth_config"] = ac
        if c2.get("oauth2_config"):
            oc = dict(c2["oauth2_config"])
            oc.pop("client_secret", None)
            c2["oauth2_config"] = oc
        rest.append(c2)
    target = []
    for c in store.get("target_connections", []):
        c2 = dict(c)
        c2["password"] = ""
        target.append(c2)
    return jsonify({
        "version": "1",
        "rest_connections": rest,
        "target_connections": target,
    })


@bp.route("/connections/import", methods=["POST"])
def import_connections():
    """Import REST and Target connections from a JSON payload."""
    data = request.get_json(force=True)
    store = _store()
    from uuid import uuid4
    imported = {"rest": 0, "target": 0, "skipped": 0}

    for c in data.get("rest_connections", []):
        # Skip duplicates by name + base_url
        existing = [x for x in store.get("rest_connections", [])
                    if x.get("name") == c.get("name")
                    and x.get("base_url") == c.get("base_url")]
        if existing:
            imported["skipped"] += 1
            continue
        c["id"] = str(uuid4())
        ac = c.get("auth_config", {})
        for k in ("password", "token", "client_secret", "value"):
            if k in ac and ac[k]:
                ac[k] = _encrypt(ac[k])
        store.setdefault("rest_connections", []).append(c)
        imported["rest"] += 1

    for c in data.get("target_connections", []):
        existing = [x for x in store.get("target_connections", [])
                    if x.get("name") == c.get("name")]
        if existing:
            imported["skipped"] += 1
            continue
        c["id"] = str(uuid4())
        if c.get("password"):
            c["password"] = _encrypt(c["password"])
        store.setdefault("target_connections", []).append(c)
        imported["target"] += 1

    return jsonify({"status": "imported", **imported})


def _get_adapter(conn_config: dict):
    target_type = conn_config.get("target_type", "oracle_adb")
    if target_type == "oracle_adb":
        from app.adapters.oracle_adb import OracleAdbAdapter
        return OracleAdbAdapter()
    elif target_type == "postgresql":
        from app.adapters.postgresql import PostgresAdapter
        return PostgresAdapter()
    elif target_type == "mysql":
        from app.adapters.mysql import MySQLAdapter
        return MySQLAdapter()
    raise ValueError(f"Unknown target type: {target_type}")
