"""Control table DDL, state machine, and CRUD operations for migration state."""
from __future__ import annotations
import logging
import json
from datetime import datetime, timezone
from uuid import uuid4

log = logging.getLogger("rest2adb.control_table")


class ControlTableManager:
    """Manages migration state via control tables in the target database."""

    def __init__(self, adapter, prefix: str = "R2A_"):
        self.adapter = adapter
        self.prefix = prefix

    def init_tables(self) -> None:
        self.adapter.init_control_tables(self.prefix)
        log.info("Control tables initialized with prefix '%s'", self.prefix)

    # --- MIGRATION JOB ---

    def create_job(self, job: dict) -> str:
        job_id = job.get("id") or str(uuid4())
        self.adapter.execute_update(
            f"""INSERT INTO {self.prefix}MIGRATION_JOB
                (JOB_ID, JOB_NAME, STATUS, REST_CONNECTION_ID, ADB_CONNECTION_ID,
                 CONFIG_JSON, CREATED_AT, TOTAL_ENDPOINTS, COMPLETED_ENDPOINTS,
                 TOTAL_ROWS_MIGRATED)
                VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10)""",
            (job_id, job.get("name", ""), "CREATED",
             job.get("rest_connection_id", ""), job.get("target_connection_id", ""),
             json.dumps(job.get("config_json", {})),
             datetime.now(timezone.utc), job.get("total_endpoints", 0), 0, 0),
        )
        return job_id

    def get_job(self, job_id: str) -> dict | None:
        rows = self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}MIGRATION_JOB WHERE JOB_ID = :1", (job_id,))
        return rows[0] if rows else None

    def list_jobs(self) -> list[dict]:
        return self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}MIGRATION_JOB ORDER BY CREATED_AT DESC")

    def update_job_status(self, job_id: str, status: str,
                          error_message: str | None = None) -> None:
        if status == "RUNNING":
            self.adapter.execute_update(
                f"UPDATE {self.prefix}MIGRATION_JOB SET STATUS=:1, STARTED_AT=:2 WHERE JOB_ID=:3",
                (status, datetime.now(timezone.utc), job_id))
        elif status in ("COMPLETED", "FAILED", "CANCELLED"):
            self.adapter.execute_update(
                f"""UPDATE {self.prefix}MIGRATION_JOB
                    SET STATUS=:1, COMPLETED_AT=:2, ERROR_MESSAGE=:3 WHERE JOB_ID=:4""",
                (status, datetime.now(timezone.utc), error_message, job_id))
        else:
            self.adapter.execute_update(
                f"UPDATE {self.prefix}MIGRATION_JOB SET STATUS=:1 WHERE JOB_ID=:2",
                (status, job_id))

    def update_job_progress(self, job_id: str, completed_endpoints: int,
                            total_rows: int) -> None:
        self.adapter.execute_update(
            f"""UPDATE {self.prefix}MIGRATION_JOB
                SET COMPLETED_ENDPOINTS=:1, TOTAL_ROWS_MIGRATED=:2 WHERE JOB_ID=:3""",
            (completed_endpoints, total_rows, job_id))

    def delete_job(self, job_id: str) -> None:
        pfx = self.prefix
        self.adapter.execute_update(
            f"DELETE FROM {pfx}BATCH_LOG WHERE ENDPOINT_STATE_ID IN "
            f"(SELECT ENDPOINT_STATE_ID FROM {pfx}ENDPOINT_STATE WHERE JOB_ID=:1)",
            (job_id,))
        for tbl in ("ENDPOINT_STATE", "SYNC_STATE", "QUARANTINE", "MIGRATION_JOB"):
            self.adapter.execute_update(
                f"DELETE FROM {pfx}{tbl} WHERE JOB_ID=:1", (job_id,))

    # --- ENDPOINT STATE ---

    def create_endpoint_state(self, job_id: str, endpoint_path: str,
                              target_table: str) -> str:
        ep_id = str(uuid4())
        self.adapter.execute_update(
            f"""INSERT INTO {self.prefix}ENDPOINT_STATE
                (ENDPOINT_STATE_ID, JOB_ID, ENDPOINT_PATH, TARGET_TABLE, STATUS,
                 LAST_SUCCESSFUL_BATCH, ROWS_FETCHED, ROWS_INSERTED, RETRY_COUNT)
                VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9)""",
            (ep_id, job_id, endpoint_path, target_table, "PENDING", 0, 0, 0, 0))
        return ep_id

    def get_endpoint_states(self, job_id: str,
                            status: list[str] | None = None) -> list[dict]:
        if status:
            ph = ",".join(f":{i+2}" for i in range(len(status)))
            return self.adapter.execute_query(
                f"SELECT * FROM {self.prefix}ENDPOINT_STATE "
                f"WHERE JOB_ID=:1 AND STATUS IN ({ph})",
                (job_id, *status))
        return self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}ENDPOINT_STATE WHERE JOB_ID=:1", (job_id,))

    def update_endpoint_status(self, ep_id: str, status: str,
                               error_message: str | None = None) -> None:
        if status == "IN_PROGRESS":
            self.adapter.execute_update(
                f"UPDATE {self.prefix}ENDPOINT_STATE SET STATUS=:1, STARTED_AT=:2 "
                f"WHERE ENDPOINT_STATE_ID=:3",
                (status, datetime.now(timezone.utc), ep_id))
        elif status in ("COMPLETED", "FAILED"):
            self.adapter.execute_update(
                f"UPDATE {self.prefix}ENDPOINT_STATE SET STATUS=:1, COMPLETED_AT=:2, "
                f"ERROR_MESSAGE=:3 WHERE ENDPOINT_STATE_ID=:4",
                (status, datetime.now(timezone.utc), error_message, ep_id))
        else:
            self.adapter.execute_update(
                f"UPDATE {self.prefix}ENDPOINT_STATE SET STATUS=:1 "
                f"WHERE ENDPOINT_STATE_ID=:2", (status, ep_id))

    def update_endpoint_checkpoint(self, ep_id: str, cursor: str | None,
                                   batch_seq: int, rows_fetched: int,
                                   rows_inserted: int) -> None:
        self.adapter.execute_update(
            f"""UPDATE {self.prefix}ENDPOINT_STATE
                SET LAST_PAGE_CURSOR=:1, LAST_SUCCESSFUL_BATCH=:2,
                    ROWS_FETCHED=:3, ROWS_INSERTED=:4
                WHERE ENDPOINT_STATE_ID=:5""",
            (cursor, batch_seq, rows_fetched, rows_inserted, ep_id))

    def increment_retry(self, ep_id: str) -> int:
        self.adapter.execute_update(
            f"UPDATE {self.prefix}ENDPOINT_STATE "
            f"SET RETRY_COUNT=RETRY_COUNT+1 WHERE ENDPOINT_STATE_ID=:1", (ep_id,))
        rows = self.adapter.execute_query(
            f"SELECT RETRY_COUNT FROM {self.prefix}ENDPOINT_STATE "
            f"WHERE ENDPOINT_STATE_ID=:1", (ep_id,))
        return rows[0]["RETRY_COUNT"] if rows else 0

    # --- BATCH LOG ---

    def log_batch(self, ep_id: str, batch_seq: int, page_param: str | None,
                  rows: int, status: str, error: str | None = None) -> str:
        batch_id = str(uuid4())
        now = datetime.now(timezone.utc)
        self.adapter.execute_update(
            f"""INSERT INTO {self.prefix}BATCH_LOG
                (BATCH_ID, ENDPOINT_STATE_ID, BATCH_SEQ, PAGE_PARAM,
                 ROWS_IN_BATCH, STATUS, STARTED_AT, COMPLETED_AT, ERROR_MESSAGE)
                VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9)""",
            (batch_id, ep_id, batch_seq, page_param, rows, status, now, now, error))
        return batch_id

    # --- QUARANTINE ---

    def add_quarantine(self, job_id: str, endpoint_path: str, batch_seq: int,
                       row_data: dict, violations: list[dict], severity: str) -> str:
        q_id = str(uuid4())
        self.adapter.execute_update(
            f"""INSERT INTO {self.prefix}QUARANTINE
                (QUARANTINE_ID, JOB_ID, ENDPOINT_PATH, BATCH_SEQ,
                 ROW_DATA, VIOLATIONS, SEVERITY, CREATED_AT, RESOLVED)
                VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9)""",
            (q_id, job_id, endpoint_path, batch_seq,
             json.dumps(row_data), json.dumps(violations), severity,
             datetime.now(timezone.utc), "N"))
        return q_id

    def get_quarantine(self, job_id: str) -> list[dict]:
        return self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}QUARANTINE WHERE JOB_ID=:1 ORDER BY CREATED_AT",
            (job_id,))

    def resolve_quarantine(self, quarantine_ids: list[str]) -> int:
        count = 0
        for qid in quarantine_ids:
            count += self.adapter.execute_update(
                f"UPDATE {self.prefix}QUARANTINE SET RESOLVED=:1 WHERE QUARANTINE_ID=:2",
                ("Y", qid))
        return count

    # --- BATCH RUN ---

    def create_batch_run(self, name: str, job_ids: list[str],
                         concurrency: int) -> str:
        batch_id = str(uuid4())
        self.adapter.execute_update(
            f"""INSERT INTO {self.prefix}BATCH_RUN
                (BATCH_RUN_ID, BATCH_NAME, STATUS, CONCURRENCY,
                 CREATED_AT, TOTAL_JOBS, COMPLETED_JOBS, FAILED_JOBS)
                VALUES (:1,:2,:3,:4,:5,:6,:7,:8)""",
            (batch_id, name, "CREATED", concurrency,
             datetime.now(timezone.utc), len(job_ids), 0, 0))
        for i, jid in enumerate(job_ids, 1):
            self.adapter.execute_update(
                f"""INSERT INTO {self.prefix}BATCH_RUN_JOBS
                    (BATCH_RUN_ID, JOB_ID, EXECUTION_ORDER, STATUS)
                    VALUES (:1,:2,:3,:4)""",
                (batch_id, jid, i, "PENDING"))
        return batch_id

    def get_batch_run(self, batch_run_id: str) -> dict | None:
        rows = self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}BATCH_RUN WHERE BATCH_RUN_ID=:1",
            (batch_run_id,))
        return rows[0] if rows else None

    def list_batch_runs(self) -> list[dict]:
        return self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}BATCH_RUN ORDER BY CREATED_AT DESC")

    def get_batch_jobs(self, batch_run_id: str,
                       status: list[str] | None = None) -> list[dict]:
        if status:
            ph = ",".join(f":{i+2}" for i in range(len(status)))
            return self.adapter.execute_query(
                f"SELECT * FROM {self.prefix}BATCH_RUN_JOBS "
                f"WHERE BATCH_RUN_ID=:1 AND STATUS IN ({ph}) ORDER BY EXECUTION_ORDER",
                (batch_run_id, *status))
        return self.adapter.execute_query(
            f"SELECT * FROM {self.prefix}BATCH_RUN_JOBS "
            f"WHERE BATCH_RUN_ID=:1 ORDER BY EXECUTION_ORDER", (batch_run_id,))

    def update_batch_run_status(self, batch_run_id: str, status: str) -> None:
        extra, params = "", [status]
        if status == "RUNNING":
            extra, params = ", STARTED_AT=:2", [status, datetime.now(timezone.utc)]
        elif status in ("COMPLETED", "PARTIAL_FAILURE", "FAILED", "CANCELLED"):
            extra, params = ", COMPLETED_AT=:2", [status, datetime.now(timezone.utc)]
        params.append(batch_run_id)
        self.adapter.execute_update(
            f"UPDATE {self.prefix}BATCH_RUN SET STATUS=:1{extra} "
            f"WHERE BATCH_RUN_ID=:{len(params)}", tuple(params))

    def update_batch_job_status(self, batch_run_id: str, job_id: str,
                                status: str) -> None:
        extra, params = "", [status]
        if status == "RUNNING":
            extra, params = ", STARTED_AT=:2", [status, datetime.now(timezone.utc)]
        elif status in ("COMPLETED", "FAILED", "SKIPPED"):
            extra, params = ", COMPLETED_AT=:2", [status, datetime.now(timezone.utc)]
        params.extend([batch_run_id, job_id])
        n = len(params)
        self.adapter.execute_update(
            f"UPDATE {self.prefix}BATCH_RUN_JOBS SET STATUS=:1{extra} "
            f"WHERE BATCH_RUN_ID=:{n-1} AND JOB_ID=:{n}", tuple(params))

    def update_batch_counters(self, batch_run_id: str) -> dict:
        rows = self.adapter.execute_query(
            f"""SELECT
                SUM(CASE WHEN STATUS='COMPLETED' THEN 1 ELSE 0 END) AS COMPLETED,
                SUM(CASE WHEN STATUS='FAILED' THEN 1 ELSE 0 END) AS FAILED
                FROM {self.prefix}BATCH_RUN_JOBS WHERE BATCH_RUN_ID=:1""",
            (batch_run_id,))
        s = rows[0] if rows else {}
        c, f = int(s.get("COMPLETED", 0) or 0), int(s.get("FAILED", 0) or 0)
        self.adapter.execute_update(
            f"UPDATE {self.prefix}BATCH_RUN SET COMPLETED_JOBS=:1, FAILED_JOBS=:2 "
            f"WHERE BATCH_RUN_ID=:3", (c, f, batch_run_id))
        return {"completed": c, "failed": f}
