@echo off
REM rest2adb-ai – Start Script (Windows)
REM Checks Python availability, installs required libraries if absent,
REM then launches the application.

cd /d "%~dp0"

set APP_NAME=rest2adb-ai
set PID_FILE=data\.pid
set LOG_DIR=data\logs
set REQUIREMENTS=requirements.txt

if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

REM ── Parse port argument ─────────────────────────────────────────────
set PORT=%1
if "%PORT%"=="" set PORT=5100
if "%PORT%"=="--port" (
    set PORT=%2
    if "%PORT%"=="" set PORT=5100
)

REM ── Check if already running ────────────────────────────────────────
if exist "%PID_FILE%" (
    set /p OLD_PID=<"%PID_FILE%"
    tasklist /fi "PID eq %OLD_PID%" 2>nul | find "%OLD_PID%" >nul
    if not errorlevel 1 (
        echo %APP_NAME% is already running ^(PID: %OLD_PID%^). Use restart.bat to restart.
        exit /b 1
    ) else (
        echo Stale PID file found. Cleaning up.
        del "%PID_FILE%"
    )
)

REM ── Step 1: Check for Python 3.14+ (install if missing) ────────────
set MIN_PY_MINOR=14
set PYTHON=
where python >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%v in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2^>nul') do set PYVER=%%v
    for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
        if %%a GEQ 3 if %%b GEQ %MIN_PY_MINOR% set PYTHON=python
    )
)
if "%PYTHON%"=="" (
    where python3 >nul 2>&1
    if %errorlevel% equ 0 (
        for /f "tokens=*" %%v in ('python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2^>nul') do set PYVER=%%v
        for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
            if %%a GEQ 3 if %%b GEQ %MIN_PY_MINOR% set PYTHON=python3
        )
    )
)
if "%PYTHON%"=="" (
    echo.
    echo WARNING: Python 3.%MIN_PY_MINOR%+ is required but was not found.
    echo.
    where winget >nul 2>&1
    if %errorlevel% equ 0 (
        echo Python can be installed via winget:
        echo.
        echo   winget install --id Python.Python.3.14 --accept-package-agreements --accept-source-agreements
        echo.
        set /p INSTALL_PY="Attempt automatic install now? (Y/n): "
        if /i "%INSTALL_PY%"=="" set INSTALL_PY=Y
        if /i "%INSTALL_PY%"=="Y" (
            echo Installing Python 3.14 via winget...
            winget install --id Python.Python.3.14 --accept-package-agreements --accept-source-agreements
            if errorlevel 1 (
                echo ERROR: Automatic install failed.
                echo Please install Python 3.%MIN_PY_MINOR%+ manually from https://www.python.org/downloads/
                exit /b 1
            )
            echo Python 3.14 installed. Refreshing PATH...
            REM Refresh PATH to pick up the new install
            for /f "tokens=*" %%p in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2^>nul') do set PYVER=%%p
            for /f "tokens=1,2 delims=." %%a in ("%PYVER%") do (
                if %%a GEQ 3 if %%b GEQ %MIN_PY_MINOR% set PYTHON=python
            )
        ) else (
            echo Please install Python 3.%MIN_PY_MINOR%+ and re-run this script.
            exit /b 1
        )
    ) else (
        echo Please install Python 3.%MIN_PY_MINOR%+ from https://www.python.org/downloads/
        exit /b 1
    )
)
if "%PYTHON%"=="" (
    echo ERROR: Python 3.%MIN_PY_MINOR%+ still not found after installation attempt.
    echo You may need to open a new command prompt for the PATH to update.
    exit /b 1
)

for /f "tokens=*" %%v in ('%PYTHON% --version 2^>^&1') do echo Using %PYTHON% ^(%%v^)

REM ── Step 2: Check and install required Python libraries ─────────────
if not exist "%REQUIREMENTS%" (
    echo WARNING: %REQUIREMENTS% not found. Skipping dependency check.
    goto :env_check
)

echo Checking Python library dependencies...
%PYTHON% -c "import importlib.metadata; pkgs=['flask','flask_socketio','flask_login','oracledb','anthropic','authlib','httpx','yaml','cryptography','requests','dotenv','rich']; missing=[p for p in pkgs if not importlib.metadata.packages_distributions().get(p)]; exit(1 if missing else 0)" >nul 2>&1
if errorlevel 1 (
    echo.
    echo Some required Python libraries are not installed.
    echo.
    set /p ANSWER="Install them now? (Y/n): "
    if /i "%ANSWER%"=="" set ANSWER=Y
    if /i "%ANSWER%"=="Y" (
        echo Installing libraries from %REQUIREMENTS%...
        %PYTHON% -m pip install -r "%REQUIREMENTS%"
        if errorlevel 1 (
            echo ERROR: Some libraries failed to install.
            exit /b 1
        )
        echo All libraries installed successfully.
    ) else (
        echo Cannot start %APP_NAME% without required libraries.
        exit /b 1
    )
) else (
    echo All required Python libraries are installed.
)

:env_check

REM ── Step 3: Check for Node.js (required by Claude Code CLI) ─────────
echo Checking for Node.js...
where node >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%v in ('node --version 2^>^&1') do echo Node.js found: %%v
) else (
    echo.
    echo Node.js is required ^(for Claude Code CLI^) but was not found.
    echo.
    where winget >nul 2>&1
    if %errorlevel% equ 0 (
        echo Node.js can be installed via winget:
        echo.
        echo   winget install --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
        echo.
        set /p INSTALL_NODE="Install Node.js via winget now? (Y/n): "
        if /i "%INSTALL_NODE%"=="" set INSTALL_NODE=Y
        if /i "%INSTALL_NODE%"=="Y" (
            echo Installing Node.js via winget...
            winget install --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
            if errorlevel 1 (
                echo ERROR: Node.js installation failed.
                echo Please install Node.js manually from https://nodejs.org/
                exit /b 1
            )
            echo Node.js installed successfully.
        ) else (
            echo Please install Node.js and re-run this script.
            exit /b 1
        )
    ) else (
        echo Please install Node.js from https://nodejs.org/
        exit /b 1
    )
)

REM ── Step 4: Check for Claude Code CLI ───────────────────────────────
echo Checking for Claude Code CLI...
where claude >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%v in ('claude --version 2^>^&1') do echo Claude Code CLI found: %%v
) else (
    echo.
    echo Claude Code CLI is required but was not found.
    echo.
    echo Install via PowerShell:
    echo   irm https://claude.ai/install.ps1 ^| iex
    echo.
    set /p INSTALL_CLI="Install Claude Code CLI now? (Y/n): "
    if /i "%INSTALL_CLI%"=="" set INSTALL_CLI=Y
    if /i "%INSTALL_CLI%"=="Y" (
        echo Installing Claude Code CLI...
        powershell -Command "irm https://claude.ai/install.ps1 | iex"
        if errorlevel 1 (
            echo ERROR: Claude Code CLI installation failed.
            echo Please install manually: irm https://claude.ai/install.ps1 ^| iex
            exit /b 1
        )
        echo Claude Code CLI installed successfully.
    ) else (
        echo Please install Claude Code CLI and re-run this script.
        exit /b 1
    )
)

REM ── Step 5: Claude authentication ───────────────────────────────────
echo Checking Claude authentication...
if defined ANTHROPIC_API_KEY (
    echo ANTHROPIC_API_KEY environment variable detected.
    goto :auth_ok
)
%PYTHON% -c "import anthropic, sys; c = anthropic.Anthropic(); sys.exit(0 if c.api_key else 1)" >nul 2>&1
if %errorlevel% equ 0 (
    echo Claude subscription credentials detected.
    goto :auth_ok
)

echo.
echo No Claude credentials detected.
echo Launching Claude Code CLI for authentication...
echo Complete the login in the prompt below, then the app will start.
echo.
claude
if errorlevel 1 (
    echo.
    echo WARNING: Claude authentication may not have completed.
    echo You can authenticate later by running: claude
    echo Or set the ANTHROPIC_API_KEY environment variable.
    echo.
)

:auth_ok

REM ── Step 6: Run environment / config check ──────────────────────────
echo Running environment check...
%PYTHON% setup_check.py --auto-check
if errorlevel 1 exit /b 1

REM ── Step 7: Check for updates ───────────────────────────────────────
echo Checking for updates...
%PYTHON% update_check.py

REM ── Step 8: Start the application ──────────────────────────────────
echo Starting %APP_NAME% on port %PORT%...
start /b %PYTHON% -m app.main --port %PORT% >> "%LOG_DIR%\app.log" 2>&1

REM Find the PID by matching the command line of our specific process
timeout /t 2 /nobreak >nul
for /f "tokens=2 delims=," %%a in ('wmic process where "commandline like '%%app.main%%' and name like '%%python%%'" get processid /format:csv 2^>nul ^| findstr /r "[0-9]"') do (
    echo %%a> "%PID_FILE%"
    goto :started
)

:started
if exist "%PID_FILE%" (
    set /p PID=<"%PID_FILE%"
    echo %APP_NAME% started on port %PORT% ^(PID: %PID%^)
) else (
    echo WARNING: Could not capture PID. %APP_NAME% may have failed to start.
    echo Check %LOG_DIR%\app.log for details.
)
echo View logs: type %LOG_DIR%\app.log

REM ── Step 6: Auto-launch web browser ──────────────────────────────
timeout /t 2 /nobreak >nul
echo Opening http://localhost:%PORT% in default browser...
start http://localhost:%PORT%
