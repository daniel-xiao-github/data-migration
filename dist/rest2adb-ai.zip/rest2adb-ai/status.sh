#!/bin/bash
# restapi2adb – Status Script (Linux/macOS)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="restapi2adb"
PID_FILE="data/.pid"
PROCESS_PATTERN="python.*app\.main"

show_process_info() {
    local pid=$1
    echo "$APP_NAME is RUNNING (PID: $pid)"
    if command -v ps &>/dev/null; then
        echo ""
        ps -p "$pid" -o pid,ppid,%cpu,%mem,etime,command 2>/dev/null
        # Also show child processes (e.g. werkzeug reloader children)
        local children
        children=$(pgrep -P "$pid" 2>/dev/null)
        if [ -n "$children" ]; then
            echo ""
            echo "Child processes:"
            for child in $children; do
                ps -p "$child" -o pid,ppid,%cpu,%mem,etime,command 2>/dev/null | tail -1
            done
        fi
    fi
}

# ── Primary: use PID file ────────────────────────────────────────────
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        show_process_info "$PID"
        exit 0
    else
        echo "PID file contains stale PID $PID. Cleaning up."
        rm -f "$PID_FILE"
    fi
fi

# ── Fallback: find by process command pattern ────────────────────────
FOUND_PID=$(pgrep -f "$PROCESS_PATTERN" 2>/dev/null | head -1)
if [ -n "$FOUND_PID" ]; then
    echo "WARNING: PID file was missing/stale but $APP_NAME is running."
    echo "$FOUND_PID" > "$PID_FILE"
    show_process_info "$FOUND_PID"
    exit 0
fi

echo "$APP_NAME is NOT running."
exit 1
