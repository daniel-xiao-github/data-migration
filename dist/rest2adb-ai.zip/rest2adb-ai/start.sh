#!/usr/bin/env bash
# ================================================================
#  REST API to Oracle ADB Data Migration Workbench - Bootstrap Script
#  Ensures Python 3.14+, pip, all Python dependencies, Node.js,
#  Claude Code CLI, and Claude authentication are ready, then
#  launches the server.  Fully automatic with coloured status output.
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ----------------------------------------------------------------
#  HELPER: Write coloured status lines
# ----------------------------------------------------------------
write_ok()   { printf '  [\033[1;32mOK\033[0m]   %s\n' "$*"; }
write_miss() { printf '  [\033[1;33mMISS\033[0m] %s\n' "$*"; }
write_fail() { printf '  [\033[1;31mFAIL\033[0m] %s\n' "$*"; }
write_info() { printf '  [\033[1;36m....\033[0m] %s\n' "$*"; }
write_warn() { printf '  [\033[1;33mWARN\033[0m] %s\n' "$*"; }

# ================================================================
#  Read version & print banner
# ================================================================
APP_VERSION="dev"
if [ -f "$SCRIPT_DIR/VERSION" ]; then
    APP_VERSION=$(cat "$SCRIPT_DIR/VERSION" | tr -d '[:space:]')
fi

echo ''
printf '  \033[1;36m================================================================\033[0m\n'
printf '  \033[1;36m REST -> ADB Migration Workbench  v%s\033[0m\n' "$APP_VERSION"
printf '  \033[1;36m================================================================\033[0m\n'
echo ''

# ================================================================
#  STEP 1 - Find a working Python 3.14+
# ================================================================
write_info 'Searching for Python 3.14+...'

PYTHON_EXE=""

# --- 1a. Scan well-known install directories (highest version first)
SEARCH_DIRS=(
    "/usr/local/bin/python3.14"
    "/usr/local/bin/python3.15"
    "/usr/bin/python3.14"
    "/usr/bin/python3.15"
    "$HOME/.local/bin/python3.14"
    "$HOME/.local/bin/python3"
    "$HOME/.local/python3.14/bin/python3"
    "$HOME/.pyenv/shims/python3"
)

# macOS Homebrew paths
if [ "$(uname)" = "Darwin" ]; then
    SEARCH_DIRS+=(
        "/opt/homebrew/bin/python3.14"
        "/opt/homebrew/bin/python3.15"
        "/opt/homebrew/bin/python3"
        "/usr/local/opt/python@3.14/bin/python3"
    )
fi

for p in "${SEARCH_DIRS[@]}"; do
    if [ -x "$p" ] 2>/dev/null; then
        if "$p" -c "import sys; assert sys.version_info >= (3,14)" 2>/dev/null; then
            PYTHON_EXE="$p"
            break
        fi
    fi
done

# --- 1b. Try "python3" / "python" on PATH
if [ -z "$PYTHON_EXE" ]; then
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            if "$cmd" -c "import sys; assert sys.version_info >= (3,14)" 2>/dev/null; then
                PYTHON_EXE="$cmd"
                break
            fi
        fi
    done
fi

# ================================================================
#  STEP 1B - Auto-install Python if not found
# ================================================================
install_python_from_source() {
    local PY_VER="3.14.0"
    local PY_URL="https://www.python.org/ftp/python/${PY_VER}/Python-${PY_VER}.tgz"
    local PY_PREFIX="$HOME/.local/python3.14"
    local BUILD_DIR
    BUILD_DIR="$(mktemp -d)"

    write_info "Downloading Python ${PY_VER} source from python.org..."
    curl -fSL "$PY_URL" -o "$BUILD_DIR/Python.tgz" || {
        write_fail "Failed to download Python source."
        rm -rf "$BUILD_DIR"
        return 1
    }

    write_info "Building Python ${PY_VER} (install prefix: $PY_PREFIX)..."
    tar -xzf "$BUILD_DIR/Python.tgz" -C "$BUILD_DIR" && \
    cd "$BUILD_DIR/Python-${PY_VER}" && \
    ./configure --prefix="$PY_PREFIX" --enable-optimizations --with-ensurepip=install 2>&1 | tail -5 && \
    make -j"$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 2)" 2>&1 | tail -5 && \
    make install 2>&1 | tail -5 && \
    cd "$SCRIPT_DIR" && \
    rm -rf "$BUILD_DIR" && \
    export PATH="$PY_PREFIX/bin:$PATH" && \
    write_ok "Python ${PY_VER} installed to $PY_PREFIX" || {
        write_fail "Build from source failed."
        cd "$SCRIPT_DIR"
        rm -rf "$BUILD_DIR"
        return 1
    }
}

if [ -z "$PYTHON_EXE" ]; then
    write_warn 'Python 3.14+ is not installed on this system.'
    echo ''

    # Detect package manager
    PKG_MGR=""
    if command -v apt-get >/dev/null 2>&1; then
        PKG_MGR="apt"
    elif command -v dnf >/dev/null 2>&1; then
        PKG_MGR="dnf"
    elif command -v yum >/dev/null 2>&1; then
        PKG_MGR="yum"
    elif command -v brew >/dev/null 2>&1; then
        PKG_MGR="brew"
    elif command -v pacman >/dev/null 2>&1; then
        PKG_MGR="pacman"
    fi

    if [ -n "$PKG_MGR" ]; then
        printf '  Install Python 3.14 using %s? (Y/n) ' "$PKG_MGR"
        read -r answer
        if echo "$answer" | grep -qiE '^y|^$'; then
            echo ''
            write_info "Installing Python 3.14 via $PKG_MGR..."
            case "$PKG_MGR" in
                apt)
                    sudo add-apt-repository -y ppa:deadsnakes/ppa && \
                    sudo apt-get update -qq && \
                    sudo apt-get install -y python3.14 python3.14-venv python3.14-dev || {
                        write_warn "Package manager install failed. Falling back to build from source..."
                        install_python_from_source || {
                            write_fail 'Could not install Python 3.14.'
                            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                            exit 1
                        }
                    }
                    ;;
                dnf)
                    sudo dnf install -y python3.14 || {
                        write_warn "Package manager install failed. Falling back to build from source..."
                        install_python_from_source || {
                            write_fail 'Could not install Python 3.14.'
                            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                            exit 1
                        }
                    }
                    ;;
                yum)
                    sudo yum install -y python3.14 || {
                        write_warn "Package manager install failed. Falling back to build from source..."
                        install_python_from_source || {
                            write_fail 'Could not install Python 3.14.'
                            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                            exit 1
                        }
                    }
                    ;;
                brew)
                    brew install python@3.14 || {
                        write_warn "Homebrew install failed. Falling back to build from source..."
                        install_python_from_source || {
                            write_fail 'Could not install Python 3.14.'
                            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                            exit 1
                        }
                    }
                    ;;
                pacman)
                    sudo pacman -S --noconfirm python || {
                        write_warn "Package manager install failed. Falling back to build from source..."
                        install_python_from_source || {
                            write_fail 'Could not install Python 3.14.'
                            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                            exit 1
                        }
                    }
                    ;;
            esac

            # Re-scan for Python after install
            export PATH="$HOME/.local/python3.14/bin:$PATH"
            for cmd in python3.14 python3 python; do
                if command -v "$cmd" >/dev/null 2>&1; then
                    if "$cmd" -c "import sys; assert sys.version_info >= (3,14)" 2>/dev/null; then
                        PYTHON_EXE="$cmd"
                        break
                    fi
                fi
            done

            if [ -z "$PYTHON_EXE" ]; then
                write_fail 'Python was installed but cannot be found on PATH.'
                write_info 'Please close this terminal, open a new one, and re-run this script.'
                exit 1
            fi
            write_ok 'Python installed successfully.'
        else
            echo ''
            echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
            echo '  Then re-run this script.'
            exit 1
        fi
    else
        # No package manager — try build from source
        echo '  No supported package manager found (apt, dnf, yum, brew, pacman).'
        echo '  Python 3.14 will be built from source and installed to ~/.local/.'
        echo ''
        echo '  Prerequisites: C compiler (gcc/clang), make, curl, and standard dev libraries.'
        echo ''
        printf '  Build and install Python from source now? (Y/n) '
        read -r answer
        if echo "$answer" | grep -qiE '^y|^$'; then
            install_python_from_source || {
                write_fail 'Could not build Python from source.'
                echo '  Please install Python 3.14+ from https://www.python.org/downloads/'
                exit 1
            }
            # Re-scan
            export PATH="$HOME/.local/python3.14/bin:$PATH"
            PYTHON_EXE=$(command -v python3.14 2>/dev/null || command -v python3 2>/dev/null || true)
            if [ -z "$PYTHON_EXE" ]; then
                write_fail 'Python 3.14+ still not found after build.'
                exit 1
            fi
        else
            echo '  Please install Python 3.14+ and re-run this script.'
            exit 1
        fi
    fi
fi

# ================================================================
#  STEP 2 - Verify Python version >= 3.14
# ================================================================
echo ''
PY_VERSION=$("$PYTHON_EXE" -c "import sys; print(sys.version.split()[0])")
if [ -z "$PY_VERSION" ]; then
    write_fail "Could not determine Python version from: $PYTHON_EXE"
    exit 1
fi

write_ok "Python $PY_VERSION at: $PYTHON_EXE"

PY_MAJOR=$("$PYTHON_EXE" -c "import sys; print(sys.version_info.major)")
PY_MINOR=$("$PYTHON_EXE" -c "import sys; print(sys.version_info.minor)")

if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 14 ]; }; then
    write_fail "Python 3.14+ is required. Found: $PY_VERSION"
    echo '  Download from: https://www.python.org/downloads/'
    exit 1
fi

# ================================================================
#  STEP 3 - Ensure pip is available
# ================================================================
write_info 'Checking pip...'

if ! "$PYTHON_EXE" -m pip --version >/dev/null 2>&1; then
    write_info 'Installing pip...'
    "$PYTHON_EXE" -m ensurepip --upgrade 2>/dev/null || true
    if ! "$PYTHON_EXE" -m pip --version >/dev/null 2>&1; then
        write_fail 'pip is not available and could not be installed.'
        exit 1
    fi
fi

write_ok 'pip ready.'

# ================================================================
#  STEP 4 - Check Python package dependencies (ImportName:PipName)
# ================================================================
echo ''
write_info 'Checking Python packages...'

# ImportName:PipName pairs — one per required dependency
REQUIRED_PACKAGES=(
    "flask:flask"
    "flask_socketio:flask-socketio"
    "flask_login:flask-login"
    "oracledb:oracledb"
    "anthropic:anthropic"
    "authlib:authlib"
    "httpx:httpx"
    "yaml:pyyaml"
    "cryptography:cryptography"
    "requests:requests"
    "dotenv:python-dotenv"
    "rich:rich"
)

# gunicorn is only needed on Linux/macOS
if [ "$(uname)" != "MINGW"* ] && [ "$(uname)" != "CYGWIN"* ]; then
    REQUIRED_PACKAGES+=("gunicorn:gunicorn")
fi

MISSING=()

for entry in "${REQUIRED_PACKAGES[@]}"; do
    IMPORT_NAME="${entry%%:*}"
    PIP_NAME="${entry##*:}"

    if "$PYTHON_EXE" -c "import $IMPORT_NAME" 2>/dev/null; then
        write_ok "$IMPORT_NAME"
    else
        write_miss "$IMPORT_NAME"
        MISSING+=("$PIP_NAME")
    fi
done

# ================================================================
#  STEP 5 - Install missing packages
# ================================================================
if [ ${#MISSING[@]} -gt 0 ]; then
    echo ''
    write_info "Installing ${#MISSING[@]} missing package(s)..."

    # Try bulk install from requirements.txt first
    REQ_FILE="$SCRIPT_DIR/requirements.txt"
    if [ -f "$REQ_FILE" ] && "$PYTHON_EXE" -m pip install --upgrade -r "$REQ_FILE" 2>/dev/null; then
        : # success
    else
        write_warn 'Bulk install had errors. Retrying individually...'
        for pip_pkg in "${MISSING[@]}"; do
            write_info "Installing $pip_pkg..."
            "$PYTHON_EXE" -m pip install "$pip_pkg" || true
        done
    fi

    # Verify all required packages
    echo ''
    write_info 'Verifying installed packages...'
    FAIL_COUNT=0
    for entry in "${REQUIRED_PACKAGES[@]}"; do
        IMPORT_NAME="${entry%%:*}"
        if "$PYTHON_EXE" -c "import $IMPORT_NAME" 2>/dev/null; then
            write_ok "$IMPORT_NAME"
        else
            write_fail "$IMPORT_NAME"
            FAIL_COUNT=$((FAIL_COUNT + 1))
        fi
    done

    if [ "$FAIL_COUNT" -gt 0 ]; then
        write_fail "$FAIL_COUNT required package(s) failed to install."
        exit 1
    fi
fi

echo ''
write_ok 'All Python dependencies ready.'

# ================================================================
#  STEP 6 - Check for Node.js (required by Claude Code CLI)
# ================================================================
echo ''
write_info 'Checking for Node.js...'

# Source nvm if available (may have been installed previously)
if [ -s "$HOME/.nvm/nvm.sh" ]; then
    export NVM_DIR="$HOME/.nvm"
    . "$NVM_DIR/nvm.sh"
fi

if command -v node >/dev/null 2>&1; then
    write_ok "Node.js $(node --version 2>&1)"
else
    write_miss 'Node.js not found (required for Claude Code CLI).'
    echo ''

    OS_TYPE="$(uname -s)"
    case "$OS_TYPE" in
        Linux*|Darwin*)
            echo '  Node.js can be installed via nvm (no root required):'
            echo ''
            echo '    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash'
            echo '    source ~/.nvm/nvm.sh'
            echo '    nvm install --lts'
            echo ''
            printf '  Install Node.js via nvm now? (Y/n) '
            read -r answer
            if echo "$answer" | grep -qiE '^y|^$'; then
                write_info 'Installing Node.js via nvm...'
                export NVM_DIR="$HOME/.nvm"
                curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash && \
                . "$NVM_DIR/nvm.sh" && \
                nvm install --lts && \
                write_ok "Node.js installed: $(node --version 2>&1)" || {
                    write_fail 'Node.js installation failed.'
                    echo '  Please install Node.js manually from https://nodejs.org/'
                    exit 1
                }
            else
                echo '  Please install Node.js and re-run this script.'
                exit 1
            fi
            ;;
        *)
            write_fail 'Unsupported OS for automatic Node.js install.'
            echo '  Please install Node.js from https://nodejs.org/'
            exit 1
            ;;
    esac
fi

# ================================================================
#  STEP 7 - Check for Claude Code CLI
# ================================================================
echo ''
write_info 'Checking for Claude Code CLI...'

# Ensure common CLI install locations are on PATH
export PATH="$HOME/.claude/local:$HOME/.local/bin:$PATH"

if command -v claude >/dev/null 2>&1; then
    write_ok "Claude Code CLI $(claude --version 2>&1)"
else
    write_miss 'Claude Code CLI not found.'
    echo ''
    echo '  Install via:'
    echo '    curl -fsSL https://claude.ai/install.sh | sh'
    echo ''
    printf '  Install Claude Code CLI now? (Y/n) '
    read -r answer
    if echo "$answer" | grep -qiE '^y|^$'; then
        write_info 'Installing Claude Code CLI...'
        # Ensure nvm node is on PATH for the installer
        if [ -s "$HOME/.nvm/nvm.sh" ]; then
            export NVM_DIR="$HOME/.nvm"
            . "$NVM_DIR/nvm.sh"
        fi
        curl -fsSL https://claude.ai/install.sh | sh && \
        write_ok 'Claude Code CLI installed successfully.' || {
            write_fail 'Claude Code CLI installation failed.'
            echo '  Please install manually: curl -fsSL https://claude.ai/install.sh | sh'
            exit 1
        }
        # Refresh PATH for the new install
        export PATH="$HOME/.claude/local:$HOME/.local/bin:$PATH"
    else
        echo '  Please install Claude Code CLI and re-run this script.'
        exit 1
    fi
fi

# ================================================================
#  STEP 8 - Claude authentication
# ================================================================
echo ''
write_info 'Checking Claude authentication...'

CLAUDE_AUTH_OK=false
if [ -n "${ANTHROPIC_API_KEY:-}" ]; then
    write_ok 'ANTHROPIC_API_KEY environment variable detected.'
    CLAUDE_AUTH_OK=true
elif "$PYTHON_EXE" -c "
import anthropic, sys
try:
    c = anthropic.Anthropic()
    sys.exit(0 if c.api_key else 1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
    write_ok 'Claude subscription credentials detected.'
    CLAUDE_AUTH_OK=true
fi

if [ "$CLAUDE_AUTH_OK" = false ]; then
    write_warn 'No Claude credentials detected.'
    echo ''
    echo '  Launching Claude Code CLI for authentication...'
    echo '  Complete the login in the prompt below, then the app will start.'
    echo ''
    # Ensure nvm node is on PATH
    if [ -s "$HOME/.nvm/nvm.sh" ]; then
        export NVM_DIR="$HOME/.nvm"
        . "$NVM_DIR/nvm.sh"
    fi
    claude || {
        write_warn 'Claude authentication may not have completed.'
        echo ''
        echo '  You can authenticate later by running: claude'
        echo '  Or set the ANTHROPIC_API_KEY environment variable.'
        echo ''
    }
fi

# ================================================================
#  STEP 9 - Run environment / config check
# ================================================================
echo ''
write_info 'Running environment check...'
"$PYTHON_EXE" "$SCRIPT_DIR/setup_check.py" --auto-check || exit 1

# ================================================================
#  STEP 10 - Check for updates
# ================================================================
echo ''
write_info 'Checking for updates...'
"$PYTHON_EXE" "$SCRIPT_DIR/update_check.py" || true

# ================================================================
#  STEP 11 - Create working directories & launch server
# ================================================================
echo ''
for dir in data data/logs data/openapi_specs data/mappings data/tokens config; do
    mkdir -p "$SCRIPT_DIR/$dir"
done

# Parse optional host/port arguments (--host X --port Y)
HOST_='0.0.0.0'
PORT_=5100

# Read defaults from config/app_config.yaml if it exists
CONFIG_FILE="$SCRIPT_DIR/config/app_config.yaml"
if [ -f "$CONFIG_FILE" ]; then
    _h=$(grep -E '^\s+host:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *"\{0,1\}\([^"]*\)"\{0,1\}/\1/' || true)
    _p=$(grep -E '^\s+port:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *\([0-9]*\).*/\1/' || true)
    [ -n "$_h" ] && HOST_="$_h"
    [ -n "$_p" ] && PORT_="$_p"
fi

# Command-line overrides
while [ $# -gt 0 ]; do
    case "$1" in
        --host) HOST_="$2"; shift 2 ;;
        --port) PORT_="$2"; shift 2 ;;
        *) shift ;;
    esac
done

SERVER_URL="http://${HOST_}:${PORT_}"
LOG_DIR="$SCRIPT_DIR/data/logs"
PID_FILE="$SCRIPT_DIR/data/.pid"

# ── Stop any previously running instance ──────────────────────────
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        write_info "Stopping previous server (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null || true
        sleep 1
        kill -0 "$OLD_PID" 2>/dev/null && kill -9 "$OLD_PID" 2>/dev/null || true
    fi
    rm -f "$PID_FILE"
fi

printf '  \033[1;36m================================================================\033[0m\n'
printf '  \033[1;36m Starting server: %s\033[0m\n' "$SERVER_URL"
printf '  \033[1;36m================================================================\033[0m\n'
echo ''

# Start the server in the background, redirect output to log file
nohup "$PYTHON_EXE" -m app.main --host "$HOST_" --port "$PORT_" >> "$LOG_DIR/app.log" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > "$PID_FILE"

# Wait for the server to become ready (up to 15 seconds)
READY=false
for i in $(seq 1 30); do
    sleep 0.5
    # Check server is still alive
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
        write_fail "Server process exited unexpectedly. Check data/logs/app.log"
        rm -f "$PID_FILE"
        exit 1
    fi
    # Try connecting
    if command -v curl >/dev/null 2>&1; then
        if curl -s -o /dev/null -w '' --max-time 1 "$SERVER_URL/" 2>/dev/null; then
            READY=true
            break
        fi
    elif "$PYTHON_EXE" -c "
import urllib.request, sys
try:
    urllib.request.urlopen('$SERVER_URL/', timeout=1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
        READY=true
        break
    fi
done

if [ "$READY" = true ]; then
    write_ok "Server is running at $SERVER_URL (PID $SERVER_PID)"
    write_info 'Opening browser...'
    # Open browser (cross-platform)
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$SERVER_URL" 2>/dev/null &
    elif command -v open >/dev/null 2>&1; then
        open "$SERVER_URL" 2>/dev/null &
    elif command -v sensible-browser >/dev/null 2>&1; then
        sensible-browser "$SERVER_URL" 2>/dev/null &
    else
        write_info "Open your browser to: $SERVER_URL"
    fi
else
    write_warn "Could not confirm server is ready -- opening browser anyway."
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$SERVER_URL" 2>/dev/null &
    elif command -v open >/dev/null 2>&1; then
        open "$SERVER_URL" 2>/dev/null &
    fi
fi

echo ''
write_ok "Server running in background (PID $SERVER_PID)."
echo "  View logs: tail -f $LOG_DIR/app.log"
echo "  Stop:      kill $SERVER_PID  (or use stop.sh)"
echo ''
