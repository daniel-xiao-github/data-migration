@echo off
REM restapi2adb - Status Script (Windows)

cd /d "%~dp0"

set APP_NAME=restapi2adb
set PID_FILE=data\.pid

REM ── Primary: use PID file ────────────────────────────────────────────
if not exist "%PID_FILE%" goto :fallback

set /p PID=<"%PID_FILE%"

tasklist /fi "PID eq %PID%" 2>nul | find "%PID%" >nul
if not errorlevel 1 (
    echo %APP_NAME% is RUNNING ^(PID: %PID%^)
    tasklist /fi "PID eq %PID%" /v 2>nul | findstr /r "[0-9]"
    exit /b 0
) else (
    echo PID file contains stale PID %PID%. Cleaning up.
    del "%PID_FILE%"
)

:fallback
REM ── Fallback: find by command line pattern ───────────────────────────
for /f "tokens=2 delims=," %%a in ('wmic process where "commandline like '%%app.main%%' and name like '%%python%%'" get processid /format:csv 2^>nul ^| findstr /r "[0-9]"') do (
    echo WARNING: PID file was missing/stale but %APP_NAME% is running ^(PID: %%a^).
    echo %%a> "%PID_FILE%"
    tasklist /fi "PID eq %%a" /v 2>nul | findstr /r "[0-9]"
    exit /b 0
)

echo %APP_NAME% is NOT running.
exit /b 1
