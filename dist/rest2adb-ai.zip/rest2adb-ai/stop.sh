#!/bin/bash
# restapi2adb – Stop Script (Linux/macOS)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="restapi2adb"
PID_FILE="data/.pid"
LOG_FILE="data/logs/service.log"
PROCESS_PATTERN="python.*app\.main"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [STOP] $1" | tee -a "$LOG_FILE"
}

# Kill a process and all its children, then wait for exit
kill_process_tree() {
    local pid=$1
    local signal=${2:-SIGTERM}

    # Kill children first (e.g. werkzeug reloader child)
    local children
    children=$(pgrep -P "$pid" 2>/dev/null)
    for child in $children; do
        kill_process_tree "$child" "$signal"
    done
    kill -"$signal" "$pid" 2>/dev/null
}

# Wait for a PID to exit, up to a timeout
wait_for_exit() {
    local pid=$1
    local timeout=${2:-10}
    for _ in $(seq 1 "$timeout"); do
        if ! kill -0 "$pid" 2>/dev/null; then
            return 0
        fi
        sleep 1
    done
    return 1
}

# Try to stop a discovered PID (SIGTERM then SIGKILL)
stop_pid() {
    local pid=$1
    log "Stopping $APP_NAME (PID: $pid)..."

    kill_process_tree "$pid" SIGTERM

    if wait_for_exit "$pid" 10; then
        log "$APP_NAME stopped gracefully."
        echo "$APP_NAME stopped."
        return 0
    fi

    log "Graceful shutdown timed out. Force-killing PID $pid..."
    kill_process_tree "$pid" SIGKILL
    sleep 1
    if ! kill -0 "$pid" 2>/dev/null; then
        log "$APP_NAME force-stopped."
        echo "$APP_NAME force-stopped."
        return 0
    fi

    log "ERROR: Failed to stop PID $pid."
    return 1
}

# ── Primary: use PID file ────────────────────────────────────────────
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        stop_pid "$PID"
        rm -f "$PID_FILE"
        exit 0
    else
        log "PID $PID from PID file is not running."
        rm -f "$PID_FILE"
    fi
fi

# ── Fallback: find by process command pattern ────────────────────────
FOUND_PID=$(pgrep -f "$PROCESS_PATTERN" 2>/dev/null | head -1)
if [ -n "$FOUND_PID" ]; then
    log "PID file was stale. Found $APP_NAME running as PID $FOUND_PID."
    stop_pid "$FOUND_PID"
    rm -f "$PID_FILE"
    exit 0
fi

log "$APP_NAME does not appear to be running."
echo "$APP_NAME is not running."
exit 0
