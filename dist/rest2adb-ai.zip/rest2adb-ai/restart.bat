@echo off
REM restapi2adb - Restart Script (Windows)

cd /d "%~dp0"

echo Restarting restapi2adb...

call stop.bat
timeout /t 2 /nobreak >nul
call start.bat %*
