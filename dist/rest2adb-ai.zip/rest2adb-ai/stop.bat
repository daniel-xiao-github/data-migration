@echo off
REM restapi2adb - Stop Script (Windows)

cd /d "%~dp0"

set APP_NAME=restapi2adb
set PID_FILE=data\.pid

REM ── Primary: use PID file ────────────────────────────────────────────
if not exist "%PID_FILE%" goto :fallback

set /p PID=<"%PID_FILE%"

REM Check if process is alive
tasklist /fi "PID eq %PID%" 2>nul | find "%PID%" >nul
if errorlevel 1 (
    echo PID %PID% from PID file is not running. Cleaning up.
    del "%PID_FILE%"
    goto :fallback
)

echo Stopping %APP_NAME% ^(PID: %PID%^)...
REM /T kills the process tree (parent + all children)
taskkill /PID %PID% /T /F >nul 2>&1

if not errorlevel 1 (
    del "%PID_FILE%"
    echo %APP_NAME% stopped.
    exit /b 0
) else (
    echo WARNING: taskkill reported an error for PID %PID%.
    del "%PID_FILE%"
)

:fallback
REM ── Fallback: find by command line pattern ───────────────────────────
for /f "tokens=2 delims=," %%a in ('wmic process where "commandline like '%%app.main%%' and name like '%%python%%'" get processid /format:csv 2^>nul ^| findstr /r "[0-9]"') do (
    echo PID file was stale. Found %APP_NAME% running as PID %%a.
    taskkill /PID %%a /T /F >nul 2>&1
    if not errorlevel 1 (
        echo %APP_NAME% stopped.
        del "%PID_FILE%" 2>nul
        exit /b 0
    )
)

echo %APP_NAME% is not running.
exit /b 0
