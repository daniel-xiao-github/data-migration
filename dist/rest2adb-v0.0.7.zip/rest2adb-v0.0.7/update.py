#!/usr/bin/env python3
"""
REST → ADB Migration Workbench — Self-Updater

Checks a public GitHub repository for newer releases, downloads the
zip asset, and replaces application files while preserving user data
(config edits, venv, data/, logs/, encryption keys).

Usage:
    python update.py                        # uses default repo
    python update.py --repo owner/repo      # custom repo
    python update.py --check                # check only, don't install
"""
import sys
import os
import json
import shutil
import tempfile
import zipfile
import argparse
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

# --------------- constants ---------------

APP_DIR = Path(__file__).resolve().parent
VERSION_FILE = APP_DIR / "VERSION"
DEFAULT_REPO = "daniel-xiao-github/data-migration"
GITHUB_API = "https://api.github.com"

# Files/dirs that belong to the user and must NOT be overwritten
PRESERVE = {
    "venv",
    "data",
    "logs",
    "config/default.yaml",
    "config/.encryption_key",
}


# --------------- helpers ---------------

def info(msg):
    print(f"\033[1;34m[INFO]\033[0m  {msg}")

def ok(msg):
    print(f"\033[1;32m[OK]\033[0m    {msg}")

def warn(msg):
    print(f"\033[1;33m[WARN]\033[0m  {msg}")

def fail(msg):
    print(f"\033[1;31m[FAIL]\033[0m  {msg}")
    sys.exit(1)


def current_version() -> str:
    if VERSION_FILE.exists():
        return VERSION_FILE.read_text().strip()
    return "0.0.0"


def parse_version(v: str) -> tuple:
    """Parse 'x.y.z' into a comparable tuple of ints."""
    v = v.lstrip("vV")
    parts = []
    for p in v.split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def github_api(path: str, repo: str) -> dict:
    """GET a JSON endpoint from the GitHub API."""
    url = f"{GITHUB_API}/repos/{repo}/{path}"
    req = Request(url, headers={
        "Accept": "application/vnd.github+json",
        "User-Agent": "rest2adb-updater",
    })
    try:
        with urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except HTTPError as e:
        if e.code == 404:
            fail(f"Repository '{repo}' not found or has no releases.")
        fail(f"GitHub API error: {e.code} {e.reason}")
    except URLError as e:
        fail(f"Network error: {e.reason}\n        Check your internet connection.")


def get_latest_release(repo: str) -> dict | None:
    """Fetch the latest release from GitHub. Returns None if no releases."""
    try:
        return github_api("releases/latest", repo)
    except SystemExit:
        return None


def get_latest_tag(repo: str) -> dict | None:
    """Fallback: fetch the most recent tag if there are no releases."""
    tags = github_api("tags", repo)
    if not tags:
        return None
    return tags[0]


def find_zip_url(release: dict, repo: str) -> str:
    """Find the deployment zip asset URL, or fall back to the dist/ directory."""
    # First look for a rest2adb-v*.zip asset in the release
    for asset in release.get("assets", []):
        name = asset.get("name", "")
        if name.startswith("rest2adb-v") and name.endswith(".zip"):
            return asset["browser_download_url"]

    # Fall back to the dist/ directory in the repo
    tag = release.get("tag_name") or release.get("name", "")
    ver = tag.lstrip("vV") if tag else ""
    if ver:
        return f"https://raw.githubusercontent.com/{repo}/main/dist/rest2adb-v{ver}.zip"

    fail("Could not determine download URL for the latest release.")


def download(url: str, dest: Path) -> None:
    """Download a file with progress indication."""
    info(f"Downloading {url} ...")
    req = Request(url, headers={"User-Agent": "rest2adb-updater"})
    try:
        with urlopen(req, timeout=120) as resp:
            total = resp.headers.get("Content-Length")
            total = int(total) if total else None
            downloaded = 0
            with open(dest, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = downloaded * 100 // total
                        print(f"\r        {downloaded // 1024}KB / {total // 1024}KB ({pct}%)", end="", flush=True)
                    else:
                        print(f"\r        {downloaded // 1024}KB downloaded", end="", flush=True)
            print()
    except (HTTPError, URLError) as e:
        fail(f"Download failed: {e}")


def find_app_root(extract_dir: Path) -> Path:
    """Locate the application root inside the extracted zip.

    The zip may contain either:
      rest2adb-v0.0.2/app/...       (deployment zip)
      repo-name-tag/rest2adb/app/...  (GitHub source zip)
    """
    # Deployment zip: top-level dir contains app/ directly
    for child in extract_dir.iterdir():
        if child.is_dir() and (child / "app").is_dir():
            return child

    # GitHub source zip: look one level deeper for rest2adb/app/
    for child in extract_dir.iterdir():
        if child.is_dir():
            nested = child / "rest2adb"
            if nested.is_dir() and (nested / "app").is_dir():
                return nested

    fail("Downloaded zip does not contain a recognisable application structure.")


def should_preserve(rel_path: str) -> bool:
    """Return True if this path should not be overwritten."""
    for pattern in PRESERVE:
        if rel_path == pattern or rel_path.startswith(pattern + "/") or rel_path.startswith(pattern + os.sep):
            return True
    return False


def apply_update(source_dir: Path, target_dir: Path) -> tuple[int, int]:
    """Copy new files from source_dir into target_dir, preserving user data.

    Returns (updated_count, skipped_count).
    """
    updated = 0
    skipped = 0

    for src_path in source_dir.rglob("*"):
        if not src_path.is_file():
            continue
        rel = src_path.relative_to(source_dir).as_posix()

        if should_preserve(rel):
            dst = target_dir / rel
            if dst.exists():
                skipped += 1
                continue

        dst = target_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_path, dst)
        updated += 1

    return updated, skipped


# --------------- main ---------------

def main():
    parser = argparse.ArgumentParser(description="Update REST → ADB Migration Workbench")
    parser.add_argument("--repo", default=DEFAULT_REPO,
                        help=f"GitHub repo in owner/name format (default: {DEFAULT_REPO})")
    parser.add_argument("--check", action="store_true",
                        help="Only check for updates; do not install")
    args = parser.parse_args()

    cur = current_version()
    info(f"Current version: v{cur}")
    info(f"Checking for updates from github.com/{args.repo} ...")

    # Try releases first, then tags
    release = get_latest_release(args.repo)
    if release:
        remote_ver = (release.get("tag_name") or "").lstrip("vV")
        release_name = release.get("name") or release.get("tag_name") or ""
    else:
        tag = get_latest_tag(args.repo)
        if not tag:
            ok("No releases or tags found. You are up to date.")
            return
        remote_ver = tag["name"].lstrip("vV")
        release_name = tag["name"]
        release = {"tag_name": tag["name"], "assets": []}

    if not remote_ver:
        fail("Could not determine the remote version.")

    info(f"Latest available: v{remote_ver}  ({release_name})")

    if parse_version(remote_ver) <= parse_version(cur):
        ok(f"You are already on the latest version (v{cur}).")
        return

    print()
    print("============================================================")
    print(f"  Update available: v{cur}  →  v{remote_ver}")
    print()
    print("  This will update application files (code, UI, scripts).")
    print("  Your configuration, data, and virtual environment will")
    print("  be preserved.")
    print("============================================================")
    print()

    if args.check:
        info("Run without --check to install this update.")
        return

    reply = input("  Proceed with update? [Y/n] ").strip()
    if reply.lower() in ("n", "no"):
        info("Update cancelled.")
        return

    print()

    # Download
    zip_url = find_zip_url(release, args.repo)
    tmp_dir = Path(tempfile.mkdtemp(prefix="rest2adb_update_"))
    zip_path = tmp_dir / "update.zip"

    try:
        download(zip_url, zip_path)

        # Extract
        info("Extracting ...")
        extract_dir = tmp_dir / "extracted"
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # Find app root in extracted content
        source_dir = find_app_root(extract_dir)

        # Back up current VERSION in case rollback is needed
        backup_dir = tmp_dir / "backup"
        backup_dir.mkdir()
        if VERSION_FILE.exists():
            shutil.copy2(VERSION_FILE, backup_dir / "VERSION")

        # Apply
        info("Applying update ...")
        updated, skipped = apply_update(source_dir, APP_DIR)

        ok(f"Update complete!  {updated} file(s) updated, {skipped} user file(s) preserved.")

        new_ver = current_version()
        print()
        print("============================================================")
        print(f"  Updated to v{new_ver}")
        print()
        print("  Please restart the server for changes to take effect:")
        if sys.platform == "win32":
            print("    start.bat")
        else:
            print("    ./start.sh")
        print("============================================================")

    except Exception as e:
        fail(f"Update failed: {e}")
    finally:
        # Clean up temp files
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
