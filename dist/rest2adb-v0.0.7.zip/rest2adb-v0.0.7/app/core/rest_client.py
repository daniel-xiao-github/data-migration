"""REST API client with pagination, retry, and auth support."""
from __future__ import annotations
import logging
import time
import json
from typing import Any, Iterator
from urllib.parse import urljoin, urlencode, urlparse, parse_qs

log = logging.getLogger("rest2adb.rest_client")

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:
    requests = None

try:
    from jsonpath_ng import parse as jp_parse
except ImportError:
    jp_parse = None


class RestClient:
    """HTTP client with pagination, retry, and auth for REST/GraphQL sources."""

    def __init__(self, connection: dict, oauth_manager=None):
        self.connection = connection
        self.oauth_manager = oauth_manager
        self.base_url = connection.get("base_url", "").rstrip("/")
        self.auth_type = connection.get("auth_type", "none")
        self.auth_config = connection.get("auth_config", {})
        self.default_headers = dict(connection.get("headers", {}))
        self.timeout = connection.get("timeout_seconds", 30)
        self.verify_ssl = connection.get("verify_ssl", True)
        self.session = self._build_session()

    def _build_session(self) -> "requests.Session":
        s = requests.Session()
        retry = Retry(total=3, backoff_factor=1, status_forcelist=[429, 500, 502, 503, 504])
        adapter = HTTPAdapter(max_retries=retry)
        s.mount("http://", adapter)
        s.mount("https://", adapter)
        s.headers.update(self.default_headers)
        s.headers.setdefault("Accept", "application/json")
        s.verify = self.verify_ssl
        self._apply_auth(s)
        return s

    def _apply_auth(self, session: "requests.Session") -> None:
        if self.auth_type == "api_key":
            key = self.auth_config.get("key", "")
            value = self.auth_config.get("value", "")
            location = self.auth_config.get("location", "header")
            if location == "header":
                session.headers[key] = value
        elif self.auth_type == "basic":
            session.auth = (
                self.auth_config.get("username", ""),
                self.auth_config.get("password", ""),
            )
        elif self.auth_type == "bearer":
            token = self.auth_config.get("token", "")
            session.headers["Authorization"] = f"Bearer {token}"
        elif self.auth_type in ("oauth2_client_credentials", "oauth2_authorization_code"):
            if self.oauth_manager:
                conn_id = self.connection.get("id", "")
                oauth_cfg = self.connection.get("oauth2_config")
                token = self.oauth_manager.get_valid_token(conn_id, oauth_cfg)
                if token:
                    session.headers["Authorization"] = f"Bearer {token}"

    def refresh_auth(self) -> None:
        self._apply_auth(self.session)

    def get(self, path: str, params: dict | None = None,
            headers: dict | None = None) -> "requests.Response":
        url = self._build_url(path)
        return self.session.get(url, params=params, headers=headers, timeout=self.timeout)

    def post(self, path: str, json_body: dict | None = None,
             params: dict | None = None, headers: dict | None = None) -> "requests.Response":
        url = self._build_url(path)
        return self.session.post(url, json=json_body, params=params,
                                 headers=headers, timeout=self.timeout)

    def test_connection(self) -> dict:
        """Test if the REST API is reachable."""
        start = time.time()
        try:
            resp = self.get("/")
            latency = (time.time() - start) * 1000
            return {
                "success": resp.status_code < 500,
                "status_code": resp.status_code,
                "latency_ms": round(latency, 2),
                "message": f"HTTP {resp.status_code}",
            }
        except Exception as e:
            latency = (time.time() - start) * 1000
            return {
                "success": False,
                "status_code": 0,
                "latency_ms": round(latency, 2),
                "message": str(e),
            }

    def fetch_all_pages(self, path: str, pagination: dict | None = None,
                        params: dict | None = None, headers: dict | None = None,
                        data_root: str | None = None,
                        start_cursor: str | None = None) -> Iterator[list[dict]]:
        """Yield batches of records, handling pagination automatically."""
        pagination = pagination or {}
        pag_type = pagination.get("type", "")
        page_size = pagination.get("page_size", 100)
        param_names = pagination.get("param_names", {})
        params = dict(params or {})

        if pag_type == "offset_limit":
            offset_key = param_names.get("offset", "offset")
            limit_key = param_names.get("limit", "limit")
            offset = int(start_cursor) if start_cursor else 0
            params[limit_key] = page_size
            while True:
                params[offset_key] = offset
                resp = self.get(path, params=params, headers=headers)
                resp.raise_for_status()
                data = self._extract_data(resp.json(), data_root)
                if not data:
                    break
                yield data
                if len(data) < page_size:
                    break
                offset += len(data)

        elif pag_type == "page_number":
            page_key = param_names.get("page", "page")
            size_key = param_names.get("size", "per_page")
            page = int(start_cursor) if start_cursor else 1
            params[size_key] = page_size
            while True:
                params[page_key] = page
                resp = self.get(path, params=params, headers=headers)
                resp.raise_for_status()
                data = self._extract_data(resp.json(), data_root)
                if not data:
                    break
                yield data
                if len(data) < page_size:
                    break
                page += 1

        elif pag_type == "cursor":
            cursor_key = param_names.get("cursor", "cursor")
            cursor_resp_key = param_names.get("cursor_response", "next_cursor")
            cursor = start_cursor
            params[param_names.get("limit", "limit")] = page_size
            while True:
                if cursor:
                    params[cursor_key] = cursor
                resp = self.get(path, params=params, headers=headers)
                resp.raise_for_status()
                body = resp.json()
                data = self._extract_data(body, data_root)
                if not data:
                    break
                yield data
                cursor = self._get_nested(body, cursor_resp_key)
                if not cursor:
                    break

        elif pag_type == "link_header":
            url = self._build_url(path)
            while url:
                resp = self.session.get(url, params=params, headers=headers, timeout=self.timeout)
                resp.raise_for_status()
                data = self._extract_data(resp.json(), data_root)
                if not data:
                    break
                yield data
                params = {}
                link = resp.headers.get("Link", "")
                url = self._parse_link_next(link)

        elif pag_type == "next_url":
            next_key = param_names.get("next_url", "next")
            resp = self.get(path, params=params, headers=headers)
            resp.raise_for_status()
            body = resp.json()
            data = self._extract_data(body, data_root)
            if data:
                yield data
            while True:
                next_url = self._get_nested(body, next_key)
                if not next_url:
                    break
                resp = self.session.get(next_url, headers=headers, timeout=self.timeout)
                resp.raise_for_status()
                body = resp.json()
                data = self._extract_data(body, data_root)
                if not data:
                    break
                yield data
        else:
            resp = self.get(path, params=params, headers=headers)
            resp.raise_for_status()
            body = resp.json()
            data = self._extract_data(body, data_root)
            if data:
                yield data

    def fetch_graphql(self, url: str, query: str, variables: dict | None = None,
                      data_root: str = "data") -> dict:
        body = {"query": query}
        if variables:
            body["variables"] = variables
        resp = self.session.post(url, json=body, timeout=self.timeout)
        resp.raise_for_status()
        return self._extract_data(resp.json(), data_root)

    def fetch_post_endpoint(self, url: str, body_template: dict,
                            data_root: str = "$.data") -> list[dict]:
        resp = self.session.post(url, json=body_template, timeout=self.timeout)
        resp.raise_for_status()
        return self._extract_data(resp.json(), data_root)

    def _build_url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        return f"{self.base_url}/{path.lstrip('/')}"

    def _extract_data(self, body: Any, data_root: str | None) -> Any:
        if not data_root:
            if isinstance(body, list):
                return body
            if isinstance(body, dict):
                for key in ("data", "results", "items", "records", "rows", "content"):
                    if key in body and isinstance(body[key], list):
                        return body[key]
            return body if isinstance(body, list) else [body] if body else []

        if data_root.startswith("$.") and jp_parse:
            expr = jp_parse(data_root)
            matches = expr.find(body)
            if matches:
                result = matches[0].value
                return result if isinstance(result, list) else [result]
            return []

        return self._get_nested(body, data_root)

    def _get_nested(self, obj: dict, path: str) -> Any:
        if not path:
            return obj
        path = path.lstrip("$.")
        parts = path.split(".")
        current = obj
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    @staticmethod
    def _parse_link_next(link_header: str) -> str | None:
        if not link_header:
            return None
        for part in link_header.split(","):
            part = part.strip()
            if 'rel="next"' in part:
                url = part.split(";")[0].strip().strip("<>")
                return url
        return None
