"""Log streaming, event SSE, health, update-check, and update-apply API routes."""
from __future__ import annotations
import os
import json
import shutil
import tempfile
import time
import zipfile
from collections import deque
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError
from flask import Blueprint, request, jsonify, Response, current_app

bp = Blueprint("logs", __name__, url_prefix="/api")

# In-memory event buffer for SSE
_events: deque = deque(maxlen=1000)


def push_event(event_type: str, data: dict) -> None:
    """Push an event to the SSE buffer (call from anywhere)."""
    _events.append({
        "type": event_type,
        "data": data,
        "time": time.time(),
    })


@bp.route("/logs/stream", methods=["GET"])
def stream_logs():
    """SSE endpoint for real-time log streaming."""
    def generate():
        last_idx = len(_events)
        yield "data: {\"type\": \"connected\"}\n\n"
        while True:
            current_len = len(_events)
            if current_len > last_idx:
                for evt in list(_events)[last_idx:]:
                    yield f"event: {evt['type']}\n"
                    yield f"data: {json.dumps(evt['data'])}\n\n"
                last_idx = current_len
            time.sleep(1)

    return Response(generate(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


@bp.route("/logs/events", methods=["GET"])
def get_events():
    """Get recent events (non-streaming fallback)."""
    limit = request.args.get("limit", 50, type=int)
    events = list(_events)[-limit:]
    return jsonify(events)


@bp.route("/logs/file", methods=["GET"])
def get_log_file():
    """Get the last N lines of the log file."""
    lines = request.args.get("lines", 100, type=int)
    log_path = current_app.config.get("LOG_FILE", "logs/migration.log")
    project_root = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    full_path = os.path.join(project_root, log_path)

    if not os.path.exists(full_path):
        return jsonify({"lines": [], "file": full_path})

    with open(full_path, "r") as f:
        all_lines = f.readlines()

    tail = all_lines[-lines:]
    return jsonify({"lines": [l.rstrip() for l in tail], "file": full_path})


@bp.route("/logs/clear", methods=["POST"])
def clear_events():
    """Clear the in-memory event buffer."""
    _events.clear()
    return jsonify({"status": "cleared"})


@bp.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "version": _get_local_version()})


@bp.route("/update/check", methods=["GET"])
def check_update():
    """Check GitHub for a newer version."""
    repo = request.args.get("repo", "daniel-xiao-github/data-migration")
    local_ver = _get_local_version()

    try:
        release = _github_latest_release(repo)
    except Exception as e:
        return jsonify({"error": str(e)}), 502

    if not release:
        return jsonify({
            "update_available": False,
            "current_version": local_ver,
            "message": "No releases found.",
        })

    remote_ver = (release.get("tag_name") or "").lstrip("vV")
    release_name = release.get("name") or release.get("tag_name") or remote_ver
    html_url = release.get("html_url") or ""
    body = release.get("body") or ""

    update_available = _parse_version(remote_ver) > _parse_version(local_ver)

    return jsonify({
        "update_available": update_available,
        "current_version": local_ver,
        "latest_version": remote_ver,
        "release_name": release_name,
        "release_url": html_url,
        "release_notes": body,
    })


def _get_local_version() -> str:
    project_root = os.path.dirname(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))
    version_file = os.path.join(project_root, "VERSION")
    if os.path.exists(version_file):
        with open(version_file) as f:
            return f.read().strip()
    return "0.0.0"


def _parse_version(v: str) -> tuple:
    parts = []
    for p in v.lstrip("vV").split("."):
        try:
            parts.append(int(p))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _github_latest_release(repo: str) -> dict | None:
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    req = Request(url, headers={
        "Accept": "application/vnd.github+json",
        "User-Agent": "rest2adb-updater",
    })
    try:
        with urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except HTTPError as e:
        if e.code == 404:
            return None
        raise
    except URLError as e:
        raise RuntimeError(f"Network error: {e.reason}")


# ── Update apply ────────────────────────────────────────────────────

# Files/dirs that belong to the user and must NOT be overwritten
_PRESERVE = {
    "venv", "data", "logs",
    "config/default.yaml", "config/.encryption_key",
}


@bp.route("/update/apply", methods=["POST"])
def apply_update():
    """Download and apply the latest release from GitHub.

    Streams newline-delimited JSON progress events so the UI can show
    real-time feedback.
    """
    repo = request.args.get("repo", "daniel-xiao-github/data-migration")

    def generate():
        def emit(stage, message, **extra):
            obj = {"stage": stage, "message": message, **extra}
            return json.dumps(obj) + "\n"

        # 1. Check
        yield emit("checking", "Checking for updates...")
        try:
            release = _github_latest_release(repo)
        except Exception as e:
            yield emit("error", f"Failed to check GitHub: {e}")
            return

        if not release:
            yield emit("error", "No releases found on GitHub.")
            return

        remote_ver = (release.get("tag_name") or "").lstrip("vV")
        local_ver = _get_local_version()

        if _parse_version(remote_ver) <= _parse_version(local_ver):
            yield emit("up_to_date", f"Already on the latest version (v{local_ver}).")
            return

        yield emit("downloading", f"Downloading v{remote_ver}...")

        # 2. Find zip URL
        zip_url = None
        for asset in release.get("assets", []):
            name = asset.get("name", "")
            if name.startswith("rest2adb-v") and name.endswith(".zip"):
                zip_url = asset["browser_download_url"]
                break
        if not zip_url:
            tag = release.get("tag_name") or ""
            ver = tag.lstrip("vV")
            if ver:
                zip_url = f"https://raw.githubusercontent.com/{repo}/main/dist/rest2adb-v{ver}.zip"
        if not zip_url:
            yield emit("error", "Could not determine download URL.")
            return

        # 3. Download
        tmp_dir = Path(tempfile.mkdtemp(prefix="rest2adb_update_"))
        zip_path = tmp_dir / "update.zip"
        try:
            req = Request(zip_url, headers={"User-Agent": "rest2adb-updater"})
            with urlopen(req, timeout=120) as resp:
                with open(zip_path, "wb") as f:
                    while True:
                        chunk = resp.read(65536)
                        if not chunk:
                            break
                        f.write(chunk)

            yield emit("extracting", "Extracting update...")

            # 4. Extract
            extract_dir = tmp_dir / "extracted"
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(extract_dir)

            # 5. Find app root
            source_dir = _find_app_root(extract_dir)
            if not source_dir:
                yield emit("error", "Downloaded zip has unrecognised structure.")
                return

            yield emit("applying", "Applying update (preserving your config & data)...")

            # 6. Apply
            app_dir = Path(os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.abspath(__file__)))))
            updated, skipped = _apply_files(source_dir, app_dir)

            new_ver = _get_local_version()
            yield emit("done",
                        f"Updated to v{new_ver}. {updated} file(s) updated, "
                        f"{skipped} user file(s) preserved.",
                        version=new_ver)

        except Exception as e:
            yield emit("error", f"Update failed: {e}")
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    return Response(generate(), mimetype="application/x-ndjson",
                    headers={"Cache-Control": "no-cache",
                             "X-Accel-Buffering": "no"})


def _find_app_root(extract_dir: Path) -> Path | None:
    """Locate the application root inside the extracted zip."""
    for child in extract_dir.iterdir():
        if child.is_dir() and (child / "app").is_dir():
            return child
    for child in extract_dir.iterdir():
        if child.is_dir():
            nested = child / "rest2adb"
            if nested.is_dir() and (nested / "app").is_dir():
                return nested
    return None


def _should_preserve(rel_path: str) -> bool:
    for pattern in _PRESERVE:
        if rel_path == pattern or rel_path.startswith(pattern + "/") or rel_path.startswith(pattern + os.sep):
            return True
    return False


def _apply_files(source_dir: Path, target_dir: Path) -> tuple[int, int]:
    updated = skipped = 0
    for src_path in source_dir.rglob("*"):
        if not src_path.is_file():
            continue
        rel = src_path.relative_to(source_dir).as_posix()
        if _should_preserve(rel):
            dst = target_dir / rel
            if dst.exists():
                skipped += 1
                continue
        dst = target_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_path, dst)
        updated += 1
    return updated, skipped


@bp.route("/restart", methods=["POST"])
def restart_server():
    """Restart the server by spawning a new process and exiting the current one.

    Uses a small helper script so that the old process fully exits before
    the new one tries to bind the port.
    """
    import sys
    import subprocess
    import threading
    from app.server import _persist_store

    # Persist store before restarting
    _persist_store(current_app.config.get("STORE", {}))

    app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    pid_file = os.path.join(app_dir, ".server.pid")
    log_dir = os.path.join(app_dir, "logs")
    log_file = os.path.join(log_dir, "server.log")
    main_py = os.path.join(app_dir, "main.py")
    current_pid = os.getpid()

    # Inline restart helper: wait for old process to exit, then start new one
    helper_code = f"""
import time, os, subprocess, sys, signal
# Kill old server
try:
    os.kill({current_pid}, signal.SIGTERM)
except OSError:
    pass
# Wait for old process to exit (up to 5 seconds)
for _ in range(50):
    try:
        os.kill({current_pid}, 0)
        time.sleep(0.1)
    except OSError:
        break
time.sleep(0.3)
# Start new server
log = open({log_file!r}, "a")
proc = subprocess.Popen(
    [sys.executable, {main_py!r}],
    stdout=log, stderr=log,
    start_new_session=True,
)
log.close()
with open({pid_file!r}, "w") as f:
    f.write(str(proc.pid))
"""

    def _do_restart():
        time.sleep(0.3)  # let the HTTP response flush
        os.makedirs(log_dir, exist_ok=True)
        subprocess.Popen(
            [sys.executable, "-c", helper_code],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    threading.Thread(target=_do_restart, daemon=True).start()
    return jsonify({"status": "restarting"})


@bp.route("/config", methods=["GET"])
def get_config():
    """Return non-sensitive configuration."""
    cfg = current_app.config.get("APP_CONFIG", {})
    return jsonify({
        "migration": cfg.get("migration", {}),
        "batch": cfg.get("batch", {}),
        "validation": cfg.get("validation", {}),
    })
