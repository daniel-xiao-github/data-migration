from __future__ import annotations

from enum import Enum


class AuthType(str, Enum):
    NONE = "none"
    API_KEY = "api_key"
    BASIC = "basic"
    BEARER = "bearer"
    OAUTH2_CLIENT_CREDS = "oauth2_client_credentials"
    OAUTH2_AUTH_CODE = "oauth2_authorization_code"


class SourceType(str, Enum):
    REST_GET = "rest_get"
    REST_POST = "rest_post"
    GRAPHQL = "graphql"


class TargetType(str, Enum):
    ORACLE_ADB = "oracle_adb"
    POSTGRESQL = "postgresql"
    MYSQL = "mysql"


class JobStatus(str, Enum):
    CREATED = "CREATED"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class EndpointStatus(str, Enum):
    PENDING = "PENDING"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class BatchStatus(str, Enum):
    CREATED = "CREATED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    PARTIAL_FAILURE = "PARTIAL_FAILURE"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class PaginationType(str, Enum):
    OFFSET_LIMIT = "offset_limit"
    PAGE_NUMBER = "page_number"
    CURSOR = "cursor"
    LINK_HEADER = "link_header"
    NEXT_URL = "next_url"


class SyncMode(str, Enum):
    FULL = "full"
    INCREMENTAL = "incremental"
    APPEND_ONLY = "append_only"


class WriteMode(str, Enum):
    INSERT = "insert"
    UPSERT = "upsert"
    TRUNCATE_RELOAD = "truncate_reload"


class TransformType(str, Enum):
    RENAME = "rename"
    TYPECAST = "typecast"
    FLATTEN = "flatten"
    EXPRESSION = "expression"
    LOOKUP = "lookup"
    CONSTANT = "constant"
    FILTER_ROW = "filter_row"


class RuleType(str, Enum):
    REQUIRED = "required"
    REGEX = "regex"
    RANGE = "range"
    LENGTH = "length"
    ENUM = "enum"
    TYPE_CHECK = "type_check"
    EXPRESSION = "expression"
    UNIQUE = "unique"
    DATE_FORMAT = "date_format"


class Severity(str, Enum):
    ERROR = "error"
    WARNING = "warning"


class AdbConnectMethod(str, Enum):
    WALLET = "wallet"
    BASIC = "basic"
