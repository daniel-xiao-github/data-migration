"""Auto-map source fields to target columns and apply transformations."""
from __future__ import annotations
import json
import logging
import re
from datetime import datetime
from difflib import SequenceMatcher
from typing import Any

log = logging.getLogger("rest2adb.mapping")

try:
    from thefuzz import fuzz as _fuzz
except ImportError:
    _fuzz = None


class MappingEngine:
    """Automatically maps source JSON fields to database target columns
    and applies configured transformations during row processing."""

    # ------------------------------------------------------------------ #
    #  Public API                                                         #
    # ------------------------------------------------------------------ #

    def auto_map(
        self,
        source_fields: list[dict],
        target_columns: list[dict],
    ) -> list[dict]:
        """Return a list of mapping dicts that pair every source field to
        the best-matching target column.

        Each source field dict is expected to have at least ``name`` (str)
        and optionally ``type`` (str).  Each target column dict is expected
        to have at least ``name`` (str) and optionally ``type`` (str).

        Matching proceeds in four phases with decreasing confidence:

        1. **Exact** (case-insensitive)  – confidence 1.0
        2. **Normalized** (strip separators, flatten camelCase) – confidence 0.9
        3. **Fuzzy** (Levenshtein / ratio ≥ 80) – confidence = ratio / 100
        4. **Type-compatible suggestion** for remaining unmatched – confidence 0.5

        Returns a list of dicts shaped like ``FieldMapping``:
        ``{source_path, target_column, transform, confidence, is_manual}``
        """
        mappings: list[dict] = []
        matched_targets: set[str] = set()
        unmatched_sources: list[dict] = []

        # Build type lookup from source fields
        src_type_map = {sf["name"]: sf.get("type", "string") for sf in source_fields}

        # Build lookup structures for target columns
        target_by_lower: dict[str, dict] = {}
        target_by_norm: dict[str, dict] = {}
        for tc in target_columns:
            target_by_lower[tc["name"].lower()] = tc
            target_by_norm[self._normalize(tc["name"])] = tc

        # Phase 1 – Exact (case-insensitive) match
        for sf in source_fields:
            src_lower = sf["name"].lower()
            if src_lower in target_by_lower and target_by_lower[src_lower]["name"] not in matched_targets:
                tc = target_by_lower[src_lower]
                mappings.append(self._make_mapping(
                    sf["name"], tc["name"], confidence=1.0,
                    source_type=src_type_map.get(sf["name"], "string")))
                matched_targets.add(tc["name"])
            else:
                unmatched_sources.append(sf)

        # Phase 2 – Normalized match
        still_unmatched: list[dict] = []
        for sf in unmatched_sources:
            src_norm = self._normalize(sf["name"])
            if src_norm in target_by_norm and target_by_norm[src_norm]["name"] not in matched_targets:
                tc = target_by_norm[src_norm]
                mappings.append(self._make_mapping(
                    sf["name"], tc["name"], confidence=0.9,
                    source_type=src_type_map.get(sf["name"], "string")))
                matched_targets.add(tc["name"])
            else:
                still_unmatched.append(sf)
        unmatched_sources = still_unmatched

        # Phase 3 – Fuzzy match
        still_unmatched = []
        available_targets = [tc for tc in target_columns if tc["name"] not in matched_targets]
        for sf in unmatched_sources:
            best_target: dict | None = None
            best_score: float = 0.0

            for tc in available_targets:
                if tc["name"] in matched_targets:
                    continue
                score = self._fuzzy_score(sf["name"], tc["name"])
                if score > best_score:
                    best_score = score
                    best_target = tc

            if best_target is not None and best_score >= 0.80:
                mappings.append(self._make_mapping(
                    sf["name"], best_target["name"],
                    confidence=round(best_score, 2),
                    source_type=src_type_map.get(sf["name"], "string")))
                matched_targets.add(best_target["name"])
            else:
                still_unmatched.append(sf)
        unmatched_sources = still_unmatched

        # Phase 4 – Type-compatible suggestions for remaining unmatched
        available_targets = [tc for tc in target_columns if tc["name"] not in matched_targets]
        for sf in unmatched_sources:
            sf_type = sf.get("type", "string")
            for tc in available_targets:
                if tc["name"] in matched_targets:
                    continue
                tc_type = tc.get("type", "string")
                if self._types_compatible(sf_type, tc_type):
                    mappings.append(self._make_mapping(
                        sf["name"], tc["name"], confidence=0.5,
                        source_type=sf_type))
                    matched_targets.add(tc["name"])
                    break

        return mappings

    def apply_mappings(self, row: dict, mappings: list[dict]) -> dict:
        """Transform a single source *row* according to *mappings* and return
        a dict keyed by target column names."""
        result: dict[str, Any] = {}
        for m in mappings:
            source_path: str = m["source_path"]
            target_col: str = m["target_column"]
            transform: dict | None = m.get("transform")

            value = self._extract_value(row, source_path)
            value = self._apply_transform(value, transform)
            result[target_col] = value
        return result

    def apply_mappings_multi_table(
        self,
        row: dict,
        parent_mappings: list[dict],
        child_tables: list[dict],
        child_mappings_by_table: dict[str, list[dict]],
    ) -> dict[str, list[dict]]:
        """Transform a single source *row* into rows for parent and child tables.

        *child_tables* is a list of dicts with keys ``source_array``,
        ``target_table``, ``parent_key``, and ``foreign_key_column``.

        Returns a dict keyed by target table name, each value a list of
        row dicts ready for insertion.
        """
        result: dict[str, list[dict]] = {}

        # Parent row
        parent_row = self.apply_mappings(row, parent_mappings)
        parent_table = parent_mappings[0].get("_target_table", "__parent__") if parent_mappings else "__parent__"
        result[parent_table] = [parent_row]

        # Child tables
        for ct in child_tables:
            source_array = ct["source_array"]
            target_table = ct["target_table"]
            parent_key = ct.get("parent_key")
            fk_column = ct.get("foreign_key_column", "PARENT_ID")
            mappings = child_mappings_by_table.get(target_table, [])
            if not mappings:
                continue

            # Extract the array from the source row
            array_data = self._extract_value(row, source_array)
            if not isinstance(array_data, list):
                continue

            # Get the parent key value for FK injection
            parent_key_value = self._extract_value(row, parent_key) if parent_key else None

            child_rows = []
            for element in array_data:
                if not isinstance(element, dict):
                    continue
                child_row = self.apply_mappings(element, mappings)
                if parent_key_value is not None:
                    child_row[fk_column] = parent_key_value
                child_rows.append(child_row)

            if child_rows:
                result[target_table] = child_rows

        return result

    def flatten_row(self, row: dict, prefix: str = "") -> dict:
        """Recursively flatten a nested dict.

        ``{"user": {"name": "Bob"}}`` becomes ``{"user.name": "Bob"}``.
        Arrays / lists are serialised as JSON strings.
        """
        flat: dict[str, Any] = {}
        for key, value in row.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                flat.update(self.flatten_row(value, prefix=full_key))
            elif isinstance(value, list):
                flat[full_key] = json.dumps(value)
            else:
                flat[full_key] = value
        return flat

    def suggest_type_mapping(self, json_type: str, target_type: str) -> dict:
        """Return a dict of suggested column types per database dialect.

        Parameters
        ----------
        json_type:
            One of ``string``, ``integer``, ``float``, ``boolean``,
            ``datetime``, ``null``, ``object``, ``array``.
        target_type:
            A high-level target type hint (ignored for the built-in lookup
            but reserved for future use).

        Returns
        -------
        dict with keys ``oracle``, ``postgresql``, ``mysql``.
        """
        mapping_table: dict[str, dict[str, str]] = {
            "string": {
                "oracle": "VARCHAR2(4000)",
                "postgresql": "TEXT",
                "mysql": "TEXT",
            },
            "integer": {
                "oracle": "NUMBER(38)",
                "postgresql": "BIGINT",
                "mysql": "BIGINT",
            },
            "float": {
                "oracle": "NUMBER",
                "postgresql": "DOUBLE PRECISION",
                "mysql": "DOUBLE",
            },
            "boolean": {
                "oracle": "NUMBER(1)",
                "postgresql": "BOOLEAN",
                "mysql": "TINYINT(1)",
            },
            "datetime": {
                "oracle": "TIMESTAMP",
                "postgresql": "TIMESTAMP",
                "mysql": "DATETIME",
            },
            "null": {
                "oracle": "VARCHAR2(4000)",
                "postgresql": "TEXT",
                "mysql": "TEXT",
            },
            "object": {
                "oracle": "CLOB",
                "postgresql": "JSONB",
                "mysql": "JSON",
            },
            "array": {
                "oracle": "CLOB",
                "postgresql": "JSONB",
                "mysql": "JSON",
            },
        }
        key = json_type.lower()
        if key in mapping_table:
            return mapping_table[key]
        return mapping_table["string"]

    # ------------------------------------------------------------------ #
    #  Internal helpers                                                    #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _normalize(name: str) -> str:
        """Normalise a field / column name for comparison.

        * Insert a separator before each uppercase letter that follows a
          lowercase letter (camelCase → camel_case).
        * Strip underscores, hyphens and dots.
        * Lowercase the result.
        """
        # camelCase → camel_case
        name = re.sub(r"([a-z])([A-Z])", r"\1_\2", name)
        # Remove separators
        name = re.sub(r"[_\-.]", "", name)
        return name.lower()

    @staticmethod
    def _simple_similarity(a: str, b: str) -> float:
        """Character-level similarity using :class:`difflib.SequenceMatcher`.

        Returns a float in ``[0.0, 1.0]``.
        """
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()

    @staticmethod
    def _extract_value(row: dict, source_path: str) -> Any:
        """Navigate a nested dict using dot-notation.

        ``"user.address.city"`` → ``row["user"]["address"]["city"]``.
        Returns ``None`` when any segment along the path is missing.
        """
        current: Any = row
        for part in source_path.split("."):
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    def _apply_transform(self, value: Any, transform: dict | None) -> Any:
        """Apply a single transformation descriptor to *value*.

        Supported transform ``type`` values:

        * ``RENAME`` – identity (the mapping itself handles renaming).
        * ``TYPECAST`` – cast to a target type.  Config keys: ``to``
          (``DATE``, ``INTEGER``, ``FLOAT``, ``STRING``, ``BOOLEAN``)
          and optionally ``format``.
        * ``FLATTEN`` – identity (dot-path extraction already happened).
        * ``EXPRESSION`` – evaluate a simple expression string.
        * ``CONSTANT`` – return ``config["value"]``.
        * ``LOOKUP`` – placeholder; returns *value* unchanged.
        """
        if transform is None:
            return value

        kind = transform.get("type", "").upper()
        config = transform.get("config", {})

        try:
            if kind == "RENAME":
                return value

            if kind == "FLATTEN":
                return value

            if kind == "LOOKUP":
                return value

            if kind == "CONSTANT":
                return config.get("value", value)

            if kind == "TYPECAST":
                return self._typecast(value, config)

            if kind == "EXPRESSION":
                return self._evaluate_expression(value, config)

            log.warning("Unknown transform type '%s'; returning value as-is.", kind)
            return value

        except Exception:
            log.warning(
                "Transform %s failed for value %r; returning original.",
                kind,
                value,
                exc_info=True,
            )
            return value

    # ------------------------------------------------------------------ #
    #  Transform sub-routines                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _typecast(value: Any, config: dict) -> Any:
        """Cast *value* to the type described by *config*."""
        target = config.get("to", "STRING").upper()

        if value is None:
            return None

        if target == "STRING":
            return str(value)

        if target == "INTEGER":
            if isinstance(value, str):
                # Strip possible thousands separators
                value = value.replace(",", "")
            return int(float(value))

        if target == "FLOAT":
            if isinstance(value, str):
                value = value.replace(",", "")
            return float(value)

        if target == "BOOLEAN":
            if isinstance(value, str):
                return value.lower() in ("true", "1", "yes", "y", "on")
            return bool(value)

        if target == "DATE":
            fmt = config.get("format")
            if isinstance(value, datetime):
                return value.isoformat()
            if isinstance(value, str):
                if fmt:
                    return datetime.strptime(value, fmt).isoformat()
                # Attempt ISO parse
                return datetime.fromisoformat(value).isoformat()
            return str(value)

        return value

    @staticmethod
    def _evaluate_expression(value: Any, config: dict) -> Any:
        """Evaluate a simple expression string.

        The expression may contain ``${field}`` tokens which are replaced
        with *value* (since we operate on a single value context here).

        Supported built-in functions: ``upper()``, ``lower()``, ``trim()``,
        and concatenation via ``||``.
        """
        expr: str = config.get("expression", "")
        if not expr:
            return value

        # Replace ${value} or ${field} placeholders with the actual value
        result = re.sub(r"\$\{[^}]*\}", str(value) if value is not None else "", expr)

        # Handle function calls
        func_match = re.match(r"^(\w+)\((.+)\)$", result.strip())
        if func_match:
            func_name = func_match.group(1).lower()
            inner = func_match.group(2)
            if func_name == "upper":
                return inner.upper()
            if func_name == "lower":
                return inner.lower()
            if func_name == "trim":
                return inner.strip()

        # Handle concatenation with ||
        if "||" in result:
            parts = [p.strip().strip("'\"") for p in result.split("||")]
            return "".join(parts)

        return result

    # ------------------------------------------------------------------ #
    #  Fuzzy / similarity helpers                                          #
    # ------------------------------------------------------------------ #

    def _fuzzy_score(self, source_name: str, target_name: str) -> float:
        """Return a similarity score in ``[0.0, 1.0]`` between two names.

        Uses *thefuzz* when available, falling back to
        :meth:`_simple_similarity`.
        """
        if _fuzz is not None:
            ratio = _fuzz.ratio(source_name.lower(), target_name.lower())
            # Also check partial ratio and token sort for better matching
            partial = _fuzz.partial_ratio(source_name.lower(), target_name.lower())
            token_sort = _fuzz.token_sort_ratio(source_name.lower(), target_name.lower())
            best = max(ratio, partial, token_sort)
            return best / 100.0

        # Fallback: basic SequenceMatcher similarity
        return self._simple_similarity(source_name, target_name)

    @staticmethod
    def _types_compatible(source_type: str, target_type: str) -> bool:
        """Check whether *source_type* and *target_type* are broadly
        compatible for a type-based suggestion."""
        if not source_type or not target_type:
            return True  # unknown types are optimistically compatible

        s = source_type.lower()
        t = target_type.lower()

        # Direct match
        if s == t:
            return True

        compatible_groups: list[set[str]] = [
            {"string", "text", "varchar", "varchar2", "char", "clob", "nvarchar"},
            {"integer", "int", "bigint", "smallint", "number", "numeric", "tinyint"},
            {"float", "double", "decimal", "number", "numeric", "real", "double precision"},
            {"boolean", "bool", "tinyint", "number"},
            {"datetime", "date", "timestamp", "timestamptz"},
            {"object", "json", "jsonb", "clob"},
            {"array", "json", "jsonb", "clob"},
        ]

        for group in compatible_groups:
            if s in group and t in group:
                return True

        return False

    @staticmethod
    def _make_mapping(
        source_path: str,
        target_column: str,
        confidence: float,
        transform: dict | None = None,
        source_type: str = "string",
    ) -> dict:
        """Build a canonical mapping dict."""
        return {
            "source_path": source_path,
            "target_column": target_column,
            "transform": transform,
            "confidence": confidence,
            "is_manual": False,
            "source_type": source_type,
        }
