# ================================================================
#  REST API to Oracle ADB Data Migration Workbench - Bootstrap Script
#  Ensures Python 3.9+ and all dependencies are installed,
#  then launches the server. Fully automatic, zero user input
#  required (except confirming Python install if missing).
# ================================================================
$ErrorActionPreference = 'Continue'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

# ----------------------------------------------------------------
#  HELPER: Write coloured status lines
# ----------------------------------------------------------------
function Write-Status {
    param([string]$Symbol, [string]$Message, [string]$Colour = 'White')
    Write-Host "  [$Symbol] " -NoNewline -ForegroundColor $Colour
    Write-Host $Message
}
function Write-OK   { param([string]$Msg) Write-Status 'OK'   $Msg 'Green'  }
function Write-Miss { param([string]$Msg) Write-Status 'MISS' $Msg 'Yellow' }
function Write-Fail { param([string]$Msg) Write-Status 'FAIL' $Msg 'Red'    }
function Write-Info { param([string]$Msg) Write-Status '....' $Msg 'Cyan'   }
function Write-Warn { param([string]$Msg) Write-Status 'WARN' $Msg 'Yellow' }

# ================================================================
#  STEP 1 - Find a working Python 3.9+
# ================================================================
# Read version from VERSION file
$versionFile = Join-Path $ScriptDir 'VERSION'
$appVersion = 'dev'
if (Test-Path $versionFile) {
    $appVersion = (Get-Content $versionFile -Raw).Trim()
}

Write-Host ''
Write-Host '  ================================================================' -ForegroundColor Cyan
Write-Host "   REST -> ADB Migration Workbench  v$appVersion"                    -ForegroundColor Cyan
Write-Host '  ================================================================' -ForegroundColor Cyan
Write-Host ''

Write-Info 'Searching for Python...'

$PythonExe = $null

# --- 1a. Scan well-known install directories (avoids Windows Store stubs entirely)
$SearchDirs = @(
    "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"
    "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"
    "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe"
    "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe"
    "$env:LOCALAPPDATA\Programs\Python\Python39\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
    "C:\Python39\python.exe"
    "$env:ProgramFiles\Python313\python.exe"
    "$env:ProgramFiles\Python312\python.exe"
    "$env:ProgramFiles\Python311\python.exe"
    "$env:ProgramFiles\Python310\python.exe"
    "$env:ProgramFiles\Python39\python.exe"
)

foreach ($p in $SearchDirs) {
    if (Test-Path $p) {
        $PythonExe = $p
        break
    }
}

# --- 1b. Try "py -3" launcher (installed by python.org, never a Store stub)
if (-not $PythonExe) {
    try {
        $null = Get-Command py -ErrorAction Stop
        $testOutput = & py -3 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $testOutput) {
            $PythonExe = 'py -3'
        }
    } catch {}
}

# --- 1c. Try "python" / "python3" on PATH, but skip WindowsApps stubs
if (-not $PythonExe) {
    foreach ($cmd in @('python', 'python3')) {
        try {
            $info = Get-Command $cmd -ErrorAction Stop
            # Skip Windows Store stubs
            if ($info.Source -match 'WindowsApps') { continue }
            $testOutput = & $cmd -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $testOutput) {
                $PythonExe = $cmd
                break
            }
        } catch {}
    }
}

# ================================================================
#  STEP 1B - Auto-install Python if not found
# ================================================================
if (-not $PythonExe) {
    Write-Warn 'Python is not installed on this system.'
    Write-Host ''
    $answer = Read-Host '  Download and install Python 3.12 automatically? (Y/N)'
    if ($answer -notmatch '^[Yy]') {
        Write-Host ''
        Write-Host '  Please install Python 3.9+ from https://www.python.org/downloads/'
        Write-Host '  IMPORTANT: Check "Add Python to PATH" during installation.'
        Write-Host '  Then re-run this script.'
        exit 1
    }

    Write-Host ''
    Write-Info 'Downloading Python 3.12.8 from python.org...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $installerUrl  = 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe'
    $installerPath = Join-Path $env:TEMP 'python-3.12.8-amd64.exe'

    try {
        $wc = New-Object Net.WebClient
        $wc.DownloadFile($installerUrl, $installerPath)
    } catch {
        try {
            Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
        } catch {
            Write-Fail "Download failed: $_"
            Write-Host '  Please download manually from https://www.python.org/downloads/'
            exit 1
        }
    }

    if (-not (Test-Path $installerPath)) {
        Write-Fail 'Installer file not found after download.'
        exit 1
    }

    Write-Info 'Installing Python (this may take 1-2 minutes)...'
    $proc = Start-Process -FilePath $installerPath `
        -ArgumentList '/passive', 'InstallAllUsers=0', 'PrependPath=1', `
                       'Include_pip=1', 'Include_test=0' `
        -Wait -PassThru

    Remove-Item $installerPath -Force -ErrorAction SilentlyContinue

    if ($proc.ExitCode -ne 0) {
        Write-Fail "Installer exited with code $($proc.ExitCode)."
        Write-Host '  Please install manually from https://www.python.org/downloads/'
        exit 1
    }

    Write-OK 'Python installed successfully.'

    # Refresh PATH from the registry so we can find it immediately
    $machinePath = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $userPath    = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path    = "$machinePath;$userPath"

    # Re-scan directories for the just-installed Python
    $PythonExe = $null
    foreach ($p in $SearchDirs) {
        if (Test-Path $p) {
            $PythonExe = $p
            break
        }
    }

    # Also try py launcher and PATH again
    if (-not $PythonExe) {
        try {
            $testOutput = & py -3 -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $testOutput) { $PythonExe = 'py -3' }
        } catch {}
    }
    if (-not $PythonExe) {
        try {
            $testOutput = & python -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $testOutput) { $PythonExe = 'python' }
        } catch {}
    }

    if (-not $PythonExe) {
        Write-Warn 'Python was installed but cannot be found in the current session.'
        Write-Host '  Please CLOSE this window, open a new terminal, and re-run this script.'
        exit 1
    }
}

# ================================================================
#  STEP 2 - Verify Python version >= 3.9
# ================================================================
Write-Host ''

# Build a command helper (handles "py -3" vs path-to-exe)
function Invoke-Python {
    param([string[]]$Arguments)
    if ($PythonExe -eq 'py -3') {
        & py -3 @Arguments 2>$null
    } else {
        & $PythonExe @Arguments 2>$null
    }
}

# Get version string
$pyVersion = Invoke-Python @('-c', 'import sys; print(sys.version.split()[0])')
if (-not $pyVersion) {
    Write-Fail "Could not determine Python version from: $PythonExe"
    exit 1
}
Write-OK "Python $pyVersion at: $PythonExe"

# Check version >= 3.9
$parts = $pyVersion.Split('.')
$major = [int]$parts[0]
$minor = [int]$parts[1]
if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 9)) {
    Write-Fail "Python 3.9+ is required. Found: $pyVersion"
    Write-Host '  Download from: https://www.python.org/downloads/'
    exit 1
}

# ================================================================
#  STEP 3 - Ensure pip is available
# ================================================================
Write-Info 'Checking pip...'
$null = Invoke-Python @('-m', 'pip', '--version')
if ($LASTEXITCODE -ne 0) {
    Write-Info 'Installing pip...'
    $null = Invoke-Python @('-m', 'ensurepip', '--upgrade')
    $null = Invoke-Python @('-m', 'pip', '--version')
    if ($LASTEXITCODE -ne 0) {
        Write-Fail 'pip is not available and could not be installed.'
        exit 1
    }
}
Write-OK 'pip ready.'

# ================================================================
#  STEP 4 - Check and install Python package dependencies
# ================================================================
Write-Host ''
Write-Info 'Checking Python packages...'

$requiredPackages = @(
    @{ ImportName = 'flask';                   PipName = 'flask' }
    @{ ImportName = 'oracledb';                PipName = 'python-oracledb' }
    @{ ImportName = 'psycopg';                 PipName = 'psycopg[binary]' }
    @{ ImportName = 'mysql.connector';         PipName = 'mysql-connector-python' }
    @{ ImportName = 'requests';                PipName = 'requests' }
    @{ ImportName = 'yaml';                    PipName = 'pyyaml' }
    @{ ImportName = 'openapi_spec_validator';  PipName = 'openapi-spec-validator' }
    @{ ImportName = 'jsonpath_ng';             PipName = 'jsonpath-ng' }
    @{ ImportName = 'thefuzz';                 PipName = 'thefuzz[speedup]' }
    @{ ImportName = 'cryptography';            PipName = 'cryptography' }
    @{ ImportName = 'pydantic';                PipName = 'pydantic' }
    @{ ImportName = 'authlib';                 PipName = 'authlib' }
)

$missing = @()

foreach ($pkg in $requiredPackages) {
    $null = Invoke-Python @('-c', "import $($pkg.ImportName)")
    if ($LASTEXITCODE -eq 0) {
        Write-OK $pkg.ImportName
    } else {
        Write-Miss $pkg.ImportName
        $missing += $pkg.PipName
    }
}

# ================================================================
#  STEP 5 - Install missing packages
# ================================================================
if ($missing.Count -gt 0) {
    Write-Host ''
    Write-Info "Installing $($missing.Count) missing package(s)..."

    # Try bulk install from requirements.txt first
    $reqFile = Join-Path $ScriptDir 'requirements.txt'
    $null = Invoke-Python @('-m', 'pip', 'install', '--upgrade', '-r', $reqFile)

    if ($LASTEXITCODE -ne 0) {
        Write-Warn 'Bulk install had errors. Retrying individually...'
        foreach ($pipPkg in $missing) {
            Write-Info "Installing $pipPkg..."
            $null = Invoke-Python @('-m', 'pip', 'install', $pipPkg)
        }
    }

    # Verify all required packages
    Write-Host ''
    Write-Info 'Verifying installed packages...'
    $failCount = 0
    foreach ($pkg in $requiredPackages) {
        $null = Invoke-Python @('-c', "import $($pkg.ImportName)")
        if ($LASTEXITCODE -eq 0) {
            Write-OK $pkg.ImportName
        } else {
            Write-Fail $pkg.ImportName
            $failCount++
        }
    }

    if ($failCount -gt 0) {
        Write-Fail "$failCount required package(s) failed to install."
        exit 1
    }
}

Write-Host ''
Write-OK 'All dependencies ready.'

# ================================================================
#  STEP 6 - Check for updates (optional)
# ================================================================
$updatePy = Join-Path $ScriptDir 'update.py'
if (Test-Path $updatePy) {
    Write-Host ''
    Write-Info 'Checking for updates...'
    $null = Invoke-Python @($updatePy, '--check')
    if ($LASTEXITCODE -eq 0) {
        Write-OK 'Version check complete.'
    }
    Write-Host ''
}

# ================================================================
#  STEP 7 - Create working directories & launch server
# ================================================================
foreach ($dir in @('data', 'logs', 'config')) {
    $dirPath = Join-Path $ScriptDir $dir
    if (-not (Test-Path $dirPath)) { New-Item -ItemType Directory -Path $dirPath -Force | Out-Null }
}

# Parse optional host/port arguments (--host X --port Y)
$Host_ = '127.0.0.1'
$Port_  = 8500

# Read defaults from config/default.yaml if it exists
$configFile = Join-Path $ScriptDir 'config' 'default.yaml'
if (Test-Path $configFile) {
    $cfgContent = Get-Content $configFile -Raw
    if ($cfgContent -match '^\s+host:\s*(.+)$') { $Host_ = $Matches[1].Trim().Trim('"').Trim("'") }
    if ($cfgContent -match '^\s+port:\s*(\d+)') { $Port_ = [int]$Matches[1] }
}

# Command-line overrides
for ($i = 0; $i -lt $args.Count; $i++) {
    if ($args[$i] -eq '--host' -and ($i + 1) -lt $args.Count) { $Host_ = $args[$i + 1] }
    if ($args[$i] -eq '--port' -and ($i + 1) -lt $args.Count) { $Port_  = [int]$args[$i + 1] }
}

$mainPy    = Join-Path $ScriptDir 'main.py'
$pidFile   = Join-Path $ScriptDir '.server.pid'
$serverUrl = "http://${Host_}:${Port_}"

# ── Stop any previously running instance ──────────────────────────
if (Test-Path $pidFile) {
    $oldPid = (Get-Content $pidFile -Raw).Trim()
    try {
        $oldProc = Get-Process -Id $oldPid -ErrorAction Stop
        Write-Info "Stopping previous server (PID $oldPid)..."
        $oldProc.Kill()
        $oldProc.WaitForExit(5000) | Out-Null
    } catch {}
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}

Write-Host ''
Write-Host '  ================================================================' -ForegroundColor Cyan
Write-Host "   Starting server: $serverUrl"                                      -ForegroundColor Cyan
Write-Host '  ================================================================' -ForegroundColor Cyan
Write-Host ''

# Start the server as a background process
if ($PythonExe -eq 'py -3') {
    $proc = Start-Process -FilePath 'py' -ArgumentList "-3 `"$mainPy`"" -PassThru -WindowStyle Hidden
} else {
    $proc = Start-Process -FilePath $PythonExe -ArgumentList "`"$mainPy`"" -PassThru -WindowStyle Hidden
}

# Save PID to file
$proc.Id | Out-File -FilePath $pidFile -Encoding ascii -NoNewline

# Wait for the server to become ready (up to 15 seconds)
$ready = $false
for ($i = 0; $i -lt 30; $i++) {
    Start-Sleep -Milliseconds 500
    try {
        $null = Invoke-WebRequest -Uri $serverUrl -UseBasicParsing -TimeoutSec 2 -ErrorAction Stop
        $ready = $true
        break
    } catch {
        # Server not ready yet -- keep waiting
    }
}

if ($ready) {
    Write-OK "Server is running at $serverUrl (PID $($proc.Id))"
    Write-Info 'Opening browser...'
    Start-Process $serverUrl
} else {
    Write-Warn "Could not confirm server is ready -- opening browser anyway."
    Start-Process $serverUrl
}

Write-Host ''
Write-OK "Server running in background. Use stop.ps1 to stop it."
Write-Host ''
