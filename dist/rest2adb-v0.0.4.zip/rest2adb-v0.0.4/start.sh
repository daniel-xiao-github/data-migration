#!/usr/bin/env bash
# ================================================================
#  REST API to Oracle ADB Data Migration Workbench - Bootstrap Script
#  Ensures Python 3.9+ and all dependencies are installed,
#  then launches the server. Fully automatic, zero user input
#  required (except confirming Python install if missing).
# ================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ----------------------------------------------------------------
#  HELPER: Write coloured status lines
# ----------------------------------------------------------------
write_ok()   { printf '  [\033[1;32mOK\033[0m]   %s\n' "$*"; }
write_miss() { printf '  [\033[1;33mMISS\033[0m] %s\n' "$*"; }
write_fail() { printf '  [\033[1;31mFAIL\033[0m] %s\n' "$*"; }
write_info() { printf '  [\033[1;36m....\033[0m] %s\n' "$*"; }
write_warn() { printf '  [\033[1;33mWARN\033[0m] %s\n' "$*"; }

# ================================================================
#  STEP 1 - Find a working Python 3.9+
# ================================================================
# Read version from VERSION file
APP_VERSION="dev"
if [ -f "$SCRIPT_DIR/VERSION" ]; then
    APP_VERSION=$(cat "$SCRIPT_DIR/VERSION" | tr -d '[:space:]')
fi

echo ''
printf '  \033[1;36m================================================================\033[0m\n'
printf '  \033[1;36m REST -> ADB Migration Workbench  v%s\033[0m\n' "$APP_VERSION"
printf '  \033[1;36m================================================================\033[0m\n'
echo ''

write_info 'Searching for Python...'

PYTHON_EXE=""

# --- 1a. Scan well-known install directories
SEARCH_DIRS=(
    "/usr/local/bin/python3.13"
    "/usr/local/bin/python3.12"
    "/usr/local/bin/python3.11"
    "/usr/local/bin/python3.10"
    "/usr/local/bin/python3.9"
    "/usr/bin/python3.13"
    "/usr/bin/python3.12"
    "/usr/bin/python3.11"
    "/usr/bin/python3.10"
    "/usr/bin/python3.9"
    "$HOME/.local/bin/python3"
    "$HOME/.pyenv/shims/python3"
)

# macOS Homebrew paths
if [ "$(uname)" = "Darwin" ]; then
    SEARCH_DIRS+=(
        "/opt/homebrew/bin/python3.13"
        "/opt/homebrew/bin/python3.12"
        "/opt/homebrew/bin/python3.11"
        "/opt/homebrew/bin/python3.10"
        "/opt/homebrew/bin/python3.9"
        "/opt/homebrew/bin/python3"
        "/usr/local/opt/python@3.12/bin/python3"
        "/usr/local/opt/python@3.11/bin/python3"
    )
fi

for p in "${SEARCH_DIRS[@]}"; do
    if [ -x "$p" ] 2>/dev/null; then
        if "$p" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null; then
            PYTHON_EXE="$p"
            break
        fi
    fi
done

# --- 1b. Try "python3" / "python" on PATH
if [ -z "$PYTHON_EXE" ]; then
    for cmd in python3 python; do
        if command -v "$cmd" >/dev/null 2>&1; then
            if "$cmd" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null; then
                PYTHON_EXE="$cmd"
                break
            fi
        fi
    done
fi

# ================================================================
#  STEP 1B - Auto-install Python if not found
# ================================================================
if [ -z "$PYTHON_EXE" ]; then
    write_warn 'Python 3.9+ is not installed on this system.'
    echo ''

    # Detect package manager
    PKG_MGR=""
    if command -v apt-get >/dev/null 2>&1; then
        PKG_MGR="apt"
    elif command -v dnf >/dev/null 2>&1; then
        PKG_MGR="dnf"
    elif command -v yum >/dev/null 2>&1; then
        PKG_MGR="yum"
    elif command -v brew >/dev/null 2>&1; then
        PKG_MGR="brew"
    elif command -v pacman >/dev/null 2>&1; then
        PKG_MGR="pacman"
    fi

    if [ -n "$PKG_MGR" ]; then
        printf '  Install Python 3 using %s? (Y/N) ' "$PKG_MGR"
        read -r answer
        if echo "$answer" | grep -qiE '^y'; then
            echo ''
            write_info "Installing Python 3 via $PKG_MGR..."
            case "$PKG_MGR" in
                apt)
                    sudo apt-get update -qq && sudo apt-get install -y python3 python3-pip python3-venv
                    ;;
                dnf)
                    sudo dnf install -y python3 python3-pip
                    ;;
                yum)
                    sudo yum install -y python3 python3-pip
                    ;;
                brew)
                    brew install python@3.12
                    ;;
                pacman)
                    sudo pacman -S --noconfirm python python-pip
                    ;;
            esac

            # Re-scan for Python
            for cmd in python3 python; do
                if command -v "$cmd" >/dev/null 2>&1; then
                    if "$cmd" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null; then
                        PYTHON_EXE="$cmd"
                        break
                    fi
                fi
            done

            if [ -z "$PYTHON_EXE" ]; then
                write_fail 'Python was installed but cannot be found.'
                write_info 'Please close this terminal, open a new one, and re-run this script.'
                exit 1
            fi
            write_ok 'Python installed successfully.'
        else
            echo ''
            echo '  Please install Python 3.9+ from https://www.python.org/downloads/'
            echo '  Then re-run this script.'
            exit 1
        fi
    else
        write_fail 'No supported package manager found.'
        echo '  Please install Python 3.9+ from https://www.python.org/downloads/'
        echo '  Then re-run this script.'
        exit 1
    fi
fi

# ================================================================
#  STEP 2 - Verify Python version >= 3.9
# ================================================================
echo ''
PY_VERSION=$("$PYTHON_EXE" -c "import sys; print(sys.version.split()[0])")

if [ -z "$PY_VERSION" ]; then
    write_fail "Could not determine Python version from: $PYTHON_EXE"
    exit 1
fi

write_ok "Python $PY_VERSION at: $PYTHON_EXE"

PY_MAJOR=$("$PYTHON_EXE" -c "import sys; print(sys.version_info.major)")
PY_MINOR=$("$PYTHON_EXE" -c "import sys; print(sys.version_info.minor)")

if [ "$PY_MAJOR" -lt 3 ] || { [ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 9 ]; }; then
    write_fail "Python 3.9+ is required. Found: $PY_VERSION"
    echo '  Download from: https://www.python.org/downloads/'
    exit 1
fi

# ================================================================
#  STEP 3 - Ensure pip is available
# ================================================================
write_info 'Checking pip...'
if ! "$PYTHON_EXE" -m pip --version >/dev/null 2>&1; then
    write_info 'Installing pip...'
    "$PYTHON_EXE" -m ensurepip --upgrade 2>/dev/null || true
    if ! "$PYTHON_EXE" -m pip --version >/dev/null 2>&1; then
        write_fail 'pip is not available and could not be installed.'
        exit 1
    fi
fi
write_ok 'pip ready.'

# ================================================================
#  STEP 4 - Check and install Python package dependencies
# ================================================================
echo ''
write_info 'Checking Python packages...'

# ImportName:PipName pairs
REQUIRED_PACKAGES=(
    "flask:flask"
    "oracledb:python-oracledb"
    "psycopg:psycopg[binary]"
    "mysql.connector:mysql-connector-python"
    "requests:requests"
    "yaml:pyyaml"
    "openapi_spec_validator:openapi-spec-validator"
    "jsonpath_ng:jsonpath-ng"
    "thefuzz:thefuzz[speedup]"
    "cryptography:cryptography"
    "pydantic:pydantic"
    "authlib:authlib"
)

MISSING=()

for entry in "${REQUIRED_PACKAGES[@]}"; do
    IMPORT_NAME="${entry%%:*}"
    PIP_NAME="${entry##*:}"
    if "$PYTHON_EXE" -c "import $IMPORT_NAME" 2>/dev/null; then
        write_ok "$IMPORT_NAME"
    else
        write_miss "$IMPORT_NAME"
        MISSING+=("$PIP_NAME")
    fi
done

# ================================================================
#  STEP 5 - Install missing packages
# ================================================================
if [ ${#MISSING[@]} -gt 0 ]; then
    echo ''
    write_info "Installing ${#MISSING[@]} missing package(s)..."

    # Try bulk install from requirements.txt first
    REQ_FILE="$SCRIPT_DIR/requirements.txt"
    if "$PYTHON_EXE" -m pip install --upgrade -r "$REQ_FILE" 2>/dev/null; then
        : # success
    else
        write_warn 'Bulk install had errors. Retrying individually...'
        for pip_pkg in "${MISSING[@]}"; do
            write_info "Installing $pip_pkg..."
            "$PYTHON_EXE" -m pip install "$pip_pkg" || true
        done
    fi

    # Verify all required packages
    echo ''
    write_info 'Verifying installed packages...'
    FAIL_COUNT=0
    for entry in "${REQUIRED_PACKAGES[@]}"; do
        IMPORT_NAME="${entry%%:*}"
        if "$PYTHON_EXE" -c "import $IMPORT_NAME" 2>/dev/null; then
            write_ok "$IMPORT_NAME"
        else
            write_fail "$IMPORT_NAME"
            FAIL_COUNT=$((FAIL_COUNT + 1))
        fi
    done

    if [ "$FAIL_COUNT" -gt 0 ]; then
        write_fail "$FAIL_COUNT required package(s) failed to install."
        exit 1
    fi
fi

echo ''
write_ok 'All dependencies ready.'

# ================================================================
#  STEP 6 - Check for updates (optional)
# ================================================================
UPDATE_PY="$SCRIPT_DIR/update.py"
if [ -f "$UPDATE_PY" ]; then
    echo ''
    write_info 'Checking for updates...'
    "$PYTHON_EXE" "$UPDATE_PY" --check 2>/dev/null && write_ok 'Version check complete.' || true
    echo ''
fi

# ================================================================
#  STEP 7 - Create working directories & launch server
# ================================================================
for dir in data logs config; do
    mkdir -p "$SCRIPT_DIR/$dir"
done

# Parse optional host/port arguments (--host X --port Y)
HOST_='127.0.0.1'
PORT_=8500

# Read defaults from config/default.yaml if it exists
CONFIG_FILE="$SCRIPT_DIR/config/default.yaml"
if [ -f "$CONFIG_FILE" ]; then
    _h=$(grep -E '^\s+host:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *"\{0,1\}\([^"]*\)"\{0,1\}/\1/' || true)
    _p=$(grep -E '^\s+port:' "$CONFIG_FILE" 2>/dev/null | head -1 | sed 's/.*: *\([0-9]*\).*/\1/' || true)
    [ -n "$_h" ] && HOST_="$_h"
    [ -n "$_p" ] && PORT_="$_p"
fi

# Command-line overrides
while [ $# -gt 0 ]; do
    case "$1" in
        --host) HOST_="$2"; shift 2 ;;
        --port) PORT_="$2"; shift 2 ;;
        *) shift ;;
    esac
done

SERVER_URL="http://${HOST_}:${PORT_}"

MAIN_PY="$SCRIPT_DIR/main.py"
PID_FILE="$SCRIPT_DIR/.server.pid"
LOG_DIR="$SCRIPT_DIR/logs"

# ── Stop any previously running instance ──────────────────────────
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        write_info "Stopping previous server (PID $OLD_PID)..."
        kill "$OLD_PID" 2>/dev/null || true
        sleep 1
        kill -0 "$OLD_PID" 2>/dev/null && kill -9 "$OLD_PID" 2>/dev/null || true
    fi
    rm -f "$PID_FILE"
fi

echo ''
printf '  \033[1;36m================================================================\033[0m\n'
printf '  \033[1;36m Starting server: %s\033[0m\n' "$SERVER_URL"
printf '  \033[1;36m================================================================\033[0m\n'
echo ''

# Start the server in the background, redirect output to log file
nohup "$PYTHON_EXE" "$MAIN_PY" >> "$LOG_DIR/server.log" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > "$PID_FILE"

# Wait for the server to become ready (up to 15 seconds)
READY=false
for i in $(seq 1 30); do
    sleep 0.5
    # Check server is still alive
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
        write_fail "Server process exited unexpectedly. Check logs/server.log"
        rm -f "$PID_FILE"
        exit 1
    fi
    # Try connecting
    if command -v curl >/dev/null 2>&1; then
        if curl -s -o /dev/null -w '' --max-time 1 "$SERVER_URL/" 2>/dev/null; then
            READY=true
            break
        fi
    elif "$PYTHON_EXE" -c "
import urllib.request, sys
try:
    urllib.request.urlopen('$SERVER_URL/', timeout=1)
except Exception:
    sys.exit(1)
" 2>/dev/null; then
        READY=true
        break
    fi
done

if [ "$READY" = true ]; then
    write_ok "Server is running at $SERVER_URL (PID $SERVER_PID)"
    write_info 'Opening browser...'
    # Open browser (cross-platform)
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$SERVER_URL" 2>/dev/null &
    elif command -v open >/dev/null 2>&1; then
        open "$SERVER_URL" 2>/dev/null &
    elif command -v sensible-browser >/dev/null 2>&1; then
        sensible-browser "$SERVER_URL" 2>/dev/null &
    else
        write_info "Open your browser to: $SERVER_URL"
    fi
else
    write_warn "Could not confirm server is ready -- opening browser anyway."
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$SERVER_URL" 2>/dev/null &
    elif command -v open >/dev/null 2>&1; then
        open "$SERVER_URL" 2>/dev/null &
    fi
fi

echo ''
write_ok "Server running in background. Use stop.sh to stop it."
echo ''
