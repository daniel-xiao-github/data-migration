"""Migration orchestrator — coordinates fetch → transform → validate → load."""
from __future__ import annotations
import logging
import re
import time
import json
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

log = logging.getLogger("rest2adb.orchestrator")


class MigrationOrchestrator:
    """Runs a single migration job: fetch pages, transform, validate, insert."""

    def __init__(self, *, rest_client, adapter, control: "ControlTableManager",
                 mapping_engine, validation_engine, delta_tracker,
                 config: dict):
        self.rest_client = rest_client
        self.adapter = adapter
        self.ctl = control
        self.mapper = mapping_engine
        self.validator = validation_engine
        self.delta = delta_tracker
        self.cfg = config
        self.batch_size = config.get("batch_size", 500)
        self.max_retries = config.get("max_retries", 3)
        self.max_workers = config.get("max_workers", 3)
        self._cancel_flag = False

    def cancel(self) -> None:
        self._cancel_flag = True

    def run_job(self, job_id: str, endpoints: list[dict],
                mappings_by_ep: dict[str, list[dict]],
                sync_config: dict | None = None) -> dict:
        """Execute a full migration job."""
        self._cancel_flag = False
        self.ctl.update_job_status(job_id, "RUNNING")
        sync_config = sync_config or {}
        completed_eps = 0
        total_rows = 0
        failed = False
        error_msg = None

        try:
            if self.max_workers > 1 and len(endpoints) > 1:
                with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
                    futures = {}
                    for ep in endpoints:
                        ep_mappings = mappings_by_ep.get(ep["path"], [])
                        f = pool.submit(self._run_endpoint, job_id, ep,
                                        ep_mappings, sync_config)
                        futures[f] = ep
                    for f in as_completed(futures):
                        ep = futures[f]
                        try:
                            rows = f.result()
                            total_rows += rows
                            completed_eps += 1
                        except Exception as e:
                            log.error("Endpoint %s failed: %s", ep.get("path"), e)
                            failed = True
                            error_msg = str(e)
            else:
                for ep in endpoints:
                    if self._cancel_flag:
                        break
                    ep_mappings = mappings_by_ep.get(ep["path"], [])
                    try:
                        rows = self._run_endpoint(job_id, ep, ep_mappings,
                                                  sync_config)
                        total_rows += rows
                        completed_eps += 1
                    except Exception as e:
                        log.error("Endpoint %s failed: %s", ep.get("path"), e)
                        failed = True
                        error_msg = str(e)

            self.ctl.update_job_progress(job_id, completed_eps, total_rows)

            if self._cancel_flag:
                self.ctl.update_job_status(job_id, "CANCELLED")
            elif failed:
                self.ctl.update_job_status(job_id, "FAILED", error_msg)
            else:
                self.ctl.update_job_status(job_id, "COMPLETED")

        except Exception as e:
            log.exception("Job %s crashed: %s", job_id, e)
            self.ctl.update_job_status(job_id, "FAILED", str(e))
            failed = True
            error_msg = str(e)

        return {
            "job_id": job_id,
            "status": "CANCELLED" if self._cancel_flag else (
                "FAILED" if failed else "COMPLETED"),
            "completed_endpoints": completed_eps,
            "total_rows": total_rows,
            "error": error_msg,
        }

    def _run_endpoint(self, job_id: str, endpoint: dict,
                      mappings: list[dict], sync_config: dict,
                      _retry: int = 0) -> int:
        path = endpoint["path"]
        # Guard: skip endpoints with unresolved {param} placeholders
        unresolved = re.findall(r'\{([^}]+)\}', path)
        if unresolved:
            msg = (f"Endpoint {path} has unresolved path parameters: "
                   f"{unresolved} — skipping")
            log.warning(msg)
            ep_id = self.ctl.create_endpoint_state(job_id, path,
                endpoint.get("target_table", ""))
            self.ctl.update_endpoint_status(ep_id, "FAILED", msg)
            return 0
        target_table = endpoint.get("target_table",
                                    endpoint.get("path", "").strip("/").replace("/", "_").upper())
        child_tables = endpoint.get("child_tables", [])
        ep_id = self.ctl.create_endpoint_state(job_id, path, target_table)
        self.ctl.update_endpoint_status(ep_id, "IN_PROGRESS")

        # Split mappings: parent vs child tables
        parent_mappings = [m for m in mappings
                           if m.get("_target_table", target_table) == target_table]
        child_mappings_by_table: dict[str, list[dict]] = {}
        for ct in child_tables:
            ct_name = ct["target_table"]
            child_mappings_by_table[ct_name] = [
                m for m in mappings if m.get("_target_table") == ct_name
            ]

        # Auto-derive identity mappings from endpoint fields when none saved
        if not parent_mappings:
            ep_fields = endpoint.get("fields", [])
            if ep_fields:
                log.info("No saved mappings for %s — auto-deriving from %d fields",
                         path, len(ep_fields))
                parent_mappings = [{
                    "source_path": f["name"],
                    "target_column": re.sub(r'^data\.', '', f["name"]).replace(".", "_").upper(),
                    "transform": None,
                    "confidence": 1.0,
                    "source_type": f.get("field_type", "string"),
                    "_target_table": target_table,
                } for f in ep_fields]
            else:
                log.warning("Endpoint %s has no mappings and no fields — skipping", path)
                self.ctl.update_endpoint_status(ep_id, "COMPLETED")
                return 0

        has_children = bool(child_tables and any(child_mappings_by_table.values()))

        # Ensure parent target table exists
        if not self.adapter.table_exists(target_table):
            columns = self._derive_columns(parent_mappings, endpoint.get("fields", []))
            if columns:
                self.adapter.create_table(target_table, columns)

        # Ensure child tables exist
        for ct in child_tables:
            ct_name = ct["target_table"]
            ct_mappings = child_mappings_by_table.get(ct_name, [])
            if ct_mappings and not self.adapter.table_exists(ct_name):
                fk_col = ct.get("foreign_key_column", "PARENT_ID")
                child_fields = ct.get("fields", [])
                columns = self._derive_columns(ct_mappings, child_fields)
                # Add FK column if not already present
                from app.adapters.base import ColumnDef
                if not any(c.name == fk_col for c in columns):
                    columns.insert(0, ColumnDef(
                        name=fk_col, data_type="VARCHAR2(4000)",
                        nullable=True, primary_key=False))
                self.adapter.create_table(ct_name, columns)

        # Handle write mode
        write_mode = sync_config.get("write_mode", "insert")
        if write_mode == "truncate_reload":
            if self.adapter.table_exists(target_table):
                self.adapter.truncate_table(target_table)
            for ct in child_tables:
                ct_name = ct["target_table"]
                if self.adapter.table_exists(ct_name):
                    self.adapter.truncate_table(ct_name)

        # Delta/incremental params
        sync_state = self.delta.load_sync_state(job_id, path)
        delta_params = self.delta.build_delta_params(sync_state, sync_config)
        delta_field = sync_config.get("delta_field")
        delta_max = None

        pagination = endpoint.get("pagination")
        data_root = endpoint.get("data_root_path")
        start_cursor = sync_state.get("LAST_PAGE_CURSOR") if sync_state else None

        total_inserted = 0
        batch_seq = 0
        pk_columns = sync_config.get("pk_columns", [])

        try:
            extra_params = dict(delta_params.get("params", {}))
            extra_headers = dict(delta_params.get("headers", {}))

            # GraphQL endpoints use fetch_graphql instead of fetch_all_pages
            http_method = endpoint.get("http_method", "GET").upper()
            if http_method == "GRAPHQL":
                graphql_url = endpoint.get("graphql_url", "")
                graphql_query = endpoint.get("graphql_query", "")
                query_name = path.split(":", 1)[1] if ":" in path else path
                gql_data_root = data_root or f"data.{query_name}"
                if graphql_url and graphql_query:
                    result = self.rest_client.fetch_graphql(
                        graphql_url, graphql_query,
                        data_root=gql_data_root)
                    if isinstance(result, list):
                        pages = iter([result])
                    elif isinstance(result, dict):
                        pages = iter([[result]])
                    else:
                        pages = iter([])
                else:
                    log.warning("GraphQL endpoint %s missing query or url", path)
                    pages = iter([])
            else:
                pages = self.rest_client.fetch_all_pages(
                    path, pagination=pagination, params=extra_params,
                    headers=extra_headers, data_root=data_root,
                    start_cursor=start_cursor)

            for page_data in pages:
                if self._cancel_flag:
                    break
                batch_seq += 1

                if has_children:
                    # Multi-table mode: split each row across parent + child tables
                    table_rows: dict[str, list[dict]] = {}
                    for row in page_data:
                        multi = self.mapper.apply_mappings_multi_table(
                            row, parent_mappings, child_tables,
                            child_mappings_by_table)
                        for tbl, rows_list in multi.items():
                            table_rows.setdefault(tbl, []).extend(rows_list)
                        if delta_field:
                            delta_max = self.delta.track_delta_value(
                                delta_max, row, delta_field)

                    # Insert parent rows
                    total_inserted += self._insert_table_rows(
                        table_rows.get(target_table, []), target_table,
                        write_mode, pk_columns, ep_id, batch_seq)

                    # Insert child table rows
                    for ct in child_tables:
                        ct_name = ct["target_table"]
                        ct_rows = table_rows.get(ct_name, [])
                        if ct_rows:
                            total_inserted += self._insert_table_rows(
                                ct_rows, ct_name, write_mode, [],
                                ep_id, batch_seq)
                else:
                    # Single-table mode (original path)
                    mapped_rows = []
                    for row in page_data:
                        mapped = self.mapper.apply_mappings(row, mappings)
                        mapped_rows.append(mapped)
                        if delta_field:
                            delta_max = self.delta.track_delta_value(
                                delta_max, row, delta_field)

                    # Validate
                    valid, _, quarantined = self.validator.validate_batch(
                        mapped_rows, mappings)

                    # Quarantine bad rows
                    for q in quarantined:
                        self.ctl.add_quarantine(
                            job_id, path, batch_seq,
                            q["row_data"], q["violations"], q["severity"])

                    # Insert valid rows
                    total_inserted += self._insert_table_rows(
                        valid, target_table, write_mode, pk_columns,
                        ep_id, batch_seq)

                self.ctl.log_batch(ep_id, batch_seq, None,
                                   total_inserted, "OK")
                self.ctl.update_endpoint_checkpoint(
                    ep_id, str(batch_seq), batch_seq,
                    total_inserted, total_inserted)

            # Save delta state
            if delta_field and delta_max is not None:
                self.delta.save_sync_state({
                    "job_id": job_id,
                    "endpoint_path": path,
                    "sync_mode": sync_config.get("sync_mode", "full"),
                    "delta_field": delta_field,
                    "last_delta_value": str(delta_max),
                    "rows_synced": total_inserted,
                })

            self.ctl.update_endpoint_status(ep_id, "COMPLETED")
            return total_inserted

        except Exception as e:
            log.error("Endpoint %s failed: %s", path, e, exc_info=True)
            self.ctl.update_endpoint_status(ep_id, "FAILED", str(e))
            self.ctl.increment_retry(ep_id)
            if _retry + 1 < self.max_retries:
                log.warning("Retrying endpoint %s (attempt %d/%d)",
                            path, _retry + 2, self.max_retries)
                time.sleep(2 ** (_retry + 1))
                return self._run_endpoint(job_id, endpoint, mappings,
                                          sync_config, _retry=_retry + 1)
            raise

    def _insert_table_rows(self, rows: list[dict], table_name: str,
                           write_mode: str, pk_columns: list[str],
                           ep_id: str, batch_seq: int) -> int:
        """Insert a list of row dicts into a single table. Returns row count."""
        if not rows:
            return 0
        cols = list(rows[0].keys())
        if not cols:
            log.warning("Skipping insert into %s — row has no columns", table_name)
            return 0

        # Filter to only columns that actually exist in the target table
        try:
            table_cols = {c.name for c in self.adapter.get_columns(table_name)}
            if table_cols:
                missing = [c for c in cols if c not in table_cols]
                if missing:
                    log.warning("Dropping %d columns not in %s: %s",
                                len(missing), table_name,
                                ", ".join(missing[:10]))
                    cols = [c for c in cols if c in table_cols]
                    if not cols:
                        log.warning("No matching columns for %s — skipping",
                                    table_name)
                        return 0
        except Exception:
            pass  # if introspection fails, proceed with all columns

        rows_tuples = [tuple(r.get(c) for c in cols) for r in rows]
        inserted = 0
        for i in range(0, len(rows_tuples), self.batch_size):
            chunk = rows_tuples[i:i + self.batch_size]
            try:
                if write_mode == "upsert" and pk_columns:
                    self.adapter.upsert_batch(table_name, cols, pk_columns, chunk)
                else:
                    self.adapter.insert_batch(table_name, cols, chunk)
                inserted += len(chunk)
            except Exception as e:
                log.error("Insert batch %d to %s failed: %s",
                          batch_seq, table_name, e)
                self.ctl.log_batch(ep_id, batch_seq, None,
                                   len(chunk), "FAILED", str(e))
                raise
        return inserted

    # Per-dialect type mappings for CREATE TABLE
    _TYPE_MAPS = {
        "oracle": {
            "string": "VARCHAR2(4000)",
            "integer": "NUMBER(38)",
            "float": "NUMBER",
            "boolean": "NUMBER(1)",
            "datetime": "TIMESTAMP",
            "date": "DATE",
            "object": "CLOB",
            "array": "CLOB",
        },
        "postgresql": {
            "string": "TEXT",
            "integer": "BIGINT",
            "float": "DOUBLE PRECISION",
            "boolean": "BOOLEAN",
            "datetime": "TIMESTAMP",
            "date": "DATE",
            "object": "JSONB",
            "array": "JSONB",
        },
        "mysql": {
            "string": "TEXT",
            "integer": "BIGINT",
            "float": "DOUBLE",
            "boolean": "TINYINT(1)",
            "datetime": "DATETIME",
            "date": "DATE",
            "object": "JSON",
            "array": "JSON",
        },
    }

    def _detect_dialect(self) -> str:
        """Return 'oracle', 'postgresql', or 'mysql' based on adapter class."""
        cls = type(self.adapter).__name__.lower()
        if "oracle" in cls:
            return "oracle"
        if "postgres" in cls:
            return "postgresql"
        if "mysql" in cls:
            return "mysql"
        return "oracle"

    def _derive_columns(self, mappings: list[dict],
                        fields: list[dict]) -> list:
        """Derive column definitions from mappings and field metadata."""
        from app.adapters.base import ColumnDef
        # Build a fallback type lookup from endpoint fields
        field_type_map = {f["name"]: f.get("field_type", "string")
                          for f in fields}
        dialect = self._detect_dialect()
        type_mapping = self._TYPE_MAPS.get(dialect, self._TYPE_MAPS["oracle"])
        default_type = type_mapping["string"]
        columns = []
        for m in mappings:
            src = m.get("source_path", "")
            col_name = m.get("target_column", src)
            # Prefer source_type from the mapping; fall back to field metadata
            ftype = m.get("source_type") or field_type_map.get(src, "string")
            db_type = type_mapping.get(ftype, default_type)
            columns.append(ColumnDef(
                name=col_name, data_type=db_type, nullable=True, primary_key=False))
        return columns
