# ================================================================
#  REST -> ADB Migration Workbench - Server Status
# ================================================================
$ErrorActionPreference = 'Continue'
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition

function Write-Status {
    param([string]$Symbol, [string]$Message, [string]$Colour = 'White')
    Write-Host "  [$Symbol] " -NoNewline -ForegroundColor $Colour
    Write-Host $Message
}
function Write-OK   { param([string]$Msg) Write-Status 'OK'   $Msg 'Green' }
function Write-Fail { param([string]$Msg) Write-Status 'FAIL' $Msg 'Red'   }
function Write-Info { param([string]$Msg) Write-Status '....' $Msg 'Cyan'  }

# Read version
$versionFile = Join-Path $ScriptDir 'VERSION'
$appVersion = 'dev'
if (Test-Path $versionFile) {
    $appVersion = (Get-Content $versionFile -Raw).Trim()
}

Write-Host ''
Write-Host "  REST -> ADB Migration Workbench  v$appVersion" -ForegroundColor Cyan
Write-Host ''

# Read host/port from config
$Host_ = '127.0.0.1'
$Port_ = 8500
$configFile = Join-Path $ScriptDir 'config' 'default.yaml'
if (Test-Path $configFile) {
    $cfgContent = Get-Content $configFile -Raw
    if ($cfgContent -match '^\s+host:\s*(.+)$') { $Host_ = $Matches[1].Trim().Trim('"').Trim("'") }
    if ($cfgContent -match '^\s+port:\s*(\d+)') { $Port_ = [int]$Matches[1] }
}
$serverUrl = "http://${Host_}:${Port_}"

$pidFile = Join-Path $ScriptDir '.server.pid'

if (-not (Test-Path $pidFile)) {
    Write-Fail 'Server is not running (no PID file).'
    exit 1
}

$serverPid = (Get-Content $pidFile -Raw).Trim()

try {
    $proc = Get-Process -Id $serverPid -ErrorAction Stop
    Write-OK "Server process is running (PID $serverPid)"
} catch {
    Write-Fail "Server is not running (PID $serverPid is stale)."
    Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
    exit 1
}

# Check if HTTP is responding
try {
    $null = Invoke-WebRequest -Uri "$serverUrl/api/health" -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
    Write-OK "HTTP responding at $serverUrl"
} catch {
    Write-Fail "Process is running but HTTP is not responding at $serverUrl"
    exit 1
}

Write-Host ''
