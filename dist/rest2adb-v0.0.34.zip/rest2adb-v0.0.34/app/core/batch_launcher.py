"""Batch launcher — runs multiple migration jobs concurrently."""
from __future__ import annotations
import logging
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Callable

log = logging.getLogger("rest2adb.batch")


class BatchLauncher:
    """Launch and manage concurrent batch migration runs."""

    def __init__(self, control: "ControlTableManager"):
        self.ctl = control
        self._active_runs: dict[str, dict] = {}
        self._lock = threading.Lock()

    def start_batch(self, batch_run_id: str, job_runner: Callable[[str], dict],
                    concurrency: int = 5) -> None:
        """Start a batch run in a background thread."""
        t = threading.Thread(
            target=self._execute_batch,
            args=(batch_run_id, job_runner, concurrency),
            daemon=True,
        )
        with self._lock:
            self._active_runs[batch_run_id] = {"thread": t, "cancel": False}
        t.start()

    def cancel_batch(self, batch_run_id: str) -> bool:
        with self._lock:
            run = self._active_runs.get(batch_run_id)
            if run:
                run["cancel"] = True
                return True
        return False

    def get_active_runs(self) -> list[str]:
        with self._lock:
            return list(self._active_runs.keys())

    def _execute_batch(self, batch_run_id: str, job_runner: Callable,
                       concurrency: int) -> None:
        self.ctl.update_batch_run_status(batch_run_id, "RUNNING")
        pending_jobs = self.ctl.get_batch_jobs(batch_run_id, status=["PENDING"])

        any_failed = False
        try:
            with ThreadPoolExecutor(max_workers=concurrency) as pool:
                futures = {}
                for bj in pending_jobs:
                    with self._lock:
                        run = self._active_runs.get(batch_run_id, {})
                        if run.get("cancel"):
                            break
                    job_id = bj["JOB_ID"]
                    self.ctl.update_batch_job_status(batch_run_id, job_id, "RUNNING")
                    f = pool.submit(job_runner, job_id)
                    futures[f] = job_id

                for f in as_completed(futures):
                    job_id = futures[f]
                    try:
                        result = f.result()
                        status = result.get("status", "COMPLETED")
                        self.ctl.update_batch_job_status(
                            batch_run_id, job_id,
                            "COMPLETED" if status == "COMPLETED" else "FAILED")
                        if status != "COMPLETED":
                            any_failed = True
                    except Exception as e:
                        log.error("Batch job %s failed: %s", job_id, e)
                        self.ctl.update_batch_job_status(
                            batch_run_id, job_id, "FAILED")
                        any_failed = True

                    self.ctl.update_batch_counters(batch_run_id)

        except Exception as e:
            log.exception("Batch run %s crashed: %s", batch_run_id, e)
            any_failed = True

        with self._lock:
            run = self._active_runs.get(batch_run_id, {})
            cancelled = run.get("cancel", False)

        if cancelled:
            self.ctl.update_batch_run_status(batch_run_id, "CANCELLED")
        elif any_failed:
            counters = self.ctl.update_batch_counters(batch_run_id)
            if counters["completed"] > 0:
                self.ctl.update_batch_run_status(batch_run_id, "PARTIAL_FAILURE")
            else:
                self.ctl.update_batch_run_status(batch_run_id, "FAILED")
        else:
            self.ctl.update_batch_run_status(batch_run_id, "COMPLETED")

        with self._lock:
            self._active_runs.pop(batch_run_id, None)
        log.info("Batch run %s finished", batch_run_id)
