"""Incremental/delta sync watermark management."""
from __future__ import annotations
import logging
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger("rest2adb.delta")


class DeltaTracker:
    """Tracks sync watermarks for incremental/delta sync."""

    def __init__(self, adapter=None):
        self.adapter = adapter

    def load_sync_state(self, job_id: str, endpoint_path: str) -> dict | None:
        if not self.adapter:
            return None
        try:
            rows = self.adapter.execute_query(
                "SELECT * FROM R2A_SYNC_STATE WHERE JOB_ID = :1 AND ENDPOINT_PATH = :2",
                (job_id, endpoint_path),
            )
            return rows[0] if rows else None
        except Exception as e:
            log.warning("Could not load sync state: %s", e)
            return None

    def save_sync_state(self, state: dict) -> None:
        if not self.adapter:
            return
        existing = self.load_sync_state(state["job_id"], state["endpoint_path"])
        try:
            if existing:
                self.adapter.execute_update(
                    """UPDATE R2A_SYNC_STATE
                       SET LAST_DELTA_VALUE = :1, LAST_ETAG = :2,
                           LAST_SYNC_AT = :3, ROWS_SYNCED = :4
                       WHERE JOB_ID = :5 AND ENDPOINT_PATH = :6""",
                    (state.get("last_delta_value"), state.get("last_etag"),
                     datetime.now(timezone.utc), state.get("rows_synced", 0),
                     state["job_id"], state["endpoint_path"]),
                )
            else:
                from uuid import uuid4
                self.adapter.execute_update(
                    """INSERT INTO R2A_SYNC_STATE
                       (SYNC_STATE_ID, JOB_ID, ENDPOINT_PATH, SYNC_MODE,
                        DELTA_FIELD, DELTA_PARAM, LAST_DELTA_VALUE,
                        LAST_ETAG, LAST_SYNC_AT, ROWS_SYNCED)
                       VALUES (:1,:2,:3,:4,:5,:6,:7,:8,:9,:10)""",
                    (str(uuid4()), state["job_id"], state["endpoint_path"],
                     state.get("sync_mode", "full"), state.get("delta_field"),
                     state.get("delta_param"), state.get("last_delta_value"),
                     state.get("last_etag"), datetime.now(timezone.utc),
                     state.get("rows_synced", 0)),
                )
        except Exception as e:
            log.error("Failed to save sync state: %s", e)

    def build_delta_params(self, sync_state: dict | None, sync_config: dict) -> dict:
        result = {"params": {}, "headers": {}}
        if not sync_state or sync_config.get("sync_mode", "full") == "full":
            return result
        delta_param = sync_config.get("delta_param") or sync_state.get("DELTA_PARAM")
        last_value = sync_state.get("LAST_DELTA_VALUE")
        last_etag = sync_state.get("LAST_ETAG")
        if delta_param and last_value:
            result["params"][delta_param] = last_value
        if last_etag:
            result["headers"]["If-None-Match"] = last_etag
        return result

    def track_delta_value(self, current_max: Any, row: dict, delta_field: str) -> Any:
        value = self._extract_value(row, delta_field)
        if value is None:
            return current_max
        if current_max is None:
            return value
        try:
            if str(value) > str(current_max):
                return value
        except (TypeError, ValueError):
            pass
        return current_max

    def _extract_value(self, row: dict, path: str) -> Any:
        parts = path.split(".")
        current = row
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current
