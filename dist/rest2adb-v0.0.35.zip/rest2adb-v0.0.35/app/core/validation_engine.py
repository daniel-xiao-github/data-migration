"""Data validation rules engine — validates rows before insert, quarantines failures."""
from __future__ import annotations
import logging
import re
import json
from datetime import datetime
from difflib import SequenceMatcher
from typing import Any
from uuid import uuid4

log = logging.getLogger("rest2adb.validation")


class ValidationEngine:
    """Applies validation rules to incoming data rows."""

    def __init__(self, rules: list[dict] | None = None):
        self.rules = rules or []

    def validate_row(self, row: dict, mappings: list[dict]) -> tuple[bool, list[dict]]:
        """Validate a single row against all rules.
        Returns (is_valid, violations) where is_valid=False means ERROR-level violation.
        """
        violations = []
        for rule in self.rules:
            field_path = rule.get("field_path", "")
            value = self._extract_value(row, field_path)
            violation = self._check_rule(value, rule, row)
            if violation:
                violations.append(violation)
        has_error = any(v["severity"] == "error" for v in violations)
        return (not has_error, violations)

    def validate_batch(self, rows: list[dict], mappings: list[dict]
                       ) -> tuple[list[dict], list[dict], list[dict]]:
        """Validate a batch.
        Returns (valid_rows, warning_rows, quarantine_entries).
        """
        valid_rows = []
        quarantine_entries = []
        warning_count = 0
        for row in rows:
            is_valid, violations = self.validate_row(row, mappings)
            if is_valid:
                valid_rows.append(row)
                if violations:
                    warning_count += len(violations)
            else:
                quarantine_entries.append({
                    "quarantine_id": str(uuid4()),
                    "row_data": row,
                    "violations": violations,
                    "severity": "error",
                })
        if warning_count:
            log.info("Batch validation: %d warnings across %d rows", warning_count, len(rows))
        if quarantine_entries:
            log.warning("Batch validation: %d rows quarantined out of %d",
                        len(quarantine_entries), len(rows))
        return valid_rows, [], quarantine_entries

    def _check_rule(self, value: Any, rule: dict, full_row: dict) -> dict | None:
        rule_type = rule.get("rule_type", "")
        config = rule.get("config", {})
        severity = rule.get("severity", "error")
        message = rule.get("message", f"Validation failed: {rule_type}")
        field = rule.get("field_path", "")
        try:
            if rule_type == "required":
                if value is None or (isinstance(value, str) and value.strip() == ""):
                    return {"field": field, "rule": rule_type, "severity": severity,
                            "message": message}
            elif rule_type == "regex":
                pattern = config.get("pattern", "")
                if value is not None and not re.match(pattern, str(value)):
                    return {"field": field, "rule": rule_type, "severity": severity,
                            "message": message}
            elif rule_type == "range":
                if value is not None:
                    try:
                        num = float(value)
                        mn, mx = config.get("min"), config.get("max")
                        if mn is not None and num < float(mn):
                            return {"field": field, "rule": rule_type, "severity": severity,
                                    "message": message}
                        if mx is not None and num > float(mx):
                            return {"field": field, "rule": rule_type, "severity": severity,
                                    "message": message}
                    except (ValueError, TypeError):
                        return {"field": field, "rule": rule_type, "severity": severity,
                                "message": f"Not a number: {value}"}
            elif rule_type == "length":
                if value is not None:
                    s = str(value)
                    mn = config.get("min", 0)
                    mx = config.get("max")
                    if len(s) < mn or (mx is not None and len(s) > mx):
                        return {"field": field, "rule": rule_type, "severity": severity,
                                "message": message}
            elif rule_type == "enum":
                allowed = config.get("values", [])
                if value is not None and str(value) not in [str(v) for v in allowed]:
                    return {"field": field, "rule": rule_type, "severity": severity,
                            "message": message}
            elif rule_type == "type_check":
                target_type = config.get("type", "string")
                if value is not None and not self._can_cast(value, target_type):
                    return {"field": field, "rule": rule_type, "severity": severity,
                            "message": message}
            elif rule_type == "date_format":
                fmt = config.get("format", "%Y-%m-%d")
                if value is not None:
                    try:
                        datetime.strptime(str(value), fmt)
                    except ValueError:
                        return {"field": field, "rule": rule_type, "severity": severity,
                                "message": message}
            elif rule_type == "expression":
                expr = config.get("expr", "")
                if not self._eval_expression(expr, full_row):
                    return {"field": field, "rule": rule_type, "severity": severity,
                            "message": message}
            elif rule_type == "unique":
                pass  # handled at batch level
        except Exception as e:
            log.error("Rule check error for %s/%s: %s", field, rule_type, e)
            return {"field": field, "rule": rule_type, "severity": severity,
                    "message": f"Rule check error: {e}"}
        return None

    def _extract_value(self, row: dict, path: str) -> Any:
        parts = path.split(".")
        current = row
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    def _can_cast(self, value: Any, target_type: str) -> bool:
        try:
            if target_type in ("integer", "int"):
                int(value)
            elif target_type in ("float", "number", "decimal"):
                float(value)
            elif target_type == "boolean":
                if str(value).lower() not in ("true", "false", "1", "0", "yes", "no"):
                    return False
            elif target_type == "date":
                datetime.fromisoformat(str(value))
            return True
        except (ValueError, TypeError):
            return False

    def _eval_expression(self, expr: str, row: dict) -> bool:
        def _replace(m):
            val = self._extract_value(row, m.group(1))
            if val is None:
                return "None"
            return repr(val) if isinstance(val, str) else str(val)
        resolved = re.sub(r'\$\{([^}]+)\}', _replace, expr)
        try:
            return bool(eval(resolved, {"__builtins__": {}}, {}))
        except Exception:
            return False

    @staticmethod
    def auto_suggest_rules(target_columns: list[dict]) -> list[dict]:
        """Suggest validation rules based on target column metadata."""
        rules = []
        for col in target_columns:
            col_name = col.get("name", "").lower()
            data_type = col.get("data_type", "").upper()
            nullable = col.get("nullable", True)
            max_length = col.get("max_length")
            if not nullable:
                rules.append({
                    "id": str(uuid4()), "field_path": col_name,
                    "rule_type": "required", "config": {},
                    "severity": "error",
                    "message": f"{col_name} is required (NOT NULL)",
                })
            if max_length and data_type in ("VARCHAR2", "VARCHAR", "CHAR"):
                rules.append({
                    "id": str(uuid4()), "field_path": col_name,
                    "rule_type": "length", "config": {"max": max_length},
                    "severity": "warning",
                    "message": f"{col_name} exceeds max length {max_length}",
                })
            if data_type in ("NUMBER", "BIGINT", "INTEGER", "INT", "DECIMAL", "NUMERIC"):
                rules.append({
                    "id": str(uuid4()), "field_path": col_name,
                    "rule_type": "type_check", "config": {"type": "number"},
                    "severity": "error",
                    "message": f"{col_name} must be numeric",
                })
            if data_type in ("DATE", "TIMESTAMP", "TIMESTAMPTZ", "DATETIME"):
                rules.append({
                    "id": str(uuid4()), "field_path": col_name,
                    "rule_type": "date_format",
                    "config": {"format": "%Y-%m-%dT%H:%M:%S"},
                    "severity": "error",
                    "message": f"{col_name} must be a valid date/time",
                })
        return rules
