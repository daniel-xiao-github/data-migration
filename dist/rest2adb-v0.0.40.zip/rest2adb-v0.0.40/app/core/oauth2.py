"""OAuth2 authorization code flow with PKCE and token refresh."""
from __future__ import annotations
import hashlib
import base64
import os
import logging
from datetime import datetime, timezone, timedelta
from urllib.parse import urlencode

log = logging.getLogger("rest2adb.oauth2")

try:
    import requests
except ImportError:
    requests = None


class OAuth2Manager:
    """Manages OAuth2 authorization code flow with PKCE."""

    def __init__(self, config: dict | None = None):
        self.config = config or {}
        self._pending_states: dict[str, dict] = {}
        self._tokens: dict[str, dict] = {}

    def generate_auth_url(self, connection_id: str, oauth_config: dict) -> str:
        state = base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip("=")
        params = {
            "response_type": "code",
            "client_id": oauth_config["client_id"],
            "redirect_uri": oauth_config.get("redirect_uri",
                                              "http://localhost:8500/oauth/callback"),
            "state": state,
            "scope": " ".join(oauth_config.get("scopes", [])),
        }
        pending = {"connection_id": connection_id, "oauth_config": oauth_config}
        if oauth_config.get("use_pkce", True):
            verifier = base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip("=")
            challenge = base64.urlsafe_b64encode(
                hashlib.sha256(verifier.encode()).digest()
            ).decode().rstrip("=")
            params["code_challenge"] = challenge
            params["code_challenge_method"] = "S256"
            pending["code_verifier"] = verifier
        if oauth_config.get("realm"):
            params["realm"] = oauth_config["realm"]
        params.update(oauth_config.get("extra_params", {}))
        self._pending_states[state] = pending
        auth_url = oauth_config["authorization_url"]
        sep = "&" if "?" in auth_url else "?"
        return f"{auth_url}{sep}{urlencode(params)}"

    def handle_callback(self, code: str, state: str) -> dict:
        if state not in self._pending_states:
            raise ValueError("Invalid or expired state parameter")
        pending = self._pending_states.pop(state)
        oauth_config = pending["oauth_config"]
        connection_id = pending["connection_id"]
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": oauth_config.get("redirect_uri",
                                              "http://localhost:8500/oauth/callback"),
            "client_id": oauth_config["client_id"],
        }
        if oauth_config.get("client_secret"):
            data["client_secret"] = oauth_config["client_secret"]
        if "code_verifier" in pending:
            data["code_verifier"] = pending["code_verifier"]
        resp = requests.post(oauth_config["token_url"], data=data, timeout=30)
        resp.raise_for_status()
        tokens = resp.json()
        token_store = {
            "connection_id": connection_id,
            "access_token": tokens["access_token"],
            "refresh_token": tokens.get("refresh_token"),
            "token_type": tokens.get("token_type", "Bearer"),
            "expires_at": (
                datetime.now(timezone.utc)
                + timedelta(seconds=tokens.get("expires_in", 3600))
            ).isoformat(),
            "scopes": oauth_config.get("scopes", []),
        }
        self._tokens[connection_id] = token_store
        return token_store

    def get_valid_token(self, connection_id: str, oauth_config: dict | None = None) -> str | None:
        token = self._tokens.get(connection_id)
        if not token:
            return None
        expires_at = datetime.fromisoformat(token["expires_at"])
        margin = timedelta(seconds=self.config.get("token_refresh_margin", 300))
        if expires_at <= datetime.now(timezone.utc) + margin:
            if token.get("refresh_token") and oauth_config:
                self._refresh_token(connection_id, token["refresh_token"], oauth_config)
                token = self._tokens.get(connection_id)
                if not token:
                    return None
        return token.get("access_token")

    def _refresh_token(self, connection_id: str, refresh_token: str,
                       oauth_config: dict) -> None:
        try:
            data = {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": oauth_config["client_id"],
            }
            if oauth_config.get("client_secret"):
                data["client_secret"] = oauth_config["client_secret"]
            resp = requests.post(oauth_config["token_url"], data=data, timeout=30)
            resp.raise_for_status()
            tokens = resp.json()
            self._tokens[connection_id] = {
                "connection_id": connection_id,
                "access_token": tokens["access_token"],
                "refresh_token": tokens.get("refresh_token", refresh_token),
                "token_type": tokens.get("token_type", "Bearer"),
                "expires_at": (
                    datetime.now(timezone.utc)
                    + timedelta(seconds=tokens.get("expires_in", 3600))
                ).isoformat(),
                "scopes": self._tokens.get(connection_id, {}).get("scopes", []),
            }
            log.info("Token refreshed for connection %s", connection_id)
        except Exception as e:
            log.error("Token refresh failed for %s: %s", connection_id, e)
            self._tokens.pop(connection_id, None)

    def revoke_token(self, connection_id: str) -> bool:
        return self._tokens.pop(connection_id, None) is not None

    def get_token_status(self, connection_id: str) -> dict:
        token = self._tokens.get(connection_id)
        if not token:
            return {"authorized": False, "connection_id": connection_id}
        expires_at = datetime.fromisoformat(token["expires_at"])
        return {
            "authorized": True,
            "connection_id": connection_id,
            "expires_at": token["expires_at"],
            "expired": expires_at <= datetime.now(timezone.utc),
            "has_refresh_token": bool(token.get("refresh_token")),
            "scopes": token.get("scopes", []),
        }

    def store_token(self, connection_id: str, token_data: dict) -> None:
        self._tokens[connection_id] = token_data

    def export_tokens(self) -> dict:
        return dict(self._tokens)

    def import_tokens(self, tokens: dict) -> None:
        self._tokens.update(tokens)
