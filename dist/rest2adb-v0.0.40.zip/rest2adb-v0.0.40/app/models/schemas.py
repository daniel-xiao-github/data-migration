from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from app.models.enums import (
    AuthType,
    BatchStatus,
    EndpointStatus,
    JobStatus,
    PaginationType,
    RuleType,
    Severity,
    SourceType,
    SyncMode,
    TargetType,
    TransformType,
    WriteMode,
)


class OAuth2AuthCodeConfig(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    authorization_url: str
    token_url: str
    client_id: str
    client_secret: Optional[str] = None
    scopes: list[str] = Field(default_factory=list)
    redirect_uri: str = "http://localhost:8500/oauth/callback"
    realm: Optional[str] = None
    use_pkce: bool = True
    extra_params: dict = Field(default_factory=dict)


class RestConnection(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    base_url: str
    source_type: SourceType = SourceType.REST_GET
    auth_type: AuthType = AuthType.NONE
    auth_config: dict = Field(default_factory=dict)
    oauth2_config: Optional[OAuth2AuthCodeConfig] = None
    openapi_url: Optional[str] = None
    graphql_url: Optional[str] = None
    headers: dict = Field(default_factory=dict)
    timeout_seconds: int = 30
    verify_ssl: bool = True


class TargetConnection(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    target_type: TargetType
    dsn: Optional[str] = None
    connect_method: Optional[str] = None
    wallet_path: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    username: str
    password: str
    min_connections: int = 2
    max_connections: int = 10


class PaginationConfig(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    type: PaginationType
    page_size: int = 100
    param_names: dict = Field(default_factory=dict)
    total_field: Optional[str] = None


class FieldInfo(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    name: str
    path: str
    field_type: str = "string"
    nullable: bool = True
    description: Optional[str] = None
    sample_value: Optional[Any] = None


class EndpointParam(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    name: str
    location: str
    required: bool = False
    param_type: str = "string"


class DiscoveredEndpoint(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    path: str
    http_method: str = "GET"
    summary: Optional[str] = None
    parameters: list[EndpointParam] = Field(default_factory=list)
    fields: list[FieldInfo] = Field(default_factory=list)
    pagination: Optional[PaginationConfig] = None
    sample_data: Optional[list[dict]] = None
    metadata_source: str = "sample"


class Transform(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    type: TransformType
    config: dict = Field(default_factory=dict)


class FieldMapping(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    source_path: str
    target_column: str
    transform: Optional[Transform] = None
    confidence: float = 1.0
    is_manual: bool = False


class ValidationRule(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    field_path: str
    rule_type: RuleType
    config: dict = Field(default_factory=dict)
    severity: Severity = Severity.ERROR
    message: str = ""


class MigrationJob(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    status: JobStatus = JobStatus.CREATED
    rest_connection_id: str
    target_connection_id: str
    config_json: dict = Field(default_factory=dict)
    sync_mode: SyncMode = SyncMode.FULL
    write_mode: WriteMode = WriteMode.INSERT
    created_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    total_endpoints: int = 0
    completed_endpoints: int = 0
    total_rows_migrated: int = 0


class EndpointState(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    job_id: str
    endpoint_path: str
    target_table: str
    status: EndpointStatus = EndpointStatus.PENDING
    last_page_cursor: Optional[str] = None
    last_successful_batch: int = 0
    rows_fetched: int = 0
    rows_inserted: int = 0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None
    retry_count: int = 0


class BatchRun(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    batch_run_id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    job_ids: list[str] = Field(default_factory=list)
    concurrency: int = 5
    status: BatchStatus = BatchStatus.CREATED
    created_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    total_jobs: int = 0
    completed_jobs: int = 0
    failed_jobs: int = 0


class SyncState(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    sync_state_id: str = Field(default_factory=lambda: str(uuid4()))
    job_id: str
    endpoint_path: str
    sync_mode: SyncMode = SyncMode.FULL
    delta_field: Optional[str] = None
    delta_param: Optional[str] = None
    last_delta_value: Optional[str] = None
    last_etag: Optional[str] = None
    last_sync_at: Optional[datetime] = None
    rows_synced: int = 0


class TokenStore(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    connection_id: str
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "Bearer"
    expires_at: Optional[datetime] = None
    scopes: list[str] = Field(default_factory=list)


class PostEndpoint(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    url: str
    body_template: dict = Field(default_factory=dict)
    pagination_in_body: bool = False
    data_root_path: str = "$.data"


class GraphQLEndpoint(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    url: str
    query: str
    variables: dict = Field(default_factory=dict)
    pagination_variable: Optional[str] = None
    data_root_path: str = "data"


class ManualEndpoint(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    url: str
    http_method: str = "GET"
    headers: dict = Field(default_factory=dict)
    query_params: dict = Field(default_factory=dict)
    body_template: Optional[dict] = None
    data_root_path: str = "$.data"
    pagination: Optional[PaginationConfig] = None
    source_type: SourceType = SourceType.REST_GET


class QuarantineEntry(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    quarantine_id: str = Field(default_factory=lambda: str(uuid4()))
    job_id: str
    endpoint_path: str
    batch_seq: int
    row_data: dict
    violations: list[dict]
    severity: Severity
    created_at: Optional[datetime] = None
    resolved: bool = False
