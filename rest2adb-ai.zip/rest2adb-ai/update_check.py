#!/usr/bin/env python3
"""Auto-update checker for restapi2adb.

Checks the GitHub data-migration repository's release branch for a newer
version.  When an update is available, downloads the dist zip, extracts it,
and overlays code files while preserving all user data (config/ and data/).
"""

import logging
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

PROJECT_ROOT = Path(__file__).resolve().parent
_VERSION_FILE = PROJECT_ROOT / "VERSION"
_LOG_FILE = PROJECT_ROOT / "data" / "logs" / "update.log"

# GitHub repository hosting the dist zip
GITHUB_REPO = "daniel-xiao-github/data-migration"
RELEASE_BRANCH = "release/rest2adb-ai"
_RAW_BASE = f"https://raw.githubusercontent.com/{GITHUB_REPO}/{RELEASE_BRANCH}"
REMOTE_VERSION_URL = f"{_RAW_BASE}/VERSION"
REMOTE_ZIP_URL = f"{_RAW_BASE}/rest2adb-ai.zip"

# Directories that contain user data and must NEVER be overwritten
PRESERVE_DIRS = {"config", "data"}


def _setup_file_logger() -> None:
    """Append update activity to data/logs/update.log."""
    _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    handler = logging.FileHandler(_LOG_FILE, encoding="utf-8")
    handler.setFormatter(
        logging.Formatter("[%(asctime)s] [%(levelname)s] %(message)s")
    )
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)


def get_local_version() -> str:
    """Read the version from the VERSION file at the project root."""
    try:
        return _VERSION_FILE.read_text().strip()
    except FileNotFoundError:
        return "0.0.0"


def _parse_semver(version: str) -> tuple[int, ...]:
    """Parse a semver string into a comparable tuple."""
    parts = re.findall(r"\d+", version)
    return tuple(int(p) for p in parts)


def _fetch_remote_version() -> Optional[str]:
    """Fetch the remote VERSION file from the GitHub release branch."""
    try:
        import requests
        resp = requests.get(REMOTE_VERSION_URL, timeout=15)
        resp.raise_for_status()
        return resp.text.strip()
    except Exception as exc:
        logger.warning("Failed to fetch remote version: %s", exc)
        return None


def check_for_update() -> Optional[dict]:
    """Compare local and remote versions.

    Returns:
        Dict with ``remote_version`` and ``local_version`` if a newer
        version is available, otherwise ``None``.
    """
    remote = _fetch_remote_version()
    if remote is None:
        return None

    local = get_local_version()
    if _parse_semver(remote) > _parse_semver(local):
        logger.info("Update available: %s → %s", local, remote)
        return {"remote_version": remote, "local_version": local}

    logger.info("rest2adb-ai is up to date (v%s).", local)
    return None


def apply_update() -> bool:
    """Download the dist zip and overlay code files, preserving user data.

    Preserved directories (config/, data/) are never overwritten.
    All other files and directories are replaced from the new distribution.

    Returns:
        True on success, False on failure.
    """
    import requests

    local_version = get_local_version()
    logger.info("Downloading update from %s ...", REMOTE_ZIP_URL)
    print("Downloading update...")

    try:
        resp = requests.get(REMOTE_ZIP_URL, timeout=120, stream=True)
        resp.raise_for_status()
    except Exception as exc:
        logger.error("Download failed: %s", exc)
        print(f"Download failed: {exc}")
        return False

    tmpdir = tempfile.mkdtemp(prefix="rest2adb_update_")
    zip_path = Path(tmpdir) / "rest2adb-ai.zip"
    try:
        # Save zip to temp
        with open(zip_path, "wb") as fh:
            for chunk in resp.iter_content(chunk_size=8192):
                fh.write(chunk)
        logger.info("Downloaded %d bytes.", zip_path.stat().st_size)

        # Extract
        extract_dir = Path(tmpdir) / "extracted"
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)

        # The zip contains a top-level rest2adb-ai/ directory
        source_dir = extract_dir / "rest2adb-ai"
        if not source_dir.is_dir():
            # Fallback: maybe files are at the root of the zip
            source_dir = extract_dir

        # Overlay: copy everything EXCEPT preserved directories
        updated_files = 0
        for item in source_dir.iterdir():
            dest = PROJECT_ROOT / item.name
            if item.name in PRESERVE_DIRS:
                logger.info("Preserving user directory: %s/", item.name)
                continue
            if item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, dest)
            updated_files += 1

        logger.info("Overlay complete – %d top-level items updated.", updated_files)
        print(f"Update applied: v{local_version} → v{get_local_version()}")
        return True

    except Exception as exc:
        logger.error("Update failed: %s", exc)
        print(f"Update failed: {exc}")
        return False
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def main() -> None:
    """CLI entry-point for the update checker."""
    _setup_file_logger()

    if "--skip-update" in sys.argv:
        print("Update check skipped (--skip-update).")
        return

    local = get_local_version()
    print(f"rest2adb-ai v{local} – checking for updates...")

    info = check_for_update()
    if info is None:
        print(f"rest2adb-ai is up to date (v{local}).")
        return

    remote = info["remote_version"]
    print(f"\nA new version is available: v{remote} (current: v{local})")
    answer = input("Download and install the update now? (Y/n): ").strip().lower()

    if answer in ("", "y", "yes"):
        if apply_update():
            print("\nUpdate installed successfully.")
            print("Please restart rest2adb-ai for changes to take effect.")
            print("  ./restart.sh  (Linux/macOS)")
            print("  restart.bat   (Windows)")
            logger.info("Update to v%s completed. Restart required.", remote)
        else:
            print("\nUpdate failed. rest2adb-ai will continue with the current version.")
            logger.error("Update to v%s failed.", remote)
    else:
        print("Update skipped.")
        logger.info("User declined update to v%s.", remote)


if __name__ == "__main__":
    main()
