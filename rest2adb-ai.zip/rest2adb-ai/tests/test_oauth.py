"""Tests for OAuth 2.0 manager module."""

import json
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from app.auth.oauth_manager import (
    save_config,
    load_all_configs,
    get_config,
    delete_config,
    build_authorization_url,
    get_token_status,
    _safe_app_key,
)


class TestSafeAppKey:
    """Tests for app key normalisation."""

    def test_basic_name(self):
        assert _safe_app_key("QuickBooks Online") == "quickbooks_online"

    def test_hyphenated_name(self):
        assert _safe_app_key("Hub-Spot") == "hub_spot"

    def test_lowercase_passthrough(self):
        assert _safe_app_key("asana") == "asana"


class TestOAuthConfigValidation:
    """Tests for OAuth config validation."""

    def test_missing_required_fields(self):
        errors = save_config({})
        assert len(errors) > 0
        assert any("app_name" in e for e in errors)

    def test_invalid_url(self):
        cfg = {
            "app_name": "Test App",
            "api_base_url": "not-a-url",
            "authorization_url": "https://example.com/auth",
            "token_url": "https://example.com/token",
            "client_id": "test-client",
            "client_secret": "test-secret",
        }
        errors = save_config(cfg)
        assert any("api_base_url" in e for e in errors)


class TestTokenStatus:
    """Tests for token status retrieval."""

    def test_no_token(self):
        status = get_token_status("nonexistent_app")
        assert status["has_token"] is False
        assert status["is_valid"] is False


class TestBuildAuthorizationUrl:
    """Tests for authorization URL construction."""

    def test_missing_config_returns_none(self):
        url = build_authorization_url("nonexistent", "http://localhost/callback")
        assert url is None

    @patch("app.auth.oauth_manager.get_config")
    def test_builds_url_with_params(self, mock_get):
        mock_get.return_value = {
            "client_id": "my-client",
            "authorization_url": "https://example.com/authorize",
            "scopes": "read write",
            "additional_params": {},
        }
        url = build_authorization_url("test", "http://localhost/callback")
        assert url is not None
        assert "client_id=my-client" in url
        assert "scope=read+write" in url
