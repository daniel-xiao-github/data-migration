"""Tests for Oracle ADB connection module."""

import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path

from app.oracle.adb_connection import (
    extract_tns_aliases,
    save_adb_credentials,
    load_adb_credentials,
)
from app.utils.secret_manager import (
    encrypt_value,
    decrypt_value,
    get_or_create_key,
)
from app.utils.validators import (
    is_valid_url,
    is_valid_oracle_identifier,
    sanitize_oracle_identifier,
    validate_port,
    validate_batch_size,
    validate_json_path,
    validate_mapping_column,
)


class TestSecretManager:
    """Tests for Fernet encryption/decryption."""

    def test_encrypt_decrypt_roundtrip(self, tmp_path):
        key_path = tmp_path / ".test_key"
        plaintext = "my-secret-api-key-12345"
        encrypted = encrypt_value(plaintext, key_path)
        assert encrypted != plaintext.encode()
        decrypted = decrypt_value(encrypted, key_path)
        assert decrypted == plaintext

    def test_key_generation(self, tmp_path):
        key_path = tmp_path / ".test_key"
        assert not key_path.exists()
        key = get_or_create_key(key_path)
        assert key_path.exists()
        assert len(key) > 20

    def test_key_persistence(self, tmp_path):
        key_path = tmp_path / ".test_key"
        key1 = get_or_create_key(key_path)
        key2 = get_or_create_key(key_path)
        assert key1 == key2


class TestValidators:
    """Tests for input validation utilities."""

    def test_valid_urls(self):
        assert is_valid_url("https://api.example.com")
        assert is_valid_url("http://localhost:5100/callback")
        assert not is_valid_url("not-a-url")
        assert not is_valid_url("")

    def test_oracle_identifiers(self):
        assert is_valid_oracle_identifier("CUSTOMER_ID")
        assert is_valid_oracle_identifier("T1")
        assert not is_valid_oracle_identifier("1_BAD")
        assert not is_valid_oracle_identifier("")
        assert not is_valid_oracle_identifier("a" * 200)

    def test_sanitize_oracle_identifier(self):
        assert sanitize_oracle_identifier("customer-id") == "CUSTOMER_ID"
        assert sanitize_oracle_identifier("my table name") == "MY_TABLE_NAME"
        assert sanitize_oracle_identifier("123bad") == "T_123BAD"

    def test_port_validation(self):
        assert validate_port(5100)
        assert validate_port(1)
        assert validate_port(65535)
        assert not validate_port(0)
        assert not validate_port(70000)
        assert not validate_port(-1)

    def test_batch_size_validation(self):
        assert validate_batch_size(500)
        assert validate_batch_size(1)
        assert validate_batch_size(10000)
        assert not validate_batch_size(0)
        assert not validate_batch_size(20000)

    def test_json_path_validation(self):
        assert validate_json_path("$.id")
        assert validate_json_path("$.customer.ref.value")
        assert not validate_json_path("id")
        assert not validate_json_path("")

    def test_mapping_column_validation(self):
        good_col = {
            "source_path": "$.id",
            "target_column": "ITEM_ID",
            "oracle_type": "NUMBER(38)",
        }
        assert validate_mapping_column(good_col) == []

        bad_col = {
            "source_path": "",
            "target_column": "",
            "oracle_type": "",
        }
        errors = validate_mapping_column(bad_col)
        assert len(errors) >= 3


class TestExtractTnsAliases:
    """Tests for wallet TNS alias extraction."""

    @patch("app.oracle.adb_connection.zipfile.ZipFile")
    def test_extracts_aliases(self, mock_zip_class):
        tnsnames_content = b"""mydb_high = (DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)...))
mydb_medium = (DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)...))
mydb_low = (DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)...))"""
        mock_zip = MagicMock()
        mock_zip.__enter__ = MagicMock(return_value=mock_zip)
        mock_zip.__exit__ = MagicMock(return_value=False)
        mock_zip.namelist.return_value = ["tnsnames.ora"]
        mock_zip.read.return_value = tnsnames_content
        mock_zip_class.return_value = mock_zip

        aliases = extract_tns_aliases("/fake/wallet.zip")
        assert "mydb_high" in aliases
        assert "mydb_medium" in aliases
        assert "mydb_low" in aliases

    def test_nonexistent_wallet(self):
        aliases = extract_tns_aliases("/nonexistent/path.zip")
        assert aliases == []
