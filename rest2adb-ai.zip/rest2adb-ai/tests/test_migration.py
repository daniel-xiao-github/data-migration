"""Tests for migration engine and related modules."""

import pytest
from unittest.mock import patch, MagicMock

from app.migration.batch_manager import BatchManager
from app.migration.resume_handler import ResumeHandler
from app.oracle.data_loader import _extract_json_path, apply_transforms
from app.oracle.table_manager import (
    generate_create_table_ddl,
    generate_merge_sql,
    _generate_insert_sql,
)


class TestExtractJsonPath:
    """Tests for JSON path extraction."""

    def test_simple_path(self):
        data = {"id": 42, "name": "Test"}
        assert _extract_json_path(data, "$.id") == 42

    def test_nested_path(self):
        data = {"customer": {"ref": {"value": "C123"}}}
        assert _extract_json_path(data, "$.customer.ref.value") == "C123"

    def test_missing_key(self):
        data = {"id": 1}
        assert _extract_json_path(data, "$.missing.key") is None

    def test_empty_path(self):
        assert _extract_json_path({"id": 1}, "") is None

    def test_no_dollar_prefix(self):
        assert _extract_json_path({"id": 1}, "id") is None


class TestApplyTransforms:
    """Tests for row transformation logic."""

    def test_basic_transform(self):
        columns = [
            {"source_path": "$.id", "target_column": "ID", "oracle_type": "NUMBER(38)"},
            {"source_path": "$.name", "target_column": "NAME", "oracle_type": "VARCHAR2(100)"},
        ]
        row = {"id": 1, "name": "Test Item"}
        result = apply_transforms(row, columns)
        assert result["ID"] == 1
        assert result["NAME"] == "Test Item"

    def test_nested_transform(self):
        columns = [
            {"source_path": "$.ref.value", "target_column": "REF_VALUE", "oracle_type": "VARCHAR2(50)"},
        ]
        row = {"ref": {"value": "R42"}}
        result = apply_transforms(row, columns)
        assert result["REF_VALUE"] == "R42"

    def test_boolean_transform(self):
        columns = [
            {
                "source_path": "$.active",
                "target_column": "IS_ACTIVE",
                "oracle_type": "NUMBER(1)",
                "transform": "true→1, false→0",
            },
        ]
        result = apply_transforms({"active": True}, columns)
        assert result["IS_ACTIVE"] == 1

        result = apply_transforms({"active": False}, columns)
        assert result["IS_ACTIVE"] == 0


class TestGenerateDDL:
    """Tests for DDL generation."""

    def test_simple_table(self):
        mapping = {
            "target_table": "STG_TEST_ITEMS",
            "target_schema": "MIGRATION",
            "columns": [
                {"target_column": "ITEM_ID", "oracle_type": "NUMBER(38)",
                 "is_primary_key": True, "is_nullable": False},
                {"target_column": "ITEM_NAME", "oracle_type": "VARCHAR2(200)",
                 "is_primary_key": False, "is_nullable": True},
            ],
        }
        ddl = generate_create_table_ddl(mapping)
        assert "CREATE TABLE MIGRATION.STG_TEST_ITEMS" in ddl
        assert "ITEM_ID" in ddl
        assert "ITEM_NAME" in ddl
        assert "NOT NULL" in ddl
        assert "PRIMARY KEY" in ddl
        assert "MIGRATION_LOADED_AT" in ddl

    def test_no_primary_key(self):
        mapping = {
            "target_table": "STG_TEST",
            "target_schema": "",
            "columns": [
                {"target_column": "COL1", "oracle_type": "VARCHAR2(50)",
                 "is_primary_key": False, "is_nullable": True},
            ],
        }
        ddl = generate_create_table_ddl(mapping)
        assert "PRIMARY KEY" not in ddl


class TestGenerateMergeSQL:
    """Tests for MERGE/INSERT SQL generation."""

    def test_merge_with_pk(self):
        mapping = {
            "target_table": "STG_ITEMS",
            "target_schema": "MIGRATION",
            "columns": [
                {"target_column": "ID", "oracle_type": "NUMBER", "is_primary_key": True},
                {"target_column": "NAME", "oracle_type": "VARCHAR2(100)", "is_primary_key": False},
            ],
        }
        sql = generate_merge_sql(mapping)
        assert "MERGE INTO" in sql
        assert "WHEN MATCHED" in sql
        assert "WHEN NOT MATCHED" in sql

    def test_insert_without_pk(self):
        mapping = {
            "target_table": "STG_LOG",
            "target_schema": "",
            "columns": [
                {"target_column": "MSG", "oracle_type": "VARCHAR2(500)", "is_primary_key": False},
            ],
        }
        sql = _generate_insert_sql(mapping)
        assert "INSERT INTO" in sql


class TestBatchManager:
    """Tests for batch manager."""

    def test_pause_resume(self):
        bm = BatchManager(max_workers=2)
        assert not bm.is_paused
        bm.pause()
        assert bm.is_paused
        bm.resume()
        assert not bm.is_paused

    def test_cancel(self):
        bm = BatchManager(max_workers=1)
        assert not bm.is_cancelled
        bm.cancel()
        assert bm.is_cancelled

    def test_initial_stats(self):
        bm = BatchManager()
        stats = bm.get_stats()
        assert isinstance(stats, dict)


class TestResumeHandler:
    """Tests for resume handler (with mocked control tables)."""

    @patch("app.migration.resume_handler.ct.get_job")
    def test_analyse_missing_job(self, mock_get_job):
        mock_get_job.return_value = None
        handler = ResumeHandler(job_id=999)
        result = handler.analyse()
        assert result["can_resume"] is False
        assert "not found" in result.get("error", "")

    @patch("app.migration.resume_handler.ct.get_tasks_for_job")
    @patch("app.migration.resume_handler.ct.get_job")
    def test_analyse_with_failed_tasks(self, mock_job, mock_tasks):
        mock_job.return_value = {"JOB_ID": 1, "STATUS": "FAILED"}
        mock_tasks.return_value = [
            {"TASK_ID": 1, "STATUS": "COMPLETED", "ENDPOINT_PATH": "/a", "TARGET_TABLE": "T1",
             "RECORDS_LOADED": 100, "RETRY_COUNT": 0, "MAX_RETRIES": 3,
             "LAST_OFFSET": 0, "LAST_PAGE_TOKEN": "", "LAST_CURSOR": ""},
            {"TASK_ID": 2, "STATUS": "FAILED", "ENDPOINT_PATH": "/b", "TARGET_TABLE": "T2",
             "RECORDS_LOADED": 50, "RETRY_COUNT": 1, "MAX_RETRIES": 3,
             "LAST_OFFSET": 50, "LAST_PAGE_TOKEN": "", "LAST_CURSOR": ""},
        ]
        handler = ResumeHandler(job_id=1)
        result = handler.analyse()
        assert result["can_resume"] is True
        assert result["completed_tasks"] == 1
        assert result["failed_tasks"] == 1
        assert result["resumable_tasks"] == 1
