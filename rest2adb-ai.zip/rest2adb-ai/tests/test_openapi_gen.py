"""Tests for OpenAPI specification generator."""

import json
import pytest
from unittest.mock import patch, MagicMock

from app.ai.openapi_generator import (
    validate_openapi_spec,
    get_spec_summary,
)


class TestValidateOpenAPISpec:
    """Tests for OpenAPI spec validation."""

    def test_valid_spec(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Test API", "version": "1.0"},
            "servers": [{"url": "https://api.example.com"}],
            "paths": {
                "/items": {
                    "get": {
                        "operationId": "listItems",
                        "summary": "List items",
                        "responses": {"200": {"description": "OK"}},
                    }
                }
            },
        }
        errors = validate_openapi_spec(spec)
        assert errors == []

    def test_missing_info(self):
        spec = {"openapi": "3.0.0", "paths": {"/x": {"get": {}}}, "servers": [{"url": "https://a.com"}]}
        errors = validate_openapi_spec(spec)
        assert any("info" in e for e in errors)

    def test_no_paths(self):
        spec = {"openapi": "3.0.0", "info": {"title": "T", "version": "1"}, "servers": [{"url": "https://a.com"}]}
        errors = validate_openapi_spec(spec)
        assert any("paths" in e.lower() or "No paths" in e for e in errors)

    def test_non_get_method_detected(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "T", "version": "1"},
            "servers": [{"url": "https://a.com"}],
            "paths": {"/items": {"post": {"summary": "Create"}}},
        }
        errors = validate_openapi_spec(spec)
        assert any("Non-GET" in e or "post" in e.lower() for e in errors)

    def test_not_a_dict(self):
        errors = validate_openapi_spec("not a dict")
        assert len(errors) > 0

    def test_missing_servers(self):
        spec = {"openapi": "3.0.0", "info": {"title": "T", "version": "1"}, "paths": {"/x": {"get": {}}}}
        errors = validate_openapi_spec(spec)
        assert any("servers" in e.lower() for e in errors)


class TestGetSpecSummary:
    """Tests for spec summary generation."""

    def test_summary_counts_endpoints(self):
        spec = {
            "info": {"title": "My API", "version": "2.0"},
            "servers": [{"url": "https://api.example.com"}],
            "paths": {
                "/a": {"get": {"operationId": "getA", "parameters": [{"name": "p1"}]}},
                "/b": {"get": {"operationId": "getB", "parameters": []}},
            },
        }
        summary = get_spec_summary(spec)
        assert summary["title"] == "My API"
        assert summary["endpoint_count"] == 2
        assert summary["server_url"] == "https://api.example.com"
        assert len(summary["endpoints"]) == 2

    def test_empty_spec_summary(self):
        summary = get_spec_summary({})
        assert summary["endpoint_count"] == 0
