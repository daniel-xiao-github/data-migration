"""Test suite for restapi2adb."""
