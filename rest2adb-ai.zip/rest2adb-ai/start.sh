#!/bin/bash
# rest2adb-ai – Start Script (Linux/macOS)
# Checks Python availability, installs required libraries if absent,
# then launches the application.
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

APP_NAME="rest2adb-ai"
PID_FILE="data/.pid"
LOG_DIR="data/logs"
LOG_FILE="$LOG_DIR/service.log"
REQUIREMENTS="requirements.txt"

mkdir -p "$LOG_DIR"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [START] $1" | tee -a "$LOG_FILE"
}

# ── Parse port argument ───────────────────────────────────────────────
PORT="${1:-5100}"
if [[ "$1" == "--port" ]]; then
    PORT="${2:-5100}"
fi

# ── Check if already running ─────────────────────────────────────────
if [ -f "$PID_FILE" ]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
        log "$APP_NAME is already running (PID: $OLD_PID). Use restart.sh to restart."
        exit 1
    else
        log "Stale PID file found. Cleaning up."
        rm -f "$PID_FILE"
    fi
fi

# ── Step 1: Check for Python 3.10+ ───────────────────────────────────
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        major=$("$cmd" -c "import sys; print(sys.version_info.major)" 2>/dev/null)
        minor=$("$cmd" -c "import sys; print(sys.version_info.minor)" 2>/dev/null)
        if [ "$major" -ge 3 ] 2>/dev/null && [ "$minor" -ge 10 ] 2>/dev/null; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    echo "ERROR: Python 3.10 or higher is required but was not found."
    echo "Please install Python 3.10+ from https://www.python.org/downloads/"
    exit 1
fi

echo "Using $PYTHON ($($PYTHON --version 2>&1))"

# ── Step 2: Check and install required Python libraries ──────────────
check_and_install_deps() {
    if [ ! -f "$REQUIREMENTS" ]; then
        log "WARNING: $REQUIREMENTS not found. Skipping dependency check."
        return 0
    fi

    MISSING=()
    while IFS= read -r line || [ -n "$line" ]; do
        # Skip blank lines and comments
        line=$(echo "$line" | sed 's/#.*//' | xargs)
        [ -z "$line" ] && continue

        # Strip platform markers (e.g. ;platform_system!="Windows")
        pkg=$(echo "$line" | sed 's/;.*//')

        # Extract package name (before any version operator)
        pkg_name=$(echo "$pkg" | sed 's/[><=!~].*//' | xargs)
        [ -z "$pkg_name" ] && continue

        # Check if installed
        if ! $PYTHON -c "import importlib.metadata; importlib.metadata.version('$pkg_name')" 2>/dev/null; then
            MISSING+=("$pkg")
        fi
    done < "$REQUIREMENTS"

    if [ ${#MISSING[@]} -eq 0 ]; then
        log "All required Python libraries are installed."
        return 0
    fi

    echo ""
    echo "The following required Python libraries are not installed:"
    echo ""
    for pkg in "${MISSING[@]}"; do
        echo "  - $pkg"
    done
    echo ""
    read -rp "Install them now? (Y/n): " answer
    answer=${answer:-Y}

    if [[ "$answer" =~ ^[Yy]$ ]]; then
        log "Installing ${#MISSING[@]} missing Python libraries..."
        if $PYTHON -m pip install "${MISSING[@]}"; then
            log "All libraries installed successfully."
        else
            log "ERROR: Some libraries failed to install. Check the output above."
            exit 1
        fi
    else
        echo "Cannot start $APP_NAME without required libraries."
        exit 1
    fi
}

check_and_install_deps

# ── Step 3: Run environment / config check ───────────────────────────
log "Running environment check..."
$PYTHON setup_check.py --auto-check || exit 1

# ── Step 4: Check for updates ─────────────────────────────────────────
log "Checking for updates..."
$PYTHON update_check.py || true

# ── Step 5: Start the application ────────────────────────────────────
log "Starting $APP_NAME on port $PORT..."
nohup $PYTHON -m app.main --port "$PORT" >> "$LOG_DIR/app.log" 2>&1 &
echo $! > "$PID_FILE"

log "$APP_NAME started on port $PORT (PID: $(cat "$PID_FILE"))"
echo "$APP_NAME started on port $PORT (PID: $(cat "$PID_FILE"))"
echo "View logs: tail -f $LOG_DIR/app.log"

# ── Step 6: Auto-launch web browser ────────────────────────────────
sleep 2  # Give the server a moment to initialize
URL="http://localhost:$PORT"
log "Opening $URL in default browser..."
if command -v xdg-open &>/dev/null; then
    xdg-open "$URL" 2>/dev/null &
elif command -v open &>/dev/null; then
    open "$URL" 2>/dev/null &
else
    log "Could not detect a browser launcher. Please open $URL manually."
fi
