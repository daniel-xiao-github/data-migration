"""Resume-from-failure logic for migration jobs.

Reads the last checkpoint for each failed or running task and
provides the information needed to continue from that point.
"""

import logging
from typing import Any, Optional

from app.migration import control_tables as ct

logger = logging.getLogger(__name__)


class ResumeHandler:
    """Handles resuming a migration job from its last checkpoint.

    Args:
        job_id: The migration job ID to resume.
    """

    def __init__(self, job_id: int):
        self.job_id = job_id
        self.job: Optional[dict] = None
        self.tasks: list[dict] = []
        self.resumable_tasks: list[dict] = []

    def analyse(self) -> dict[str, Any]:
        """Analyse the job to determine resume eligibility.

        Returns:
            A summary dict with ``can_resume``, ``completed_tasks``,
            ``failed_tasks``, ``pending_tasks``, and ``resumable_tasks``.
        """
        self.job = ct.get_job(self.job_id)
        if not self.job:
            return {"can_resume": False, "error": f"Job {self.job_id} not found."}

        self.tasks = ct.get_tasks_for_job(self.job_id)

        completed = [t for t in self.tasks if t["STATUS"] == "COMPLETED"]
        failed = [t for t in self.tasks if t["STATUS"] == "FAILED"]
        running = [t for t in self.tasks if t["STATUS"] == "RUNNING"]
        pending = [t for t in self.tasks if t["STATUS"] == "PENDING"]

        # Tasks that can be resumed: FAILED and RUNNING (stale)
        self.resumable_tasks = failed + running + pending

        can_resume = len(self.resumable_tasks) > 0

        summary = {
            "can_resume": can_resume,
            "job_id": self.job_id,
            "job_status": self.job.get("STATUS", ""),
            "total_tasks": len(self.tasks),
            "completed_tasks": len(completed),
            "failed_tasks": len(failed),
            "running_tasks": len(running),
            "pending_tasks": len(pending),
            "resumable_tasks": len(self.resumable_tasks),
        }

        logger.info(
            "Resume analysis for job %d: %d resumable of %d tasks.",
            self.job_id, len(self.resumable_tasks), len(self.tasks),
        )
        return summary

    def get_resume_plan(self) -> list[dict]:
        """Build a resume plan with checkpoint data for each resumable task.

        Returns:
            List of task dicts augmented with ``checkpoint`` information.
        """
        plan: list[dict] = []
        for task in self.resumable_tasks:
            task_id = task["TASK_ID"]
            checkpoint = ct.get_last_checkpoint(task_id)

            resume_info = {
                "task_id": task_id,
                "endpoint_path": task["ENDPOINT_PATH"],
                "target_table": task["TARGET_TABLE"],
                "previous_status": task["STATUS"],
                "records_loaded_so_far": task.get("RECORDS_LOADED", 0),
                "retry_count": task.get("RETRY_COUNT", 0),
                "max_retries": task.get("MAX_RETRIES", 3),
                "start_offset": 0,
                "start_page_token": "",
                "start_cursor": "",
            }

            if checkpoint:
                cp_type = checkpoint.get("CHECKPOINT_TYPE", "")
                cp_value = checkpoint.get("CHECKPOINT_VALUE", "")

                if cp_type == "OFFSET":
                    resume_info["start_offset"] = int(cp_value) if cp_value else 0
                elif cp_type == "PAGE_TOKEN":
                    resume_info["start_page_token"] = cp_value
                elif cp_type == "CURSOR":
                    resume_info["start_cursor"] = cp_value

                resume_info["checkpoint"] = checkpoint
            else:
                # Use task-level pagination state
                resume_info["start_offset"] = task.get("LAST_OFFSET", 0) or 0
                resume_info["start_page_token"] = task.get("LAST_PAGE_TOKEN", "") or ""
                resume_info["start_cursor"] = task.get("LAST_CURSOR", "") or ""

            plan.append(resume_info)

        logger.info(
            "Resume plan for job %d: %d tasks to resume.",
            self.job_id, len(plan),
        )
        return plan

    def prepare_resume(self) -> bool:
        """Update the job status to RUNNING and reset resumable tasks.

        Returns:
            True if the job was prepared for resuming.
        """
        if not self.job:
            self.analyse()

        if not self.resumable_tasks:
            logger.warning("No resumable tasks for job %d.", self.job_id)
            return False

        # Update job status
        ct.update_job_status(self.job_id, "RUNNING")

        # Reset FAILED tasks to PENDING (but keep their checkpoint data)
        for task in self.resumable_tasks:
            if task["STATUS"] == "FAILED":
                new_retry = (task.get("RETRY_COUNT", 0) or 0) + 1
                ct.update_task_status(
                    task["TASK_ID"],
                    "PENDING",
                )

        logger.info("Job %d prepared for resume.", self.job_id)
        return True
