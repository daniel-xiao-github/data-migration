"""Migration control/state tables in Oracle ADB.

Creates and manages the MIGRATION_JOBS, MIGRATION_TASKS,
MIGRATION_ERRORS, and MIGRATION_CHECKPOINTS control tables.
"""

import logging
from typing import Any, Optional

import oracledb

from app.oracle.adb_connection import get_connection, release_connection

logger = logging.getLogger(__name__)

# ── DDL Statements ─────────────────────────────────────────────────────

_CREATE_MIGRATION_JOBS = """
CREATE TABLE MIGRATION_JOBS (
    JOB_ID              NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    JOB_NAME            VARCHAR2(200) NOT NULL,
    SOURCE_APP          VARCHAR2(100) NOT NULL,
    OPENAPI_SPEC_FILE   VARCHAR2(500),
    MAPPING_FILE        VARCHAR2(500),
    STATUS              VARCHAR2(30) DEFAULT 'CREATED',
    CREATED_AT          TIMESTAMP DEFAULT SYSTIMESTAMP,
    STARTED_AT          TIMESTAMP,
    COMPLETED_AT        TIMESTAMP,
    CREATED_BY          VARCHAR2(100),
    TOTAL_ENDPOINTS     NUMBER,
    COMPLETED_ENDPOINTS NUMBER DEFAULT 0,
    TOTAL_RECORDS       NUMBER DEFAULT 0,
    ERROR_MESSAGE       CLOB
)"""

_CREATE_MIGRATION_TASKS = """
CREATE TABLE MIGRATION_TASKS (
    TASK_ID             NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    JOB_ID              NUMBER NOT NULL REFERENCES MIGRATION_JOBS(JOB_ID),
    ENDPOINT_PATH       VARCHAR2(500) NOT NULL,
    TARGET_TABLE        VARCHAR2(128) NOT NULL,
    STATUS              VARCHAR2(30) DEFAULT 'PENDING',
    STARTED_AT          TIMESTAMP,
    COMPLETED_AT        TIMESTAMP,
    RECORDS_FETCHED     NUMBER DEFAULT 0,
    RECORDS_LOADED      NUMBER DEFAULT 0,
    RECORDS_FAILED      NUMBER DEFAULT 0,
    LAST_PAGE_TOKEN     VARCHAR2(1000),
    LAST_OFFSET         NUMBER DEFAULT 0,
    LAST_CURSOR         VARCHAR2(1000),
    ERROR_MESSAGE       CLOB,
    RETRY_COUNT         NUMBER DEFAULT 0,
    MAX_RETRIES         NUMBER DEFAULT 3
)"""

_CREATE_MIGRATION_ERRORS = """
CREATE TABLE MIGRATION_ERRORS (
    ERROR_ID            NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    TASK_ID             NUMBER NOT NULL REFERENCES MIGRATION_TASKS(TASK_ID),
    JOB_ID              NUMBER NOT NULL REFERENCES MIGRATION_JOBS(JOB_ID),
    ERROR_TIMESTAMP     TIMESTAMP DEFAULT SYSTIMESTAMP,
    ERROR_TYPE          VARCHAR2(100),
    ERROR_CODE          VARCHAR2(50),
    ERROR_MESSAGE       CLOB,
    SOURCE_RECORD       CLOB,
    RETRY_ELIGIBLE      NUMBER(1) DEFAULT 1
)"""

_CREATE_MIGRATION_CHECKPOINTS = """
CREATE TABLE MIGRATION_CHECKPOINTS (
    CHECKPOINT_ID       NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    TASK_ID             NUMBER NOT NULL REFERENCES MIGRATION_TASKS(TASK_ID),
    CHECKPOINT_TYPE     VARCHAR2(50),
    CHECKPOINT_VALUE    VARCHAR2(2000),
    RECORDS_AT_CHECKPOINT NUMBER,
    CREATED_AT          TIMESTAMP DEFAULT SYSTIMESTAMP
)"""

_CONTROL_TABLES = [
    ("MIGRATION_JOBS", _CREATE_MIGRATION_JOBS),
    ("MIGRATION_TASKS", _CREATE_MIGRATION_TASKS),
    ("MIGRATION_ERRORS", _CREATE_MIGRATION_ERRORS),
    ("MIGRATION_CHECKPOINTS", _CREATE_MIGRATION_CHECKPOINTS),
]


def _table_exists(cursor: oracledb.Cursor, table_name: str) -> bool:
    """Check if a table exists in the current schema."""
    cursor.execute(
        "SELECT COUNT(*) FROM user_tables WHERE table_name = :1",
        [table_name],
    )
    return cursor.fetchone()[0] > 0


def ensure_control_tables() -> list[str]:
    """Create control tables if they don't already exist.

    Returns:
        List of table names that were created.
    """
    conn = get_connection()
    created: list[str] = []
    try:
        cursor = conn.cursor()
        for table_name, ddl in _CONTROL_TABLES:
            if not _table_exists(cursor, table_name):
                cursor.execute(ddl)
                created.append(table_name)
                logger.info("Created control table: %s", table_name)
            else:
                logger.debug("Control table %s already exists.", table_name)
        conn.commit()
        cursor.close()
    except oracledb.Error as exc:
        logger.error("Failed to create control tables: %s", exc)
        raise
    finally:
        release_connection(conn)
    return created


def reset_control_tables() -> list[str]:
    """Drop and re-create all control tables.

    Returns:
        List of table names that were recreated.
    """
    conn = get_connection()
    dropped: list[str] = []
    try:
        cursor = conn.cursor()
        # Drop in reverse order (child tables first)
        for table_name, _ in reversed(_CONTROL_TABLES):
            if _table_exists(cursor, table_name):
                cursor.execute(f"DROP TABLE {table_name} CASCADE CONSTRAINTS PURGE")
                dropped.append(table_name)
                logger.info("Dropped control table: %s", table_name)
        conn.commit()
        cursor.close()
    except oracledb.Error as exc:
        logger.error("Failed to drop control tables: %s", exc)
        raise
    finally:
        release_connection(conn)

    return ensure_control_tables()


# ── Job Operations ─────────────────────────────────────────────────────

def create_job(
    job_name: str,
    source_app: str,
    spec_file: str = "",
    mapping_file: str = "",
    total_endpoints: int = 0,
    created_by: str = "system",
) -> int:
    """Insert a new migration job and return its ID.

    Args:
        job_name: Human-readable job name.
        source_app: REST API app name.
        spec_file: Path to the OpenAPI spec file.
        mapping_file: Path to the mapping file.
        total_endpoints: Number of endpoints to migrate.
        created_by: Creator identifier.

    Returns:
        The generated JOB_ID.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        job_id_var = cursor.var(int)
        cursor.execute(
            """INSERT INTO MIGRATION_JOBS
               (JOB_NAME, SOURCE_APP, OPENAPI_SPEC_FILE, MAPPING_FILE,
                TOTAL_ENDPOINTS, CREATED_BY)
               VALUES (:1, :2, :3, :4, :5, :6)
               RETURNING JOB_ID INTO :7""",
            [job_name, source_app, spec_file, mapping_file,
             total_endpoints, created_by, job_id_var],
        )
        conn.commit()
        job_id = job_id_var.getvalue()[0]
        cursor.close()
        logger.info("Created migration job %d: '%s'.", job_id, job_name)
        return job_id
    finally:
        release_connection(conn)


def update_job_status(
    job_id: int,
    status: str,
    error_message: str = "",
    total_records: Optional[int] = None,
    completed_endpoints: Optional[int] = None,
) -> None:
    """Update the status of a migration job.

    Args:
        job_id: The job ID.
        status: New status.
        error_message: Optional error message.
        total_records: Optional total records count.
        completed_endpoints: Optional completed endpoints count.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        set_parts = ["STATUS = :1"]
        values: list[Any] = [status]

        if status == "RUNNING":
            set_parts.append("STARTED_AT = SYSTIMESTAMP")
        if status in ("COMPLETED", "FAILED", "CANCELLED"):
            set_parts.append("COMPLETED_AT = SYSTIMESTAMP")
        if error_message:
            set_parts.append("ERROR_MESSAGE = :err")
            values.append(error_message)
        if total_records is not None:
            set_parts.append("TOTAL_RECORDS = :tr")
            values.append(total_records)
        if completed_endpoints is not None:
            set_parts.append("COMPLETED_ENDPOINTS = :ce")
            values.append(completed_endpoints)

        # Build parameterised SQL
        sql = f"UPDATE MIGRATION_JOBS SET {', '.join(set_parts)} WHERE JOB_ID = :jid"
        values.append(job_id)
        cursor.execute(sql, values)
        conn.commit()
        cursor.close()
        logger.info("Job %d status → %s.", job_id, status)
    finally:
        release_connection(conn)


def get_job(job_id: int) -> Optional[dict]:
    """Retrieve a migration job by ID.

    Args:
        job_id: The job ID.

    Returns:
        Job dict or None.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM MIGRATION_JOBS WHERE JOB_ID = :1", [job_id])
        columns = [col[0] for col in cursor.description]
        row = cursor.fetchone()
        cursor.close()
        if row:
            return dict(zip(columns, row))
        return None
    finally:
        release_connection(conn)


def list_jobs(status: Optional[str] = None, limit: int = 50) -> list[dict]:
    """List migration jobs.

    Args:
        status: Optional status filter.
        limit: Maximum rows.

    Returns:
        List of job dicts.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        if status:
            cursor.execute(
                "SELECT * FROM MIGRATION_JOBS WHERE STATUS = :1 ORDER BY CREATED_AT DESC FETCH FIRST :2 ROWS ONLY",
                [status, limit],
            )
        else:
            cursor.execute(
                "SELECT * FROM MIGRATION_JOBS ORDER BY CREATED_AT DESC FETCH FIRST :1 ROWS ONLY",
                [limit],
            )
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
        cursor.close()
        return [dict(zip(columns, row)) for row in rows]
    finally:
        release_connection(conn)


# ── Task Operations ────────────────────────────────────────────────────

def create_task(
    job_id: int,
    endpoint_path: str,
    target_table: str,
    max_retries: int = 3,
) -> int:
    """Insert a migration task and return its ID.

    Args:
        job_id: Parent job ID.
        endpoint_path: API endpoint path.
        target_table: Target Oracle table name.
        max_retries: Maximum retry count.

    Returns:
        The generated TASK_ID.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        task_id_var = cursor.var(int)
        cursor.execute(
            """INSERT INTO MIGRATION_TASKS
               (JOB_ID, ENDPOINT_PATH, TARGET_TABLE, MAX_RETRIES)
               VALUES (:1, :2, :3, :4)
               RETURNING TASK_ID INTO :5""",
            [job_id, endpoint_path, target_table, max_retries, task_id_var],
        )
        conn.commit()
        task_id = task_id_var.getvalue()[0]
        cursor.close()
        return task_id
    finally:
        release_connection(conn)


def update_task_status(
    task_id: int,
    status: str,
    records_fetched: Optional[int] = None,
    records_loaded: Optional[int] = None,
    records_failed: Optional[int] = None,
    last_page_token: str = "",
    last_offset: Optional[int] = None,
    last_cursor: str = "",
    error_message: str = "",
) -> None:
    """Update a migration task's status and progress.

    Args:
        task_id: The task ID.
        status: New status.
        records_fetched: Number of records fetched so far.
        records_loaded: Number of records successfully loaded.
        records_failed: Number of records that failed to load.
        last_page_token: Last pagination token.
        last_offset: Last offset value.
        last_cursor: Last cursor value.
        error_message: Error message on failure.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        set_parts = ["STATUS = :status"]
        params: dict[str, Any] = {"status": status, "tid": task_id}

        if status == "RUNNING":
            set_parts.append("STARTED_AT = SYSTIMESTAMP")
        if status in ("COMPLETED", "FAILED", "SKIPPED"):
            set_parts.append("COMPLETED_AT = SYSTIMESTAMP")
        if records_fetched is not None:
            set_parts.append("RECORDS_FETCHED = :rf")
            params["rf"] = records_fetched
        if records_loaded is not None:
            set_parts.append("RECORDS_LOADED = :rl")
            params["rl"] = records_loaded
        if records_failed is not None:
            set_parts.append("RECORDS_FAILED = :rfail")
            params["rfail"] = records_failed
        if last_page_token:
            set_parts.append("LAST_PAGE_TOKEN = :lpt")
            params["lpt"] = last_page_token
        if last_offset is not None:
            set_parts.append("LAST_OFFSET = :lo")
            params["lo"] = last_offset
        if last_cursor:
            set_parts.append("LAST_CURSOR = :lc")
            params["lc"] = last_cursor
        if error_message:
            set_parts.append("ERROR_MESSAGE = :err")
            params["err"] = error_message

        sql = f"UPDATE MIGRATION_TASKS SET {', '.join(set_parts)} WHERE TASK_ID = :tid"
        cursor.execute(sql, params)
        conn.commit()
        cursor.close()
    finally:
        release_connection(conn)


def get_tasks_for_job(job_id: int) -> list[dict]:
    """Retrieve all tasks for a migration job.

    Args:
        job_id: The job ID.

    Returns:
        List of task dicts.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM MIGRATION_TASKS WHERE JOB_ID = :1 ORDER BY TASK_ID",
            [job_id],
        )
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
        cursor.close()
        return [dict(zip(columns, row)) for row in rows]
    finally:
        release_connection(conn)


# ── Error Operations ───────────────────────────────────────────────────

def log_error(
    task_id: int,
    job_id: int,
    error_type: str,
    error_code: str,
    error_message: str,
    source_record: str = "",
    retry_eligible: bool = True,
) -> None:
    """Insert an error record into MIGRATION_ERRORS.

    Args:
        task_id: The task ID.
        job_id: The job ID.
        error_type: Category of error.
        error_code: Error code.
        error_message: Detailed error message.
        source_record: The source record that caused the error.
        retry_eligible: Whether this error can be retried.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO MIGRATION_ERRORS
               (TASK_ID, JOB_ID, ERROR_TYPE, ERROR_CODE, ERROR_MESSAGE,
                SOURCE_RECORD, RETRY_ELIGIBLE)
               VALUES (:1, :2, :3, :4, :5, :6, :7)""",
            [task_id, job_id, error_type, error_code,
             error_message, source_record[:4000], 1 if retry_eligible else 0],
        )
        conn.commit()
        cursor.close()
    finally:
        release_connection(conn)


def get_errors_for_job(job_id: int, limit: int = 100) -> list[dict]:
    """Retrieve error records for a job.

    Args:
        job_id: The job ID.
        limit: Maximum rows.

    Returns:
        List of error dicts.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            """SELECT * FROM MIGRATION_ERRORS WHERE JOB_ID = :1
               ORDER BY ERROR_TIMESTAMP DESC FETCH FIRST :2 ROWS ONLY""",
            [job_id, limit],
        )
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()
        cursor.close()
        return [dict(zip(columns, row)) for row in rows]
    finally:
        release_connection(conn)


# ── Checkpoint Operations ──────────────────────────────────────────────

def save_checkpoint(
    task_id: int,
    checkpoint_type: str,
    checkpoint_value: str,
    records_count: int,
) -> None:
    """Save a pagination checkpoint for a task.

    Args:
        task_id: The task ID.
        checkpoint_type: Type of checkpoint (PAGE_TOKEN, OFFSET, CURSOR, TIMESTAMP).
        checkpoint_value: The checkpoint value.
        records_count: Number of records at this checkpoint.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            """INSERT INTO MIGRATION_CHECKPOINTS
               (TASK_ID, CHECKPOINT_TYPE, CHECKPOINT_VALUE, RECORDS_AT_CHECKPOINT)
               VALUES (:1, :2, :3, :4)""",
            [task_id, checkpoint_type, checkpoint_value, records_count],
        )
        conn.commit()
        cursor.close()
    finally:
        release_connection(conn)


def get_last_checkpoint(task_id: int) -> Optional[dict]:
    """Retrieve the most recent checkpoint for a task.

    Args:
        task_id: The task ID.

    Returns:
        Checkpoint dict or None.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            """SELECT * FROM MIGRATION_CHECKPOINTS
               WHERE TASK_ID = :1
               ORDER BY CREATED_AT DESC FETCH FIRST 1 ROW ONLY""",
            [task_id],
        )
        columns = [col[0] for col in cursor.description]
        row = cursor.fetchone()
        cursor.close()
        if row:
            return dict(zip(columns, row))
        return None
    finally:
        release_connection(conn)
