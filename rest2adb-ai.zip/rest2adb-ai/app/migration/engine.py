"""Core migration orchestration engine.

Coordinates the full migration pipeline: prerequisite validation, job
creation, DDL execution, paginated data extraction, batch loading, and
real-time progress reporting via WebSocket events.
"""

import json
import logging
import time
from pathlib import Path
from typing import Any, Optional

from app.ai.openapi_generator import load_spec
from app.ai.schema_mapper import load_mapping
from app.api_client.rest_client import RESTClient
from app.auth.oauth_manager import get_valid_access_token
from app.migration import control_tables as ct
from app.migration.batch_manager import BatchManager
from app.migration.resume_handler import ResumeHandler
from app.oracle.adb_connection import get_connection, release_connection
from app.oracle.data_loader import batch_insert
from app.oracle.table_manager import create_table_from_mapping
from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)


class MigrationEngine:
    """Orchestrates REST API → Oracle ADB data migration.

    Args:
        app_name: REST API application name.
        spec_file: Path to the OpenAPI spec JSON file.
        mapping_file: Path to the mapping JSON file.
        socketio: Optional Flask-SocketIO instance for real-time events.
    """

    def __init__(
        self,
        app_name: str,
        spec_file: str,
        mapping_file: str,
        socketio: Any = None,
    ):
        self.app_name = app_name
        self.spec_file = spec_file
        self.mapping_file = mapping_file
        self.socketio = socketio

        self.cfg = load_config().get("migration", {})
        self.batch_size = self.cfg.get("default_batch_size", 500)
        self.max_concurrent = self.cfg.get("max_concurrent_tasks", 3)
        self.rate_limit = self.cfg.get("rate_limit_per_second", 10)
        self.checkpoint_freq = self.cfg.get("checkpoint_frequency", 1)

        self.spec: dict = {}
        self.mappings: list[dict] = []
        self.job_id: Optional[int] = None
        self._cancelled = False

    def emit(self, event: str, data: dict) -> None:
        """Emit a WebSocket event if socketio is available.

        Args:
            event: Event name.
            data: Event payload.
        """
        if self.socketio:
            self.socketio.emit(event, data, namespace="/migration")
        logger.debug("Event '%s': %s", event, json.dumps(data, default=str)[:500])

    def cancel(self) -> None:
        """Signal the engine to cancel the current migration."""
        self._cancelled = True
        if self.job_id:
            ct.update_job_status(self.job_id, "CANCELLED")
        self.emit("job_cancelled", {"job_id": self.job_id})

    # ── Validation ─────────────────────────────────────────────────────

    def validate_prerequisites(self) -> list[str]:
        """Check that all prerequisites are satisfied.

        Returns:
            List of error strings (empty if all OK).
        """
        errors: list[str] = []

        # Check OAuth token
        token = get_valid_access_token(self.app_name)
        if not token:
            errors.append(f"No valid OAuth token for '{self.app_name}'.")

        # Check ADB connection
        try:
            conn = get_connection()
            release_connection(conn)
        except Exception as exc:
            errors.append(f"Oracle ADB connection failed: {exc}")

        # Check spec file
        spec_path = Path(self.spec_file)
        if not spec_path.exists():
            errors.append(f"OpenAPI spec file not found: {self.spec_file}")

        # Check mapping file
        mapping_path = Path(self.mapping_file)
        if not mapping_path.exists():
            errors.append(f"Mapping file not found: {self.mapping_file}")

        return errors

    # ── Run ────────────────────────────────────────────────────────────

    def run(self, job_name: str = "") -> int:
        """Execute the full migration pipeline.

        Args:
            job_name: Optional human-readable name for the job.

        Returns:
            The migration job ID.
        """
        self._cancelled = False

        # Load spec and mappings
        self.spec = load_spec(self.spec_file)
        self.mappings = load_mapping(self.mapping_file)

        # Ensure control tables
        ct.ensure_control_tables()

        # Create job
        if not job_name:
            job_name = f"{self.app_name} Migration {time.strftime('%Y-%m-%d %H:%M')}"

        self.job_id = ct.create_job(
            job_name=job_name,
            source_app=self.app_name,
            spec_file=self.spec_file,
            mapping_file=self.mapping_file,
            total_endpoints=len(self.mappings),
        )

        ct.update_job_status(self.job_id, "RUNNING")
        self.emit("job_started", {"job_id": self.job_id, "job_name": job_name})

        # Create tasks
        task_ids: list[int] = []
        for mapping in self.mappings:
            if mapping.get("error"):
                continue
            task_id = ct.create_task(
                job_id=self.job_id,
                endpoint_path=mapping.get("source_endpoint", ""),
                target_table=mapping.get("target_table", ""),
                max_retries=self.cfg.get("max_retries", 3),
            )
            task_ids.append(task_id)

        # DDL execution – create staging tables
        for mapping in self.mappings:
            if mapping.get("error"):
                continue
            try:
                create_table_from_mapping(mapping)
            except Exception as exc:
                logger.error("DDL failed for %s: %s", mapping.get("target_table"), exc)

        # Execute tasks
        total_records = 0
        completed_endpoints = 0

        base_url = ""
        if self.spec.get("servers"):
            base_url = self.spec["servers"][0].get("url", "")

        client = RESTClient(
            app_name=self.app_name,
            base_url=base_url,
            rate_limit=self.rate_limit,
        )

        try:
            for i, (task_id, mapping) in enumerate(zip(task_ids, self.mappings)):
                if self._cancelled:
                    break
                if mapping.get("error"):
                    continue

                task_records = self._execute_task(client, task_id, mapping)
                total_records += task_records
                completed_endpoints += 1

                ct.update_job_status(
                    self.job_id,
                    "RUNNING",
                    total_records=total_records,
                    completed_endpoints=completed_endpoints,
                )

                progress = (completed_endpoints / len(self.mappings)) * 100
                self.emit("job_progress", {
                    "job_id": self.job_id,
                    "progress": round(progress, 1),
                    "completed_endpoints": completed_endpoints,
                    "total_endpoints": len(self.mappings),
                    "total_records": total_records,
                })

        except Exception as exc:
            logger.error("Migration job %d failed: %s", self.job_id, exc)
            ct.update_job_status(self.job_id, "FAILED", error_message=str(exc))
            self.emit("job_failed", {"job_id": self.job_id, "error": str(exc)})
            return self.job_id
        finally:
            client.close()

        # Completion
        final_status = "CANCELLED" if self._cancelled else "COMPLETED"
        ct.update_job_status(
            self.job_id, final_status,
            total_records=total_records,
            completed_endpoints=completed_endpoints,
        )
        self.emit("job_completed", {
            "job_id": self.job_id,
            "status": final_status,
            "total_records": total_records,
        })
        logger.info(
            "Migration job %d %s: %d records across %d endpoints.",
            self.job_id, final_status.lower(), total_records, completed_endpoints,
        )
        return self.job_id

    def _execute_task(
        self, client: RESTClient, task_id: int, mapping: dict
    ) -> int:
        """Execute a single migration task (one endpoint).

        Args:
            client: The REST API client.
            task_id: The task ID.
            mapping: The mapping configuration for this endpoint.

        Returns:
            Number of records loaded.
        """
        endpoint = mapping.get("source_endpoint", "")
        target_table = mapping.get("target_table", "")
        pagination = mapping.get("pagination", {})

        ct.update_task_status(task_id, "RUNNING")
        self.emit("task_started", {
            "job_id": self.job_id,
            "task_id": task_id,
            "endpoint": endpoint,
            "target_table": target_table,
        })

        total_loaded = 0
        total_failed = 0
        total_fetched = 0
        batch_count = 0

        try:
            records, checkpoint = client.get_all_pages(
                endpoint=endpoint,
                pagination_config=pagination,
            )
            total_fetched = len(records)

            # Process in batches
            for start in range(0, len(records), self.batch_size):
                if self._cancelled:
                    break

                batch = records[start:start + self.batch_size]
                loaded, failed, errors = batch_insert(
                    mapping, batch, job_id=self.job_id,
                )
                total_loaded += loaded
                total_failed += failed
                batch_count += 1

                # Log errors
                for err in errors:
                    ct.log_error(
                        task_id=task_id,
                        job_id=self.job_id,
                        error_type="DATA_LOAD",
                        error_code=err.get("error_code", ""),
                        error_message=err.get("error_message", ""),
                        source_record=err.get("source_record", ""),
                    )

                # Checkpoint
                if batch_count % self.checkpoint_freq == 0:
                    ct.save_checkpoint(
                        task_id=task_id,
                        checkpoint_type=checkpoint.get("type", "OFFSET"),
                        checkpoint_value=str(start + len(batch)),
                        records_count=total_loaded,
                    )

                # Update task progress
                ct.update_task_status(
                    task_id,
                    "RUNNING",
                    records_fetched=total_fetched,
                    records_loaded=total_loaded,
                    records_failed=total_failed,
                )

                self.emit("task_progress", {
                    "job_id": self.job_id,
                    "task_id": task_id,
                    "records_fetched": total_fetched,
                    "records_loaded": total_loaded,
                    "records_failed": total_failed,
                })

            # Task completed
            ct.update_task_status(
                task_id, "COMPLETED",
                records_fetched=total_fetched,
                records_loaded=total_loaded,
                records_failed=total_failed,
            )
            self.emit("task_completed", {
                "job_id": self.job_id,
                "task_id": task_id,
                "records_loaded": total_loaded,
            })

        except Exception as exc:
            logger.error("Task %d failed (%s): %s", task_id, endpoint, exc)
            ct.update_task_status(
                task_id, "FAILED",
                records_fetched=total_fetched,
                records_loaded=total_loaded,
                records_failed=total_failed,
                error_message=str(exc),
            )
            ct.log_error(
                task_id=task_id,
                job_id=self.job_id,
                error_type="TASK_FAILURE",
                error_code="EXCEPTION",
                error_message=str(exc),
            )
            self.emit("task_failed", {
                "job_id": self.job_id,
                "task_id": task_id,
                "error": str(exc),
            })

        return total_loaded
