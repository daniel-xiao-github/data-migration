"""Batch execution and concurrency control for migrations.

Provides a manager that can run multiple endpoint migration tasks in
parallel (up to a configurable concurrency limit) and track overall
progress.
"""

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Optional

from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)


class BatchManager:
    """Manages concurrent batch execution of migration tasks.

    Args:
        max_workers: Maximum number of concurrent tasks.
        rate_limit: API requests per second (shared across workers).
    """

    def __init__(
        self,
        max_workers: int = 3,
        rate_limit: float = 10.0,
    ):
        cfg = load_config().get("migration", {})
        self.max_workers = max_workers or cfg.get("max_concurrent_tasks", 3)
        self.rate_limit = rate_limit or cfg.get("rate_limit_per_second", 10.0)

        self._paused = False
        self._cancelled = False
        self._active_tasks: dict[int, str] = {}  # task_id → status

    def pause(self) -> None:
        """Signal all workers to pause."""
        self._paused = True
        logger.info("BatchManager: pause requested.")

    def resume(self) -> None:
        """Signal all workers to resume."""
        self._paused = False
        logger.info("BatchManager: resume requested.")

    def cancel(self) -> None:
        """Signal all workers to cancel."""
        self._cancelled = True
        logger.info("BatchManager: cancel requested.")

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def is_cancelled(self) -> bool:
        return self._cancelled

    def wait_if_paused(self) -> None:
        """Block until un-paused or cancelled."""
        while self._paused and not self._cancelled:
            time.sleep(0.5)

    def execute_tasks(
        self,
        tasks: list[dict],
        task_fn: Callable[[dict], dict],
        on_complete: Optional[Callable[[int, dict], None]] = None,
    ) -> list[dict]:
        """Execute a list of migration tasks with concurrency control.

        Args:
            tasks: List of task dicts (must have ``task_id``).
            task_fn: Callable that takes a task dict and returns a result dict.
            on_complete: Optional callback invoked as each task completes.

        Returns:
            List of result dicts, one per task.
        """
        results: list[dict] = []
        self._cancelled = False
        self._paused = False

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_task = {}
            for task in tasks:
                if self._cancelled:
                    break
                self.wait_if_paused()
                future = executor.submit(self._run_task, task, task_fn)
                future_to_task[future] = task

            for future in as_completed(future_to_task):
                task = future_to_task[future]
                task_id = task.get("task_id", 0)
                try:
                    result = future.result()
                    results.append(result)
                    if on_complete:
                        on_complete(task_id, result)
                except Exception as exc:
                    error_result = {
                        "task_id": task_id,
                        "status": "FAILED",
                        "error": str(exc),
                    }
                    results.append(error_result)
                    if on_complete:
                        on_complete(task_id, error_result)
                    logger.error("Task %d raised exception: %s", task_id, exc)

        return results

    def _run_task(
        self, task: dict, task_fn: Callable[[dict], dict]
    ) -> dict:
        """Wrapper that respects pause/cancel signals.

        Args:
            task: The task dict.
            task_fn: The task execution function.

        Returns:
            The result dict from task_fn.
        """
        task_id = task.get("task_id", 0)
        self._active_tasks[task_id] = "RUNNING"

        try:
            self.wait_if_paused()
            if self._cancelled:
                self._active_tasks[task_id] = "CANCELLED"
                return {"task_id": task_id, "status": "CANCELLED"}

            result = task_fn(task)
            self._active_tasks[task_id] = result.get("status", "COMPLETED")
            return result

        except Exception as exc:
            self._active_tasks[task_id] = "FAILED"
            raise

    def get_active_tasks(self) -> dict[int, str]:
        """Return a snapshot of currently active tasks and their statuses."""
        return dict(self._active_tasks)

    def get_stats(self) -> dict[str, int]:
        """Return a summary of task statuses.

        Returns:
            Dict with counts for each status.
        """
        stats: dict[str, int] = {}
        for status in self._active_tasks.values():
            stats[status] = stats.get(status, 0) + 1
        return stats
