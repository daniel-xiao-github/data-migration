"""restapi2adb – REST API to Oracle Autonomous Database Migration Tool.

Flask application factory and package version.
"""

import logging
import secrets
from pathlib import Path

_VERSION_FILE = Path(__file__).resolve().parent.parent / "VERSION"


def _read_version() -> str:
    """Read version from the VERSION file at project root."""
    try:
        return _VERSION_FILE.read_text().strip()
    except FileNotFoundError:
        return "0.0.0"


__version__ = _read_version()

from flask import Flask
from flask_login import LoginManager
from flask_socketio import SocketIO

from app.utils.config_manager import load_config
from app.utils.logger import setup_logging

socketio = SocketIO()
login_manager = LoginManager()


def create_app(config_overrides: dict | None = None) -> Flask:
    """Create and configure the Flask application.

    Args:
        config_overrides: Optional dict of config values to override defaults.

    Returns:
        A configured Flask application instance.
    """
    cfg = load_config()

    # Logging
    log_cfg = cfg.get("logging", {})
    setup_logging(
        level=log_cfg.get("level", "INFO"),
        max_bytes=log_cfg.get("max_file_size_mb", 10) * 1024 * 1024,
    )
    logger = logging.getLogger(__name__)

    app = Flask(
        __name__,
        template_folder=str(Path(__file__).parent / "web" / "templates"),
        static_folder=str(Path(__file__).parent / "web" / "static"),
    )

    app_cfg = cfg.get("app", {})
    secret = app_cfg.get("secret_key", "")
    if not secret or secret == "auto-generated-on-first-run":
        secret = secrets.token_hex(32)
    app.config["SECRET_KEY"] = secret
    app.config["APP_CONFIG"] = cfg

    if config_overrides:
        app.config.update(config_overrides)

    # Flask-Login
    login_manager.login_view = "web.login"
    login_manager.login_message_category = "warning"
    login_manager.init_app(app)

    # Flask-SocketIO
    socketio.init_app(app, async_mode="threading")

    # Register blueprints
    from app.web.routes import web_bp
    from app.web.api_routes import api_bp

    app.register_blueprint(web_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    # Register SocketIO events
    from app.web import socketio_events  # noqa: F401

    # Inject version into all templates
    @app.context_processor
    def inject_version():
        return {"app_version": __version__}

    logger.info("restapi2adb v%s application created.", __version__)
    return app
