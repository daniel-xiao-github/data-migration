"""Oracle ADB DDL generation and table management.

Generates CREATE TABLE statements from mapping configurations and
manages target staging tables in Oracle ADB.
"""

import logging
from typing import Any

import oracledb

from app.oracle.adb_connection import get_connection, release_connection

logger = logging.getLogger(__name__)


def generate_create_table_ddl(mapping: dict) -> str:
    """Generate a CREATE TABLE DDL statement from a mapping configuration.

    Args:
        mapping: A mapping dict with ``target_table``, ``target_schema``,
                 and ``columns`` keys.

    Returns:
        The DDL string.
    """
    table_name = mapping.get("target_table", "UNNAMED_TABLE")
    schema = mapping.get("target_schema", "")
    full_name = f"{schema}.{table_name}" if schema else table_name
    columns = mapping.get("columns", [])

    col_defs: list[str] = []
    pk_cols: list[str] = []

    for col in columns:
        target = col["target_column"]
        oracle_type = col["oracle_type"]
        nullable = col.get("is_nullable", True)
        is_pk = col.get("is_primary_key", False)

        parts = [f"    {target}", oracle_type]
        if not nullable:
            parts.append("NOT NULL")
        col_defs.append(" ".join(parts))

        if is_pk:
            pk_cols.append(target)

    # Add audit columns
    col_defs.append("    MIGRATION_LOADED_AT TIMESTAMP DEFAULT SYSTIMESTAMP")
    col_defs.append("    MIGRATION_JOB_ID NUMBER")

    lines = [f"CREATE TABLE {full_name} ("]
    lines.append(",\n".join(col_defs))

    if pk_cols:
        pk_name = f"PK_{table_name}"[:30]
        lines.append(f"    ,CONSTRAINT {pk_name} PRIMARY KEY ({', '.join(pk_cols)})")

    lines.append(")")
    ddl = "\n".join(lines)
    logger.debug("Generated DDL for %s:\n%s", full_name, ddl)
    return ddl


def generate_merge_sql(mapping: dict) -> str:
    """Generate a MERGE INTO (upsert) statement for idempotent loads.

    Args:
        mapping: Mapping dict with table and column info.

    Returns:
        The MERGE SQL string with bind-variable placeholders.
    """
    table_name = mapping.get("target_table", "UNNAMED_TABLE")
    schema = mapping.get("target_schema", "")
    full_name = f"{schema}.{table_name}" if schema else table_name
    columns = mapping.get("columns", [])

    pk_cols = [c for c in columns if c.get("is_primary_key")]
    non_pk_cols = [c for c in columns if not c.get("is_primary_key")]

    if not pk_cols:
        # Fall back to simple INSERT if no PK
        return _generate_insert_sql(mapping)

    # Build MERGE statement
    src_cols = [f":{c['target_column']}" for c in columns]
    select_parts = [
        f"{src} AS {c['target_column']}"
        for c, src in zip(columns, src_cols)
    ]

    on_clause = " AND ".join(
        f"t.{c['target_column']} = s.{c['target_column']}" for c in pk_cols
    )
    update_set = ", ".join(
        f"t.{c['target_column']} = s.{c['target_column']}" for c in non_pk_cols
    )
    insert_cols = ", ".join(c["target_column"] for c in columns)
    insert_vals = ", ".join(f"s.{c['target_column']}" for c in columns)

    sql = f"""MERGE INTO {full_name} t
USING (SELECT {', '.join(select_parts)} FROM DUAL) s
ON ({on_clause})
WHEN MATCHED THEN UPDATE SET {update_set}, t.MIGRATION_LOADED_AT = SYSTIMESTAMP
WHEN NOT MATCHED THEN INSERT ({insert_cols}, MIGRATION_LOADED_AT)
VALUES ({insert_vals}, SYSTIMESTAMP)"""

    return sql


def _generate_insert_sql(mapping: dict) -> str:
    """Generate a plain INSERT statement (no PK for merge)."""
    table_name = mapping.get("target_table", "UNNAMED_TABLE")
    schema = mapping.get("target_schema", "")
    full_name = f"{schema}.{table_name}" if schema else table_name
    columns = mapping.get("columns", [])

    col_names = ", ".join(c["target_column"] for c in columns)
    placeholders = ", ".join(f":{c['target_column']}" for c in columns)

    return f"INSERT INTO {full_name} ({col_names}, MIGRATION_LOADED_AT) VALUES ({placeholders}, SYSTIMESTAMP)"


def table_exists(table_name: str, schema: str = "") -> bool:
    """Check whether a table exists in Oracle ADB.

    Args:
        table_name: The table name (uppercase).
        schema: Optional schema/owner.

    Returns:
        True if the table exists.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        if schema:
            cursor.execute(
                "SELECT COUNT(*) FROM all_tables WHERE table_name = :1 AND owner = :2",
                [table_name.upper(), schema.upper()],
            )
        else:
            cursor.execute(
                "SELECT COUNT(*) FROM user_tables WHERE table_name = :1",
                [table_name.upper()],
            )
        count = cursor.fetchone()[0]
        cursor.close()
        return count > 0
    finally:
        release_connection(conn)


def create_table_from_mapping(mapping: dict) -> tuple[bool, str]:
    """Create a staging table in ADB based on the mapping config.

    If the table already exists, this is a no-op.

    Args:
        mapping: The mapping configuration dict.

    Returns:
        ``(success, message)`` tuple.
    """
    table_name = mapping.get("target_table", "")
    schema = mapping.get("target_schema", "")

    if table_exists(table_name, schema):
        msg = f"Table {schema}.{table_name} already exists – skipping DDL."
        logger.info(msg)
        return True, msg

    ddl = generate_create_table_ddl(mapping)
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(ddl)
        conn.commit()
        cursor.close()
        msg = f"Table {schema}.{table_name} created successfully."
        logger.info(msg)
        return True, msg
    except oracledb.Error as exc:
        logger.error("DDL execution failed for %s: %s", table_name, exc)
        return False, f"DDL failed: {exc}"
    finally:
        release_connection(conn)


def drop_table(table_name: str, schema: str = "") -> tuple[bool, str]:
    """Drop a table from ADB.

    Args:
        table_name: Table name.
        schema: Optional schema.

    Returns:
        ``(success, message)`` tuple.
    """
    full_name = f"{schema}.{table_name}" if schema else table_name
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"DROP TABLE {full_name} CASCADE CONSTRAINTS PURGE")
        conn.commit()
        cursor.close()
        msg = f"Table {full_name} dropped."
        logger.info(msg)
        return True, msg
    except oracledb.Error as exc:
        logger.error("Drop table failed for %s: %s", full_name, exc)
        return False, f"Drop failed: {exc}"
    finally:
        release_connection(conn)


def get_table_row_count(table_name: str, schema: str = "") -> int:
    """Return the row count for a table.

    Args:
        table_name: Table name.
        schema: Optional schema.
    """
    full_name = f"{schema}.{table_name}" if schema else table_name
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {full_name}")
        count = cursor.fetchone()[0]
        cursor.close()
        return count
    except oracledb.Error:
        return 0
    finally:
        release_connection(conn)
