"""Oracle Autonomous Database connection manager.

Uses ``python-oracledb`` in thin mode (no Oracle Client required).
Supports both wallet (mTLS) and direct connection-string connectivity,
with connection pooling and auto-reconnect.
"""

import logging
import os
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Optional

import oracledb

from app.utils.config_manager import load_config
from app.utils.secret_manager import load_encrypted_json, save_encrypted_json

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_CREDENTIALS_FILE = _PROJECT_ROOT / "data" / "tokens" / "adb_credentials.enc"

# Module-level pool
_pool: Optional[oracledb.ConnectionPool] = None


def save_adb_credentials(
    connection_type: str,
    username: str,
    password: str,
    wallet_path: str = "",
    tns_alias: str = "",
    connection_string: str = "",
) -> None:
    """Encrypt and persist Oracle ADB credentials.

    Args:
        connection_type: ``"wallet"`` or ``"connection_string"``.
        username: Database username.
        password: Database password.
        wallet_path: Path to wallet.zip (for mTLS connections).
        tns_alias: TNS alias from tnsnames.ora inside the wallet.
        connection_string: Full connection string (for direct TLS).
    """
    save_encrypted_json(
        {
            "connection_type": connection_type,
            "username": username,
            "password": password,
            "wallet_path": wallet_path,
            "tns_alias": tns_alias,
            "connection_string": connection_string,
        },
        _CREDENTIALS_FILE,
    )
    logger.info("ADB credentials saved (type=%s, user=%s).", connection_type, username)


def load_adb_credentials() -> Optional[dict]:
    """Load and decrypt stored ADB credentials.

    Returns:
        Credential dict or None.
    """
    return load_encrypted_json(_CREDENTIALS_FILE)


def extract_tns_aliases(wallet_zip_path: str) -> list[str]:
    """Parse tnsnames.ora inside a wallet .zip and return TNS aliases.

    Args:
        wallet_zip_path: Path to the Oracle wallet zip file.

    Returns:
        List of TNS alias names found in the wallet.
    """
    aliases: list[str] = []
    try:
        with zipfile.ZipFile(wallet_zip_path, "r") as zf:
            for name in zf.namelist():
                if name.lower().endswith("tnsnames.ora"):
                    content = zf.read(name).decode("utf-8", errors="replace")
                    for line in content.splitlines():
                        line = line.strip()
                        # TNS entries start with alias_name = (DESCRIPTION ...
                        if "=" in line and not line.startswith("#"):
                            alias = line.split("=")[0].strip()
                            if alias and "(" not in alias:
                                aliases.append(alias)
    except Exception as exc:
        logger.error("Failed to parse wallet zip '%s': %s", wallet_zip_path, exc)
    return aliases


def _prepare_wallet(wallet_zip_path: str) -> str:
    """Extract wallet zip to a temp directory and return the directory path.

    Args:
        wallet_zip_path: Path to the wallet zip file.

    Returns:
        Path to the extracted wallet directory.
    """
    wallet_dir = tempfile.mkdtemp(prefix="adb_wallet_")
    with zipfile.ZipFile(wallet_zip_path, "r") as zf:
        zf.extractall(wallet_dir)
    logger.debug("Wallet extracted to %s", wallet_dir)
    return wallet_dir


def create_pool(
    connection_type: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    wallet_path: Optional[str] = None,
    tns_alias: Optional[str] = None,
    connection_string: Optional[str] = None,
) -> oracledb.ConnectionPool:
    """Create or replace the module-level connection pool.

    If no explicit arguments are provided, credentials are loaded from
    encrypted storage and config.

    Args:
        connection_type: ``"wallet"`` or ``"connection_string"``.
        username: Database username.
        password: Database password.
        wallet_path: Path to wallet.zip.
        tns_alias: TNS alias.
        connection_string: Direct connection string.

    Returns:
        The ``oracledb.ConnectionPool`` instance.

    Raises:
        oracledb.Error: On connection failure.
    """
    global _pool

    cfg = load_config().get("oracle", {})
    creds = load_adb_credentials() or {}

    conn_type = connection_type or creds.get("connection_type") or cfg.get("connection_type", "wallet")
    user = username or creds.get("username") or cfg.get("username", "")
    pwd = password or creds.get("password", "")
    w_path = wallet_path or creds.get("wallet_path") or cfg.get("wallet_path", "")
    t_alias = tns_alias or creds.get("tns_alias") or cfg.get("tns_alias", "")
    c_string = connection_string or creds.get("connection_string", "")

    pool_min = cfg.get("pool_min", 2)
    pool_max = cfg.get("pool_max", 10)
    pool_incr = cfg.get("pool_increment", 1)

    if _pool is not None:
        try:
            _pool.close(force=True)
        except Exception:
            pass

    pool_params: dict[str, Any] = {
        "user": user,
        "password": pwd,
        "min": pool_min,
        "max": pool_max,
        "increment": pool_incr,
    }

    if conn_type == "wallet" and w_path:
        wallet_dir = _prepare_wallet(w_path)
        pool_params["config_dir"] = wallet_dir
        pool_params["dsn"] = t_alias
        pool_params["wallet_location"] = wallet_dir
        pool_params["wallet_password"] = pwd
    else:
        pool_params["dsn"] = c_string

    _pool = oracledb.create_pool(**pool_params)
    logger.info(
        "Oracle connection pool created (type=%s, min=%d, max=%d).",
        conn_type, pool_min, pool_max,
    )
    return _pool


def get_pool() -> oracledb.ConnectionPool:
    """Return the current connection pool, creating one if needed.

    Returns:
        The active connection pool.

    Raises:
        RuntimeError: If no credentials are available.
    """
    global _pool
    if _pool is None:
        creds = load_adb_credentials()
        if not creds:
            raise RuntimeError("No ADB credentials configured. Please set up Oracle connection first.")
        _pool = create_pool()
    return _pool


def get_connection() -> oracledb.Connection:
    """Acquire a connection from the pool.

    Automatically attempts to reconnect on transient failures.

    Returns:
        An ``oracledb.Connection`` instance.
    """
    pool = get_pool()
    try:
        return pool.acquire()
    except oracledb.Error as exc:
        logger.warning("Pool acquire failed, recreating pool: %s", exc)
        create_pool()
        return get_pool().acquire()


def release_connection(conn: oracledb.Connection) -> None:
    """Release a connection back to the pool.

    Args:
        conn: The connection to return.
    """
    try:
        pool = get_pool()
        pool.release(conn)
    except Exception as exc:
        logger.debug("Error releasing connection: %s", exc)


def test_connection(
    connection_type: str,
    username: str,
    password: str,
    wallet_path: str = "",
    tns_alias: str = "",
    connection_string: str = "",
) -> tuple[bool, dict[str, str]]:
    """Test database connectivity with the given parameters.

    Args:
        connection_type: ``"wallet"`` or ``"connection_string"``.
        username: Database username.
        password: Database password.
        wallet_path: Wallet zip path.
        tns_alias: TNS alias.
        connection_string: Direct connection string.

    Returns:
        ``(success, info_dict)`` where info_dict contains ``version``
        and ``current_schema`` on success, or ``error`` on failure.
    """
    try:
        params: dict[str, Any] = {"user": username, "password": password}

        if connection_type == "wallet" and wallet_path:
            wallet_dir = _prepare_wallet(wallet_path)
            params["config_dir"] = wallet_dir
            params["dsn"] = tns_alias
            params["wallet_location"] = wallet_dir
            params["wallet_password"] = password
        else:
            params["dsn"] = connection_string

        conn = oracledb.connect(**params)
        cursor = conn.cursor()
        cursor.execute("SELECT banner FROM v$version WHERE ROWNUM = 1")
        version = cursor.fetchone()[0]
        cursor.execute("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL")
        schema = cursor.fetchone()[0]
        cursor.close()
        conn.close()

        logger.info("ADB test connection successful (version=%s, schema=%s).", version, schema)
        return True, {"version": version, "current_schema": schema}

    except Exception as exc:
        logger.error("ADB test connection failed: %s", exc)
        return False, {"error": str(exc)}


def close_pool() -> None:
    """Close the connection pool (for graceful shutdown)."""
    global _pool
    if _pool is not None:
        try:
            _pool.close(force=True)
            logger.info("Oracle connection pool closed.")
        except Exception as exc:
            logger.warning("Error closing pool: %s", exc)
        finally:
            _pool = None
