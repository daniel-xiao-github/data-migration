"""Batch data loader for Oracle ADB.

Handles batch inserts and merges (upserts) with per-row error capture
using ``executemany()`` with ``batcherrors=True``.
"""

import logging
from typing import Any

import oracledb

from app.oracle.adb_connection import get_connection, release_connection
from app.oracle.table_manager import generate_merge_sql, _generate_insert_sql

logger = logging.getLogger(__name__)


def apply_transforms(row: dict, columns: list[dict]) -> dict[str, Any]:
    """Apply column transforms and extract values from a source record.

    Uses JSONPath-like dot notation to extract nested values from the
    source row, then applies any Oracle-specific transforms.

    Args:
        row: The source JSON record.
        columns: List of column mapping dicts.

    Returns:
        A dict of ``{target_column: transformed_value}`` ready for binding.
    """
    result: dict[str, Any] = {}
    for col in columns:
        source_path = col.get("source_path", "")
        target = col["target_column"]

        # Extract value via dot-path (e.g. "$.customerRef.value")
        value = _extract_json_path(row, source_path)

        # Apply boolean transform
        transform = col.get("transform")
        if transform and value is not None:
            if "true" in str(transform).lower() and "false" in str(transform).lower():
                # Boolean → NUMBER(1)
                value = 1 if value else 0

        result[target] = value

    return result


def _extract_json_path(data: Any, path: str) -> Any:
    """Extract a value from nested dicts/lists using a JSONPath-like expression.

    Supports ``$.field.nested.value`` notation.  Array indexing is not
    currently supported (arrays yield the raw list).

    Args:
        data: The source dict.
        path: A JSONPath expression starting with ``$``.

    Returns:
        The extracted value, or None if the path doesn't resolve.
    """
    if not path or not path.startswith("$"):
        return None

    parts = path.lstrip("$.").split(".")
    node = data
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part)
        else:
            return None
        if node is None:
            return None
    return node


def batch_insert(
    mapping: dict,
    rows: list[dict],
    job_id: int | None = None,
) -> tuple[int, int, list[dict]]:
    """Insert a batch of rows into the target Oracle table.

    Uses ``executemany()`` with ``batcherrors=True`` so that individual
    row failures do not abort the entire batch.

    Args:
        mapping: The mapping configuration for the target table.
        rows: List of source JSON records.
        job_id: Optional migration job ID for the audit column.

    Returns:
        ``(loaded_count, failed_count, error_details)`` tuple.
    """
    if not rows:
        return 0, 0, []

    columns = mapping.get("columns", [])
    table_name = mapping.get("target_table", "")

    # Transform rows
    bind_rows: list[dict[str, Any]] = []
    for row in rows:
        bind_data = apply_transforms(row, columns)
        if job_id is not None:
            bind_data["MIGRATION_JOB_ID"] = job_id
        bind_rows.append(bind_data)

    # Determine SQL (MERGE if PKs, INSERT otherwise)
    pk_cols = [c for c in columns if c.get("is_primary_key")]
    if pk_cols:
        sql = generate_merge_sql(mapping)
    else:
        sql = _generate_insert_sql(mapping)

    conn = get_connection()
    errors_detail: list[dict] = []
    loaded = 0
    failed = 0

    try:
        cursor = conn.cursor()
        cursor.executemany(sql, bind_rows, batcherrors=True)

        # Process batch errors
        batch_errors = cursor.getbatcherrors()
        failed_offsets = set()
        for error in batch_errors:
            failed_offsets.add(error.offset)
            errors_detail.append({
                "offset": error.offset,
                "error_code": str(error.code),
                "error_message": error.message,
                "source_record": str(rows[error.offset])[:4000],
            })
            logger.warning(
                "Row %d failed for %s: [%s] %s",
                error.offset, table_name, error.code, error.message,
            )

        conn.commit()
        cursor.close()

        loaded = len(bind_rows) - len(failed_offsets)
        failed = len(failed_offsets)

        logger.info(
            "Batch insert to %s: %d loaded, %d failed (of %d).",
            table_name, loaded, failed, len(bind_rows),
        )

    except oracledb.Error as exc:
        logger.error("Batch insert failed for %s: %s", table_name, exc)
        failed = len(bind_rows)
        errors_detail.append({
            "offset": -1,
            "error_code": str(getattr(exc, "code", "")),
            "error_message": str(exc),
            "source_record": "",
        })
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        release_connection(conn)

    return loaded, failed, errors_detail


def batch_upsert(
    mapping: dict,
    rows: list[dict],
    job_id: int | None = None,
) -> tuple[int, int, list[dict]]:
    """Upsert (MERGE) a batch of rows into the target table.

    This is functionally equivalent to ``batch_insert()`` when the
    mapping contains primary key columns (it uses MERGE automatically).

    Args:
        mapping: The mapping configuration.
        rows: Source records.
        job_id: Optional migration job ID.

    Returns:
        ``(loaded_count, failed_count, error_details)`` tuple.
    """
    return batch_insert(mapping, rows, job_id)


def get_current_row_count(table_name: str, schema: str = "") -> int:
    """Return the current row count for a target table.

    Args:
        table_name: The table name.
        schema: Optional schema.
    """
    full_name = f"{schema}.{table_name}" if schema else table_name
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) FROM {full_name}")
        count = cursor.fetchone()[0]
        cursor.close()
        return count
    except oracledb.Error:
        return 0
    finally:
        release_connection(conn)
