"""Oracle Autonomous Database modules for restapi2adb."""
