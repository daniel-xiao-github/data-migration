"""Centralized logging setup for restapi2adb.

Configures file and console handlers with automatic rotation, structured
formatting, and sensitive-data masking.
"""

import logging
import logging.handlers
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

_LOG_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "logs"

# Patterns that look like secrets (API keys, tokens, passwords)
_SENSITIVE_PATTERNS = [
    re.compile(r'(sk-ant-api\d{2}-[A-Za-z0-9_-]{20,})', re.IGNORECASE),
    re.compile(r'(Bearer\s+[A-Za-z0-9_\-.]+)', re.IGNORECASE),
    re.compile(r'(password["\s:=]+)[^\s,}"\']+', re.IGNORECASE),
    re.compile(r'(api[_-]?key["\s:=]+)[^\s,}"\']+', re.IGNORECASE),
    re.compile(r'(secret["\s:=]+)[^\s,}"\']+', re.IGNORECASE),
    re.compile(r'(token["\s:=]+)[^\s,}"\']+', re.IGNORECASE),
]


class SensitiveMaskingFilter(logging.Filter):
    """Logging filter that redacts sensitive data from log messages."""

    def filter(self, record: logging.LogRecord) -> bool:
        if isinstance(record.msg, str):
            record.msg = mask_sensitive(record.msg)
        if record.args:
            if isinstance(record.args, dict):
                record.args = {
                    k: mask_sensitive(str(v)) if isinstance(v, str) else v
                    for k, v in record.args.items()
                }
            elif isinstance(record.args, tuple):
                record.args = tuple(
                    mask_sensitive(str(a)) if isinstance(a, str) else a
                    for a in record.args
                )
        return True


def mask_sensitive(text: str) -> str:
    """Replace sensitive-looking substrings with ``***REDACTED***``.

    Args:
        text: The string to sanitize.

    Returns:
        Sanitized string with secrets masked.
    """
    for pattern in _SENSITIVE_PATTERNS:
        text = pattern.sub(lambda m: m.group(0)[:8] + "***REDACTED***", text)
    return text


def setup_logging(
    level: str = "INFO",
    max_bytes: int = 10 * 1024 * 1024,
    backup_count: int = 30,
    log_dir: Optional[Path] = None,
) -> None:
    """Configure the root logger and application-specific loggers.

    Creates four rotating log files:
    * ``app_{date}.log`` – general application log
    * ``migration_{date}.log`` – migration engine events
    * ``api_{date}.log`` – REST API call logs
    * ``error_{date}.log`` – ERROR and above only

    Args:
        level: Root log level name (DEBUG, INFO, …).
        max_bytes: Max size per log file before rotation.
        backup_count: Number of rotated files to keep.
        log_dir: Override for the log directory.
    """
    log_dir = Path(log_dir) if log_dir else _LOG_DIR
    log_dir.mkdir(parents=True, exist_ok=True)

    date_tag = datetime.now().strftime("%Y%m%d")
    fmt = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    mask_filter = SensitiveMaskingFilter()
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Clear existing handlers to avoid duplicates on re-init
    root.handlers.clear()

    # Console handler
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    console.addFilter(mask_filter)
    root.addHandler(console)

    # Per-category file handlers
    categories = {
        f"app_{date_tag}.log": (logging.getLogger(), level),
        f"migration_{date_tag}.log": (logging.getLogger("app.migration"), level),
        f"api_{date_tag}.log": (logging.getLogger("app.api_client"), level),
        f"error_{date_tag}.log": (logging.getLogger(), "ERROR"),
    }

    for filename, (target_logger, lvl) in categories.items():
        handler = logging.handlers.RotatingFileHandler(
            log_dir / filename,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8",
        )
        handler.setLevel(getattr(logging, lvl.upper(), logging.INFO))
        handler.setFormatter(fmt)
        handler.addFilter(mask_filter)
        root.addHandler(handler)

    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    root.info("Logging initialized – level=%s, dir=%s", level, log_dir)
