"""YAML configuration loader/saver with encrypted-secret support.

Reads ``config/app_config.yaml`` (and optionally other YAML files) into a
dict, and provides helpers to read/write individual keys.  Secret values
are stored encrypted via :mod:`app.utils.secret_manager`.
"""

import logging
import os
import secrets
from pathlib import Path
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_DEFAULT_CONFIG_PATH = _PROJECT_ROOT / "config" / "app_config.yaml"

# Singleton cache
_config_cache: Optional[dict[str, Any]] = None


def _read_version() -> str:
    """Read version from the project-root VERSION file."""
    ver_file = _PROJECT_ROOT / "VERSION"
    try:
        return ver_file.read_text().strip()
    except FileNotFoundError:
        return "0.0.0"


def _default_config() -> dict[str, Any]:
    """Return the full default configuration dictionary."""
    return {
        "app": {
            "name": "restapi2adb",
            "version": _read_version(),
            "host": "0.0.0.0",
            "port": 5100,
            "debug": False,
            "secret_key": secrets.token_hex(32),
        },
        "ai": {
            "default_provider": "anthropic",
            "default_model": "claude-sonnet-4-5-20250514",
            "max_tokens": 8192,
            "temperature": 0.1,
        },
        "oracle": {
            "connection_type": "wallet",
            "wallet_path": "",
            "tns_alias": "",
            "username": "",
            "pool_min": 2,
            "pool_max": 10,
            "pool_increment": 1,
        },
        "migration": {
            "default_batch_size": 500,
            "max_concurrent_tasks": 3,
            "rate_limit_per_second": 10,
            "max_retries": 3,
            "retry_backoff_base": 2,
            "checkpoint_frequency": 1,
        },
        "update": {
            "auto_check": True,
        },
        "logging": {
            "level": "INFO",
            "max_file_size_mb": 10,
            "retention_days": 30,
        },
    }


def load_config(config_path: Optional[Path] = None, *, force: bool = False) -> dict[str, Any]:
    """Load application configuration from YAML.

    Creates the file with sensible defaults when it doesn't exist yet.

    Args:
        config_path: Path to the YAML file. Defaults to ``config/app_config.yaml``.
        force: If *True*, bypass the in-memory cache.

    Returns:
        The configuration dictionary.
    """
    global _config_cache
    if _config_cache is not None and not force:
        return _config_cache

    config_path = Path(config_path) if config_path else _DEFAULT_CONFIG_PATH

    if not config_path.exists():
        logger.info("Config file not found – generating default at %s", config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        cfg = _default_config()
        save_config(cfg, config_path)
    else:
        with open(config_path, "r", encoding="utf-8") as fh:
            cfg = yaml.safe_load(fh) or {}
        # Merge with defaults so new keys are always present
        defaults = _default_config()
        cfg = _deep_merge(defaults, cfg)

    _config_cache = cfg
    return cfg


def save_config(cfg: dict[str, Any], config_path: Optional[Path] = None) -> None:
    """Persist the configuration dict to YAML.

    Args:
        cfg: Configuration dictionary.
        config_path: Destination path.
    """
    config_path = Path(config_path) if config_path else _DEFAULT_CONFIG_PATH
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as fh:
        yaml.dump(cfg, fh, default_flow_style=False, sort_keys=False)
    logger.info("Configuration saved to %s", config_path)


def get(key: str, default: Any = None) -> Any:
    """Retrieve a dot-separated key from the loaded config.

    Example::

        get("ai.default_model")  # → "claude-sonnet-4-5-20250514"

    Args:
        key: Dot-separated config path.
        default: Fallback if the key is missing.
    """
    cfg = load_config()
    parts = key.split(".")
    node: Any = cfg
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part)
        else:
            return default
        if node is None:
            return default
    return node


def set_value(key: str, value: Any, config_path: Optional[Path] = None) -> None:
    """Set a dot-separated key in the config and persist.

    Args:
        key: Dot-separated config path.
        value: New value.
        config_path: Optional config file path.
    """
    cfg = load_config(config_path, force=True)
    parts = key.split(".")
    node = cfg
    for part in parts[:-1]:
        node = node.setdefault(part, {})
    node[parts[-1]] = value
    save_config(cfg, config_path)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge *override* into *base*, returning a new dict."""
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged
