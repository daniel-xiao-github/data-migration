"""Input validation utilities for restapi2adb.

Provides reusable validators for URLs, identifiers, Oracle names, and
other user-supplied values.
"""

import logging
import re
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Oracle identifier rules: up to 128 chars, starts with letter, alphanumeric + _$#
_ORACLE_IDENT_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_$#]{0,127}$')

# Reasonable API key pattern (min 20 chars, alphanumeric + dashes/underscores)
_API_KEY_RE = re.compile(r'^[A-Za-z0-9_\-]{20,}$')


def is_valid_url(url: str) -> bool:
    """Return *True* if *url* is a syntactically valid HTTP(S) URL.

    Args:
        url: The URL string to validate.
    """
    try:
        result = urlparse(url)
        return result.scheme in ("http", "https") and bool(result.netloc)
    except Exception:
        return False


def is_valid_oracle_identifier(name: str) -> bool:
    """Return *True* if *name* is a valid Oracle identifier.

    Args:
        name: The identifier to test (table name, column name, etc.).
    """
    return bool(_ORACLE_IDENT_RE.match(name))


def sanitize_oracle_identifier(name: str) -> str:
    """Convert an arbitrary string into a safe Oracle identifier.

    Replaces non-alphanumeric characters with underscores, upper-cases the
    result, and truncates to 128 characters.

    Args:
        name: The raw name.

    Returns:
        A sanitized Oracle-safe identifier.
    """
    sanitized = re.sub(r'[^A-Za-z0-9_]', '_', name).upper().strip('_')
    if sanitized and not sanitized[0].isalpha():
        sanitized = "T_" + sanitized
    return sanitized[:128]


def is_valid_api_key(key: str) -> bool:
    """Perform a basic format check on an API key string.

    This does NOT verify the key with the provider; it only checks length
    and character set.

    Args:
        key: The API key to validate.
    """
    return bool(key) and len(key) >= 20


def validate_port(port: int) -> bool:
    """Return *True* if *port* is a valid TCP port number.

    Args:
        port: Port number.
    """
    return isinstance(port, int) and 1 <= port <= 65535


def validate_batch_size(size: int) -> bool:
    """Return *True* if *size* is a reasonable batch size (1–10 000).

    Args:
        size: Batch size value.
    """
    return isinstance(size, int) and 1 <= size <= 10_000


def validate_json_path(path: str) -> bool:
    """Return *True* if *path* looks like a JSONPath expression.

    Accepts simple dot-notation paths starting with ``$``.

    Args:
        path: The JSONPath expression.
    """
    return bool(path) and path.startswith("$")


def validate_mapping_column(col: dict) -> list[str]:
    """Validate a single column mapping dictionary.

    Args:
        col: A dict with keys like ``source_path``, ``target_column``,
            ``oracle_type``, etc.

    Returns:
        A list of validation error strings (empty if valid).
    """
    errors: list[str] = []

    if not col.get("source_path"):
        errors.append("source_path is required")
    elif not validate_json_path(col["source_path"]):
        errors.append(f"Invalid JSONPath: {col['source_path']}")

    target = col.get("target_column", "")
    if not target:
        errors.append("target_column is required")
    elif not is_valid_oracle_identifier(target):
        errors.append(f"Invalid Oracle column name: {target}")

    if not col.get("oracle_type"):
        errors.append("oracle_type is required")

    return errors


def validate_oauth_config(cfg: dict) -> list[str]:
    """Validate an OAuth configuration dictionary.

    Args:
        cfg: Dictionary with OAuth fields.

    Returns:
        A list of validation error strings (empty if valid).
    """
    errors: list[str] = []
    required_fields = ["app_name", "api_base_url", "authorization_url",
                       "token_url", "client_id", "client_secret"]
    for field in required_fields:
        if not cfg.get(field):
            errors.append(f"'{field}' is required")

    for url_field in ["api_base_url", "authorization_url", "token_url"]:
        value = cfg.get(url_field, "")
        if value and not is_valid_url(value):
            errors.append(f"'{url_field}' is not a valid URL: {value}")

    return errors
