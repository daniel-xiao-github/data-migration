"""Fernet-based secret encryption and decryption for restapi2adb.

Provides secure storage and retrieval of sensitive values such as API keys,
OAuth tokens, and database passwords using symmetric Fernet encryption.
"""

import json
import logging
import os
import stat
from pathlib import Path
from typing import Any, Optional

from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)

# Default key file location relative to project root
_DEFAULT_KEY_PATH = Path(__file__).resolve().parent.parent.parent / "config" / ".secrets.key"


def get_or_create_key(key_path: Optional[Path] = None) -> bytes:
    """Load the Fernet key from disk, or generate and persist a new one.

    Args:
        key_path: Path to the key file.  Defaults to config/.secrets.key.

    Returns:
        The raw Fernet key bytes.
    """
    key_path = Path(key_path) if key_path else _DEFAULT_KEY_PATH
    key_path.parent.mkdir(parents=True, exist_ok=True)

    if key_path.exists():
        key = key_path.read_bytes().strip()
        logger.debug("Loaded encryption key from %s", key_path)
        return key

    key = Fernet.generate_key()
    key_path.write_bytes(key)

    # Restrict permissions on Unix systems
    try:
        os.chmod(key_path, stat.S_IRUSR | stat.S_IWUSR)  # 600
    except OSError:
        pass  # Windows doesn't support Unix permissions

    logger.info("Generated new encryption key at %s", key_path)
    return key


def _get_fernet(key_path: Optional[Path] = None) -> Fernet:
    """Return a Fernet instance using the stored (or newly created) key."""
    return Fernet(get_or_create_key(key_path))


def encrypt_value(plaintext: str, key_path: Optional[Path] = None) -> bytes:
    """Encrypt a plaintext string and return the cipher-text bytes.

    Args:
        plaintext: The value to encrypt.
        key_path: Optional path to the Fernet key file.

    Returns:
        Encrypted bytes suitable for writing to disk.
    """
    f = _get_fernet(key_path)
    return f.encrypt(plaintext.encode("utf-8"))


def decrypt_value(ciphertext: bytes, key_path: Optional[Path] = None) -> str:
    """Decrypt cipher-text bytes back to a plaintext string.

    Args:
        ciphertext: The encrypted bytes to decrypt.
        key_path: Optional path to the Fernet key file.

    Returns:
        The original plaintext string.

    Raises:
        InvalidToken: If the key is wrong or data is corrupted.
    """
    f = _get_fernet(key_path)
    return f.decrypt(ciphertext).decode("utf-8")


def save_encrypted_json(data: dict[str, Any], file_path: Path,
                        key_path: Optional[Path] = None) -> None:
    """Serialize a dict as JSON, encrypt it, and write to *file_path*.

    Args:
        data: The dictionary to persist.
        file_path: Destination file (e.g. ``data/tokens/ai_credentials.enc``).
        key_path: Optional Fernet key path.
    """
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    plaintext = json.dumps(data)
    encrypted = encrypt_value(plaintext, key_path)
    file_path.write_bytes(encrypted)
    logger.info("Saved encrypted data to %s", file_path)


def load_encrypted_json(file_path: Path,
                        key_path: Optional[Path] = None) -> Optional[dict[str, Any]]:
    """Read an encrypted JSON file and return the decoded dict.

    Args:
        file_path: Path to the encrypted file.
        key_path: Optional Fernet key path.

    Returns:
        The decrypted dictionary, or ``None`` if the file doesn't exist or
        decryption fails.
    """
    file_path = Path(file_path)
    if not file_path.exists():
        logger.debug("Encrypted file not found: %s", file_path)
        return None
    try:
        ciphertext = file_path.read_bytes()
        plaintext = decrypt_value(ciphertext, key_path)
        return json.loads(plaintext)
    except (InvalidToken, json.JSONDecodeError) as exc:
        logger.error("Failed to decrypt/parse %s: %s", file_path, exc)
        return None
