"""REST API client modules for restapi2adb."""
