"""Generic REST API client driven by OpenAPI specifications.

Makes authenticated HTTP requests to any REST API using the configured
OAuth tokens or custom headers, with rate limiting and retry logic.
"""

import logging
import time
from typing import Any, Optional

import httpx

from app.auth.oauth_manager import get_valid_access_token
from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)


class RESTClient:
    """Configurable REST API client with rate limiting and retries.

    Args:
        app_name: The REST API application name (for token lookup).
        base_url: The API base URL.
        rate_limit: Max requests per second.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        app_name: str,
        base_url: str,
        rate_limit: float = 10.0,
        timeout: int = 30,
    ):
        self.app_name = app_name
        self.base_url = base_url.rstrip("/")
        self.rate_limit = rate_limit
        self.timeout = timeout

        cfg = load_config().get("migration", {})
        self.max_retries = cfg.get("max_retries", 3)
        self.backoff_base = cfg.get("retry_backoff_base", 2)

        self._last_request_time: float = 0.0
        self._client = httpx.Client(timeout=timeout)

        logger.info(
            "RESTClient initialised for '%s' (base_url=%s, rate=%.1f/s).",
            app_name, base_url, rate_limit,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def _rate_limit_wait(self) -> None:
        """Enforce the configured rate limit between requests."""
        if self.rate_limit <= 0:
            return
        min_interval = 1.0 / self.rate_limit
        elapsed = time.time() - self._last_request_time
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)

    def _get_auth_headers(self) -> dict[str, str]:
        """Build authorization headers using the stored OAuth token."""
        token = get_valid_access_token(self.app_name)
        if token:
            return {"Authorization": f"Bearer {token}"}
        return {}

    def get(
        self,
        endpoint: str,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
    ) -> dict[str, Any]:
        """Make an authenticated GET request with retries.

        Args:
            endpoint: The API endpoint path (appended to base_url).
            params: Query parameters.
            headers: Additional HTTP headers.

        Returns:
            The parsed JSON response body.

        Raises:
            httpx.HTTPStatusError: After all retries are exhausted.
        """
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        req_headers = self._get_auth_headers()
        if headers:
            req_headers.update(headers)

        for attempt in range(1, self.max_retries + 1):
            self._rate_limit_wait()
            self._last_request_time = time.time()

            try:
                response = self._client.get(url, params=params, headers=req_headers)
                response.raise_for_status()
                logger.debug(
                    "GET %s → %d (%d bytes).",
                    url, response.status_code, len(response.content),
                )
                return response.json()

            except httpx.HTTPStatusError as exc:
                status = exc.response.status_code
                if status == 429:
                    # Rate limited – use Retry-After or exponential backoff
                    retry_after = exc.response.headers.get("Retry-After")
                    wait = float(retry_after) if retry_after else self.backoff_base ** attempt
                    logger.warning(
                        "Rate limited (429) on %s; waiting %.1fs (attempt %d/%d).",
                        url, wait, attempt, self.max_retries,
                    )
                    time.sleep(wait)
                elif status >= 500 and attempt < self.max_retries:
                    wait = self.backoff_base ** attempt
                    logger.warning(
                        "Server error %d on %s; retrying in %.1fs (attempt %d/%d).",
                        status, url, wait, attempt, self.max_retries,
                    )
                    time.sleep(wait)
                else:
                    logger.error("HTTP %d on GET %s: %s", status, url, exc.response.text[:500])
                    raise

            except httpx.RequestError as exc:
                if attempt < self.max_retries:
                    wait = self.backoff_base ** attempt
                    logger.warning(
                        "Request error on %s: %s; retrying in %.1fs.",
                        url, exc, wait,
                    )
                    time.sleep(wait)
                else:
                    raise

        raise RuntimeError(f"GET {url} failed after {self.max_retries} retries.")

    def get_all_pages(
        self,
        endpoint: str,
        pagination_config: dict,
        params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        start_offset: int = 0,
        start_page_token: str = "",
        start_cursor: str = "",
    ) -> tuple[list[dict], dict]:
        """Fetch all pages from a paginated endpoint.

        Args:
            endpoint: The API endpoint path.
            pagination_config: Dict with ``type``, ``page_size_param``,
                ``default_page_size``, etc.
            params: Additional query parameters.
            headers: Additional headers.
            start_offset: Resume offset for offset-based pagination.
            start_page_token: Resume token for token-based pagination.
            start_cursor: Resume cursor for cursor-based pagination.

        Returns:
            ``(all_records, last_checkpoint)`` – a flat list of all fetched
            records and a dict with the final pagination state.
        """
        from app.api_client.pagination_handler import PaginationHandler

        handler = PaginationHandler(pagination_config)
        all_records: list[dict] = []
        page_params = params.copy() if params else {}
        checkpoint: dict[str, Any] = {}

        # Set initial state for resume
        handler.set_start_state(start_offset, start_page_token, start_cursor)

        while True:
            current_params = handler.get_page_params(page_params)
            response = self.get(endpoint, params=current_params, headers=headers)

            records = handler.extract_records(response)
            all_records.extend(records)

            checkpoint = handler.get_checkpoint()
            logger.debug(
                "Fetched page: %d records (total: %d) from %s.",
                len(records), len(all_records), endpoint,
            )

            if not handler.has_next_page(response, records):
                break

            handler.advance(response)

        logger.info(
            "Completed pagination for %s: %d total records.",
            endpoint, len(all_records),
        )
        return all_records, checkpoint
