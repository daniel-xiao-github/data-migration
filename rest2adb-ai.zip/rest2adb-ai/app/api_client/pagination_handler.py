"""Auto-pagination handler for REST API responses.

Supports offset-based, cursor-based, and page-token-based pagination
patterns commonly used across REST APIs.
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class PaginationHandler:
    """Handles various REST API pagination patterns.

    Args:
        config: Pagination configuration dict with keys like ``type``,
            ``page_size_param``, ``default_page_size``, ``offset_param``,
            ``cursor_param``, ``page_token_param``, ``response_records_path``,
            ``response_next_token_path``, ``response_has_more_path``.
    """

    def __init__(self, config: dict):
        self.pag_type: str = config.get("type", "offset")
        self.page_size_param: str = config.get("page_size_param", "limit")
        self.page_size: int = config.get("default_page_size", 100)

        # Offset pagination
        self.offset_param: str = config.get("offset_param", "offset")

        # Cursor/token pagination
        self.cursor_param: str = config.get("cursor_param", "cursor")
        self.page_token_param: str = config.get("page_token_param", "pageToken")

        # Response extraction
        self.records_path: str = config.get("response_records_path", "")
        self.next_token_path: str = config.get("response_next_token_path", "")
        self.has_more_path: str = config.get("response_has_more_path", "")
        self.total_count_path: str = config.get("response_total_count_path", "")

        # State
        self._current_offset: int = 0
        self._current_cursor: str = ""
        self._current_page_token: str = ""
        self._page_count: int = 0

    def set_start_state(
        self,
        offset: int = 0,
        page_token: str = "",
        cursor: str = "",
    ) -> None:
        """Set the initial pagination state (for resuming).

        Args:
            offset: Starting offset.
            page_token: Starting page token.
            cursor: Starting cursor.
        """
        self._current_offset = offset
        self._current_page_token = page_token
        self._current_cursor = cursor

    def get_page_params(self, base_params: dict) -> dict:
        """Build query parameters for the current page.

        Args:
            base_params: Base parameters to merge with pagination params.

        Returns:
            Complete query parameter dict.
        """
        params = base_params.copy()
        params[self.page_size_param] = self.page_size

        if self.pag_type == "offset":
            params[self.offset_param] = self._current_offset
        elif self.pag_type == "cursor":
            if self._current_cursor:
                params[self.cursor_param] = self._current_cursor
        elif self.pag_type == "page_token":
            if self._current_page_token:
                params[self.page_token_param] = self._current_page_token

        return params

    def extract_records(self, response: Any) -> list[dict]:
        """Extract the data records from an API response.

        Args:
            response: The parsed JSON response.

        Returns:
            List of record dicts.
        """
        if not self.records_path:
            # Auto-detect common patterns
            if isinstance(response, list):
                return response
            if isinstance(response, dict):
                for key in ("data", "items", "results", "records", "value",
                            "entities", "objects", "rows", "entries"):
                    if key in response and isinstance(response[key], list):
                        return response[key]
                # If there's a single list value, use it
                for value in response.values():
                    if isinstance(value, list):
                        return value
            return [response] if isinstance(response, dict) else []

        return self._extract_path(response, self.records_path)

    def has_next_page(self, response: Any, current_records: list) -> bool:
        """Determine whether more pages are available.

        Args:
            response: The parsed JSON response.
            current_records: Records extracted from this page.

        Returns:
            True if there are more pages to fetch.
        """
        if not current_records or len(current_records) < self.page_size:
            return False

        if self.has_more_path:
            more = self._extract_path_scalar(response, self.has_more_path)
            return bool(more)

        if self.next_token_path:
            token = self._extract_path_scalar(response, self.next_token_path)
            return bool(token)

        if self.pag_type == "offset":
            # Check total count if available
            if self.total_count_path:
                total = self._extract_path_scalar(response, self.total_count_path)
                if total is not None:
                    return (self._current_offset + len(current_records)) < int(total)
            # Otherwise, if we got a full page there might be more
            return len(current_records) >= self.page_size

        return False

    def advance(self, response: Any) -> None:
        """Advance the pagination state to the next page.

        Args:
            response: The response from the current page.
        """
        self._page_count += 1

        if self.pag_type == "offset":
            self._current_offset += self.page_size

        elif self.pag_type == "cursor":
            if self.next_token_path:
                cursor = self._extract_path_scalar(response, self.next_token_path)
                self._current_cursor = str(cursor) if cursor else ""
            else:
                # Try common cursor field names
                for key in ("next_cursor", "cursor", "after", "next"):
                    if isinstance(response, dict) and key in response:
                        self._current_cursor = str(response[key])
                        break

        elif self.pag_type == "page_token":
            if self.next_token_path:
                token = self._extract_path_scalar(response, self.next_token_path)
                self._current_page_token = str(token) if token else ""
            else:
                for key in ("nextPageToken", "next_page_token", "pageToken", "nextToken"):
                    if isinstance(response, dict) and key in response:
                        self._current_page_token = str(response[key])
                        break

    def get_checkpoint(self) -> dict:
        """Return the current pagination state for checkpointing.

        Returns:
            Dict with ``type``, ``offset``, ``cursor``, ``page_token``,
            ``page_count``.
        """
        return {
            "type": self.pag_type,
            "offset": self._current_offset,
            "cursor": self._current_cursor,
            "page_token": self._current_page_token,
            "page_count": self._page_count,
        }

    # ── Helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _extract_path(data: Any, path: str) -> list:
        """Extract a list from a dot-separated path in the response."""
        parts = path.strip("$.").split(".")
        node = data
        for part in parts:
            if isinstance(node, dict):
                node = node.get(part)
            else:
                return []
            if node is None:
                return []
        return node if isinstance(node, list) else [node]

    @staticmethod
    def _extract_path_scalar(data: Any, path: str) -> Any:
        """Extract a scalar value from a dot-separated path."""
        parts = path.strip("$.").split(".")
        node = data
        for part in parts:
            if isinstance(node, dict):
                node = node.get(part)
            else:
                return None
            if node is None:
                return None
        return node
