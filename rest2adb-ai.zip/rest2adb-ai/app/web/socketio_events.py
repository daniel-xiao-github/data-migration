"""Real-time WebSocket event handlers for migration progress.

Registers Flask-SocketIO event handlers on the ``/migration`` namespace
for live progress tracking of migration jobs.
"""

import logging

from app import socketio
from flask_socketio import emit, join_room, leave_room

logger = logging.getLogger(__name__)


@socketio.on("connect", namespace="/migration")
def on_connect():
    """Handle client connection to the migration namespace."""
    logger.info("WebSocket client connected to /migration.")
    emit("connected", {"message": "Connected to migration events."})


@socketio.on("disconnect", namespace="/migration")
def on_disconnect():
    """Handle client disconnection."""
    logger.info("WebSocket client disconnected from /migration.")


@socketio.on("join_job", namespace="/migration")
def on_join_job(data):
    """Join a job-specific room for targeted events.

    Args:
        data: Dict with ``job_id``.
    """
    job_id = data.get("job_id")
    if job_id:
        room = f"job_{job_id}"
        join_room(room)
        logger.info("Client joined room: %s", room)
        emit("joined", {"room": room, "job_id": job_id})


@socketio.on("leave_job", namespace="/migration")
def on_leave_job(data):
    """Leave a job-specific room.

    Args:
        data: Dict with ``job_id``.
    """
    job_id = data.get("job_id")
    if job_id:
        room = f"job_{job_id}"
        leave_room(room)
        logger.info("Client left room: %s", room)


@socketio.on("request_status", namespace="/migration")
def on_request_status(data):
    """Handle a status request for a specific job.

    Args:
        data: Dict with ``job_id``.
    """
    job_id = data.get("job_id")
    if not job_id:
        emit("error", {"message": "job_id is required."})
        return

    try:
        from app.migration.control_tables import get_job, get_tasks_for_job

        job = get_job(job_id)
        if not job:
            emit("error", {"message": f"Job {job_id} not found."})
            return

        tasks = get_tasks_for_job(job_id)

        # Convert datetimes for JSON
        for item in [job] + tasks:
            for key, val in item.items():
                if hasattr(val, "isoformat"):
                    item[key] = str(val)

        emit("job_status", {"job": job, "tasks": tasks})
    except Exception as exc:
        emit("error", {"message": str(exc)})
