/**
 * restapi2adb – OAuth Configuration UI
 */

document.addEventListener('DOMContentLoaded', function () {
    loadOAuthConfigs();

    document.getElementById('btnNewApp').addEventListener('click', resetForm);
    document.getElementById('btnSaveOAuth').addEventListener('click', saveConfig);
    document.getElementById('btnAuthorize').addEventListener('click', authorize);
    document.getElementById('btnDeleteOAuth').addEventListener('click', deleteConfig);
    document.getElementById('btnAiSuggest').addEventListener('click', aiSuggest);
    document.getElementById('btnAddParam').addEventListener('click', addParamRow);

    document.getElementById('oraConnType') && document.getElementById('oraConnType').addEventListener('change', toggleConnFields);
});

let currentAppKey = '';

async function loadOAuthConfigs() {
    try {
        const configs = await apiCall('/api/oauth/configs');
        const list = document.getElementById('appList');
        const empty = document.getElementById('appListEmpty');

        if (!configs || configs.length === 0) {
            empty.classList.remove('d-none');
            return;
        }
        empty.classList.add('d-none');
        list.innerHTML = '';

        configs.forEach(function (cfg) {
            const name = cfg.app_name || cfg.key;
            const token = cfg.token_status || {};
            const statusIcon = token.is_valid ? '<i class="bi bi-check-circle-fill text-success"></i>' :
                               token.has_token ? '<i class="bi bi-exclamation-circle-fill text-warning"></i>' :
                               '<i class="bi bi-x-circle text-muted"></i>';
            const item = document.createElement('a');
            item.href = '#';
            item.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center';
            item.innerHTML = '<span>' + name + '</span>' + statusIcon;
            item.addEventListener('click', function (e) {
                e.preventDefault();
                loadConfigIntoForm(cfg);
            });
            list.appendChild(item);
        });
    } catch (err) {
        console.error('Failed to load OAuth configs:', err);
    }
}

function loadConfigIntoForm(cfg) {
    currentAppKey = cfg.key || '';
    document.getElementById('formTitle').textContent = 'Edit: ' + (cfg.app_name || '');
    document.getElementById('appName').value = cfg.app_name || '';
    document.getElementById('apiBaseUrl').value = cfg.api_base_url || '';
    document.getElementById('authUrl').value = cfg.authorization_url || '';
    document.getElementById('tokenUrl').value = cfg.token_url || '';
    document.getElementById('scopes').value = cfg.scopes || '';
    document.getElementById('clientId').value = cfg.client_id || '';
    document.getElementById('clientSecret').value = '';
    document.getElementById('redirectUri').value = cfg.redirect_uri || 'http://localhost:5100/oauth/callback';

    // Additional params
    const container = document.getElementById('additionalParams');
    container.innerHTML = '';
    if (cfg.additional_params) {
        Object.entries(cfg.additional_params).forEach(function (entry) {
            addParamRow(entry[0], entry[1]);
        });
    }

    // Token status
    const tokenDiv = document.getElementById('tokenStatus');
    const tokenText = document.getElementById('tokenStatusText');
    if (cfg.token_status && cfg.token_status.has_token) {
        tokenDiv.classList.remove('d-none');
        if (cfg.token_status.is_valid) {
            tokenText.textContent = 'Valid (expires: ' + formatDate(cfg.token_status.expires_at * 1000) + ')';
        } else {
            tokenText.textContent = 'Expired. Re-authorize to refresh.';
        }
    } else {
        tokenDiv.classList.add('d-none');
    }

    document.getElementById('aiSuggestionBadge').classList.add('d-none');
}

function resetForm() {
    currentAppKey = '';
    document.getElementById('formTitle').textContent = 'New OAuth Configuration';
    document.getElementById('appName').value = '';
    document.getElementById('apiBaseUrl').value = '';
    document.getElementById('authUrl').value = '';
    document.getElementById('tokenUrl').value = '';
    document.getElementById('scopes').value = '';
    document.getElementById('clientId').value = '';
    document.getElementById('clientSecret').value = '';
    document.getElementById('redirectUri').value = 'http://localhost:5100/oauth/callback';
    document.getElementById('additionalParams').innerHTML = '';
    document.getElementById('tokenStatus').classList.add('d-none');
    document.getElementById('aiSuggestionBadge').classList.add('d-none');
}

async function saveConfig() {
    const additional = {};
    document.querySelectorAll('.param-row').forEach(function (row) {
        const k = row.querySelector('.param-key').value.trim();
        const v = row.querySelector('.param-value').value.trim();
        if (k) additional[k] = v;
    });

    const data = {
        app_name: document.getElementById('appName').value.trim(),
        api_base_url: document.getElementById('apiBaseUrl').value.trim(),
        authorization_url: document.getElementById('authUrl').value.trim(),
        token_url: document.getElementById('tokenUrl').value.trim(),
        scopes: document.getElementById('scopes').value.trim(),
        client_id: document.getElementById('clientId').value.trim(),
        client_secret: document.getElementById('clientSecret').value,
        redirect_uri: document.getElementById('redirectUri').value.trim(),
        additional_params: additional,
    };

    try {
        await apiCall('/api/oauth/config', 'POST', data);
        showToast('Configuration saved!', 'success');
        loadOAuthConfigs();
    } catch (err) {
        showToast('Save failed: ' + err.message, 'danger');
    }
}

async function authorize() {
    const appName = document.getElementById('appName').value.trim();
    if (!appName) {
        showToast('Enter an app name first.', 'warning');
        return;
    }
    try {
        const data = await apiCall('/api/oauth/authorize/' + encodeURIComponent(appName), 'POST');
        if (data.authorization_url) {
            window.open(data.authorization_url, '_blank');
        }
    } catch (err) {
        showToast('Authorization failed: ' + err.message, 'danger');
    }
}

async function deleteConfig() {
    const appName = document.getElementById('appName').value.trim();
    if (!appName || !confirm('Delete configuration for "' + appName + '"?')) return;
    try {
        await apiCall('/api/oauth/config/' + encodeURIComponent(appName), 'DELETE');
        showToast('Configuration deleted.', 'success');
        resetForm();
        loadOAuthConfigs();
    } catch (err) {
        showToast('Delete failed: ' + err.message, 'danger');
    }
}

async function aiSuggest() {
    const appName = document.getElementById('appName').value.trim();
    if (!appName) {
        showToast('Enter an app name first.', 'warning');
        return;
    }

    const btn = document.getElementById('btnAiSuggest');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Suggesting...';

    try {
        const data = await apiCall('/api/oauth/suggest', 'POST', { app_name: appName });
        if (data.api_base_url) document.getElementById('apiBaseUrl').value = data.api_base_url;
        if (data.authorization_url) document.getElementById('authUrl').value = data.authorization_url;
        if (data.token_url) document.getElementById('tokenUrl').value = data.token_url;
        if (data.default_scopes) document.getElementById('scopes').value = data.default_scopes;
        document.getElementById('aiSuggestionBadge').classList.remove('d-none');
        showToast('AI suggestions applied!', 'success');
    } catch (err) {
        showToast('AI suggestion failed: ' + err.message, 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-stars"></i> AI Suggest';
    }
}

function addParamRow(key, value) {
    key = typeof key === 'string' ? key : '';
    value = typeof value === 'string' ? value : '';
    const container = document.getElementById('additionalParams');
    const row = document.createElement('div');
    row.className = 'input-group mb-1 param-row';
    row.innerHTML = '<input type="text" class="form-control param-key" placeholder="Key" value="' + key + '">' +
                    '<input type="text" class="form-control param-value" placeholder="Value" value="' + value + '">' +
                    '<button class="btn btn-outline-danger" type="button" onclick="this.parentElement.remove()"><i class="bi bi-x"></i></button>';
    container.appendChild(row);
}
