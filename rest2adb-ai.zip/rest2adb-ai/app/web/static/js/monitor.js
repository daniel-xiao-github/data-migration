/**
 * restapi2adb – Monitor Dashboard UI
 */

document.addEventListener('DOMContentLoaded', function () {
    loadJobs();

    document.getElementById('btnRefresh').addEventListener('click', loadJobs);
    document.getElementById('filterStatus').addEventListener('change', loadJobs);
    document.getElementById('filterLimit').addEventListener('change', loadJobs);
    document.getElementById('btnResumeJob').addEventListener('click', resumeJob);
});

let currentDetailJobId = null;

async function loadJobs() {
    const status = document.getElementById('filterStatus').value;
    const limit = document.getElementById('filterLimit').value;
    let url = '/api/monitor/jobs?limit=' + limit;
    if (status) url += '&status=' + status;

    const tbody = document.getElementById('monitorJobsBody');

    try {
        const jobs = await apiCall(url);
        if (!Array.isArray(jobs) || jobs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No jobs found</td></tr>';
            return;
        }

        tbody.innerHTML = '';
        jobs.forEach(function (job) {
            const sc = statusBadgeClass(job.STATUS);
            const completed = (job.COMPLETED_ENDPOINTS || 0) + '/' + (job.TOTAL_ENDPOINTS || 0);
            tbody.innerHTML += '<tr>' +
                '<td>' + job.JOB_ID + '</td>' +
                '<td>' + (job.JOB_NAME || '') + '</td>' +
                '<td>' + (job.SOURCE_APP || '') + '</td>' +
                '<td><span class="badge bg-' + sc + '">' + job.STATUS + '</span></td>' +
                '<td>' + completed + '</td>' +
                '<td>' + (job.TOTAL_RECORDS || 0).toLocaleString() + '</td>' +
                '<td>' + formatDate(job.CREATED_AT) + '</td>' +
                '<td><button class="btn btn-sm btn-outline-primary btn-view-job" data-id="' +
                job.JOB_ID + '"><i class="bi bi-eye"></i></button></td>' +
                '</tr>';
        });

        // Attach view handlers
        document.querySelectorAll('.btn-view-job').forEach(function (btn) {
            btn.addEventListener('click', function () {
                viewJob(parseInt(this.dataset.id));
            });
        });
    } catch (err) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center text-danger">' +
                          'Error loading jobs: ' + err.message + '</td></tr>';
    }
}

async function viewJob(jobId) {
    currentDetailJobId = jobId;
    try {
        const data = await apiCall('/api/monitor/job/' + jobId);
        const job = data.job;
        const tasks = data.tasks || [];
        const errors = data.errors || [];

        document.getElementById('detailJobName').textContent = job.JOB_NAME || 'Job ' + jobId;
        document.getElementById('detailJobId').textContent = job.JOB_ID;
        document.getElementById('detailStatus').innerHTML =
            '<span class="badge bg-' + statusBadgeClass(job.STATUS) + '">' + job.STATUS + '</span>';
        document.getElementById('detailRecords').textContent = (job.TOTAL_RECORDS || 0).toLocaleString();
        document.getElementById('detailCreated').textContent = formatDate(job.CREATED_AT);

        // Show resume button for failed/paused jobs
        const resumeBtn = document.getElementById('btnResumeJob');
        resumeBtn.style.display = (job.STATUS === 'FAILED' || job.STATUS === 'PAUSED') ? '' : 'none';

        // Tasks
        const tasksTbody = document.getElementById('detailTasksBody');
        tasksTbody.innerHTML = '';
        tasks.forEach(function (task) {
            const tsc = statusBadgeClass(task.STATUS);
            tasksTbody.innerHTML += '<tr>' +
                '<td>' + task.TASK_ID + '</td>' +
                '<td>' + (task.ENDPOINT_PATH || '') + '</td>' +
                '<td>' + (task.TARGET_TABLE || '') + '</td>' +
                '<td><span class="badge bg-' + tsc + '">' + task.STATUS + '</span></td>' +
                '<td>' + (task.RECORDS_FETCHED || 0) + '</td>' +
                '<td>' + (task.RECORDS_LOADED || 0) + '</td>' +
                '<td>' + (task.RECORDS_FAILED || 0) + '</td>' +
                '</tr>';
        });

        // Errors
        const errorsTbody = document.getElementById('detailErrorsBody');
        if (errors.length === 0) {
            errorsTbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No errors</td></tr>';
        } else {
            errorsTbody.innerHTML = '';
            errors.forEach(function (err) {
                errorsTbody.innerHTML += '<tr>' +
                    '<td>' + formatDate(err.ERROR_TIMESTAMP) + '</td>' +
                    '<td>' + (err.ERROR_TYPE || '') + '</td>' +
                    '<td>' + (err.ERROR_CODE || '') + '</td>' +
                    '<td>' + (err.ERROR_MESSAGE || '').substring(0, 200) + '</td>' +
                    '</tr>';
            });
        }

        new bootstrap.Modal(document.getElementById('jobDetailModal')).show();
    } catch (err) {
        showToast('Failed to load job details: ' + err.message, 'danger');
    }
}

async function resumeJob() {
    if (!currentDetailJobId) return;
    if (!confirm('Resume job ' + currentDetailJobId + '?')) return;

    try {
        const data = await apiCall('/api/migration/resume', 'POST', { job_id: currentDetailJobId });
        showToast('Job resumed! ' + (data.message || ''), 'success');
        bootstrap.Modal.getInstance(document.getElementById('jobDetailModal')).hide();
        loadJobs();
    } catch (err) {
        showToast('Resume failed: ' + err.message, 'danger');
    }
}
