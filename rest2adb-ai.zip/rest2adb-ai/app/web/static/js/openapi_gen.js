/**
 * restapi2adb – OpenAPI Generation UI
 */

document.addEventListener('DOMContentLoaded', function () {
    loadSavedSpecs();

    document.getElementById('btnGenerate').addEventListener('click', generateSpec);
    document.getElementById('btnSaveSpec').addEventListener('click', saveSpec);
    document.getElementById('btnRegenerate').addEventListener('click', generateSpec);
});

let currentSpecFilename = '';

async function loadSavedSpecs() {
    try {
        const specs = await apiCall('/api/openapi/specs');
        const list = document.getElementById('specList');
        const empty = document.getElementById('specListEmpty');

        if (!specs || specs.length === 0) {
            empty.classList.remove('d-none');
            return;
        }
        empty.classList.add('d-none');
        list.innerHTML = '';

        specs.forEach(function (spec) {
            const item = document.createElement('a');
            item.href = '#';
            item.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center';
            item.innerHTML = '<div><strong>' + spec.app_name + '</strong><br><small class="text-muted">' +
                             spec.filename + '</small></div>' +
                             '<button class="btn btn-sm btn-outline-danger btn-delete-spec" data-filename="' +
                             spec.filename + '"><i class="bi bi-trash"></i></button>';
            item.addEventListener('click', function (e) {
                if (e.target.closest('.btn-delete-spec')) {
                    e.preventDefault();
                    deleteSpec(spec.filename);
                    return;
                }
                e.preventDefault();
                loadSpec(spec.filename);
            });
            list.appendChild(item);
        });
    } catch (err) {
        console.error('Failed to load specs:', err);
    }
}

async function generateSpec() {
    const appName = document.getElementById('oasAppName').value.trim();
    if (!appName) {
        showToast('Enter an app name.', 'warning');
        return;
    }

    const entities = document.getElementById('oasEntities').value.trim();
    const version = document.getElementById('oasVersion').value.trim();

    const spinner = document.getElementById('generateSpinner');
    const btn = document.getElementById('btnGenerate');
    spinner.classList.remove('d-none');
    btn.disabled = true;

    try {
        const data = await apiCall('/api/openapi/generate', 'POST', {
            app_name: appName,
            entities: entities,
            version: version,
        });

        displaySpec(data.spec, data.summary);
        currentSpecFilename = data.saved_to.split('/').pop();
        showToast('OpenAPI spec generated and saved!', 'success');
        loadSavedSpecs();
    } catch (err) {
        showToast('Generation failed: ' + err.message, 'danger');
    } finally {
        spinner.classList.add('d-none');
        btn.disabled = false;
    }
}

async function loadSpec(filename) {
    try {
        const data = await apiCall('/api/openapi/spec/' + encodeURIComponent(filename));
        displaySpec(data.spec, data.summary);
        currentSpecFilename = filename;
    } catch (err) {
        showToast('Failed to load spec: ' + err.message, 'danger');
    }
}

function displaySpec(spec, summary) {
    // Editor
    document.getElementById('specEditor').value = JSON.stringify(spec, null, 2);

    // Summary
    if (summary) {
        document.getElementById('specSummary').style.display = '';
        document.getElementById('sumTitle').textContent = summary.title || '-';
        document.getElementById('sumServer').textContent = summary.server_url || '-';
        document.getElementById('sumEndpoints').textContent = summary.endpoint_count || 0;

        const tbody = document.getElementById('sumEndpointTable');
        tbody.innerHTML = '';
        (summary.endpoints || []).forEach(function (ep) {
            tbody.innerHTML += '<tr><td>' + ep.path + '</td><td>' + (ep.operation_id || '') +
                               '</td><td>' + (ep.description || '') + '</td><td>' +
                               (ep.param_count || 0) + '</td></tr>';
        });
    }
}

async function saveSpec() {
    if (!currentSpecFilename) {
        showToast('No spec loaded to save.', 'warning');
        return;
    }
    try {
        const spec = JSON.parse(document.getElementById('specEditor').value);
        await apiCall('/api/openapi/spec/' + encodeURIComponent(currentSpecFilename), 'PUT', spec);
        showToast('Spec saved!', 'success');
    } catch (err) {
        showToast('Save failed: ' + err.message, 'danger');
    }
}

async function deleteSpec(filename) {
    if (!confirm('Delete this spec?')) return;
    try {
        await apiCall('/api/openapi/spec/' + encodeURIComponent(filename), 'DELETE');
        showToast('Spec deleted.', 'success');
        loadSavedSpecs();
        if (currentSpecFilename === filename) {
            document.getElementById('specEditor').value = '';
            document.getElementById('specSummary').style.display = 'none';
            currentSpecFilename = '';
        }
    } catch (err) {
        showToast('Delete failed: ' + err.message, 'danger');
    }
}
