/**
 * restapi2adb – Schema Mapping UI
 */

document.addEventListener('DOMContentLoaded', function () {
    loadSpecOptions();
    loadSavedMappings();

    document.getElementById('btnAutoMap').addEventListener('click', autoMap);
    document.getElementById('btnSaveMapping').addEventListener('click', saveMapping);
    document.getElementById('btnPreviewDDL').addEventListener('click', previewDDL);
});

let currentMappings = [];
let currentMappingFilename = '';

async function loadSpecOptions() {
    try {
        const specs = await apiCall('/api/openapi/specs');
        const select = document.getElementById('mapSpecFile');
        specs.forEach(function (spec) {
            const opt = document.createElement('option');
            opt.value = spec.path;
            opt.textContent = spec.app_name + ' (' + spec.filename + ')';
            select.appendChild(opt);
        });
    } catch (err) {
        console.error('Failed to load specs:', err);
    }
}

async function loadSavedMappings() {
    try {
        const mappings = await apiCall('/api/mapping/list');
        const list = document.getElementById('mappingList');
        const empty = document.getElementById('mappingListEmpty');

        if (!mappings || mappings.length === 0) {
            empty.classList.remove('d-none');
            return;
        }
        empty.classList.add('d-none');
        list.innerHTML = '';

        mappings.forEach(function (m) {
            const item = document.createElement('a');
            item.href = '#';
            item.className = 'list-group-item list-group-item-action';
            item.innerHTML = '<strong>' + m.app_name + '</strong><br>' +
                             '<small class="text-muted">' + m.filename + '</small>';
            item.addEventListener('click', function (e) {
                e.preventDefault();
                loadMapping(m.filename);
            });
            list.appendChild(item);
        });
    } catch (err) {
        console.error('Failed to load mappings:', err);
    }
}

async function autoMap() {
    const appName = document.getElementById('mapAppName').value.trim();
    const specFile = document.getElementById('mapSpecFile').value;

    if (!appName || !specFile) {
        showToast('Select an app name and spec file.', 'warning');
        return;
    }

    const spinner = document.getElementById('mapSpinner');
    spinner.classList.remove('d-none');
    document.getElementById('btnAutoMap').disabled = true;

    try {
        const data = await apiCall('/api/mapping/generate', 'POST', {
            app_name: appName,
            spec_file: specFile,
        });

        currentMappings = data.mappings || [];
        currentMappingFilename = data.saved_to ? data.saved_to.split('/').pop() : '';
        renderMappingGrid(currentMappings);
        showToast(data.count + ' mapping(s) generated!', 'success');
        loadSavedMappings();
    } catch (err) {
        showToast('Mapping generation failed: ' + err.message, 'danger');
    } finally {
        spinner.classList.add('d-none');
        document.getElementById('btnAutoMap').disabled = false;
    }
}

async function loadMapping(filename) {
    try {
        const data = await apiCall('/api/mapping/' + encodeURIComponent(filename));
        currentMappings = Array.isArray(data) ? data : [data];
        currentMappingFilename = filename;
        renderMappingGrid(currentMappings);
    } catch (err) {
        showToast('Failed to load mapping: ' + err.message, 'danger');
    }
}

function renderMappingGrid(mappings) {
    const container = document.getElementById('mappingTables');
    document.getElementById('mappingPlaceholder').style.display = 'none';
    document.getElementById('mappingActions').classList.remove('d-none');
    container.innerHTML = '';

    mappings.forEach(function (mapping, idx) {
        if (mapping.error) {
            container.innerHTML += '<div class="alert alert-danger">Error for ' +
                                   (mapping.source_endpoint || 'unknown') + ': ' + mapping.error + '</div>';
            return;
        }

        const card = document.createElement('div');
        card.className = 'card mb-3';
        card.innerHTML = '<div class="card-header d-flex justify-content-between">' +
            '<h6 class="mb-0">' + (mapping.source_endpoint || '') + ' → ' + (mapping.target_table || '') + '</h6>' +
            '<span class="badge bg-info">' + (mapping.columns || []).length + ' columns</span></div>';

        const body = document.createElement('div');
        body.className = 'card-body p-0';

        let tableHTML = '<div class="table-responsive"><table class="table table-sm table-hover mapping-table mb-0">' +
            '<thead><tr><th>Source Path</th><th>Target Column</th><th>Oracle Type</th>' +
            '<th>PK</th><th>Nullable</th><th>Transform</th></tr></thead><tbody>';

        (mapping.columns || []).forEach(function (col) {
            const pkChecked = col.is_primary_key ? 'checked' : '';
            const nullChecked = col.is_nullable !== false ? 'checked' : '';
            tableHTML += '<tr>' +
                '<td><input type="text" class="form-control form-control-sm" value="' + (col.source_path || '') + '"></td>' +
                '<td><input type="text" class="form-control form-control-sm" value="' + (col.target_column || '') + '"></td>' +
                '<td><input type="text" class="form-control form-control-sm" value="' + (col.oracle_type || '') + '"></td>' +
                '<td class="text-center"><input type="checkbox" class="form-check-input" ' + pkChecked + '></td>' +
                '<td class="text-center"><input type="checkbox" class="form-check-input" ' + nullChecked + '></td>' +
                '<td><input type="text" class="form-control form-control-sm" value="' + (col.transform || '') + '"></td>' +
                '</tr>';
        });

        tableHTML += '</tbody></table></div>';
        body.innerHTML = tableHTML;
        card.appendChild(body);
        container.appendChild(card);
    });
}

async function saveMapping() {
    if (!currentMappingFilename) {
        showToast('No mapping loaded to save.', 'warning');
        return;
    }
    try {
        await apiCall('/api/mapping/' + encodeURIComponent(currentMappingFilename), 'PUT', currentMappings);
        showToast('Mapping saved!', 'success');
    } catch (err) {
        showToast('Save failed: ' + err.message, 'danger');
    }
}

async function previewDDL() {
    if (!currentMappings || currentMappings.length === 0) {
        showToast('Generate or load a mapping first.', 'warning');
        return;
    }

    const ddlDiv = document.getElementById('ddlPreview');
    const ddlContent = document.getElementById('ddlContent');
    ddlDiv.style.display = '';
    ddlContent.textContent = '';

    for (const mapping of currentMappings) {
        if (mapping.error) continue;
        try {
            const data = await apiCall('/api/mapping/ddl-preview', 'POST', mapping);
            ddlContent.textContent += data.ddl + ';\n\n';
        } catch (err) {
            ddlContent.textContent += '-- Error generating DDL: ' + err.message + '\n\n';
        }
    }

    document.getElementById('btnCopyDDL').addEventListener('click', function () {
        navigator.clipboard.writeText(ddlContent.textContent);
        showToast('DDL copied to clipboard.', 'success');
    });
}
