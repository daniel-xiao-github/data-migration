/**
 * restapi2adb – Migration Execution UI
 */

document.addEventListener('DOMContentLoaded', function () {
    loadMigrationOptions();

    document.getElementById('btnStartMigration').addEventListener('click', startMigration);
    document.getElementById('btnCancel').addEventListener('click', cancelMigration);
    document.getElementById('btnValidate').addEventListener('click', validatePrereqs);
    document.getElementById('btnTestConnection').addEventListener('click', testConnection);

    document.getElementById('oraConnType').addEventListener('change', function () {
        const isWallet = this.value === 'wallet';
        document.getElementById('walletFields').style.display = isWallet ? '' : 'none';
        document.getElementById('connStringFields').style.display = isWallet ? 'none' : '';
    });

    connectWebSocket();
});

let socket = null;
let migrationStartTime = null;
let elapsedTimer = null;

async function loadMigrationOptions() {
    try {
        const specs = await apiCall('/api/openapi/specs');
        const specSelect = document.getElementById('migSpecFile');
        specs.forEach(function (spec) {
            const opt = document.createElement('option');
            opt.value = spec.path;
            opt.textContent = spec.app_name + ' (' + spec.filename + ')';
            specSelect.appendChild(opt);
        });
    } catch (err) { /* ignore */ }

    try {
        const mappings = await apiCall('/api/mapping/list');
        const mapSelect = document.getElementById('migMappingFile');
        mappings.forEach(function (m) {
            const opt = document.createElement('option');
            opt.value = m.path;
            opt.textContent = m.app_name + ' (' + m.filename + ')';
            mapSelect.appendChild(opt);
        });
    } catch (err) { /* ignore */ }
}

function connectWebSocket() {
    if (typeof io === 'undefined') return;

    socket = io('/migration', { transports: ['websocket', 'polling'] });

    socket.on('connected', function () {
        addLog('Connected to migration event stream.', 'info');
    });

    socket.on('job_started', function (data) {
        addLog('Job ' + data.job_id + ' started: ' + (data.job_name || ''), 'success');
        document.getElementById('statStatus').textContent = 'RUNNING';
        migrationStartTime = Date.now();
        startElapsedTimer();
    });

    socket.on('job_progress', function (data) {
        updateProgress(data);
    });

    socket.on('task_started', function (data) {
        addLog('Task started: ' + data.endpoint + ' → ' + data.target_table, 'info');
        addTaskProgress(data);
    });

    socket.on('task_progress', function (data) {
        updateTaskProgress(data);
    });

    socket.on('task_completed', function (data) {
        addLog('Task ' + data.task_id + ' completed: ' + data.records_loaded + ' records.', 'success');
    });

    socket.on('task_failed', function (data) {
        addLog('Task ' + data.task_id + ' FAILED: ' + (data.error || ''), 'error');
    });

    socket.on('job_completed', function (data) {
        addLog('Job ' + data.job_id + ' COMPLETED. Total: ' + data.total_records + ' records.', 'success');
        document.getElementById('statStatus').textContent = data.status || 'COMPLETED';
        stopElapsedTimer();
    });

    socket.on('job_failed', function (data) {
        addLog('Job FAILED: ' + (data.error || ''), 'error');
        document.getElementById('statStatus').textContent = 'FAILED';
        stopElapsedTimer();
    });

    socket.on('job_cancelled', function () {
        addLog('Job cancelled.', 'warn');
        document.getElementById('statStatus').textContent = 'CANCELLED';
        stopElapsedTimer();
    });
}

async function startMigration() {
    const appName = document.getElementById('migAppName').value.trim();
    const specFile = document.getElementById('migSpecFile').value;
    const mappingFile = document.getElementById('migMappingFile').value;
    const jobName = document.getElementById('migJobName').value.trim();

    if (!appName || !specFile || !mappingFile) {
        showToast('Please fill in App Name, Spec, and Mapping.', 'warning');
        return;
    }

    document.getElementById('migrationPanel').style.display = '';
    document.getElementById('logStream').innerHTML = '';
    addLog('Starting migration...', 'info');

    try {
        await apiCall('/api/migration/start', 'POST', {
            app_name: appName,
            spec_file: specFile,
            mapping_file: mappingFile,
            job_name: jobName,
        });
    } catch (err) {
        addLog('Failed to start: ' + err.message, 'error');
        showToast('Start failed: ' + err.message, 'danger');
    }
}

async function cancelMigration() {
    if (!confirm('Cancel the active migration?')) return;
    try {
        await apiCall('/api/migration/cancel', 'POST');
        addLog('Cancellation requested.', 'warn');
    } catch (err) {
        showToast('Cancel failed: ' + err.message, 'danger');
    }
}

async function validatePrereqs() {
    const appName = document.getElementById('migAppName').value.trim();
    const specFile = document.getElementById('migSpecFile').value;
    const mappingFile = document.getElementById('migMappingFile').value;

    try {
        const data = await apiCall('/api/migration/validate', 'POST', {
            app_name: appName,
            spec_file: specFile,
            mapping_file: mappingFile,
        });
        if (data.valid) {
            showToast('All prerequisites validated!', 'success');
        } else {
            showToast('Validation issues: ' + data.errors.join('; '), 'warning');
        }
    } catch (err) {
        showToast('Validation failed: ' + err.message, 'danger');
    }
}

async function testConnection() {
    const connType = document.getElementById('oraConnType').value;
    const data = {
        connection_type: connType,
        username: document.getElementById('oraUsername').value.trim(),
        password: document.getElementById('oraPassword').value,
        wallet_path: document.getElementById('oraWalletPath').value.trim(),
        tns_alias: document.getElementById('oraTnsAlias').value.trim(),
        connection_string: document.getElementById('oraConnString').value.trim(),
    };

    const resultDiv = document.getElementById('connResult');
    resultDiv.innerHTML = '<div class="spinner-border spinner-border-sm"></div> Testing...';

    try {
        const result = await apiCall('/api/oracle/test', 'POST', data);
        if (result.success) {
            resultDiv.innerHTML = '<div class="alert alert-success py-1 mb-0">Connected! ' +
                                  (result.version || '') + ' (Schema: ' + (result.current_schema || '') + ')</div>';
        } else {
            resultDiv.innerHTML = '<div class="alert alert-danger py-1 mb-0">Failed: ' + (result.error || '') + '</div>';
        }
    } catch (err) {
        resultDiv.innerHTML = '<div class="alert alert-danger py-1 mb-0">Error: ' + err.message + '</div>';
    }
}

function updateProgress(data) {
    document.getElementById('overallPercent').textContent = data.progress + '%';
    document.getElementById('overallBar').style.width = data.progress + '%';
    document.getElementById('statTotalRecords').textContent = (data.total_records || 0).toLocaleString();
    document.getElementById('statCompletedEP').textContent =
        (data.completed_endpoints || 0) + '/' + (data.total_endpoints || 0);
}

function addTaskProgress(data) {
    const list = document.getElementById('taskProgressList');
    const id = 'task-' + data.task_id;
    if (document.getElementById(id)) return;
    const div = document.createElement('div');
    div.id = id;
    div.className = 'mb-2';
    div.innerHTML = '<div class="d-flex justify-content-between mb-1"><small>' +
                    data.endpoint + '</small><small class="task-records">0 records</small></div>' +
                    '<div class="progress" style="height:8px;">' +
                    '<div class="progress-bar bg-info" style="width:0%"></div></div>';
    list.appendChild(div);
}

function updateTaskProgress(data) {
    const el = document.getElementById('task-' + data.task_id);
    if (!el) return;
    const records = el.querySelector('.task-records');
    if (records) records.textContent = (data.records_loaded || 0) + ' records';
}

function addLog(message, level) {
    level = level || 'info';
    const stream = document.getElementById('logStream');
    const time = new Date().toLocaleTimeString();
    const div = document.createElement('div');
    div.className = 'log-' + level;
    div.textContent = '[' + time + '] ' + message;
    stream.appendChild(div);
    stream.scrollTop = stream.scrollHeight;
}

function startElapsedTimer() {
    stopElapsedTimer();
    elapsedTimer = setInterval(function () {
        if (!migrationStartTime) return;
        const elapsed = Math.floor((Date.now() - migrationStartTime) / 1000);
        const min = Math.floor(elapsed / 60);
        const sec = elapsed % 60;
        document.getElementById('statElapsed').textContent =
            min + ':' + (sec < 10 ? '0' : '') + sec;
    }, 1000);
}

function stopElapsedTimer() {
    if (elapsedTimer) {
        clearInterval(elapsedTimer);
        elapsedTimer = null;
    }
}
