/**
 * restapi2adb – Core UI Logic
 *
 * Handles theme toggling and shared utility functions.
 */

document.addEventListener('DOMContentLoaded', function () {
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    const htmlEl = document.documentElement;

    const savedTheme = localStorage.getItem('restapi2adb-theme') || 'light';
    htmlEl.setAttribute('data-bs-theme', savedTheme);
    if (themeIcon) {
        themeIcon.className = savedTheme === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', function () {
            const current = htmlEl.getAttribute('data-bs-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            htmlEl.setAttribute('data-bs-theme', next);
            localStorage.setItem('restapi2adb-theme', next);
            if (themeIcon) {
                themeIcon.className = next === 'dark' ? 'bi bi-sun' : 'bi bi-moon-stars';
            }
        });
    }

    // Check for updates (only on authenticated pages)
    if (document.getElementById('updateBanner')) {
        checkForUpdate();
    }
});

/**
 * Show a Bootstrap toast notification.
 */
function showToast(message, type) {
    type = type || 'info';
    const container = document.getElementById('toastContainer') || createToastContainer();
    const id = 'toast-' + Date.now();
    const html = `
        <div id="${id}" class="toast align-items-center text-bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>`;
    container.insertAdjacentHTML('beforeend', html);
    const el = document.getElementById(id);
    const toast = new bootstrap.Toast(el, { delay: 5000 });
    toast.show();
    el.addEventListener('hidden.bs.toast', function () { el.remove(); });
}

function createToastContainer() {
    const div = document.createElement('div');
    div.id = 'toastContainer';
    div.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    div.style.zIndex = '1100';
    document.body.appendChild(div);
    return div;
}

/**
 * Make an API call with JSON body and return the parsed response.
 */
async function apiCall(url, method, body) {
    method = method || 'GET';
    const opts = {
        method: method,
        headers: { 'Content-Type': 'application/json' },
    };
    if (body && method !== 'GET') {
        opts.body = JSON.stringify(body);
    }
    const resp = await fetch(url, opts);
    const data = await resp.json();
    if (!resp.ok) {
        throw new Error(data.error || data.message || 'API error');
    }
    return data;
}

/**
 * Format a timestamp for display.
 */
function formatDate(ts) {
    if (!ts) return '-';
    const d = new Date(ts);
    if (isNaN(d.getTime())) return ts;
    return d.toLocaleString();
}

/**
 * Get a Bootstrap badge class for a status string.
 */
function statusBadgeClass(status) {
    const map = {
        COMPLETED: 'success',
        RUNNING: 'primary',
        FAILED: 'danger',
        CANCELLED: 'secondary',
        CREATED: 'info',
        PAUSED: 'warning',
        PENDING: 'secondary',
        SKIPPED: 'light',
    };
    return map[status] || 'secondary';
}

// ── Update Management ─────────────────────────────────────────────────

/**
 * Check for a new version and show the update banner if available.
 */
async function checkForUpdate() {
    // Skip if user dismissed within this session
    if (sessionStorage.getItem('restapi2adb-update-dismissed')) return;
    try {
        const data = await apiCall('/api/update/check');
        if (data.update_available) {
            const banner = document.getElementById('updateBanner');
            const text = document.getElementById('updateBannerText');
            if (banner && text) {
                text.textContent = `Version ${data.remote_version} is available (current: ${data.local_version}).`;
                banner.classList.remove('d-none');
                banner.classList.add('show');
            }
        }
    } catch (err) {
        // Silently ignore – update check is non-critical
        console.debug('Update check skipped:', err.message);
    }
}

/**
 * Dismiss the update banner for this session.
 */
function dismissUpdate() {
    const banner = document.getElementById('updateBanner');
    if (banner) {
        banner.classList.add('d-none');
        banner.classList.remove('show');
    }
    sessionStorage.setItem('restapi2adb-update-dismissed', '1');
}

/**
 * Download, install the update, and prompt to restart.
 */
async function applyUpdate() {
    const banner = document.getElementById('updateBanner');
    const progress = document.getElementById('updateProgress');
    const btn = document.getElementById('btnApplyUpdate');

    // Hide banner, show progress
    if (banner) { banner.classList.add('d-none'); banner.classList.remove('show'); }
    if (progress) { progress.classList.remove('d-none'); }
    if (btn) { btn.disabled = true; }

    try {
        const data = await apiCall('/api/update/apply', 'POST');
        if (progress) { progress.classList.add('d-none'); }
        if (data.success) {
            showRestartModal(data.old_version, data.new_version);
        } else {
            showToast('Update failed: ' + (data.message || 'Unknown error'), 'danger');
        }
    } catch (err) {
        if (progress) { progress.classList.add('d-none'); }
        showToast('Update failed: ' + err.message, 'danger');
    }
}

/**
 * Show a modal telling the user to restart the application.
 */
function showRestartModal(oldVer, newVer) {
    const id = 'restartModal';
    // Remove if already exists
    const existing = document.getElementById(id);
    if (existing) existing.remove();

    const html = `
    <div class="modal fade" id="${id}" data-bs-backdrop="static" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-success text-white">
            <h5 class="modal-title"><i class="bi bi-check-circle-fill me-2"></i>Update Installed</h5>
          </div>
          <div class="modal-body text-center py-4">
            <p class="fs-5 mb-2">Successfully updated from <strong>v${oldVer}</strong> to <strong>v${newVer}</strong></p>
            <p class="text-muted mb-3">Your configuration, mappings, and data have been preserved.</p>
            <hr>
            <p class="mb-1">Please restart the application for changes to take effect:</p>
            <div class="bg-body-secondary rounded p-3 mt-2 text-start" style="font-family: monospace;">
              <div>Linux/macOS: <strong>./restart.sh</strong></div>
              <div>Windows: <strong>restart.bat</strong></div>
            </div>
          </div>
          <div class="modal-footer justify-content-center">
            <button class="btn btn-success" data-bs-dismiss="modal">OK</button>
          </div>
        </div>
      </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
    const modal = new bootstrap.Modal(document.getElementById(id));
    modal.show();
}
