"""Flask route definitions for the restapi2adb web UI.

Serves HTML pages for the dashboard, OAuth configuration, OpenAPI
generation, schema mapping, migration execution, and monitoring.
"""

import logging
from pathlib import Path

from flask import Blueprint, redirect, render_template, request, session, url_for, flash
from flask_login import current_user, login_required, login_user, logout_user

from app.auth.ai_auth import (
    AIUser,
    AI_MODELS,
    get_current_ai_user,
    is_claude_cli_installed,
    login as ai_login,
    auto_login as ai_auto_login,
    logout as ai_logout,
    restore_session,
    get_auth_source,
    AUTH_SOURCE_SUBSCRIPTION,
    AUTH_SOURCE_ENV,
)

logger = logging.getLogger(__name__)

web_bp = Blueprint("web", __name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent


_auto_login_attempted = False


@web_bp.before_request
def check_auth():
    """Redirect unauthenticated users to the login page.

    On the very first protected request after startup, attempt a full
    ``auto_login()`` (which validates credentials over the network).
    This lets users land directly on the dashboard when a Claude
    subscription session or API key is already available.
    """
    global _auto_login_attempted

    public_endpoints = ("web.login", "web.static", "web.oauth_callback")
    if request.endpoint in public_endpoints:
        return
    if get_current_ai_user():
        return

    # Lightweight restore (no network call)
    if restore_session():
        login_user(get_current_ai_user())
        return

    # First visit after startup: try full auto-login once
    if not _auto_login_attempted:
        _auto_login_attempted = True
        success, _ = ai_auto_login()
        if success:
            user = get_current_ai_user()
            if user:
                login_user(user)
                return

    return redirect(url_for("web.login"))


# ── Login ──────────────────────────────────────────────────────────────

@web_bp.route("/login", methods=["GET", "POST"])
def login():
    """Claude subscription / credential login page.

    Supports three authentication modes:
    - **subscription**: Uses Claude Code CLI session credentials.
      The user authenticates once with ``claude`` and the SDK picks up
      the session automatically.  No API key required.
    - **env_key**: Uses the ``ANTHROPIC_API_KEY`` environment variable.
    - **manual**: User pastes an API key from the Anthropic console.
    """
    source = get_auth_source()
    subscription_detected = source == AUTH_SOURCE_SUBSCRIPTION
    env_key_detected = source == AUTH_SOURCE_ENV
    cli_installed = is_claude_cli_installed()

    tpl_vars = dict(
        models=AI_MODELS,
        subscription_detected=subscription_detected,
        env_key_detected=env_key_detected,
        cli_installed=cli_installed,
    )

    if request.method == "POST":
        auth_mode = request.form.get("auth_mode", "manual")
        provider = request.form.get("provider", "anthropic")
        model = request.form.get("model", "claude-sonnet-4-5-20250514")

        if auth_mode == "subscription":
            # Use Claude CLI subscription session — no key needed
            success, message = ai_login(
                auth_source=AUTH_SOURCE_SUBSCRIPTION,
                provider=provider,
                model=model,
            )
        elif auth_mode == "env_key":
            # Use ANTHROPIC_API_KEY from environment
            success, message = ai_auto_login()
        else:
            # Manual key entry
            api_key = request.form.get("api_key", "").strip()
            if not api_key:
                flash("Please enter your API key.", "danger")
                return render_template("login.html", **tpl_vars)
            success, message = ai_login(api_key, provider, model)

        if success:
            user = get_current_ai_user()
            if user:
                login_user(user)
            flash(f"Connected successfully! {message}", "success")
            return redirect(url_for("web.dashboard"))
        else:
            flash(message, "danger")
            return render_template("login.html", **tpl_vars)

    return render_template("login.html", **tpl_vars)


@web_bp.route("/logout")
def logout():
    """Log out and clear AI session."""
    global _auto_login_attempted
    _auto_login_attempted = False
    ai_logout()
    logout_user()
    flash("Logged out successfully.", "info")
    return redirect(url_for("web.login"))


# ── Dashboard ──────────────────────────────────────────────────────────

@web_bp.route("/")
@web_bp.route("/dashboard")
def dashboard():
    """Main dashboard page."""
    return render_template("dashboard.html")


# ── OAuth Configuration ───────────────────────────────────────────────

@web_bp.route("/oauth")
def oauth_config():
    """OAuth 2.0 configuration page."""
    return render_template("oauth_config.html")


@web_bp.route("/oauth/callback")
def oauth_callback():
    """OAuth callback handler."""
    from app.auth.oauth_manager import exchange_code_for_tokens

    code = request.args.get("code")
    state = request.args.get("state", "")
    error = request.args.get("error")

    if error:
        flash(f"OAuth error: {error}", "danger")
        return redirect(url_for("web.oauth_config"))

    if not code:
        flash("No authorization code received.", "danger")
        return redirect(url_for("web.oauth_config"))

    # The app_name should be stored in session state before redirect
    app_name = session.get("oauth_app_name", "")
    if not app_name:
        flash("OAuth session expired. Please try again.", "warning")
        return redirect(url_for("web.oauth_config"))

    redirect_uri = url_for("web.oauth_callback", _external=True)
    success, result = exchange_code_for_tokens(app_name, code, redirect_uri)

    if success:
        flash(f"OAuth authorization successful for '{app_name}'!", "success")
    else:
        flash(f"Token exchange failed: {result.get('error', 'Unknown error')}", "danger")

    return redirect(url_for("web.oauth_config"))


# ── OpenAPI Generator ─────────────────────────────────────────────────

@web_bp.route("/openapi")
def openapi_generate():
    """AI OpenAPI specification generator page."""
    return render_template("openapi_generate.html")


# ── Schema Mapping ────────────────────────────────────────────────────

@web_bp.route("/mapping")
def mapping():
    """Schema mapping review/edit page."""
    return render_template("mapping.html")


# ── Migration Execution ───────────────────────────────────────────────

@web_bp.route("/migration")
def migration():
    """Migration execution and batch management page."""
    return render_template("migration.html")


# ── Monitor Dashboard ─────────────────────────────────────────────────

@web_bp.route("/monitor")
def monitor():
    """Real-time monitoring dashboard page."""
    return render_template("monitor.html")
