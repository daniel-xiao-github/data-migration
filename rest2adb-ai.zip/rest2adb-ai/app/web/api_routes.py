"""REST API endpoints for AJAX and WebSocket interactions.

Provides JSON endpoints consumed by the frontend JavaScript modules
for OAuth management, OpenAPI generation, schema mapping, migration
control, and monitoring.
"""

import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import threading
from pathlib import Path

from flask import Blueprint, jsonify, request, session, url_for

from app.auth.ai_auth import get_current_ai_user, is_claude_cli_installed
from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)

api_bp = Blueprint("api", __name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

# Active migration engine (single-user app)
_active_engine = None
_engine_lock = threading.Lock()


def _require_auth():
    """Return an error response if the user is not authenticated."""
    if not get_current_ai_user():
        return jsonify({"error": "Not authenticated"}), 401
    return None


# ── Claude CLI API (pre-auth — accessible from login page) ────────────

@api_bp.route("/claude-cli/status", methods=["GET"])
def claude_cli_status():
    """Check whether the Claude Code CLI is installed and authenticated."""
    installed = is_claude_cli_installed()
    node_installed = shutil.which("node") is not None
    py_ver = sys.version_info[:3]
    result = {
        "cli_installed": installed,
        "node_installed": node_installed,
        "python_version": f"{py_ver[0]}.{py_ver[1]}.{py_ver[2]}",
        "python_ok": py_ver[:2] >= (3, 9),
        "platform": platform.system().lower(),
    }
    if installed:
        # Check if the CLI is authenticated by probing `claude --version`
        try:
            proc = subprocess.run(
                ["claude", "--version"],
                capture_output=True, text=True, timeout=10,
            )
            result["cli_version"] = proc.stdout.strip() if proc.returncode == 0 else None
        except Exception:
            result["cli_version"] = None
    return jsonify(result)


@api_bp.route("/claude-cli/install", methods=["POST"])
def claude_cli_install():
    """Install Python 3.9+ (if needed), Node.js, Claude Code CLI, and Python deps.

    Checks for a suitable Python interpreter, installs Node.js via nvm
    (or winget on Windows), runs the official Claude Code CLI installer,
    then ensures the ``anthropic`` and ``rich`` Python packages are present.
    This endpoint is intentionally accessible without authentication
    because it is invoked from the login page before the user has
    credentials.
    """

    system = platform.system().lower()

    steps: list[dict] = []
    # Extra PATH entries accumulated during install (e.g. nvm, pyenv)
    extra_path = ""

    # Step 0: Ensure Python >= 3.9 is available
    _MIN_PY = (3, 9)
    py_ver = sys.version_info[:3]
    py_tag = f"{py_ver[0]}.{py_ver[1]}.{py_ver[2]}"
    if py_ver[:2] >= _MIN_PY:
        steps.append({"step": f"Python ({py_tag})", "status": "already_installed"})
    else:
        # The running interpreter is too old — try to install a newer one
        if system in ("linux", "darwin"):
            # Use pyenv to install without touching system Python
            pyenv_script = (
                'export PYENV_ROOT="$HOME/.pyenv" && '
                "curl -fsSL https://pyenv.run | bash && "
                'export PATH="$PYENV_ROOT/bin:$PATH" && '
                "eval \"$(pyenv init -)\" && "
                "pyenv install 3.12 -s && "
                "pyenv global 3.12 && "
                "python3 --version"
            )
            cmd = ["bash", "-c", pyenv_script]
        elif system == "windows":
            cmd = ["powershell", "-Command",
                   "winget install --id Python.Python.3.12 "
                   "--accept-package-agreements --accept-source-agreements"]
        else:
            steps.append({
                "step": f"Python ({py_tag})",
                "status": "failed",
                "error": f"Python {_MIN_PY[0]}.{_MIN_PY[1]}+ required; found {py_tag}.",
            })
            return jsonify({
                "success": False,
                "message": (
                    f"Python {_MIN_PY[0]}.{_MIN_PY[1]}+ is required (found {py_tag}). "
                    "Please install from https://www.python.org/downloads/"
                ),
                "steps": steps,
            }), 500

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300,
            )
            if proc.returncode == 0:
                steps.append({
                    "step": "Python 3.12 (pyenv)" if system != "windows" else "Python 3.12 (winget)",
                    "status": "installed",
                    "output": proc.stdout[-500:] if proc.stdout else "",
                })
            else:
                stderr = (proc.stderr or proc.stdout or "Unknown error")[-500:]
                steps.append({
                    "step": f"Python ({py_tag} — upgrade needed)",
                    "status": "failed",
                    "error": stderr,
                })
                return jsonify({
                    "success": False,
                    "message": (
                        f"Python {_MIN_PY[0]}.{_MIN_PY[1]}+ is required (found {py_tag}). "
                        "Automatic install failed. Please install manually from "
                        "https://www.python.org/downloads/ and restart."
                    ),
                    "steps": steps,
                }), 500
        except subprocess.TimeoutExpired:
            steps.append({
                "step": f"Python ({py_tag} — upgrade needed)",
                "status": "failed",
                "error": "Python installation timed out after 300 seconds.",
            })
            return jsonify({
                "success": False,
                "message": "Python installation timed out.",
                "steps": steps,
            }), 500
        except Exception as exc:
            steps.append({
                "step": f"Python ({py_tag} — upgrade needed)",
                "status": "failed",
                "error": str(exc),
            })
            return jsonify({
                "success": False,
                "message": (
                    f"Python {_MIN_PY[0]}.{_MIN_PY[1]}+ is required (found {py_tag}). "
                    f"Auto-install error: {exc}. "
                    "Please install from https://www.python.org/downloads/"
                ),
                "steps": steps,
            }), 500

    # Step 1: Ensure Node.js is available (required by Claude Code CLI)
    node_bin = shutil.which("node")
    if node_bin:
        steps.append({"step": "Node.js", "status": "already_installed"})
    else:
        if system in ("linux", "darwin"):
            # Install via nvm (no root required, works on Linux + macOS)
            nvm_dir = os.path.expanduser("~/.nvm")
            install_script = (
                'export NVM_DIR="$HOME/.nvm" && '
                "curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash && "
                '. "$NVM_DIR/nvm.sh" && '
                "nvm install --lts && "
                "node --version"
            )
            cmd = ["bash", "-c", install_script]
        elif system == "windows":
            # On Windows, attempt install via winget (ships with Win 10+)
            cmd = ["powershell", "-Command",
                   "winget install --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements"]
        else:
            return jsonify({
                "success": False,
                "message": f"Unsupported platform: {system}",
                "steps": [],
            }), 400

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=180,
            )
            if proc.returncode == 0:
                steps.append({
                    "step": "Node.js",
                    "status": "installed",
                    "output": proc.stdout[-500:] if proc.stdout else "",
                })
                # Make nvm-installed Node available to subsequent steps
                if system in ("linux", "darwin"):
                    nvm_current = os.path.join(nvm_dir, "versions", "node")
                    if os.path.isdir(nvm_current):
                        # Find the version just installed
                        versions = sorted(os.listdir(nvm_current))
                        if versions:
                            extra_path = os.path.join(nvm_current, versions[-1], "bin")
            else:
                stderr = (proc.stderr or proc.stdout or "Unknown error")[-500:]
                steps.append({
                    "step": "Node.js",
                    "status": "failed",
                    "error": stderr,
                })
                return jsonify({
                    "success": False,
                    "message": "Node.js installation failed. Install Node.js manually, then retry.",
                    "steps": steps,
                }), 500
        except subprocess.TimeoutExpired:
            steps.append({
                "step": "Node.js",
                "status": "failed",
                "error": "Installation timed out after 180 seconds.",
            })
            return jsonify({
                "success": False,
                "message": "Node.js installation timed out.",
                "steps": steps,
            }), 500
        except Exception as exc:
            steps.append({
                "step": "Node.js",
                "status": "failed",
                "error": str(exc),
            })
            return jsonify({
                "success": False,
                "message": str(exc),
                "steps": steps,
            }), 500

    # Build an environment with any extra PATH for subsequent steps
    env = os.environ.copy()
    if extra_path:
        env["PATH"] = extra_path + os.pathsep + env.get("PATH", "")

    # Step 2: Install Claude Code CLI
    if is_claude_cli_installed():
        steps.append({"step": "Claude Code CLI", "status": "already_installed"})
    else:
        if system in ("linux", "darwin"):
            # Source nvm so that npm/npx are available to the installer
            cli_script = ""
            if extra_path or os.path.isdir(os.path.expanduser("~/.nvm")):
                cli_script = 'export NVM_DIR="$HOME/.nvm" && [ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh" && '
            cli_script += "curl -fsSL https://claude.ai/install.sh | sh"
            cmd = ["bash", "-c", cli_script]
        elif system == "windows":
            cmd = ["powershell", "-Command",
                   "irm https://claude.ai/install.ps1 | iex"]
        else:
            return jsonify({
                "success": False,
                "message": f"Unsupported platform: {system}",
                "steps": steps,
            }), 400

        try:
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=120, env=env,
            )
            if proc.returncode == 0:
                steps.append({
                    "step": "Claude Code CLI",
                    "status": "installed",
                    "output": proc.stdout[-500:] if proc.stdout else "",
                })
            else:
                steps.append({
                    "step": "Claude Code CLI",
                    "status": "failed",
                    "error": (proc.stderr or proc.stdout or "Unknown error")[-500:],
                })
                return jsonify({
                    "success": False,
                    "message": "Claude Code CLI installation failed.",
                    "steps": steps,
                }), 500
        except subprocess.TimeoutExpired:
            steps.append({
                "step": "Claude Code CLI",
                "status": "failed",
                "error": "Installation timed out after 120 seconds.",
            })
            return jsonify({
                "success": False,
                "message": "Installation timed out.",
                "steps": steps,
            }), 500
        except Exception as exc:
            steps.append({
                "step": "Claude Code CLI",
                "status": "failed",
                "error": str(exc),
            })
            return jsonify({
                "success": False,
                "message": str(exc),
                "steps": steps,
            }), 500

    # Step 3: Install Python dependencies (anthropic, rich)
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "anthropic", "rich"],
            capture_output=True, text=True, timeout=120,
        )
        if proc.returncode == 0:
            steps.append({"step": "Python packages (anthropic, rich)", "status": "installed"})
        else:
            steps.append({
                "step": "Python packages (anthropic, rich)",
                "status": "failed",
                "error": (proc.stderr or proc.stdout or "pip install failed")[-500:],
            })
    except Exception as exc:
        steps.append({
            "step": "Python packages (anthropic, rich)",
            "status": "failed",
            "error": str(exc),
        })

    all_ok = all(s["status"] in ("installed", "already_installed") for s in steps)
    cli_now_installed = is_claude_cli_installed()

    return jsonify({
        "success": all_ok,
        "cli_installed": cli_now_installed,
        "message": (
            "Installation complete! Run 'claude' in your terminal to "
            "authenticate with your subscription, then refresh this page."
            if all_ok else
            "Some steps failed. Check the details below."
        ),
        "steps": steps,
    }), 200 if all_ok else 500


# ── OAuth API ──────────────────────────────────────────────────────────

@api_bp.route("/oauth/configs", methods=["GET"])
def list_oauth_configs():
    """List all configured OAuth apps."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.auth.oauth_manager import load_all_configs, get_token_status
    configs = load_all_configs()
    result = []
    for key, cfg in configs.items():
        status = get_token_status(cfg.get("app_name", key))
        result.append({**cfg, "token_status": status, "key": key})
    return jsonify(result)


@api_bp.route("/oauth/config", methods=["POST"])
def save_oauth_config():
    """Save an OAuth configuration."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.auth.oauth_manager import save_config
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400
    errors = save_config(data)
    if errors:
        return jsonify({"errors": errors}), 400
    return jsonify({"message": "Configuration saved."})


@api_bp.route("/oauth/config/<app_name>", methods=["DELETE"])
def delete_oauth_config(app_name: str):
    """Delete an OAuth configuration."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.auth.oauth_manager import delete_config
    delete_config(app_name)
    return jsonify({"message": f"Configuration for '{app_name}' deleted."})


@api_bp.route("/oauth/authorize/<app_name>", methods=["POST"])
def authorize_oauth(app_name: str):
    """Build and return the OAuth authorization URL."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.auth.oauth_manager import build_authorization_url
    redirect_uri = url_for("web.oauth_callback", _external=True)
    auth_url = build_authorization_url(app_name, redirect_uri)
    if not auth_url:
        return jsonify({"error": "OAuth config not found."}), 404
    session["oauth_app_name"] = app_name
    return jsonify({"authorization_url": auth_url})


@api_bp.route("/oauth/suggest", methods=["POST"])
def suggest_oauth_config():
    """Use AI to suggest OAuth configuration for an app name."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.claude_service import call_claude_json
    data = request.get_json()
    app_name = data.get("app_name", "")
    if not app_name:
        return jsonify({"error": "app_name is required"}), 400

    prompt = f"""Given the REST API application name "{app_name}", provide the standard OAuth 2.0 configuration as JSON:
{{
  "api_base_url": "...",
  "authorization_url": "...",
  "token_url": "...",
  "default_scopes": "...",
  "additional_params": {{}},
  "documentation_url": "...",
  "notes": "..."
}}
Include only well-known, documented URLs. Output ONLY valid JSON."""

    try:
        result = call_claude_json(prompt)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ── OpenAPI Generation API ─────────────────────────────────────────────

@api_bp.route("/openapi/generate", methods=["POST"])
def generate_openapi():
    """Generate an OpenAPI spec using AI."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.openapi_generator import generate_openapi_spec, save_spec, get_spec_summary
    data = request.get_json()
    app_name = data.get("app_name", "")
    entities = data.get("entities", "")
    version = data.get("version", "")

    if not app_name:
        return jsonify({"error": "app_name is required"}), 400

    try:
        spec = generate_openapi_spec(app_name, entities, version)
        filepath = save_spec(spec, app_name)
        summary = get_spec_summary(spec)
        return jsonify({
            "spec": spec,
            "summary": summary,
            "saved_to": str(filepath),
        })
    except Exception as exc:
        logger.error("OpenAPI generation failed: %s", exc)
        return jsonify({"error": str(exc)}), 500


@api_bp.route("/openapi/specs", methods=["GET"])
def list_specs():
    """List all saved OpenAPI specs."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.openapi_generator import list_saved_specs
    return jsonify(list_saved_specs())


@api_bp.route("/openapi/spec/<filename>", methods=["GET"])
def get_spec(filename: str):
    """Load a specific OpenAPI spec."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.openapi_generator import load_spec, get_spec_summary
    filepath = _PROJECT_ROOT / "data" / "openapi_specs" / filename
    if not filepath.exists():
        return jsonify({"error": "Spec not found"}), 404
    spec = load_spec(filepath)
    return jsonify({"spec": spec, "summary": get_spec_summary(spec)})


@api_bp.route("/openapi/spec/<filename>", methods=["DELETE"])
def delete_spec(filename: str):
    """Delete a saved OpenAPI spec."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.openapi_generator import delete_spec
    if delete_spec(filename):
        return jsonify({"message": "Spec deleted."})
    return jsonify({"error": "Spec not found"}), 404


@api_bp.route("/openapi/spec/<filename>", methods=["PUT"])
def update_spec(filename: str):
    """Update a saved OpenAPI spec."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    data = request.get_json()
    filepath = _PROJECT_ROOT / "data" / "openapi_specs" / filename
    if not filepath.exists():
        return jsonify({"error": "Spec not found"}), 404
    with open(filepath, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    return jsonify({"message": "Spec updated."})


# ── Schema Mapping API ─────────────────────────────────────────────────

@api_bp.route("/mapping/generate", methods=["POST"])
def generate_mapping():
    """Generate schema mappings using AI."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.schema_mapper import generate_all_mappings, save_mapping
    from app.ai.openapi_generator import load_spec
    data = request.get_json()
    app_name = data.get("app_name", "")
    spec_file = data.get("spec_file", "")

    if not app_name or not spec_file:
        return jsonify({"error": "app_name and spec_file are required"}), 400

    try:
        spec = load_spec(spec_file)
        mappings = generate_all_mappings(app_name, spec)
        filepath = save_mapping(mappings, app_name)
        return jsonify({
            "mappings": mappings,
            "saved_to": str(filepath),
            "count": len(mappings),
        })
    except Exception as exc:
        logger.error("Mapping generation failed: %s", exc)
        return jsonify({"error": str(exc)}), 500


@api_bp.route("/mapping/list", methods=["GET"])
def list_mappings():
    """List all saved mapping files."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.schema_mapper import list_saved_mappings
    return jsonify(list_saved_mappings())


@api_bp.route("/mapping/<filename>", methods=["GET"])
def get_mapping(filename: str):
    """Load a specific mapping file."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.schema_mapper import load_mapping
    filepath = _PROJECT_ROOT / "data" / "mappings" / filename
    if not filepath.exists():
        return jsonify({"error": "Mapping not found"}), 404
    mappings = load_mapping(filepath)
    return jsonify(mappings)


@api_bp.route("/mapping/<filename>", methods=["PUT"])
def update_mapping(filename: str):
    """Update a saved mapping file."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    data = request.get_json()
    filepath = _PROJECT_ROOT / "data" / "mappings" / filename
    if not filepath.exists():
        return jsonify({"error": "Mapping not found"}), 404
    with open(filepath, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    return jsonify({"message": "Mapping updated."})


@api_bp.route("/mapping/<filename>", methods=["DELETE"])
def delete_mapping(filename: str):
    """Delete a saved mapping file."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.ai.schema_mapper import delete_mapping
    if delete_mapping(filename):
        return jsonify({"message": "Mapping deleted."})
    return jsonify({"error": "Mapping not found"}), 404


@api_bp.route("/mapping/ddl-preview", methods=["POST"])
def preview_ddl():
    """Preview the DDL for a mapping."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.oracle.table_manager import generate_create_table_ddl
    data = request.get_json()
    if not data:
        return jsonify({"error": "Mapping data required"}), 400
    ddl = generate_create_table_ddl(data)
    return jsonify({"ddl": ddl})


# ── Oracle ADB API ─────────────────────────────────────────────────────

@api_bp.route("/oracle/test", methods=["POST"])
def test_oracle_connection():
    """Test Oracle ADB connectivity."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.oracle.adb_connection import test_connection, save_adb_credentials
    data = request.get_json()
    conn_type = data.get("connection_type", "wallet")
    username = data.get("username", "")
    password = data.get("password", "")
    wallet_path = data.get("wallet_path", "")
    tns_alias = data.get("tns_alias", "")
    connection_string = data.get("connection_string", "")

    success, info = test_connection(
        conn_type, username, password, wallet_path, tns_alias, connection_string
    )

    if success:
        save_adb_credentials(conn_type, username, password, wallet_path, tns_alias, connection_string)

    return jsonify({"success": success, **info})


@api_bp.route("/oracle/wallet/aliases", methods=["POST"])
def get_wallet_aliases():
    """Parse TNS aliases from a wallet zip."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.oracle.adb_connection import extract_tns_aliases
    data = request.get_json()
    wallet_path = data.get("wallet_path", "")
    if not wallet_path:
        return jsonify({"error": "wallet_path required"}), 400
    aliases = extract_tns_aliases(wallet_path)
    return jsonify({"aliases": aliases})


# ── Migration API ──────────────────────────────────────────────────────

@api_bp.route("/migration/start", methods=["POST"])
def start_migration():
    """Start a new migration job."""
    global _active_engine
    auth_err = _require_auth()
    if auth_err:
        return auth_err

    from app import socketio
    from app.migration.engine import MigrationEngine

    data = request.get_json()
    app_name = data.get("app_name", "")
    spec_file = data.get("spec_file", "")
    mapping_file = data.get("mapping_file", "")
    job_name = data.get("job_name", "")

    if not all([app_name, spec_file, mapping_file]):
        return jsonify({"error": "app_name, spec_file, and mapping_file are required"}), 400

    with _engine_lock:
        engine = MigrationEngine(app_name, spec_file, mapping_file, socketio)
        _active_engine = engine

    # Run in a background thread
    def run_migration():
        try:
            engine.run(job_name)
        except Exception as exc:
            logger.error("Migration thread failed: %s", exc)

    thread = threading.Thread(target=run_migration, daemon=True)
    thread.start()

    return jsonify({"message": "Migration started.", "status": "RUNNING"})


@api_bp.route("/migration/cancel", methods=["POST"])
def cancel_migration():
    """Cancel the active migration."""
    global _active_engine
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    with _engine_lock:
        if _active_engine:
            _active_engine.cancel()
            return jsonify({"message": "Migration cancellation requested."})
    return jsonify({"error": "No active migration."}), 404


@api_bp.route("/migration/resume", methods=["POST"])
def resume_migration():
    """Resume a failed migration job."""
    global _active_engine
    auth_err = _require_auth()
    if auth_err:
        return auth_err

    from app import socketio
    from app.migration.engine import MigrationEngine
    from app.migration.resume_handler import ResumeHandler
    from app.migration.control_tables import get_job

    data = request.get_json()
    job_id = data.get("job_id")
    if not job_id:
        return jsonify({"error": "job_id is required"}), 400

    job = get_job(job_id)
    if not job:
        return jsonify({"error": f"Job {job_id} not found."}), 404

    handler = ResumeHandler(job_id)
    analysis = handler.analyse()
    if not analysis.get("can_resume"):
        return jsonify({"error": "Job cannot be resumed.", "analysis": analysis}), 400

    handler.prepare_resume()

    engine = MigrationEngine(
        app_name=job["SOURCE_APP"],
        spec_file=job.get("OPENAPI_SPEC_FILE", ""),
        mapping_file=job.get("MAPPING_FILE", ""),
        socketio=socketio,
    )

    with _engine_lock:
        _active_engine = engine

    def run_resume():
        try:
            engine.run(job.get("JOB_NAME", "Resumed Job"))
        except Exception as exc:
            logger.error("Resume thread failed: %s", exc)

    thread = threading.Thread(target=run_resume, daemon=True)
    thread.start()

    return jsonify({"message": "Migration resumed.", "analysis": analysis})


@api_bp.route("/migration/validate", methods=["POST"])
def validate_migration():
    """Validate migration prerequisites."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.migration.engine import MigrationEngine
    data = request.get_json()
    engine = MigrationEngine(
        data.get("app_name", ""),
        data.get("spec_file", ""),
        data.get("mapping_file", ""),
    )
    errors = engine.validate_prerequisites()
    return jsonify({"valid": len(errors) == 0, "errors": errors})


# ── Monitor API ────────────────────────────────────────────────────────

@api_bp.route("/monitor/jobs", methods=["GET"])
def list_jobs():
    """List migration jobs."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.migration.control_tables import list_jobs
    status = request.args.get("status")
    limit = int(request.args.get("limit", 50))
    try:
        jobs = list_jobs(status, limit)
        # Convert datetime objects for JSON
        for job in jobs:
            for key in ("CREATED_AT", "STARTED_AT", "COMPLETED_AT"):
                if job.get(key):
                    job[key] = str(job[key])
        return jsonify(jobs)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@api_bp.route("/monitor/job/<int:job_id>", methods=["GET"])
def get_job_detail(job_id: int):
    """Get detailed information about a migration job."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.migration.control_tables import get_job, get_tasks_for_job, get_errors_for_job
    try:
        job = get_job(job_id)
        if not job:
            return jsonify({"error": "Job not found"}), 404
        tasks = get_tasks_for_job(job_id)
        errors = get_errors_for_job(job_id)

        # Convert datetimes
        for item in [job] + tasks + errors:
            for key, val in item.items():
                if hasattr(val, "isoformat"):
                    item[key] = str(val)

        return jsonify({"job": job, "tasks": tasks, "errors": errors})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@api_bp.route("/monitor/control-tables/reset", methods=["POST"])
def reset_control_tables():
    """Reset (drop and re-create) all control tables."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.migration.control_tables import reset_control_tables
    try:
        created = reset_control_tables()
        return jsonify({"message": "Control tables reset.", "tables": created})
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


# ── Dashboard Stats API ───────────────────────────────────────────────

@api_bp.route("/dashboard/stats", methods=["GET"])
def dashboard_stats():
    """Get dashboard summary statistics."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from app.auth.oauth_manager import load_all_configs
    from app.ai.openapi_generator import list_saved_specs
    from app.ai.schema_mapper import list_saved_mappings

    try:
        from app.migration.control_tables import list_jobs
        jobs = list_jobs(limit=100)
        active = sum(1 for j in jobs if j.get("STATUS") in ("RUNNING", "CREATED"))
        total_records = sum(j.get("TOTAL_RECORDS", 0) or 0 for j in jobs)
        last_job = jobs[0] if jobs else None
    except Exception:
        jobs = []
        active = 0
        total_records = 0
        last_job = None

    oauth_configs = load_all_configs()
    specs = list_saved_specs()
    mappings = list_saved_mappings()

    stats = {
        "active_migrations": active,
        "total_records": total_records,
        "connected_apps": len(oauth_configs),
        "total_specs": len(specs),
        "total_mappings": len(mappings),
        "total_jobs": len(jobs),
        "last_job": None,
    }

    if last_job:
        for key, val in last_job.items():
            if hasattr(val, "isoformat"):
                last_job[key] = str(val)
        stats["last_job"] = last_job

    return jsonify(stats)


# ── Update API ─────────────────────────────────────────────────────────

@api_bp.route("/update/check", methods=["GET"])
def check_update():
    """Check for a newer version of rest2adb-ai."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from update_check import check_for_update, get_local_version
    try:
        info = check_for_update()
        if info:
            return jsonify({
                "update_available": True,
                "local_version": info["local_version"],
                "remote_version": info["remote_version"],
            })
        return jsonify({
            "update_available": False,
            "local_version": get_local_version(),
        })
    except Exception as exc:
        logger.error("Update check failed: %s", exc)
        return jsonify({"error": str(exc)}), 500


@api_bp.route("/update/apply", methods=["POST"])
def apply_update():
    """Download and install the latest version."""
    auth_err = _require_auth()
    if auth_err:
        return auth_err
    from update_check import apply_update as do_apply, get_local_version
    try:
        old_version = get_local_version()
        success = do_apply()
        if success:
            new_version = get_local_version()
            return jsonify({
                "success": True,
                "old_version": old_version,
                "new_version": new_version,
                "message": f"Updated from v{old_version} to v{new_version}. Please restart the application.",
            })
        return jsonify({"success": False, "message": "Update failed. Check logs for details."}), 500
    except Exception as exc:
        logger.error("Update apply failed: %s", exc)
        return jsonify({"success": False, "message": str(exc)}), 500
