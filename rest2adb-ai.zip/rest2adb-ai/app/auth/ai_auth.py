"""AI (Claude) authentication and credential management.

Supports multiple credential sources for the Anthropic API, prioritising
Claude subscription authentication via the Claude Code CLI:

1. **Claude subscription (CLI)** — the user authenticates once with
   ``claude`` in their terminal (browser-based login) and the SDK
   automatically picks up the session.  No key required.
2. **ANTHROPIC_API_KEY environment variable** — set from the Anthropic
   console (https://console.anthropic.com/settings/keys).
3. **Encrypted credentials file** — key previously saved via the UI.
4. **Manual entry** — fallback via the login page.

The recommended path is (1): install the Claude Code CLI, run ``claude``
to authenticate with a Pro/Max/Team/Enterprise subscription, then start
restapi2adb.  The SDK detects the session automatically.
"""

import logging
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import anthropic
from flask_login import UserMixin

from app.utils.config_manager import load_config
from app.utils.secret_manager import load_encrypted_json, save_encrypted_json

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_CREDENTIALS_FILE = _PROJECT_ROOT / "data" / "tokens" / "ai_credentials.enc"

# Credential source constants
AUTH_SOURCE_SUBSCRIPTION = "subscription"  # Claude CLI subscription
AUTH_SOURCE_ENV = "environment"            # ANTHROPIC_API_KEY env var
AUTH_SOURCE_STORED = "stored"              # encrypted credentials file
AUTH_SOURCE_MANUAL = "manual"              # entered via login page

# Available models
AI_MODELS = [
    {"id": "claude-sonnet-4-5-20250514", "name": "Claude Sonnet 4.5 (Default)"},
    {"id": "claude-haiku-4-5-20250414", "name": "Claude Haiku 4.5"},
    {"id": "claude-opus-4-0-20250514", "name": "Claude Opus 4"},
]


@dataclass
class AIUser(UserMixin):
    """Represents an authenticated AI-connected user session."""

    id: str = "ai_user"
    provider: str = "anthropic"
    model: str = "claude-sonnet-4-5-20250514"
    auth_source: str = AUTH_SOURCE_SUBSCRIPTION
    is_authenticated: bool = True

    def get_id(self) -> str:
        return self.id


# In-memory user instance (single-user application)
_current_user: Optional[AIUser] = None


def get_current_ai_user() -> Optional[AIUser]:
    """Return the current authenticated AI user, or None."""
    return _current_user


# ── Claude Code CLI Detection ─────────────────────────────────────────

def is_claude_cli_installed() -> bool:
    """Check whether the Claude Code CLI is available on PATH."""
    return shutil.which("claude") is not None


def _detect_subscription_auth() -> bool:
    """Test whether a Claude subscription session is available.

    The Claude Code CLI stores authentication tokens locally after the
    user runs ``claude`` and completes the browser-based login.  The
    ``anthropic`` SDK can then pick up those credentials automatically
    when no explicit ``api_key`` is passed.

    Returns True if ``Anthropic()`` can initialise without error.
    """
    # Quick check: if ANTHROPIC_API_KEY is set, the SDK will use that
    # instead of CLI auth — let that path handle it separately.
    if os.environ.get("ANTHROPIC_API_KEY", "").strip():
        return False

    try:
        # The SDK will raise AuthenticationError or similar if no
        # credentials are available.  We do a lightweight probe.
        client = anthropic.Anthropic()
        # Accessing .api_key succeeds if credentials resolved
        if client.api_key:
            return True
    except Exception:
        pass
    return False


# ── Credential Resolution ─────────────────────────────────────────────

def _get_env_api_key() -> Optional[str]:
    """Read the API key from the ``ANTHROPIC_API_KEY`` environment variable."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    return key if key else None


def _get_stored_api_key() -> Optional[str]:
    """Read the API key from the encrypted credentials file."""
    creds = load_encrypted_json(_CREDENTIALS_FILE)
    return creds.get("api_key") if creds else None


def get_api_key() -> Optional[str]:
    """Resolve the Anthropic API key from the best available source.

    Resolution order:
    1. ``ANTHROPIC_API_KEY`` environment variable
    2. Encrypted credentials file (previously saved via UI)

    Returns:
        The API key string, or None if no key-based credentials are available.
    """
    key = _get_env_api_key()
    if key:
        return key
    key = _get_stored_api_key()
    if key:
        return key
    return None


def get_auth_source() -> Optional[str]:
    """Determine which credential source is currently active.

    Resolution order:
    1. Claude subscription via CLI (no key needed)
    2. ``ANTHROPIC_API_KEY`` environment variable
    3. Encrypted stored credentials

    Returns:
        One of the ``AUTH_SOURCE_*`` constants, or None.
    """
    if _detect_subscription_auth():
        return AUTH_SOURCE_SUBSCRIPTION
    if _get_env_api_key():
        return AUTH_SOURCE_ENV
    if _get_stored_api_key():
        return AUTH_SOURCE_STORED
    return None


# ── Validation ─────────────────────────────────────────────────────────

def validate_credentials(
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-5-20250514",
    auth_source: Optional[str] = None,
) -> tuple[bool, str]:
    """Validate Anthropic credentials by making a lightweight test call.

    Args:
        api_key: Explicit API key, or None for auto-detection.
        model: The model to test with.
        auth_source: If ``AUTH_SOURCE_SUBSCRIPTION``, bypass key requirement.

    Returns:
        A tuple of ``(is_valid, message)``.
    """
    if auth_source == AUTH_SOURCE_SUBSCRIPTION:
        # Subscription auth — the SDK auto-resolves credentials from CLI session
        try:
            client = anthropic.Anthropic()
            response = client.messages.create(
                model=model,
                max_tokens=50,
                messages=[{"role": "user", "content": "Say 'connected' in one word."}],
            )
            content = response.content[0].text if response.content else ""
            logger.info("Claude subscription validated (model=%s).", model)
            return True, f"Connected via Claude subscription to {model}. Response: {content.strip()}"
        except anthropic.AuthenticationError:
            logger.warning("Claude subscription auth failed.")
            return False, (
                "Claude subscription authentication failed. "
                "Run 'claude' in your terminal to re-authenticate with your subscription."
            )
        except anthropic.APIConnectionError as exc:
            logger.error("Claude API connection error: %s", exc)
            return False, "Cannot connect to Anthropic API. Check your internet connection."
        except Exception as exc:
            logger.error("Subscription validation error: %s", exc)
            return False, f"Validation error: {str(exc)}"

    # Key-based auth
    resolved_key = api_key or get_api_key()
    if not resolved_key:
        return False, (
            "No Claude credentials found. Use one of these methods:\n"
            "1. Install Claude Code CLI and run 'claude' to authenticate "
            "with your subscription (recommended).\n"
            "2. Set the ANTHROPIC_API_KEY environment variable.\n"
            "3. Enter your API key manually below."
        )

    try:
        client = anthropic.Anthropic(api_key=resolved_key)
        response = client.messages.create(
            model=model,
            max_tokens=50,
            messages=[{"role": "user", "content": "Say 'connected' in one word."}],
        )
        content = response.content[0].text if response.content else ""
        logger.info("Claude credentials validated (model=%s).", model)
        return True, f"Connected to {model}. Response: {content.strip()}"
    except anthropic.AuthenticationError:
        logger.warning("Claude credential validation failed: invalid key.")
        return False, (
            "Invalid credentials. Verify your API key is active at "
            "https://console.anthropic.com/settings/keys, or use "
            "'claude' CLI to authenticate with your subscription."
        )
    except anthropic.APIConnectionError as exc:
        logger.error("Claude API connection error: %s", exc)
        return False, "Cannot connect to Anthropic API. Check your internet connection."
    except Exception as exc:
        logger.error("Claude credential validation error: %s", exc)
        return False, f"Validation error: {str(exc)}"


# ── Credential Persistence ────────────────────────────────────────────

def save_credentials(
    api_key: str,
    provider: str = "anthropic",
    model: str = "claude-sonnet-4-5-20250514",
    auth_source: str = AUTH_SOURCE_MANUAL,
) -> None:
    """Encrypt and persist AI credentials."""
    save_encrypted_json(
        {
            "provider": provider,
            "api_key": api_key,
            "model": model,
            "auth_source": auth_source,
        },
        _CREDENTIALS_FILE,
    )
    logger.info(
        "AI credentials saved (provider=%s, model=%s, source=%s).",
        provider, model, auth_source,
    )


def load_credentials() -> Optional[dict]:
    """Load and decrypt stored AI credentials."""
    return load_encrypted_json(_CREDENTIALS_FILE)


# ── Session Management ────────────────────────────────────────────────

def auto_login() -> tuple[bool, str]:
    """Attempt automatic login using the best available credentials.

    Checks in order:
    1. Claude subscription via CLI (no key needed)
    2. ``ANTHROPIC_API_KEY`` environment variable
    3. Stored encrypted credentials

    Returns:
        ``(success, message)`` tuple.
    """
    global _current_user

    source = get_auth_source()
    if not source:
        return False, "No Claude credentials detected."

    cfg = load_config()
    model = cfg.get("ai", {}).get("default_model", "claude-sonnet-4-5-20250514")

    creds = load_credentials()
    if creds and creds.get("model"):
        model = creds["model"]

    if source == AUTH_SOURCE_SUBSCRIPTION:
        valid, message = validate_credentials(auth_source=AUTH_SOURCE_SUBSCRIPTION, model=model)
    else:
        key = get_api_key()
        valid, message = validate_credentials(key, model)

    if not valid:
        return False, message

    _current_user = AIUser(
        provider="anthropic",
        model=model,
        auth_source=source,
    )
    logger.info(
        "Auto-login succeeded via %s (model=%s).", source, model,
    )
    return True, message


def login(
    api_key: Optional[str] = None,
    provider: str = "anthropic",
    model: str = "claude-sonnet-4-5-20250514",
    auth_source: Optional[str] = None,
) -> tuple[bool, str]:
    """Validate and activate a Claude session.

    Args:
        api_key: Explicit API key, or None for subscription/auto-detect.
        provider: AI provider.
        model: Model to use.
        auth_source: Override the auth source detection.

    Returns:
        ``(success, message)`` tuple.
    """
    global _current_user

    # Subscription-based login (Claude CLI)
    if auth_source == AUTH_SOURCE_SUBSCRIPTION or (not api_key and _detect_subscription_auth()):
        valid, message = validate_credentials(auth_source=AUTH_SOURCE_SUBSCRIPTION, model=model)
        if not valid:
            return False, message
        _current_user = AIUser(
            provider=provider, model=model, auth_source=AUTH_SOURCE_SUBSCRIPTION,
        )
        logger.info("Claude session activated via subscription (model=%s).", model)
        return True, message

    # Key-based login
    resolved_key = api_key or get_api_key()
    valid, message = validate_credentials(resolved_key, model)
    if not valid:
        return False, message

    if api_key:
        source = AUTH_SOURCE_MANUAL
        save_credentials(api_key, provider, model, source)
    elif _get_env_api_key():
        source = AUTH_SOURCE_ENV
    else:
        source = AUTH_SOURCE_STORED

    _current_user = AIUser(
        provider=provider, model=model, auth_source=source,
    )
    logger.info("Claude session activated (source=%s, model=%s).", source, model)
    return True, message


def logout() -> None:
    """Clear the current AI session."""
    global _current_user
    _current_user = None
    logger.info("AI session cleared.")


def restore_session() -> bool:
    """Attempt to restore a session from available credentials.

    Checks subscription, env var, and stored credentials (in that order).
    Does **not** make a network call — use ``auto_login()`` for validated
    restoration.

    Returns:
        True if credentials are available and a session was restored.
    """
    global _current_user

    source = get_auth_source()
    if not source:
        return False

    cfg = load_config()
    model = cfg.get("ai", {}).get("default_model", "claude-sonnet-4-5-20250514")

    creds = load_credentials()
    if creds and creds.get("model"):
        model = creds["model"]

    _current_user = AIUser(
        provider="anthropic",
        model=model,
        auth_source=source,
    )
    return True
