"""Authentication modules for restapi2adb."""
