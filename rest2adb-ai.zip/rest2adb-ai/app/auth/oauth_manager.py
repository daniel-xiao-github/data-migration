"""OAuth 2.0 flow manager for REST API applications.

Supports configuring, executing, and refreshing OAuth 2.0 tokens for
any REST API provider.  Configurations and tokens are persisted with
encryption.
"""

import logging
import time
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlencode

import httpx
import yaml

from app.utils.secret_manager import load_encrypted_json, save_encrypted_json
from app.utils.validators import validate_oauth_config

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_OAUTH_CONFIG_FILE = _PROJECT_ROOT / "config" / "oauth_configs.yaml"
_TOKEN_DIR = _PROJECT_ROOT / "data" / "tokens"


def _safe_app_key(app_name: str) -> str:
    """Normalise an app name into a safe filesystem/dict key."""
    return app_name.lower().replace(" ", "_").replace("-", "_")


# ── Configuration Persistence ──────────────────────────────────────────

def load_all_configs() -> dict[str, dict]:
    """Load all OAuth configurations from ``config/oauth_configs.yaml``.

    Returns:
        Dict mapping app keys to their configuration dicts.
    """
    if not _OAUTH_CONFIG_FILE.exists():
        return {}
    try:
        with open(_OAUTH_CONFIG_FILE, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        logger.error("Failed to load OAuth configs: %s", exc)
        return {}


def save_all_configs(configs: dict[str, dict]) -> None:
    """Persist all OAuth configurations to YAML."""
    _OAUTH_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(_OAUTH_CONFIG_FILE, "w", encoding="utf-8") as fh:
        yaml.dump(configs, fh, default_flow_style=False, sort_keys=False)
    logger.info("OAuth configs saved (%d apps).", len(configs))


def get_config(app_name: str) -> Optional[dict]:
    """Retrieve the OAuth config for a specific app.

    Args:
        app_name: The REST API application name.
    """
    return load_all_configs().get(_safe_app_key(app_name))


def save_config(cfg: dict) -> list[str]:
    """Validate and save a single app's OAuth configuration.

    Secrets (client_secret) are stripped from the YAML and stored
    encrypted separately.

    Args:
        cfg: The OAuth configuration dict.

    Returns:
        List of validation errors (empty on success).
    """
    errors = validate_oauth_config(cfg)
    if errors:
        return errors

    app_key = _safe_app_key(cfg["app_name"])
    configs = load_all_configs()

    # Separate secret for encrypted storage
    client_secret = cfg.pop("client_secret", "")
    configs[app_key] = cfg
    save_all_configs(configs)

    # Encrypt secret separately
    if client_secret:
        _save_secret(app_key, "client_secret", client_secret)

    logger.info("OAuth config saved for '%s'.", cfg["app_name"])
    return []


def delete_config(app_name: str) -> None:
    """Remove an app's OAuth config and tokens."""
    app_key = _safe_app_key(app_name)
    configs = load_all_configs()
    configs.pop(app_key, None)
    save_all_configs(configs)

    # Clean up tokens
    token_file = _TOKEN_DIR / f"{app_key}_oauth.enc"
    secret_file = _TOKEN_DIR / f"{app_key}_secret.enc"
    for f in (token_file, secret_file):
        if f.exists():
            f.unlink()
    logger.info("OAuth config deleted for '%s'.", app_name)


# ── Secret & Token Storage ─────────────────────────────────────────────

def _save_secret(app_key: str, key: str, value: str) -> None:
    """Encrypt and store a single secret value."""
    save_encrypted_json({key: value}, _TOKEN_DIR / f"{app_key}_secret.enc")


def _load_secret(app_key: str, key: str) -> Optional[str]:
    """Load a single encrypted secret value."""
    data = load_encrypted_json(_TOKEN_DIR / f"{app_key}_secret.enc")
    return data.get(key) if data else None


def save_tokens(app_name: str, tokens: dict) -> None:
    """Encrypt and persist OAuth tokens for an app.

    Args:
        app_name: The application name.
        tokens: Dict with ``access_token``, ``refresh_token``, ``expires_at``, etc.
    """
    app_key = _safe_app_key(app_name)
    save_encrypted_json(tokens, _TOKEN_DIR / f"{app_key}_oauth.enc")
    logger.info("OAuth tokens saved for '%s'.", app_name)


def load_tokens(app_name: str) -> Optional[dict]:
    """Load decrypted OAuth tokens for an app."""
    app_key = _safe_app_key(app_name)
    return load_encrypted_json(_TOKEN_DIR / f"{app_key}_oauth.enc")


# ── OAuth 2.0 Flows ───────────────────────────────────────────────────

def build_authorization_url(app_name: str, redirect_uri: str) -> Optional[str]:
    """Construct the OAuth authorization URL for the user to visit.

    Args:
        app_name: Name of the configured REST API app.
        redirect_uri: The local callback URL.

    Returns:
        The full authorization URL, or None if config is missing.
    """
    cfg = get_config(app_name)
    if not cfg:
        logger.error("No OAuth config found for '%s'.", app_name)
        return None

    app_key = _safe_app_key(app_name)
    client_id = cfg.get("client_id", "")
    auth_url = cfg.get("authorization_url", "")
    scopes = cfg.get("scopes", "")
    additional = cfg.get("additional_params", {}) or {}

    params: dict[str, str] = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": scopes,
    }
    params.update(additional)

    full_url = f"{auth_url}?{urlencode(params)}"
    logger.info("Built authorization URL for '%s'.", app_name)
    return full_url


def exchange_code_for_tokens(
    app_name: str, auth_code: str, redirect_uri: str
) -> tuple[bool, dict[str, Any]]:
    """Exchange an authorization code for access and refresh tokens.

    Args:
        app_name: Name of the configured REST API app.
        auth_code: The authorization code received from the provider.
        redirect_uri: The redirect URI used in the authorization request.

    Returns:
        ``(success, token_data_or_error)`` tuple.
    """
    cfg = get_config(app_name)
    if not cfg:
        return False, {"error": f"No OAuth config for '{app_name}'."}

    app_key = _safe_app_key(app_name)
    client_secret = _load_secret(app_key, "client_secret") or ""

    data = {
        "grant_type": "authorization_code",
        "code": auth_code,
        "redirect_uri": redirect_uri,
        "client_id": cfg.get("client_id", ""),
        "client_secret": client_secret,
    }

    try:
        with httpx.Client(timeout=30) as client:
            resp = client.post(cfg["token_url"], data=data)
            resp.raise_for_status()
            tokens = resp.json()
    except Exception as exc:
        logger.error("Token exchange failed for '%s': %s", app_name, exc)
        return False, {"error": str(exc)}

    # Compute absolute expiry
    if "expires_in" in tokens and "expires_at" not in tokens:
        tokens["expires_at"] = time.time() + int(tokens["expires_in"])

    save_tokens(app_name, tokens)
    return True, tokens


def refresh_access_token(app_name: str) -> tuple[bool, dict[str, Any]]:
    """Refresh an expired access token using the stored refresh token.

    Args:
        app_name: Name of the configured REST API app.

    Returns:
        ``(success, new_token_data_or_error)`` tuple.
    """
    cfg = get_config(app_name)
    if not cfg:
        return False, {"error": f"No OAuth config for '{app_name}'."}

    tokens = load_tokens(app_name)
    if not tokens or "refresh_token" not in tokens:
        return False, {"error": "No refresh token available."}

    app_key = _safe_app_key(app_name)
    client_secret = _load_secret(app_key, "client_secret") or ""

    data = {
        "grant_type": "refresh_token",
        "refresh_token": tokens["refresh_token"],
        "client_id": cfg.get("client_id", ""),
        "client_secret": client_secret,
    }

    try:
        with httpx.Client(timeout=30) as client:
            resp = client.post(cfg["token_url"], data=data)
            resp.raise_for_status()
            new_tokens = resp.json()
    except Exception as exc:
        logger.error("Token refresh failed for '%s': %s", app_name, exc)
        return False, {"error": str(exc)}

    # Preserve the refresh token if the provider didn't return a new one
    if "refresh_token" not in new_tokens:
        new_tokens["refresh_token"] = tokens["refresh_token"]

    if "expires_in" in new_tokens and "expires_at" not in new_tokens:
        new_tokens["expires_at"] = time.time() + int(new_tokens["expires_in"])

    save_tokens(app_name, new_tokens)
    return True, new_tokens


def get_valid_access_token(app_name: str) -> Optional[str]:
    """Return a valid access token, refreshing if necessary.

    Args:
        app_name: Name of the configured REST API app.

    Returns:
        The access token string, or None if unavailable.
    """
    tokens = load_tokens(app_name)
    if not tokens:
        return None

    expires_at = tokens.get("expires_at", 0)
    # Refresh if token expires within the next 60 seconds
    if time.time() >= (expires_at - 60):
        logger.info("Access token for '%s' expired or expiring soon; refreshing.", app_name)
        ok, result = refresh_access_token(app_name)
        if not ok:
            logger.error("Token refresh failed: %s", result)
            return None
        return result.get("access_token")

    return tokens.get("access_token")


def get_token_status(app_name: str) -> dict[str, Any]:
    """Get the current token status for an app.

    Returns:
        Dict with ``has_token``, ``is_valid``, ``expires_at``, etc.
    """
    tokens = load_tokens(app_name)
    if not tokens:
        return {"has_token": False, "is_valid": False}

    expires_at = tokens.get("expires_at", 0)
    is_valid = time.time() < expires_at
    return {
        "has_token": True,
        "is_valid": is_valid,
        "expires_at": expires_at,
        "has_refresh_token": "refresh_token" in tokens,
    }
