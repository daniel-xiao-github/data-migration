"""Application entry point for restapi2adb.

Launches the Flask/SocketIO server with the configured host and port.
Supports ``--port`` command-line argument and selects the appropriate
WSGI server based on the platform (gunicorn on Linux/macOS, waitress on
Windows).
"""

import argparse
import logging
import platform
import sys

from app import create_app, login_manager, socketio
from app.auth.ai_auth import AIUser, get_current_ai_user, restore_session
from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)


@login_manager.user_loader
def load_user(user_id: str):
    """Flask-Login user loader callback."""
    user = get_current_ai_user()
    if user and user.get_id() == user_id:
        return user
    # Attempt to restore from encrypted credentials
    if restore_session():
        return get_current_ai_user()
    return None


def main() -> None:
    """Parse arguments and start the application server."""
    parser = argparse.ArgumentParser(description="restapi2adb – REST API to Oracle ADB Migration Tool")
    parser.add_argument("--port", type=int, default=None, help="Port to listen on (default: from config or 5100)")
    parser.add_argument("--host", type=str, default=None, help="Host to bind to (default: from config or 0.0.0.0)")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    args = parser.parse_args()

    cfg = load_config()
    app_cfg = cfg.get("app", {})

    host = args.host or app_cfg.get("host", "0.0.0.0")
    port = args.port or app_cfg.get("port", 5100)
    debug = args.debug or app_cfg.get("debug", False)

    app = create_app()

    logger.info("Starting restapi2adb on %s:%d (debug=%s).", host, port, debug)
    print(f"\n  restapi2adb is running at http://{host}:{port}\n")

    socketio.run(
        app,
        host=host,
        port=port,
        debug=debug,
        allow_unsafe_werkzeug=True,
    )


if __name__ == "__main__":
    main()
