"""AI-driven REST API → Oracle ADB schema mapper.

Uses Claude to automatically generate mapping configurations between
REST API response schemas (from OpenAPI specs) and Oracle ADB staging tables.
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional

from app.ai.claude_service import call_claude_json

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_MAPPINGS_DIR = _PROJECT_ROOT / "data" / "mappings"

# ── Prompt Template ────────────────────────────────────────────────────

_MAPPING_PROMPT = """You are an expert data engineer specializing in REST API to Oracle database migrations.

Given this REST API response schema from {app_name}:
{response_schema_json}

Endpoint: {endpoint_path}

Generate an Oracle ADB table mapping in JSON format:

{{
  "source_endpoint": "{endpoint_path}",
  "source_entity": "<entity name>",
  "target_table": "STG_{app_name_upper}_{entity_upper}",
  "target_schema": "MIGRATION",
  "columns": [
    {{
      "source_path": "$.id",
      "target_column": "COLUMN_NAME",
      "oracle_type": "NUMBER(38)",
      "is_primary_key": true,
      "is_nullable": false,
      "transform": null
    }}
  ],
  "pagination": {{
    "type": "offset|cursor|page_token",
    "page_size_param": "paramName",
    "default_page_size": 100,
    "offset_param": "paramName"
  }},
  "incremental_key": {{
    "source_path": "$.metaData.lastUpdatedTime",
    "target_column": "LAST_UPDATED_TIME",
    "type": "timestamp"
  }}
}}

Rules:
- Target table names: STG_{{APP_NAME}}_{{ENTITY_NAME}} (uppercase, underscores)
- Map JSON types to appropriate Oracle types:
  - string → VARCHAR2(size) where size reflects the typical data length
  - integer/number → NUMBER with appropriate precision
  - boolean → NUMBER(1) with transform (true→1, false→0)
  - date/datetime strings → DATE or TIMESTAMP with appropriate TO_DATE/TO_TIMESTAMP transform
  - nested objects → flatten with dot-path notation in source_path
  - arrays → separate child table with foreign key reference
- Identify the natural primary key from the API response
- Identify the best incremental/delta extraction key (last modified timestamp)
- Include pagination config specific to the endpoint
- Add Oracle-specific transforms where needed (date conversion, boolean conversion)

Output ONLY valid JSON. No explanatory text."""


def generate_mapping(
    app_name: str,
    endpoint_path: str,
    response_schema: dict,
    model: Optional[str] = None,
) -> dict:
    """Generate a single endpoint mapping using Claude.

    Args:
        app_name: Name of the REST API application.
        endpoint_path: The API endpoint path (e.g. ``/api/v3/invoices``).
        response_schema: The OpenAPI response schema for this endpoint.
        model: Optional Claude model override.

    Returns:
        The mapping configuration dict.
    """
    app_upper = app_name.upper().replace(" ", "_").replace("-", "_")

    prompt = _MAPPING_PROMPT.format(
        app_name=app_name,
        app_name_upper=app_upper,
        entity_upper="ENTITY",
        endpoint_path=endpoint_path,
        response_schema_json=json.dumps(response_schema, indent=2)[:6000],
    )

    logger.info("Generating mapping for %s → %s.", app_name, endpoint_path)
    kwargs = {"model": model} if model else {}
    mapping = call_claude_json(prompt, **kwargs)

    # Validate basic structure
    errors = validate_mapping(mapping)
    if errors:
        logger.warning("Mapping validation warnings: %s", errors)

    return mapping


def generate_all_mappings(
    app_name: str,
    openapi_spec: dict,
    model: Optional[str] = None,
) -> list[dict]:
    """Generate mappings for all GET endpoints in an OpenAPI spec.

    Args:
        app_name: Name of the REST API application.
        openapi_spec: The full OpenAPI spec dict.
        model: Optional Claude model override.

    Returns:
        List of mapping configuration dicts.
    """
    mappings: list[dict] = []
    paths = openapi_spec.get("paths", {})

    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue

        get_def = methods.get("get")
        if not get_def:
            continue

        # Extract response schema
        responses = get_def.get("responses", {})
        response_schema = _extract_response_schema(responses, openapi_spec)

        if response_schema:
            try:
                mapping = generate_mapping(app_name, path, response_schema, model)
                mappings.append(mapping)
            except Exception as exc:
                logger.error("Failed to generate mapping for %s: %s", path, exc)
                mappings.append({
                    "source_endpoint": path,
                    "error": str(exc),
                })

    return mappings


def _extract_response_schema(
    responses: dict, full_spec: dict
) -> Optional[dict]:
    """Extract the response schema from an OpenAPI responses block.

    Looks for the 200 response's JSON content schema, resolving ``$ref``
    references where possible.

    Args:
        responses: The OpenAPI ``responses`` dict for an endpoint.
        full_spec: The full OpenAPI spec (for resolving refs).

    Returns:
        The response schema dict, or None if not found.
    """
    success_resp = responses.get("200") or responses.get("default")
    if not success_resp:
        return None

    content = success_resp.get("content", {})
    json_content = content.get("application/json", {})
    schema = json_content.get("schema")

    if not schema:
        return success_resp  # Return the whole response as context

    # Resolve $ref if present
    schema = _resolve_refs(schema, full_spec)
    return schema


def _resolve_refs(schema: dict, full_spec: dict, depth: int = 5) -> dict:
    """Recursively resolve ``$ref`` pointers in an OpenAPI schema.

    Args:
        schema: The schema (or sub-schema) to resolve.
        full_spec: The full OpenAPI spec.
        depth: Maximum recursion depth.

    Returns:
        The resolved schema dict.
    """
    if depth <= 0 or not isinstance(schema, dict):
        return schema

    if "$ref" in schema:
        ref_path = schema["$ref"]
        # Resolve JSON pointer like "#/components/schemas/Invoice"
        if ref_path.startswith("#/"):
            parts = ref_path[2:].split("/")
            node = full_spec
            for part in parts:
                if isinstance(node, dict):
                    node = node.get(part, {})
                else:
                    return schema
            if isinstance(node, dict):
                return _resolve_refs(node, full_spec, depth - 1)
        return schema

    # Recurse into properties
    resolved = {}
    for key, value in schema.items():
        if isinstance(value, dict):
            resolved[key] = _resolve_refs(value, full_spec, depth - 1)
        elif isinstance(value, list):
            resolved[key] = [
                _resolve_refs(item, full_spec, depth - 1)
                if isinstance(item, dict) else item
                for item in value
            ]
        else:
            resolved[key] = value
    return resolved


def validate_mapping(mapping: dict) -> list[str]:
    """Validate a mapping configuration dict.

    Args:
        mapping: The mapping dict.

    Returns:
        List of validation error/warning strings.
    """
    errors: list[str] = []

    if not mapping.get("source_endpoint"):
        errors.append("Missing source_endpoint.")
    if not mapping.get("target_table"):
        errors.append("Missing target_table.")

    columns = mapping.get("columns", [])
    if not columns:
        errors.append("No columns defined.")

    has_pk = False
    for i, col in enumerate(columns):
        if not col.get("source_path"):
            errors.append(f"Column {i}: missing source_path.")
        if not col.get("target_column"):
            errors.append(f"Column {i}: missing target_column.")
        if not col.get("oracle_type"):
            errors.append(f"Column {i}: missing oracle_type.")
        if col.get("is_primary_key"):
            has_pk = True

    if not has_pk:
        errors.append("Warning: no primary key column defined.")

    return errors


def save_mapping(mappings: list[dict], app_name: str) -> Path:
    """Save mapping configurations to disk.

    Args:
        mappings: List of mapping dicts.
        app_name: The application name.

    Returns:
        Path to the saved file.
    """
    _MAPPINGS_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = app_name.lower().replace(" ", "_").replace("-", "_")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = f"{safe_name}_mapping_{timestamp}.json"
    filepath = _MAPPINGS_DIR / filename

    with open(filepath, "w", encoding="utf-8") as fh:
        json.dump(mappings, fh, indent=2)

    logger.info("Mappings saved to %s.", filepath)
    return filepath


def load_mapping(filepath: str | Path) -> list[dict]:
    """Load mapping configurations from a JSON file.

    Args:
        filepath: Path to the mapping file.

    Returns:
        List of mapping dicts.
    """
    with open(filepath, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        return [data]
    return data


def list_saved_mappings() -> list[dict]:
    """List all saved mapping files.

    Returns:
        List of dicts with ``filename``, ``path``, ``app_name``, ``created``.
    """
    _MAPPINGS_DIR.mkdir(parents=True, exist_ok=True)
    mappings: list[dict] = []
    for fp in sorted(_MAPPINGS_DIR.glob("*.json"), reverse=True):
        try:
            parts = fp.stem.rsplit("_mapping_", 1)
            app_name = parts[0] if parts else fp.stem
        except Exception:
            app_name = fp.stem
        mappings.append({
            "filename": fp.name,
            "path": str(fp),
            "app_name": app_name,
            "created": fp.stat().st_mtime,
        })
    return mappings


def delete_mapping(filename: str) -> bool:
    """Delete a saved mapping file.

    Args:
        filename: The filename to delete.

    Returns:
        True if deleted.
    """
    filepath = _MAPPINGS_DIR / filename
    if filepath.exists():
        filepath.unlink()
        logger.info("Deleted mapping: %s", filename)
        return True
    return False
