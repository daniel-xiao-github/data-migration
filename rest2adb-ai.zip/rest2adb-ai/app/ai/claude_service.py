"""Claude API integration service.

Centralised interface for all Claude/Anthropic API calls used by
restapi2adb.  Handles client lifecycle, retries, and response caching.

Authentication priority:
1. **Claude subscription (CLI)** — ``Anthropic()`` with no explicit key;
   the SDK auto-detects credentials from a locally authenticated
   ``claude`` CLI session (Pro/Max/Team/Enterprise subscription).
2. **ANTHROPIC_API_KEY environment variable** — set from the Anthropic
   console.
3. **Stored credentials** — previously saved via the UI.
"""

import hashlib
import json
import logging
import time
from typing import Any, Optional

import anthropic

from app.auth.ai_auth import (
    get_api_key,
    load_credentials,
    get_auth_source,
    AUTH_SOURCE_SUBSCRIPTION,
    AUTH_SOURCE_ENV,
)
from app.utils.config_manager import load_config

logger = logging.getLogger(__name__)

# In-memory response cache: hash(prompt) → (timestamp, response_text)
_cache: dict[str, tuple[float, str]] = {}
_CACHE_TTL = 3600  # 1 hour


def _get_client() -> anthropic.Anthropic:
    """Return an Anthropic client using the best available credentials.

    Resolution order:
    1. Claude subscription via CLI — ``Anthropic()`` with no key.
       The SDK picks up the session token from the locally authenticated
       Claude Code CLI.
    2. ``ANTHROPIC_API_KEY`` environment variable — the SDK reads it
       automatically.
    3. Stored credentials — explicit ``api_key=`` parameter.

    Raises:
        RuntimeError: If no credentials are available.
    """
    source = get_auth_source()

    if source == AUTH_SOURCE_SUBSCRIPTION:
        # Claude CLI subscription — the SDK auto-resolves credentials
        return anthropic.Anthropic()

    if source == AUTH_SOURCE_ENV:
        # Let the SDK read ANTHROPIC_API_KEY from the environment
        return anthropic.Anthropic()

    # Fallback: use the explicitly stored key
    api_key = get_api_key()
    if not api_key:
        raise RuntimeError(
            "No Claude credentials configured. Use one of these methods:\n"
            "1. Install Claude Code CLI and run 'claude' to authenticate "
            "with your subscription (recommended).\n"
            "2. Set the ANTHROPIC_API_KEY environment variable.\n"
            "3. Log in via the web UI with an API key."
        )
    return anthropic.Anthropic(api_key=api_key)


def _get_model() -> str:
    """Return the configured default model ID."""
    creds = load_credentials()
    if creds and creds.get("model"):
        return creds["model"]
    cfg = load_config()
    return cfg.get("ai", {}).get("default_model", "claude-sonnet-4-5-20250514")


def _cache_key(prompt: str, model: str) -> str:
    """Compute a cache key for a given prompt + model."""
    return hashlib.sha256(f"{model}:{prompt}".encode()).hexdigest()


def call_claude(
    prompt: str,
    system_prompt: str = "",
    model: Optional[str] = None,
    max_tokens: int = 8192,
    temperature: float = 0.1,
    use_cache: bool = True,
) -> str:
    """Send a prompt to Claude and return the text response.

    Includes caching to avoid redundant API calls for identical prompts.

    Args:
        prompt: The user message to send.
        system_prompt: Optional system message.
        model: Model ID override.  Defaults to the configured model.
        max_tokens: Maximum response tokens.
        temperature: Sampling temperature.
        use_cache: Whether to use the response cache.

    Returns:
        The assistant's text response.

    Raises:
        RuntimeError: If no credentials are configured.
        anthropic.APIError: On API failures after retries.
    """
    model = model or _get_model()
    key = _cache_key(prompt, model)

    # Check cache
    if use_cache and key in _cache:
        ts, cached_text = _cache[key]
        if time.time() - ts < _CACHE_TTL:
            logger.debug("Cache hit for prompt (model=%s).", model)
            return cached_text
        else:
            del _cache[key]

    client = _get_client()
    max_retries = 3
    backoff = 2

    messages = [{"role": "user", "content": prompt}]
    kwargs: dict[str, Any] = {
        "model": model,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": messages,
    }
    if system_prompt:
        kwargs["system"] = system_prompt

    for attempt in range(1, max_retries + 1):
        try:
            response = client.messages.create(**kwargs)
            text = response.content[0].text if response.content else ""
            # Cache the response
            if use_cache:
                _cache[key] = (time.time(), text)
            logger.info(
                "Claude call succeeded (model=%s, tokens_in=%d, tokens_out=%d).",
                model,
                response.usage.input_tokens,
                response.usage.output_tokens,
            )
            return text

        except anthropic.RateLimitError:
            wait = backoff ** attempt
            logger.warning("Rate limited; retrying in %ds (attempt %d/%d).", wait, attempt, max_retries)
            time.sleep(wait)
        except anthropic.APIStatusError as exc:
            if exc.status_code >= 500 and attempt < max_retries:
                wait = backoff ** attempt
                logger.warning("Server error %d; retrying in %ds.", exc.status_code, wait)
                time.sleep(wait)
            else:
                raise

    raise RuntimeError("Claude API call failed after all retries.")


def call_claude_json(
    prompt: str,
    system_prompt: str = "",
    model: Optional[str] = None,
    max_tokens: int = 8192,
    temperature: float = 0.1,
) -> dict | list:
    """Call Claude and parse the response as JSON.

    If the response contains markdown fences, they are stripped before
    parsing.

    Args:
        prompt: The user message.
        system_prompt: Optional system message.
        model: Model ID override.
        max_tokens: Maximum response tokens.
        temperature: Sampling temperature.

    Returns:
        The parsed JSON object (dict or list).

    Raises:
        json.JSONDecodeError: If the response is not valid JSON.
    """
    text = call_claude(prompt, system_prompt, model, max_tokens, temperature)

    # Strip markdown code fences if present
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        # Remove first and last fence lines
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines)

    return json.loads(text)


def clear_cache() -> int:
    """Clear the in-memory response cache.

    Returns:
        The number of entries cleared.
    """
    count = len(_cache)
    _cache.clear()
    logger.info("AI response cache cleared (%d entries).", count)
    return count
