"""AI-driven OpenAPI specification generator.

Uses Claude to auto-generate focused, GET-only OpenAPI 3.0 JSON specs
for any REST API application.
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional

from app.ai.claude_service import call_claude, call_claude_json

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_SPECS_DIR = _PROJECT_ROOT / "data" / "openapi_specs"

# ── Prompt Template ────────────────────────────────────────────────────

_GENERATION_PROMPT = """You are an expert API developer with deep knowledge of the {app_name} REST API.
Generate a clean, minimal OpenAPI 3.0.0 JSON specification focused EXCLUSIVELY on GET endpoints for reading and exporting data from {app_name}.

Requirements:
- Include ONLY GET endpoints (no POST/PUT/DELETE/PATCH)
- Focus on these entities: {entities}
- Use {app_name}'s official, documented endpoint paths and URL patterns
- Include the correct API base URL as the server URL
- Include standard query parameters for each endpoint:
  - Pagination parameters specific to {app_name}'s pagination pattern
  - Date filtering parameters (modified since, created since) where supported
  - Field selection parameters where supported
- Response schemas must reflect {app_name}'s actual documented response structure:
  - Correct field names, data types, and nesting
  - Include the pagination wrapper/envelope if {app_name} uses one
- Include standard {app_name} headers (API version headers, etc.)
- Set operationId to a clear, descriptive name for each endpoint
- Add a brief description for each endpoint and parameter

Output ONLY the raw JSON. No markdown code fences. No explanatory text.
Ensure the JSON is valid and parseable.

API Version: {version}"""

_CORRECTION_PROMPT = """The previously generated OpenAPI spec had these validation errors:

{errors}

Please fix the spec and output ONLY the corrected, complete, valid OpenAPI 3.0.0 JSON.
No markdown code fences. No explanatory text.

Here was the original (broken) spec:
{original_spec}"""


def generate_openapi_spec(
    app_name: str,
    entities: str = "all primary data entities",
    version: str = "latest stable",
    model: Optional[str] = None,
) -> dict:
    """Generate an OpenAPI 3.0 spec for the given REST API app using Claude.

    Args:
        app_name: Name of the REST API application (e.g. "QuickBooks Online").
        entities: Comma-separated list of entities, or "all primary data entities".
        version: API version preference.
        model: Optional Claude model override.

    Returns:
        The parsed OpenAPI spec as a dict.

    Raises:
        ValueError: If the generated spec is invalid after correction attempts.
    """
    prompt = _GENERATION_PROMPT.format(
        app_name=app_name,
        entities=entities or "all primary data entities",
        version=version or "latest stable",
    )

    logger.info("Generating OpenAPI spec for '%s' (entities=%s).", app_name, entities)

    # First attempt
    kwargs = {"model": model} if model else {}
    spec = call_claude_json(prompt, **kwargs)

    # Validate
    errors = validate_openapi_spec(spec)
    if errors:
        logger.warning("Generated spec has %d errors; sending correction prompt.", len(errors))
        correction = _CORRECTION_PROMPT.format(
            errors="\n".join(f"- {e}" for e in errors),
            original_spec=json.dumps(spec, indent=2)[:8000],
        )
        spec = call_claude_json(correction, **kwargs)

        errors = validate_openapi_spec(spec)
        if errors:
            logger.error("Spec still invalid after correction: %s", errors)
            raise ValueError(f"Generated spec invalid: {'; '.join(errors)}")

    return spec


def validate_openapi_spec(spec: dict) -> list[str]:
    """Validate an OpenAPI spec dict for basic conformance.

    Args:
        spec: The OpenAPI spec dict.

    Returns:
        List of error strings (empty if valid).
    """
    errors: list[str] = []

    if not isinstance(spec, dict):
        return ["Spec is not a JSON object."]

    # Check version
    oas_version = spec.get("openapi", "")
    if not oas_version.startswith("3."):
        errors.append(f"Expected OpenAPI 3.x, got '{oas_version}'.")

    # Check info
    if "info" not in spec:
        errors.append("Missing 'info' section.")

    # Check paths
    paths = spec.get("paths", {})
    if not paths:
        errors.append("No paths defined.")

    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method in methods:
            if method.lower() not in ("get", "parameters", "summary", "description", "servers"):
                if method.lower() in ("post", "put", "delete", "patch"):
                    errors.append(f"Non-GET method '{method}' found on {path}.")

    # Check servers
    if "servers" not in spec or not spec["servers"]:
        errors.append("No 'servers' defined.")

    return errors


def save_spec(spec: dict, app_name: str) -> Path:
    """Save a generated OpenAPI spec to disk.

    Args:
        spec: The OpenAPI spec dict.
        app_name: The application name.

    Returns:
        The path to the saved file.
    """
    _SPECS_DIR.mkdir(parents=True, exist_ok=True)
    safe_name = app_name.lower().replace(" ", "_").replace("-", "_")
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    filename = f"{safe_name}_{timestamp}.json"
    filepath = _SPECS_DIR / filename

    with open(filepath, "w", encoding="utf-8") as fh:
        json.dump(spec, fh, indent=2)

    logger.info("OpenAPI spec saved to %s.", filepath)
    return filepath


def load_spec(filepath: str | Path) -> dict:
    """Load an OpenAPI spec from a JSON file.

    Args:
        filepath: Path to the spec file.

    Returns:
        The parsed spec dict.
    """
    with open(filepath, "r", encoding="utf-8") as fh:
        return json.load(fh)


def list_saved_specs() -> list[dict]:
    """List all saved OpenAPI spec files.

    Returns:
        List of dicts with ``filename``, ``path``, ``app_name``, and
        ``created`` keys.
    """
    _SPECS_DIR.mkdir(parents=True, exist_ok=True)
    specs: list[dict] = []
    for fp in sorted(_SPECS_DIR.glob("*.json"), reverse=True):
        try:
            with open(fp, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            info = data.get("info", {})
            specs.append({
                "filename": fp.name,
                "path": str(fp),
                "app_name": info.get("title", fp.stem),
                "created": fp.stat().st_mtime,
            })
        except Exception:
            specs.append({
                "filename": fp.name,
                "path": str(fp),
                "app_name": fp.stem,
                "created": fp.stat().st_mtime,
            })
    return specs


def delete_spec(filename: str) -> bool:
    """Delete a saved OpenAPI spec file.

    Args:
        filename: The filename (not full path) to delete.

    Returns:
        True if deleted successfully.
    """
    filepath = _SPECS_DIR / filename
    if filepath.exists():
        filepath.unlink()
        logger.info("Deleted spec: %s", filename)
        return True
    return False


def get_spec_summary(spec: dict) -> dict:
    """Produce a human-readable summary of an OpenAPI spec.

    Args:
        spec: The OpenAPI spec dict.

    Returns:
        Summary dict with endpoint count, entities, etc.
    """
    paths = spec.get("paths", {})
    endpoints: list[dict] = []
    for path, methods in paths.items():
        if not isinstance(methods, dict):
            continue
        for method, details in methods.items():
            if method.lower() == "get":
                params = details.get("parameters", [])
                endpoints.append({
                    "path": path,
                    "operation_id": details.get("operationId", ""),
                    "description": details.get("summary", details.get("description", "")),
                    "param_count": len(params),
                })

    return {
        "title": spec.get("info", {}).get("title", "Unknown"),
        "version": spec.get("info", {}).get("version", ""),
        "server_url": (spec.get("servers", [{}])[0].get("url", "") if spec.get("servers") else ""),
        "endpoint_count": len(endpoints),
        "endpoints": endpoints,
    }
