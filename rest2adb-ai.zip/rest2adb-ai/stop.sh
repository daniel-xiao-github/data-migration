#!/bin/bash
# restapi2adb – Stop Script (Linux/macOS)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PID_FILE="data/.pid"
LOG_FILE="data/logs/service.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [STOP] $1" | tee -a "$LOG_FILE"
}

if [ ! -f "$PID_FILE" ]; then
    log "No PID file found. restapi2adb does not appear to be running."
    exit 0
fi

PID=$(cat "$PID_FILE")

if ! kill -0 "$PID" 2>/dev/null; then
    log "Process $PID is not running. Cleaning up PID file."
    rm -f "$PID_FILE"
    exit 0
fi

log "Stopping restapi2adb (PID: $PID)..."
kill -SIGTERM "$PID" 2>/dev/null

# Wait up to 10 seconds for graceful shutdown
for i in $(seq 1 10); do
    if ! kill -0 "$PID" 2>/dev/null; then
        rm -f "$PID_FILE"
        log "restapi2adb stopped gracefully."
        echo "restapi2adb stopped."
        exit 0
    fi
    sleep 1
done

# Force kill if still running
log "Graceful shutdown timed out. Force-killing PID $PID..."
kill -9 "$PID" 2>/dev/null
rm -f "$PID_FILE"
log "restapi2adb force-stopped."
echo "restapi2adb force-stopped."
