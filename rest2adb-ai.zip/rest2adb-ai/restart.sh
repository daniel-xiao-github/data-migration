#!/bin/bash
# restapi2adb – Restart Script (Linux/macOS)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

LOG_FILE="data/logs/service.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [RESTART] $1" | tee -a "$LOG_FILE"
}

log "Restarting restapi2adb..."

# Stop if running
bash "$SCRIPT_DIR/stop.sh"

# Brief pause
sleep 2

# Start with any passed arguments
bash "$SCRIPT_DIR/start.sh" "$@"
