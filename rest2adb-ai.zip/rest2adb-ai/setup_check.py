#!/usr/bin/env python3
"""Environment validation and dependency installer for restapi2adb.

Checks Python version, required packages, configuration files, encryption
key, and data directories.  Optionally installs missing packages with user
approval (or automatically when ``--auto-check`` is provided).
"""

import importlib.metadata
import os
import platform
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
REQUIREMENTS_FILE = PROJECT_ROOT / "requirements.txt"
CONFIG_DIR = PROJECT_ROOT / "config"
DATA_DIR = PROJECT_ROOT / "data"
SECRETS_KEY = CONFIG_DIR / ".secrets.key"
APP_CONFIG = CONFIG_DIR / "app_config.yaml"

MIN_PYTHON = (3, 10)

REQUIRED_DIRS = [
    DATA_DIR / "openapi_specs",
    DATA_DIR / "mappings",
    DATA_DIR / "logs",
    DATA_DIR / "tokens",
]


def _colour(text: str, code: int) -> str:
    """Wrap *text* in ANSI colour if stdout is a tty."""
    if sys.stdout.isatty():
        return f"\033[{code}m{text}\033[0m"
    return text


green = lambda t: _colour(t, 32)
red = lambda t: _colour(t, 31)
yellow = lambda t: _colour(t, 33)
bold = lambda t: _colour(t, 1)


# ---------------------------------------------------------------------------
# Checks
# ---------------------------------------------------------------------------

def check_python_version() -> tuple[bool, str]:
    """Verify the running Python interpreter meets the minimum version."""
    ver = sys.version_info[:2]
    ok = ver >= MIN_PYTHON
    tag = f"{ver[0]}.{ver[1]}.{sys.version_info[2]}"
    return ok, tag


def _parse_requirements() -> list[tuple[str, str]]:
    """Return a list of ``(package_name, version_spec)`` from requirements.txt."""
    pkgs: list[tuple[str, str]] = []
    if not REQUIREMENTS_FILE.exists():
        return pkgs
    for line in REQUIREMENTS_FILE.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Strip platform markers (e.g. ;platform_system=="Windows")
        line = line.split(";")[0].strip()
        for op in (">=", "==", "<=", "!=", "~="):
            if op in line:
                name, ver = line.split(op, 1)
                pkgs.append((name.strip(), f"{op}{ver.strip()}"))
                break
        else:
            pkgs.append((line, ""))
    return pkgs


def check_packages(auto_install: bool = False) -> list[tuple[str, bool, str]]:
    """Check each requirement and optionally install missing packages.

    Returns:
        List of ``(package_name, is_installed, version_or_message)`` tuples.
    """
    results: list[tuple[str, bool, str]] = []
    for name, _spec in _parse_requirements():
        # Normalise name for importlib (PEP 503)
        dist_name = name.replace("-", "_").lower()
        try:
            ver = importlib.metadata.version(name)
            results.append((name, True, ver))
        except importlib.metadata.PackageNotFoundError:
            if auto_install:
                print(f"  Installing {name}…", end=" ", flush=True)
                rc = subprocess.call(
                    [sys.executable, "-m", "pip", "install", f"{name}{_spec}"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                if rc == 0:
                    try:
                        ver = importlib.metadata.version(name)
                        results.append((name, True, ver))
                        print(green("OK"))
                    except importlib.metadata.PackageNotFoundError:
                        results.append((name, False, "install succeeded but not found"))
                        print(red("FAIL"))
                else:
                    results.append((name, False, "install failed"))
                    print(red("FAIL"))
            else:
                answer = input(
                    f"  Package '{name}' is not installed. Install it now? (Y/n): "
                ).strip().lower()
                if answer in ("", "y", "yes"):
                    rc = subprocess.call(
                        [sys.executable, "-m", "pip", "install", f"{name}{_spec}"]
                    )
                    if rc == 0:
                        try:
                            ver = importlib.metadata.version(name)
                            results.append((name, True, ver))
                        except importlib.metadata.PackageNotFoundError:
                            results.append((name, False, "install succeeded but not found"))
                    else:
                        results.append((name, False, "install failed"))
                else:
                    results.append((name, False, "skipped by user"))
    return results


def check_config() -> bool:
    """Ensure config/app_config.yaml exists; generate defaults if not."""
    if APP_CONFIG.exists():
        return True
    # Import lazily to avoid issues when deps are not yet installed
    try:
        from app.utils.config_manager import load_config
        load_config()
        return True
    except Exception:
        return False


def check_secrets_key() -> bool:
    """Ensure config/.secrets.key exists; generate if not."""
    if SECRETS_KEY.exists():
        return True
    try:
        from app.utils.secret_manager import get_or_create_key
        get_or_create_key()
        return True
    except Exception:
        return False


def check_directories() -> bool:
    """Create required data directories if they don't exist."""
    try:
        for d in REQUIRED_DIRS:
            d.mkdir(parents=True, exist_ok=True)
        return True
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Summary printer
# ---------------------------------------------------------------------------

def print_summary(
    py_ok: bool, py_ver: str,
    pkg_results: list[tuple[str, bool, str]],
    config_ok: bool, key_ok: bool, dirs_ok: bool,
) -> bool:
    """Print a formatted summary table and return overall pass/fail."""
    w_label = 20
    w_value = 24
    line = "─"

    print()
    print(f"┌{line * (w_label + w_value + 3)}┐")
    print(f"│ {'restapi2adb Environment Check':<{w_label + w_value + 2}}│")
    print(f"├{line * (w_label + 1)}┬{line * (w_value + 1)}┤")

    def row(label: str, value: str, ok: bool) -> None:
        mark = green("✓") if ok else red("✗")
        print(f"│ {label:<{w_label}}│ {value:<{w_value - 2}}{mark} │")

    row("Python Version", py_ver, py_ok)
    for name, ok, ver in pkg_results:
        row(name, ver if ok else ver, ok)
    row("Config File", "Found" if config_ok else "Missing", config_ok)
    row("Encryption Key", "Found" if key_ok else "Missing", key_ok)
    row("Data Directories", "Ready" if dirs_ok else "Error", dirs_ok)

    print(f"└{line * (w_label + 1)}┴{line * (w_value + 1)}┘")
    print()

    all_ok = py_ok and all(ok for _, ok, _ in pkg_results) and config_ok and key_ok and dirs_ok
    if all_ok:
        print(green("All checks passed. Ready to start."))
    else:
        print(red("Some checks failed. Please resolve the issues above."))
    return all_ok


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    auto = "--auto-check" in sys.argv
    print(bold("restapi2adb – Environment Check"))
    print()

    py_ok, py_ver = check_python_version()
    if not py_ok:
        print(red(f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]}+ required (found {py_ver})."))
        sys.exit(1)

    pkg_results = check_packages(auto_install=auto)
    dirs_ok = check_directories()
    config_ok = check_config()
    key_ok = check_secrets_key()

    ok = print_summary(py_ok, py_ver, pkg_results, config_ok, key_ok, dirs_ok)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
