#!/bin/bash
# restapi2adb – Status Script (Linux/macOS)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PID_FILE="data/.pid"

if [ ! -f "$PID_FILE" ]; then
    echo "restapi2adb is NOT running (no PID file)."
    exit 1
fi

PID=$(cat "$PID_FILE")

if kill -0 "$PID" 2>/dev/null; then
    echo "restapi2adb is RUNNING (PID: $PID)"
    # Show memory and CPU usage if possible
    if command -v ps &>/dev/null; then
        echo ""
        ps -p "$PID" -o pid,ppid,%cpu,%mem,etime,command 2>/dev/null
    fi
    exit 0
else
    echo "restapi2adb is NOT running (stale PID: $PID)."
    rm -f "$PID_FILE"
    exit 1
fi
